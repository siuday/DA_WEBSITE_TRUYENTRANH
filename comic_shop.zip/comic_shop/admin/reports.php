<?php
declare(strict_types=1);

/**
 * COMIC SHOP
 * File: admin/reports.php
 * Báo cáo doanh thu và hoạt động bán hàng.
 */

require_once __DIR__ . '/includes/bootstrap.php';

/* =========================================================
   1. KẾT NỐI DATABASE
========================================================= */

$reportDb = null;

$reportDbCandidates = [
    $GLOBALS['comic_shop_db'] ?? null,
    $GLOBALS['pdo'] ?? null,
    $GLOBALS['conn'] ?? null,
    $GLOBALS['mysqli'] ?? null,
    $GLOBALS['db'] ?? null,
    $pdo ?? null,
    $conn ?? null,
    $mysqli ?? null,
    $db ?? null,
];

foreach ($reportDbCandidates as $candidate) {
    if (
        $candidate instanceof PDO ||
        (class_exists('mysqli') && $candidate instanceof mysqli)
    ) {
        $reportDb = $candidate;
        break;
    }
}

$reportDbReady = $reportDb instanceof PDO ||
    (class_exists('mysqli') && $reportDb instanceof mysqli);

/* =========================================================
   2. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_report_escape')) {
    function comic_report_escape($value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_report_money')) {
    function comic_report_money($amount): string
    {
        return number_format((float)$amount, 0, ',', '.') . ' ₫';
    }
}

if (!function_exists('comic_report_query')) {
    function comic_report_query(
        $db,
        string $sql,
        array $params = []
    ): array {
        if ($db instanceof PDO) {
            $stmt = $db->prepare($sql);
            $stmt->execute($params);

            $rows = $stmt->columnCount() > 0
                ? $stmt->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $affected = $stmt->rowCount();
            $stmt->closeCursor();

            return [
                'rows' => $rows,
                'affected' => $affected,
            ];
        }

        if (class_exists('mysqli') && $db instanceof mysqli) {
            $stmt = $db->prepare($sql);

            if (!$stmt) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn database.'
                );
            }

            if ($params !== []) {
                $types = '';
                $bindParams = [];

                foreach ($params as $param) {
                    if (is_int($param) || is_bool($param)) {
                        $types .= 'i';
                    } elseif (is_float($param)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }
                }

                $bindParams[] = $types;

                foreach ($params as &$param) {
                    $bindParams[] = &$param;
                }

                unset($param);

                if (!call_user_func_array(
                    [$stmt, 'bind_param'],
                    $bindParams
                )) {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không thể gắn tham số truy vấn.'
                    );
                }
            }

            if (!$stmt->execute()) {
                $error = $stmt->error;
                $stmt->close();

                throw new RuntimeException(
                    $error ?: 'Truy vấn database thất bại.'
                );
            }

            $rows = [];

            if ($stmt->field_count > 0) {
                $result = $stmt->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không đọc được kết quả truy vấn.'
                    );
                }
            }

            $affected = $stmt->affected_rows;
            $stmt->close();

            return [
                'rows' => $rows,
                'affected' => $affected,
            ];
        }

        throw new RuntimeException(
            'Không tìm thấy kết nối PDO hoặc MySQLi.'
        );
    }
}

if (!function_exists('comic_report_status_label')) {
    function comic_report_status_label(string $status): string
    {
        $labels = [
            'pending' => 'Chờ xử lý',
            'processing' => 'Đang xử lý',
            'shipping' => 'Đang giao',
            'completed' => 'Hoàn tất',
            'cancelled' => 'Đã hủy',
        ];

        return $labels[$status] ?? $status;
    }
}

/* =========================================================
   3. KHOẢNG THỜI GIAN BÁO CÁO
========================================================= */

$today = date('Y-m-d');
$firstDayOfMonth = date('Y-m-01');

$startDate = isset($_GET['start_date'])
    && is_string($_GET['start_date'])
    ? trim($_GET['start_date'])
    : $firstDayOfMonth;

$endDate = isset($_GET['end_date'])
    && is_string($_GET['end_date'])
    ? trim($_GET['end_date'])
    : $today;

$startObject = DateTimeImmutable::createFromFormat(
    '!Y-m-d',
    $startDate
);

$endObject = DateTimeImmutable::createFromFormat(
    '!Y-m-d',
    $endDate
);

if (
    !$startObject ||
    $startObject->format('Y-m-d') !== $startDate
) {
    $startDate = $firstDayOfMonth;
    $startObject = DateTimeImmutable::createFromFormat(
        '!Y-m-d',
        $startDate
    );
}

if (
    !$endObject ||
    $endObject->format('Y-m-d') !== $endDate
) {
    $endDate = $today;
    $endObject = DateTimeImmutable::createFromFormat(
        '!Y-m-d',
        $endDate
    );
}

if ($startDate > $endDate) {
    $temp = $startDate;
    $startDate = $endDate;
    $endDate = $temp;
}

$startDateTime = $startDate . ' 00:00:00';
$endDateTime = $endDate . ' 23:59:59';

$reportParams = [$startDateTime, $endDateTime];

/* =========================================================
   4. KHỞI TẠO BÁO CÁO
========================================================= */

$reportErrors = [];

$overview = [
    'total_orders' => 0,
    'completed_orders' => 0,
    'revenue' => 0,
    'average_order' => 0,
    'items_sold' => 0,
    'customer_count' => 0,
];

$statusRows = [];
$dailyRows = [];
$topComicRows = [];
$recentOrderRows = [];
$bestRevenueDay = 0;
$bestOrderDay = 0;

/* =========================================================
   5. LẤY SỐ LIỆU TỔNG QUAN
========================================================= */

if ($reportDbReady) {
    try {
        $overviewRows = comic_report_query(
            $reportDb,
            'SELECT
                COUNT(*) AS total_orders,
                COALESCE(SUM(
                    CASE WHEN status = ? THEN 1 ELSE 0 END
                ), 0) AS completed_orders,
                COALESCE(SUM(
                    CASE
                        WHEN status = ? THEN total_amount
                        ELSE 0
                    END
                ), 0) AS revenue
             FROM orders
             WHERE created_at BETWEEN ? AND ?',
            array_merge(
                ['completed', 'completed'],
                $reportParams
            )
        )['rows'];

        if ($overviewRows) {
            $overview['total_orders'] =
                (int)$overviewRows[0]['total_orders'];

            $overview['completed_orders'] =
                (int)$overviewRows[0]['completed_orders'];

            $overview['revenue'] =
                (float)$overviewRows[0]['revenue'];
        }

        $overview['average_order'] =
            $overview['completed_orders'] > 0
                ? $overview['revenue'] / $overview['completed_orders']
                : 0;

        $itemsRows = comic_report_query(
            $reportDb,
            'SELECT COALESCE(SUM(oi.quantity), 0) AS items_sold
             FROM order_items oi
             INNER JOIN orders o ON o.id = oi.order_id
             WHERE o.created_at BETWEEN ? AND ?
               AND o.status <> ?',
            array_merge($reportParams, ['cancelled'])
        )['rows'];

        $overview['items_sold'] = (int)(
            $itemsRows[0]['items_sold'] ?? 0
        );

        $customerRows = comic_report_query(
            $reportDb,
            "SELECT COUNT(DISTINCT user_id) AS customer_count
             FROM orders
             WHERE created_at BETWEEN ? AND ?
               AND user_id IS NOT NULL
               AND status <> ?",
            array_merge($reportParams, ['cancelled'])
        )['rows'];

        $overview['customer_count'] = (int)(
            $customerRows[0]['customer_count'] ?? 0
        );

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Reports] ' . $exception->getMessage()
        );

        $reportErrors[] =
            'Không tải được số liệu tổng quan. Hãy kiểm tra kết nối database.';
    }
}

/* =========================================================
   6. THỐNG KÊ TRẠNG THÁI ĐƠN HÀNG
========================================================= */

if ($reportDbReady) {
    try {
        $statusRows = comic_report_query(
            $reportDb,
            'SELECT status, COUNT(*) AS total
             FROM orders
             WHERE created_at BETWEEN ? AND ?
             GROUP BY status
             ORDER BY total DESC',
            $reportParams
        )['rows'];

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Reports] ' . $exception->getMessage()
        );

        $reportErrors[] =
            'Không tải được thống kê trạng thái đơn hàng.';
    }
}

/* =========================================================
   7. DOANH THU THEO NGÀY
========================================================= */

if ($reportDbReady) {
    try {
        $dailyRows = comic_report_query(
            $reportDb,
            "SELECT
                DATE(created_at) AS report_day,
                COUNT(*) AS order_count,
                COALESCE(SUM(
                    CASE
                        WHEN status = 'completed' THEN total_amount
                        ELSE 0
                    END
                ), 0) AS revenue
             FROM orders
             WHERE created_at BETWEEN ? AND ?
             GROUP BY DATE(created_at)
             ORDER BY report_day ASC",
            $reportParams
        )['rows'];

        foreach ($dailyRows as $daily) {
            $bestRevenueDay = max(
                $bestRevenueDay,
                (float)$daily['revenue']
            );

            $bestOrderDay = max(
                $bestOrderDay,
                (int)$daily['order_count']
            );
        }

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Reports] ' . $exception->getMessage()
        );

        $reportErrors[] =
            'Không tải được báo cáo doanh thu theo ngày.';
    }
}

/* =========================================================
   8. TRUYỆN BÁN CHẠY
========================================================= */

if ($reportDbReady) {
    try {
        $topComicRows = comic_report_query(
            $reportDb,
            'SELECT
                oi.comic_id,
                oi.comic_title,
                COALESCE(SUM(oi.quantity), 0) AS quantity_sold,
                COALESCE(SUM(oi.total), 0) AS sales_amount
             FROM order_items oi
             INNER JOIN orders o ON o.id = oi.order_id
             WHERE o.created_at BETWEEN ? AND ?
               AND o.status <> ?
             GROUP BY oi.comic_id, oi.comic_title
             ORDER BY quantity_sold DESC, sales_amount DESC
             LIMIT 8',
            array_merge($reportParams, ['cancelled'])
        )['rows'];

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Reports] ' . $exception->getMessage()
        );

        $reportErrors[] =
            'Không tải được danh sách truyện bán chạy.';
    }
}

/* =========================================================
   9. ĐƠN HÀNG GẦN ĐÂY
========================================================= */

if ($reportDbReady) {
    try {
        $recentOrderRows = comic_report_query(
            $reportDb,
            'SELECT
                id,
                order_code,
                full_name,
                total_amount,
                payment_method,
                payment_status,
                status,
                created_at
             FROM orders
             WHERE created_at BETWEEN ? AND ?
             ORDER BY created_at DESC, id DESC
             LIMIT 8',
            $reportParams
        )['rows'];

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Reports] ' . $exception->getMessage()
        );

        $reportErrors[] =
            'Không tải được danh sách đơn hàng gần đây.';
    }
}

/* =========================================================
   10. HIỂN THỊ GIAO DIỆN
========================================================= */

$pageTitle = 'Báo cáo thống kê';
$pageDescription = 'Theo dõi doanh thu và tình hình bán hàng.';
$activeMenu = 'reports';

require_once __DIR__ . '/includes/header.php';

$statusColors = [
    'pending' => '#e6a23c',
    'processing' => '#4586ec',
    'shipping' => '#8e63d9',
    'completed' => '#198754',
    'cancelled' => '#d94841',
];

$totalStatusOrders = 0;

foreach ($statusRows as $statusRow) {
    $totalStatusOrders += (int)$statusRow['total'];
}
?>

<style>
.reports-admin{color:#f2f2f2}
.reports-admin .ra-alert{margin-bottom:17px;padding:12px 15px;border:1px solid rgba(255,107,96,.4);border-left:4px solid #ff6b60;background:rgba(255,107,96,.14);color:#ff8f86;font-size:12px;line-height:1.7}
.reports-admin .ra-filter{display:flex;align-items:flex-end;flex-wrap:wrap;gap:12px;margin-bottom:22px;padding:16px;border:1px solid #3d3d44;border-radius:11px;background:#232327}
.reports-admin .ra-field{display:flex;flex-direction:column;gap:6px}
.reports-admin .ra-field label{color:#a9a9b2;font-size:11px;font-weight:800}
.reports-admin .ra-field input{min-height:38px;padding:7px 10px;border:1px solid #3d3d44;border-radius:12px;background:#232327;color:#f2f2f2;font:inherit;font-size:12px}
.reports-admin .ra-btn{display:inline-flex;align-items:center;justify-content:center;min-height:37px;padding:8px 12px;border:1px solid transparent;border-radius:999px;background:#f2f2f2;color:#111111;font-size:12px;font-weight:800;text-decoration:none;cursor:pointer}
.reports-admin .ra-btn:hover{background:#ffffff;color:#111111}
.reports-admin .ra-btn.secondary{border-color:#3d3d44;background:#232327;color:#d4d4da}
.reports-admin .ra-btn.secondary:hover{border-color:#f2f2f2;color:#f2f2f2}
.reports-admin .ra-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-bottom:21px}
.reports-admin .ra-stat{position:relative;overflow:hidden;padding:18px;border:1px solid #3d3d44;border-radius:20px;background:#232327;box-shadow:0 4px 18px rgba(0,0,0,0.18)}
.reports-admin .ra-stat-label{display:block;color:#a9a9b2;font-size:11px;font-weight:700}
.reports-admin .ra-stat-value{display:block;margin-top:10px;font-size:23px;font-weight:850;line-height:1.3;overflow-wrap:anywhere}
.reports-admin .ra-stat-note{display:block;margin-top:6px;color:#a9a9b2;font-size:10px;line-height:1.5}
.reports-admin .ra-layout{display:grid;grid-template-columns:minmax(0,1.55fr) minmax(270px,1fr);gap:17px;margin-bottom:20px}
.reports-admin .ra-panel{min-width:0;overflow:hidden;border:1px solid #3d3d44;border-radius:20px;background:#232327;box-shadow:0 4px 18px rgba(0,0,0,0.18)}
.reports-admin .ra-panel-head{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:17px 19px;border-bottom:1px solid #3d3d44}
.reports-admin .ra-panel-head h2{margin:0;font-size:14px;font-weight:850}
.reports-admin .ra-muted{color:#a9a9b2;font-size:11px;line-height:1.7}
.reports-admin .ra-chart{padding:18px}
.reports-admin .ra-day{display:grid;grid-template-columns:74px minmax(40px,1fr) minmax(65px,auto);align-items:center;gap:9px;margin-bottom:13px}
.reports-admin .ra-day:last-child{margin-bottom:0}
.reports-admin .ra-day-label{color:#a9a9b2;font-size:10px}
.reports-admin .ra-bar-bg{height:10px;overflow:hidden;border-radius:20px;background:#36363c}
.reports-admin .ra-bar{height:100%;min-width:0;border-radius:20px;background:#f2f2f2}
.reports-admin .ra-day-value{text-align:right;color:#d4d4da;font-size:10px;font-weight:800;white-space:nowrap}
.reports-admin .ra-status-list{padding:18px}
.reports-admin .ra-status-row{margin-bottom:18px}
.reports-admin .ra-status-row:last-child{margin-bottom:0}
.reports-admin .ra-status-top{display:flex;justify-content:space-between;gap:12px;margin-bottom:7px;font-size:11px}
.reports-admin .ra-status-name{font-weight:750}
.reports-admin .ra-status-num{color:#a9a9b2}
.reports-admin .ra-status-track{height:8px;overflow:hidden;border-radius:20px;background:#36363c}
.reports-admin .ra-status-fill{height:100%;border-radius:20px}
.reports-admin .ra-table-wrap{width:100%;overflow-x:auto}
.reports-admin table{width:100%;min-width:620px;border-collapse:collapse}
.reports-admin th{padding:12px 14px;background:#2c2c31;color:#a9a9b2;text-align:left;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.04em;white-space:nowrap}
.reports-admin td{padding:13px 14px;border-top:1px solid #3d3d44;vertical-align:middle;font-size:12px}
.reports-admin tbody tr:hover{background:#2c2c31}
.reports-admin .ra-product-title{display:block;color:#f2f2f2;font-size:12px;font-weight:800;line-height:1.5}
.reports-admin .ra-product-id{display:block;margin-top:4px;color:#a9a9b2;font-size:10px}
.reports-admin .ra-order-code{color:#303743;font-size:12px;font-weight:850}
.reports-admin .ra-order-customer{display:block;margin-top:5px;color:#a9a9b2;font-size:11px}
.reports-admin .ra-status-badge{display:inline-flex;padding:5px 8px;border-radius:5px;font-size:10px;font-weight:800;white-space:nowrap}
.reports-admin .ra-empty{padding:34px 18px;text-align:center;color:#a9a9b2;font-size:12px}
.reports-admin .ra-section-gap{margin-bottom:20px}
@media(max-width:1050px){.reports-admin .ra-stats{grid-template-columns:repeat(2,minmax(0,1fr))}.reports-admin .ra-layout{grid-template-columns:1fr}}
@media(max-width:600px){.reports-admin .ra-stats{grid-template-columns:1fr}.reports-admin .ra-filter{align-items:stretch}.reports-admin .ra-field,.reports-admin .ra-field input{width:100%;box-sizing:border-box}.reports-admin .ra-day{grid-template-columns:62px minmax(30px,1fr) auto;gap:7px}}
</style>

<div class="reports-admin">

    <?php if (!$reportDbReady): ?>
        <div class="ra-alert" role="alert">
            Không tìm thấy kết nối database.
            Hãy kiểm tra <strong>config/db.php</strong> và
            <strong>admin/includes/bootstrap.php</strong>.
        </div>
    <?php endif; ?>

    <?php if ($reportErrors): ?>
        <div class="ra-alert" role="alert">
            <strong>Một số báo cáo chưa tải được:</strong>
            <ul style="margin:7px 0 0;padding-left:19px">
                <?php foreach (array_unique($reportErrors) as $reportError): ?>
                    <li><?= comic_report_escape($reportError) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form class="ra-filter" method="get" action="reports.php">
        <div class="ra-field">
            <label for="start-date">Từ ngày</label>
            <input
                type="date"
                id="start-date"
                name="start_date"
                value="<?= comic_report_escape($startDate) ?>"
                max="<?= comic_report_escape($endDate) ?>"
                required
            >
        </div>

        <div class="ra-field">
            <label for="end-date">Đến ngày</label>
            <input
                type="date"
                id="end-date"
                name="end_date"
                value="<?= comic_report_escape($endDate) ?>"
                min="<?= comic_report_escape($startDate) ?>"
                max="<?= comic_report_escape($today) ?>"
                required
            >
        </div>

        <button type="submit" class="ra-btn">Lọc báo cáo</button>

        <a class="ra-btn secondary" href="reports.php">Tháng hiện tại</a>
    </form>

    <section class="ra-stats" aria-label="Tổng quan bán hàng">
        <div class="ra-stat">
            <span class="ra-stat-label">Doanh thu đơn hoàn tất</span>
            <strong class="ra-stat-value" style="color:#f2f2f2">
                <?= comic_report_money($overview['revenue']) ?>
            </strong>
            <span class="ra-stat-note">
                Chỉ tính đơn có trạng thái hoàn tất
            </span>
        </div>

        <div class="ra-stat">
            <span class="ra-stat-label">Tổng đơn hàng</span>
            <strong class="ra-stat-value">
                <?= number_format($overview['total_orders']) ?>
            </strong>
            <span class="ra-stat-note">
                Bao gồm mọi trạng thái đơn hàng trong khoảng ngày đã chọn
            </span>
        </div>

        <div class="ra-stat">
            <span class="ra-stat-label">Giá trị đơn hoàn tất trung bình</span>
            <strong class="ra-stat-value">
                <?= comic_report_money($overview['average_order']) ?>
            </strong>
            <span class="ra-stat-note">
                Doanh thu đơn hoàn tất chia số đơn hoàn tất
            </span>
        </div>

        <div class="ra-stat">
            <span class="ra-stat-label">Số lượng truyện đã bán</span>
            <strong class="ra-stat-value">
                <?= number_format($overview['items_sold']) ?>
            </strong>
            <span class="ra-stat-note">
                Loại trừ các đơn hàng đã hủy
            </span>
        </div>
    </section>

    <div class="ra-layout">

        <section class="ra-panel">
            <div class="ra-panel-head">
                <h2>Doanh thu theo ngày</h2>
                <span class="ra-muted">
                    <?= comic_report_escape(date('d/m/Y', strtotime($startDate))) ?>
                    – <?= comic_report_escape(date('d/m/Y', strtotime($endDate))) ?>
                </span>
            </div>

            <div class="ra-chart">
                <?php if (!$dailyRows): ?>

                    <div class="ra-empty">
                        Chưa có đơn hàng trong khoảng thời gian này.
                    </div>

                <?php else: ?>

                    <?php foreach ($dailyRows as $daily): ?>
                        <?php
                        $revenue = (float)$daily['revenue'];

                        $width = $bestRevenueDay > 0
                            ? ($revenue / $bestRevenueDay) * 100
                            : 0;

                        $dayText = date(
                            'd/m',
                            strtotime((string)$daily['report_day'])
                        );
                        ?>

                        <div class="ra-day">
                            <span class="ra-day-label">
                                <?= comic_report_escape($dayText) ?>
                            </span>

                            <div
                                class="ra-bar-bg"
                                title="<?= comic_report_escape(comic_report_money($revenue)) ?>"
                            >
                                <div
                                    class="ra-bar"
                                    style="width:<?= number_format($width, 2, '.', '') ?>%"
                                ></div>
                            </div>

                            <span class="ra-day-value">
                                <?= comic_report_money($revenue) ?>
                            </span>
                        </div>
                    <?php endforeach; ?>

                    <p class="ra-muted" style="margin:17px 0 0">
                        Biểu đồ hiển thị doanh thu của đơn hoàn tất.
                        Ngày không có đơn hàng sẽ không xuất hiện trong danh sách.
                    </p>

                <?php endif; ?>
            </div>
        </section>

        <section class="ra-panel">
            <div class="ra-panel-head">
                <h2>Trạng thái đơn hàng</h2>
                <span class="ra-muted">
                    <?= number_format($totalStatusOrders) ?> đơn
                </span>
            </div>

            <div class="ra-status-list">
                <?php if (!$statusRows): ?>

                    <div class="ra-empty">
                        Chưa có dữ liệu trạng thái.
                    </div>

                <?php else: ?>

                    <?php foreach ($statusRows as $statusRow): ?>
                        <?php
                        $status = (string)$statusRow['status'];
                        $count = (int)$statusRow['total'];

                        $percent = $totalStatusOrders > 0
                            ? ($count / $totalStatusOrders) * 100
                            : 0;

                        $color = $statusColors[$status] ?? '#78818f';
                        ?>

                        <div class="ra-status-row">
                            <div class="ra-status-top">
                                <span class="ra-status-name">
                                    <?= comic_report_escape(
                                        comic_report_status_label($status)
                                    ) ?>
                                </span>

                                <span class="ra-status-num">
                                    <?= number_format($count) ?> đơn
                                    · <?= number_format($percent, 1) ?>%
                                </span>
                            </div>

                            <div class="ra-status-track">
                                <div
                                    class="ra-status-fill"
                                    style="width:<?= number_format($percent, 2, '.', '') ?>%;background:<?= comic_report_escape($color) ?>"
                                ></div>
                            </div>
                        </div>
                    <?php endforeach; ?>

                <?php endif; ?>

                <div style="margin-top:22px;padding-top:15px;border-top:1px solid #3d3d44">
                    <span class="ra-muted">Khách hàng có tài khoản đặt đơn trong kỳ</span>

                    <strong style="display:block;margin-top:6px;font-size:22px;font-weight:850">
                        <?= number_format($overview['customer_count']) ?>
                    </strong>
                </div>
            </div>
        </section>

    </div>

    <section class="ra-panel ra-section-gap">
        <div class="ra-panel-head">
            <h2>Truyện bán chạy</h2>
            <span class="ra-muted">Top 8 theo số lượng bán</span>
        </div>

        <?php if (!$topComicRows): ?>

            <div class="ra-empty">
                Chưa có dữ liệu bán hàng trong khoảng thời gian đã chọn.
            </div>

        <?php else: ?>

            <div class="ra-table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>STT</th>
                            <th>Tên truyện</th>
                            <th>Số lượng bán</th>
                            <th>Thành tiền</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($topComicRows as $index => $comic): ?>
                            <tr>
                                <td>
                                    <?= $index + 1 ?>
                                </td>

                                <td>
                                    <span class="ra-product-title">
                                        <?= comic_report_escape($comic['comic_title']) ?>
                                    </span>

                                    <span class="ra-product-id">
                                        <?= $comic['comic_id'] !== null
                                            ? 'Mã truyện #' . (int)$comic['comic_id']
                                            : 'Truyện không còn liên kết sản phẩm' ?>
                                    </span>
                                </td>

                                <td>
                                    <strong>
                                        <?= number_format((int)$comic['quantity_sold']) ?>
                                    </strong>
                                </td>

                                <td>
                                    <strong>
                                        <?= comic_report_money($comic['sales_amount']) ?>
                                    </strong>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php endif; ?>
    </section>

    <section class="ra-panel ra-section-gap">
        <div class="ra-panel-head">
            <h2>Đơn hàng gần đây</h2>
            <span class="ra-muted">Tối đa 8 đơn trong kỳ báo cáo</span>
        </div>

        <?php if (!$recentOrderRows): ?>

            <div class="ra-empty">
                Không có đơn hàng trong khoảng thời gian này.
            </div>

        <?php else: ?>

            <div class="ra-table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Mã đơn hàng</th>
                            <th>Khách hàng</th>
                            <th>Thanh toán</th>
                            <th>Tổng tiền</th>
                            <th>Trạng thái</th>
                            <th>Ngày đặt</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($recentOrderRows as $order): ?>
                            <?php
                            $status = (string)$order['status'];
                            $statusColor = $statusColors[$status] ?? '#78818f';

                            $paymentLabels = [
                                'cod' => 'COD',
                                'banking' => 'Chuyển khoản',
                            ];

                            $paymentStatusLabels = [
                                'pending' => 'Chờ thanh toán',
                                'completed' => 'Đã thanh toán',
                                'failed' => 'Thanh toán lỗi',
                            ];
                            ?>

                            <tr>
                                <td>
                                    <span class="ra-order-code">
                                        <?= comic_report_escape($order['order_code']) ?>
                                    </span>
                                </td>

                                <td>
                                    <?= comic_report_escape($order['full_name']) ?>
                                </td>

                                <td>
                                    <span style="display:block;font-weight:750">
                                        <?= comic_report_escape(
                                            $paymentLabels[$order['payment_method']]
                                            ?? $order['payment_method']
                                        ) ?>
                                    </span>

                                    <span class="ra-muted">
                                        <?= comic_report_escape(
                                            $paymentStatusLabels[$order['payment_status']]
                                            ?? $order['payment_status']
                                        ) ?>
                                    </span>
                                </td>

                                <td>
                                    <strong>
                                        <?= comic_report_money($order['total_amount']) ?>
                                    </strong>
                                </td>

                                <td>
                                    <span
                                        class="ra-status-badge"
                                        style="background:<?= comic_report_escape($statusColor) ?>18;color:<?= comic_report_escape($statusColor) ?>"
                                    >
                                        <?= comic_report_escape(
                                            comic_report_status_label($status)
                                        ) ?>
                                    </span>
                                </td>

                                <td>
                                    <?= comic_report_escape(
                                        date(
                                            'd/m/Y H:i',
                                            strtotime((string)$order['created_at'])
                                        )
                                    ) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php endif; ?>
    </section>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
