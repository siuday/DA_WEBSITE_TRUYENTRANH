<?php
declare(strict_types=1);

/**
 * Comic Shop - Admin Authors
 * File: admin/authors.php
 *
 * Chức năng:
 * - Xem và tìm kiếm tác giả.
 * - Thêm và chỉnh sửa tác giả.
 * - Hiển thị số truyện và bộ truyện của mỗi tác giả.
 * - Chỉ cho xóa tác giả chưa được sử dụng.
 *
 * Cấu trúc authors:
 * id, name, slug, bio, avatar.
 */

$pageTitle = 'Quản lý tác giả';
$pageDescription = 'Quản lý thông tin và tác phẩm của các tác giả.';
$activeMenu = 'authors';

require_once __DIR__ . '/includes/bootstrap.php';

if (
    !function_exists('comic_admin_media_url') &&
    is_file(__DIR__ . '/includes/media.php')
) {
    require_once __DIR__ . '/includes/media.php';
}

/* Dự phòng nếu thiếu includes/media.php: chỉ trả về đường dẫn ảnh. */
if (!function_exists('comic_admin_media_url')) {
    function comic_admin_media_url(
        ?string $path,
        string $label = '',
        string $kind = 'cover'
    ): string {
        $path = trim(str_replace('\\', '/', (string) $path));

        if ($path === '' || preg_match('~^(https?:)?//|^data:~i', $path)) {
            return $path;
        }

        return '../' . ltrim($path, '/');
    }
}

$database = $GLOBALS['comic_shop_db'] ?? null;

$dbReady = $database instanceof PDO ||
    (class_exists('mysqli') && $database instanceof mysqli);

/* =========================================================
   1. DATABASE HELPER: PDO VÀ MYSQLI
========================================================= */

if (!function_exists('comic_admin_authors_query')) {
    function comic_admin_authors_query(
        $database,
        string $sql,
        array $params = []
    ): array {
        if ($database instanceof PDO) {
            $stmt = $database->prepare($sql);
            $stmt->execute($params);

            $rows = $stmt->columnCount() > 0
                ? $stmt->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $affected = $stmt->rowCount();
            $insertId = $database->lastInsertId();

            $stmt->closeCursor();

            return [
                'rows' => $rows,
                'affected' => $affected,
                'insert_id' => $insertId,
            ];
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            $stmt = $database->prepare($sql);

            if (!$stmt) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn MySQL.'
                );
            }

            if ($params !== []) {
                $types = '';

                foreach ($params as $param) {
                    if (is_int($param) || is_bool($param)) {
                        $types .= 'i';
                    } elseif (is_float($param)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }
                }

                $bindArgs = [$types];

                foreach ($params as $key => &$param) {
                    $bindArgs[] = &$param;
                }

                unset($param);

                if (
                    !call_user_func_array(
                        [$stmt, 'bind_param'],
                        $bindArgs
                    )
                ) {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không thể gắn tham số truy vấn MySQL.'
                    );
                }
            }

            if (!$stmt->execute()) {
                $message = $stmt->error
                    ?: 'Truy vấn MySQL thất bại.';

                $stmt->close();

                throw new RuntimeException($message);
            }

            $rows = [];

            if ($stmt->field_count > 0) {
                $result = $stmt->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không đọc được kết quả truy vấn MySQL.'
                    );
                }
            }

            $affected = $stmt->affected_rows;
            $insertId = $stmt->insert_id;

            $stmt->close();

            return [
                'rows' => $rows,
                'affected' => $affected,
                'insert_id' => $insertId,
            ];
        }

        throw new RuntimeException(
            'Không có kết nối PDO/MySQLi hợp lệ.'
        );
    }
}

/* =========================================================
   2. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_admin_authors_escape')) {
    function comic_admin_authors_escape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_admin_authors_slug')) {
    function comic_admin_authors_slug(string $value): string
    {
        $value = str_replace(
            ['Đ', 'đ'],
            ['D', 'd'],
            trim($value)
        );

        if (function_exists('iconv')) {
            $converted = @iconv(
                'UTF-8',
                'ASCII//TRANSLIT//IGNORE',
                $value
            );

            if ($converted !== false) {
                $value = $converted;
            }
        }

        $value = strtolower($value);

        $value = preg_replace(
            '/[^a-z0-9]+/',
            '-',
            $value
        ) ?? '';

        return trim($value, '-');
    }
}

if (!function_exists('comic_admin_authors_avatar_url')) {
    function comic_admin_authors_avatar_url(string $path, string $label = ''): string
    {
        return comic_admin_media_url($path, $label, 'avatar');
    }
}

if (!function_exists('comic_admin_authors_redirect')) {
    function comic_admin_authors_redirect(): void
    {
        header('Location: authors.php', true, 303);
        exit;
    }
}

if (!function_exists('comic_admin_authors_set_flash')) {
    function comic_admin_authors_set_flash(
        string $type,
        string $message
    ): void {
        $_SESSION['comic_authors_flash'] = [
            'type' => $type,
            'message' => $message,
        ];
    }
}

/* =========================================================
   3. KHỞI TẠO TRẠNG THÁI
========================================================= */

$flash = $_SESSION['comic_authors_flash'] ?? null;
unset($_SESSION['comic_authors_flash']);

$errors = [];

$action = isset($_GET['action']) && is_string($_GET['action'])
    ? $_GET['action']
    : 'list';

if (!in_array($action, ['list', 'create', 'edit'], true)) {
    $action = 'list';
}

$editId = max(0, (int) ($_GET['id'] ?? 0));

$formData = [
    'name' => '',
    'slug' => '',
    'bio' => '',
    'avatar' => '',
];

$hasSubmittedForm = false;

/* =========================================================
   4. XỬ LÝ FORM POST
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $postedToken =
        isset($_POST['csrf_token']) &&
        is_string($_POST['csrf_token'])
            ? $_POST['csrf_token']
            : '';

    if (
        !function_exists('comic_admin_csrf_valid') ||
        !comic_admin_csrf_valid($postedToken)
    ) {
        comic_admin_authors_set_flash(
            'error',
            'Phiên làm việc đã hết hạn. Vui lòng thử lại.'
        );

        comic_admin_authors_redirect();
    }

    $postAction =
        isset($_POST['action']) &&
        is_string($_POST['action'])
            ? $_POST['action']
            : '';

    if (!$dbReady) {
        $errors[] =
            'Chưa kết nối được cơ sở dữ liệu. Kiểm tra config/db.php.';
    } elseif ($postAction === 'delete') {

        /*
         * Chỉ xóa tác giả khi không còn truyện hoặc bộ truyện
         * nào tham chiếu đến tác giả đó.
         */

        $id = (int) ($_POST['id'] ?? 0);

        if ($id < 1) {
            comic_admin_authors_set_flash(
                'error',
                'ID tác giả không hợp lệ.'
            );

            comic_admin_authors_redirect();
        }

        try {
            $authorRows = comic_admin_authors_query(
                $database,
                'SELECT id, name
                 FROM authors
                 WHERE id = ?
                 LIMIT 1',
                [$id]
            )['rows'];

            if (!$authorRows) {
                comic_admin_authors_set_flash(
                    'error',
                    'Không tìm thấy tác giả cần xóa.'
                );

                comic_admin_authors_redirect();
            }

            $comicCount = (int) (
                comic_admin_authors_query(
                    $database,
                    'SELECT COUNT(*) AS total
                     FROM comics
                     WHERE author_id = ?',
                    [$id]
                )['rows'][0]['total'] ?? 0
            );

            $seriesCount = (int) (
                comic_admin_authors_query(
                    $database,
                    'SELECT COUNT(*) AS total
                     FROM series
                     WHERE author_id = ?',
                    [$id]
                )['rows'][0]['total'] ?? 0
            );

            if ($comicCount > 0 || $seriesCount > 0) {
                comic_admin_authors_set_flash(
                    'error',
                    'Không thể xóa tác giả này vì đang liên kết với ' .
                    $comicCount . ' truyện và ' .
                    $seriesCount . ' bộ truyện. ' .
                    'Hãy chuyển dữ liệu liên quan trước.'
                );

                comic_admin_authors_redirect();
            }

            comic_admin_authors_query(
                $database,
                'DELETE FROM authors WHERE id = ?',
                [$id]
            );

            comic_admin_authors_set_flash(
                'success',
                'Đã xóa tác giả thành công.'
            );

            $_SESSION['comic_admin_csrf'] =
                bin2hex(random_bytes(32));

        } catch (Throwable $exception) {
            error_log(
                '[Comic Shop Authors] ' .
                $exception->getMessage()
            );

            comic_admin_authors_set_flash(
                'error',
                'Không thể xóa tác giả. Kiểm tra các dữ liệu liên quan.'
            );
        }

        comic_admin_authors_redirect();

    } elseif ($postAction === 'save') {

        $hasSubmittedForm = true;

        $mode =
            isset($_POST['form_mode']) &&
            $_POST['form_mode'] === 'edit'
                ? 'edit'
                : 'create';

        $action = $mode;
        $editId = (int) ($_POST['id'] ?? 0);

        $formData = [
            'name' => trim((string) ($_POST['name'] ?? '')),
            'slug' => trim((string) ($_POST['slug'] ?? '')),
            'bio' => trim((string) ($_POST['bio'] ?? '')),
            'avatar' => trim((string) ($_POST['avatar'] ?? '')),
        ];

        $name = $formData['name'];

        $slug = $formData['slug'] !== ''
            ? comic_admin_authors_slug($formData['slug'])
            : comic_admin_authors_slug($name);

        $nameLength = function_exists('mb_strlen')
            ? mb_strlen($name, 'UTF-8')
            : strlen($name);

        if ($name === '' || $nameLength > 120) {
            $errors[] =
                'Tên tác giả là bắt buộc và không được vượt quá 120 ký tự.';
        }

        if ($slug === '' || strlen($slug) > 140) {
            $errors[] =
                'Slug không hợp lệ hoặc vượt quá 140 ký tự.';
        }

        if (strlen($formData['avatar']) > 255) {
            $errors[] =
                'Đường dẫn ảnh đại diện không được vượt quá 255 ký tự.';
        }

        if (!$errors) {
            try {
                $slugSql = 'SELECT id FROM authors WHERE slug = ?';
                $slugParams = [$slug];

                if ($mode === 'edit') {
                    if ($editId < 1) {
                        $errors[] =
                            'ID tác giả cần chỉnh sửa không hợp lệ.';
                    } else {
                        $slugSql .= ' AND id <> ?';
                        $slugParams[] = $editId;
                    }
                }

                $slugSql .= ' LIMIT 1';

                if (
                    !$errors &&
                    comic_admin_authors_query(
                        $database,
                        $slugSql,
                        $slugParams
                    )['rows']
                ) {
                    $errors[] =
                        'Slug đã được sử dụng. Vui lòng chọn slug khác.';
                }

                if (!$errors && $mode === 'edit') {
                    $existing = comic_admin_authors_query(
                        $database,
                        'SELECT id
                         FROM authors
                         WHERE id = ?
                         LIMIT 1',
                        [$editId]
                    )['rows'];

                    if (!$existing) {
                        $errors[] =
                            'Tác giả cần chỉnh sửa không còn tồn tại.';
                    } else {
                        comic_admin_authors_query(
                            $database,
                            'UPDATE authors
                             SET name = ?, slug = ?, bio = ?, avatar = ?
                             WHERE id = ?',
                            [
                                $name,
                                $slug,
                                $formData['bio'] !== ''
                                    ? $formData['bio']
                                    : null,
                                $formData['avatar'] !== ''
                                    ? $formData['avatar']
                                    : null,
                                $editId,
                            ]
                        );

                        comic_admin_authors_set_flash(
                            'success',
                            'Đã cập nhật tác giả "' . $name . '".'
                        );

                        $_SESSION['comic_admin_csrf'] =
                            bin2hex(random_bytes(32));

                        comic_admin_authors_redirect();
                    }

                } elseif (!$errors) {
                    comic_admin_authors_query(
                        $database,
                        'INSERT INTO authors
                            (name, slug, bio, avatar)
                         VALUES (?, ?, ?, ?)',
                        [
                            $name,
                            $slug,
                            $formData['bio'] !== ''
                                ? $formData['bio']
                                : null,
                            $formData['avatar'] !== ''
                                ? $formData['avatar']
                                : null,
                        ]
                    );

                    comic_admin_authors_set_flash(
                        'success',
                        'Đã thêm tác giả "' . $name . '".'
                    );

                    $_SESSION['comic_admin_csrf'] =
                        bin2hex(random_bytes(32));

                    comic_admin_authors_redirect();
                }

            } catch (Throwable $exception) {
                error_log(
                    '[Comic Shop Authors] ' .
                    $exception->getMessage()
                );

                $errors[] =
                    'Không lưu được tác giả. Kiểm tra dữ liệu và kết nối database.';
            }
        }

    } else {
        comic_admin_authors_set_flash(
            'error',
            'Thao tác không hợp lệ.'
        );

        comic_admin_authors_redirect();
    }
}

/* =========================================================
   5. TẢI DỮ LIỆU FORM CHỈNH SỬA
========================================================= */

$editAuthor = null;

if ($dbReady && $action === 'edit' && $editId > 0) {
    try {
        $rows = comic_admin_authors_query(
            $database,
            'SELECT id, name, slug, bio, avatar
             FROM authors
             WHERE id = ?
             LIMIT 1',
            [$editId]
        )['rows'];

        $editAuthor = $rows[0] ?? null;

        if (!$editAuthor) {
            $action = 'list';

            $errors[] =
                'Không tìm thấy tác giả cần chỉnh sửa.';

        } elseif (!$hasSubmittedForm) {
            $formData = [
                'name' => (string) ($editAuthor['name'] ?? ''),
                'slug' => (string) ($editAuthor['slug'] ?? ''),
                'bio' => (string) ($editAuthor['bio'] ?? ''),
                'avatar' => (string) ($editAuthor['avatar'] ?? ''),
            ];
        }

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Authors] ' .
            $exception->getMessage()
        );

        $errors[] = 'Không tải được thông tin tác giả.';
        $action = 'list';
    }
}

/* =========================================================
   6. TÌM KIẾM VÀ PHÂN TRANG
========================================================= */

$search = isset($_GET['q']) && is_string($_GET['q'])
    ? trim($_GET['q'])
    : '';

$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;

$totalAuthors = 0;
$totalPages = 1;
$authorRows = [];

$authorStats = [
    'total' => 0,
    'with_comics' => 0,
    'without_comics' => 0,
];

$offset = 0;

if ($dbReady && $action === 'list') {
    try {
        $statRows = comic_admin_authors_query(
            $database,
            'SELECT
                COUNT(*) AS total,
                COALESCE(
                    SUM(
                        (
                            SELECT COUNT(*)
                            FROM comics c
                            WHERE c.author_id = authors.id
                        ) > 0
                    ),
                    0
                ) AS with_comics
             FROM authors'
        )['rows'];

        if ($statRows) {
            $authorStats['total'] =
                (int) $statRows[0]['total'];

            $authorStats['with_comics'] =
                (int) $statRows[0]['with_comics'];

            $authorStats['without_comics'] =
                $authorStats['total'] -
                $authorStats['with_comics'];
        }

        $whereSql = '';
        $params = [];

        if ($search !== '') {
            $whereSql = ' WHERE (
                a.name LIKE ?
                OR a.slug LIKE ?
                OR a.bio LIKE ?
            )';

            $like = '%' . $search . '%';

            $params = [
                $like,
                $like,
                $like,
            ];
        }

        $countRows = comic_admin_authors_query(
            $database,
            'SELECT COUNT(*) AS total
             FROM authors a' . $whereSql,
            $params
        )['rows'];

        $totalAuthors = (int) (
            $countRows[0]['total'] ?? 0
        );

        $totalPages = max(
            1,
            (int) ceil($totalAuthors / $perPage)
        );

        $page = min($page, $totalPages);
        $offset = ($page - 1) * $perPage;

        $listParams = $params;
        $listParams[] = $perPage;
        $listParams[] = $offset;

        $authorRows = comic_admin_authors_query(
            $database,
            'SELECT
                a.id,
                a.name,
                a.slug,
                a.bio,
                a.avatar,
                (
                    SELECT COUNT(*)
                    FROM comics c
                    WHERE c.author_id = a.id
                ) AS comic_count,
                (
                    SELECT COUNT(*)
                    FROM series s
                    WHERE s.author_id = a.id
                ) AS series_count
             FROM authors a' . $whereSql . '
             ORDER BY a.name ASC
             LIMIT ? OFFSET ?',
            $listParams
        )['rows'];

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Authors] ' .
            $exception->getMessage()
        );

        $errors[] =
            'Không tải được danh sách tác giả. Hãy kiểm tra schema và kết nối cơ sở dữ liệu.';
    }
}

if ($action === 'create') {
    $pageTitle = 'Thêm tác giả';
    $pageDescription = 'Thêm tác giả mới vào thư viện Comic Shop.';
} elseif ($action === 'edit') {
    $pageTitle = 'Chỉnh sửa tác giả';
    $pageDescription = 'Cập nhật hồ sơ tác giả.';
}

require_once __DIR__ . '/includes/header.php';
?>

<style>
.authors-admin {
    color: #f2f2f2;
}

.authors-admin .aa-alert {
    margin-bottom: 17px;
    padding: 12px 15px;
    border: 1px solid rgba(255,107,96,.4);
    border-left: 4px solid #ff6b60;
    background: rgba(255,107,96,.14);
    color: #ff8f86;
    font-size: 12px;
    line-height: 1.65;
}

.authors-admin .aa-alert.success {
    border-color: rgba(80,200,130,.4);
    border-left-color: #50c882;
    background: rgba(80,200,130,.16);
    color: #6fdc9c;
}

.authors-admin .aa-stats {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 14px;
    margin-bottom: 21px;
}

.authors-admin .aa-stat {
    padding: 17px;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.18);
}

.authors-admin .aa-stat-label {
    color: #a9a9b2;
    font-size: 11px;
    font-weight: 700;
}

.authors-admin .aa-stat-value {
    display: block;
    margin-top: 6px;
    font-size: 25px;
    font-weight: 850;
}

.authors-admin .aa-toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
    margin-bottom: 17px;
}

.authors-admin .aa-search {
    display: flex;
    flex: 1;
    flex-wrap: wrap;
    gap: 8px;
}

.authors-admin .aa-search input {
    min-width: 200px;
    min-height: 39px;
    flex: 1;
    padding: 9px 12px;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    background: #232327;
    color: #f2f2f2;
    font: inherit;
    font-size: 12px;
}

.authors-admin .aa-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    min-height: 36px;
    padding: 8px 12px;
    border: 1px solid transparent;
    border-radius: 999px;
    background: #f2f2f2;
    color: #111111;
    font-size: 12px;
    font-weight: 800;
    text-decoration: none;
    cursor: pointer;
}

.authors-admin .aa-btn:hover {
    background: #ffffff;
    color: #111111;
}

.authors-admin .aa-btn.secondary {
    border-color: #3d3d44;
    background: #232327;
    color: #d4d4da;
}

.authors-admin .aa-btn.secondary:hover {
    border-color: #f2f2f2;
    color: #f2f2f2;
}

.authors-admin .aa-btn.danger {
    border-color: rgba(255,107,96,.4);
    background: rgba(255,107,96,.14);
    color: #ff8f86;
}

.authors-admin .aa-btn.danger:hover {
    background: rgba(255,107,96,.14);
}

.authors-admin .aa-panel {
    overflow: hidden;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.22);
}

.authors-admin .aa-panel-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 10px;
    padding: 17px 20px;
    border-bottom: 1px solid #3d3d44;
}

.authors-admin .aa-panel-head h2 {
    margin: 0;
    font-size: 14px;
    font-weight: 850;
}

.authors-admin .aa-muted {
    color: #a9a9b2;
    font-size: 11px;
}

.authors-admin .aa-table-wrap {
    overflow-x: auto;
}

.authors-admin table {
    width: 100%;
    border-collapse: collapse;
}

.authors-admin th {
    padding: 13px 15px;
    background: #2c2c31;
    border-bottom: 1px solid #3d3d44;
    color: #a9a9b2;
    font-size: 10px;
    font-weight: 850;
    letter-spacing: .5px;
    text-align: left;
    text-transform: uppercase;
    white-space: nowrap;
}

.authors-admin td {
    padding: 14px 15px;
    border-bottom: 1px solid #3d3d44;
    color: #d4d4da;
    font-size: 12px;
    vertical-align: middle;
}

.authors-admin tbody tr:last-child td {
    border-bottom: 0;
}

.authors-admin tbody tr:hover {
    background: #2c2c31;
}

.authors-admin .aa-author {
    display: flex;
    align-items: center;
    gap: 11px;
    min-width: 190px;
}

.authors-admin .aa-avatar {
    display: grid;
    width: 46px;
    height: 46px;
    flex: 0 0 46px;
    place-items: center;
    overflow: hidden;
    border-radius: 50%;
    background: #36363c;
    color: #f2f2f2;
    font-size: 17px;
    font-weight: 850;
}

.authors-admin .aa-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.authors-admin .aa-name {
    display: block;
    color: #f2f2f2;
    font-weight: 800;
}

.authors-admin .aa-slug {
    display: block;
    margin-top: 4px;
    color: #a9a9b2;
    font-size: 10px;
}

.authors-admin .aa-bio {
    min-width: 190px;
    max-width: 350px;
    color: #a9a9b2;
    line-height: 1.6;
    overflow-wrap: anywhere;
}

.authors-admin .aa-count {
    display: inline-flex;
    min-width: 32px;
    min-height: 29px;
    align-items: center;
    justify-content: center;
    padding: 4px 8px;
    border-radius: 20px;
    background: #f0f2f6;
    color: #46515e;
    font-size: 11px;
    font-weight: 850;
}

.authors-admin .aa-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
}

.authors-admin .aa-actions form {
    margin: 0;
}

.authors-admin .aa-empty {
    padding: 40px 18px;
    color: #a9a9b2;
    font-size: 12px;
    text-align: center;
}

.authors-admin .aa-pagination {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
    padding: 15px 18px;
    border-top: 1px solid #3d3d44;
}

.authors-admin .aa-pages {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
}

.authors-admin .aa-pages a,
.authors-admin .aa-pages span {
    display: grid;
    min-width: 33px;
    height: 33px;
    padding: 0 9px;
    place-items: center;
    border: 1px solid #3d3d44;
    border-radius: 6px;
    background: #232327;
    color: #d4d4da;
    font-size: 11px;
    text-decoration: none;
}

.authors-admin .aa-pages .current {
    border-color: #f2f2f2;
    background: #f2f2f2;
    color: #111111;
}

.authors-admin .aa-form {
    max-width: 850px;
    overflow: hidden;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.22);
}

.authors-admin .aa-form-body {
    padding: 22px;
}

.authors-admin .aa-field {
    margin-bottom: 19px;
}

.authors-admin .aa-field label {
    display: block;
    margin-bottom: 7px;
    color: #363d48;
    font-size: 11px;
    font-weight: 800;
}

.authors-admin .aa-field input,
.authors-admin .aa-field textarea {
    display: block;
    width: 100%;
    min-height: 42px;
    padding: 10px 12px;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    background: #232327;
    color: #f2f2f2;
    font: inherit;
    font-size: 12px;
    outline: none;
}

.authors-admin .aa-field textarea {
    min-height: 140px;
    resize: vertical;
}

.authors-admin .aa-field input:focus,
.authors-admin .aa-field textarea:focus {
    border-color: #f2f2f2;
    box-shadow: 0 0 0 3px rgba(239, 67, 56, .1);
}

.authors-admin .aa-help {
    margin-top: 6px;
    color: #a9a9b2;
    font-size: 10px;
    line-height: 1.6;
}

.authors-admin .aa-preview {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-top: 10px;
}

.authors-admin .aa-preview img {
    width: 72px;
    height: 72px;
    object-fit: cover;
    border: 1px solid #3d3d44;
    border-radius: 50%;
    background: #2c2c31;
}

.authors-admin .aa-form-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 9px;
    padding-top: 17px;
    border-top: 1px solid #3d3d44;
}

@media (max-width: 900px) {
    .authors-admin .aa-stats {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }
}

@media (max-width: 650px) {
    .authors-admin .aa-stats {
        grid-template-columns: 1fr 1fr;
        gap: 9px;
    }

    .authors-admin .aa-stat {
        padding: 13px;
    }

    .authors-admin .aa-stat-value {
        font-size: 22px;
    }

    .authors-admin .aa-form-body {
        padding: 15px;
    }

    .authors-admin .aa-toolbar {
        align-items: stretch;
    }

    .authors-admin .aa-search {
        width: 100%;
    }

    .authors-admin .aa-search input {
        min-width: 0;
    }
}
</style>

<div class="authors-admin">

    <?php if (is_array($flash) && !empty($flash['message'])): ?>
        <div
            class="aa-alert <?= ($flash['type'] ?? '') === 'success' ? 'success' : '' ?>"
            role="status"
        >
            <?= comic_admin_authors_escape($flash['message']) ?>
        </div>
    <?php endif; ?>

    <?php if (!$dbReady): ?>
        <div class="aa-alert" role="alert">
            Không tìm thấy kết nối cơ sở dữ liệu. Kiểm tra
            config/db.php và admin/includes/bootstrap.php.
        </div>
    <?php endif; ?>

    <?php if ($errors): ?>
        <div class="aa-alert" role="alert">
            <strong>Cần kiểm tra:</strong>

            <ul style="margin:7px 0 0;padding-left:19px">
                <?php foreach ($errors as $error): ?>
                    <li><?= comic_admin_authors_escape($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if (in_array($action, ['create', 'edit'], true)): ?>

        <div class="aa-toolbar">
            <div>
                <h2 style="margin:0;font-size:20px;font-weight:850">
                    <?= $action === 'edit'
                        ? 'Chỉnh sửa tác giả'
                        : 'Thêm tác giả mới' ?>
                </h2>

                <p class="aa-muted" style="margin:5px 0 0">
                    Tên tác giả và slug phải hợp lệ; slug không được trùng.
                </p>
            </div>

            <a class="aa-btn secondary" href="authors.php">
                ← Quay lại
            </a>
        </div>

        <section class="aa-form">

            <div class="aa-panel-head">
                <h2>Thông tin tác giả</h2>
            </div>

            <div class="aa-form-body">

                <form method="post" action="authors.php">

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= comic_admin_authors_escape(
                            comic_admin_csrf_token()
                        ) ?>"
                    >

                    <input type="hidden" name="action" value="save">

                    <input
                        type="hidden"
                        name="form_mode"
                        value="<?= comic_admin_authors_escape($action) ?>"
                    >

                    <input
                        type="hidden"
                        name="id"
                        value="<?= (int) $editId ?>"
                    >

                    <div class="aa-field">
                        <label for="author-name">Tên tác giả *</label>

                        <input
                            id="author-name"
                            type="text"
                            name="name"
                            maxlength="120"
                            required
                            value="<?= comic_admin_authors_escape($formData['name']) ?>"
                            placeholder="Ví dụ: Eiichiro Oda"
                        >
                    </div>

                    <div class="aa-field">
                        <label for="author-slug">Slug</label>

                        <input
                            id="author-slug"
                            type="text"
                            name="slug"
                            maxlength="140"
                            value="<?= comic_admin_authors_escape($formData['slug']) ?>"
                            placeholder="eiichiro-oda"
                        >

                        <div class="aa-help">
                            Để trống để tự tạo từ tên tác giả.
                            Slug được dùng trong đường dẫn và phải duy nhất.
                        </div>
                    </div>

                    <div class="aa-field">
                        <label for="author-avatar">
                            Đường dẫn ảnh đại diện
                        </label>

                        <input
                            id="author-avatar"
                            type="text"
                            name="avatar"
                            maxlength="255"
                            value="<?= comic_admin_authors_escape($formData['avatar']) ?>"
                            placeholder="assets/images/avatars/eiichiro-oda.jpg"
                        >

                        <div class="aa-help">
                            Nhập URL ảnh hoặc đường dẫn tương đối.
                            Trường này lưu đường dẫn, không tải ảnh lên máy chủ.
                        </div>

                        <?php if ($formData['avatar'] !== ''): ?>
                            <div class="aa-preview">
                                <img
                                    src="<?= comic_admin_authors_escape(
                                        comic_admin_authors_avatar_url(
                                            (string) $formData['avatar']
                                        )
                                    ) ?>"
                                    alt="Ảnh tác giả xem trước"
                                    onerror="this.style.display='none'"
                                >

                                <span class="aa-muted">
                                    Ảnh xem trước
                                </span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="aa-field">
                        <label for="author-bio">
                            Tiểu sử / giới thiệu
                        </label>

                        <textarea
                            id="author-bio"
                            name="bio"
                            rows="5"
                            placeholder="Giới thiệu về tác giả..."
                        ><?= comic_admin_authors_escape($formData['bio']) ?></textarea>
                    </div>

                    <div class="aa-form-actions">

                        <button class="aa-btn" type="submit">
                            <?= $action === 'edit'
                                ? 'Lưu thay đổi'
                                : 'Thêm tác giả' ?>
                        </button>

                        <a class="aa-btn secondary" href="authors.php">
                            Hủy
                        </a>

                    </div>

                </form>

            </div>
        </section>

    <?php else: ?>

        <!-- THỐNG KÊ TÁC GIẢ -->

        <section class="aa-stats" aria-label="Thống kê tác giả">

            <div class="aa-stat">
                <span class="aa-stat-label">Tổng tác giả</span>

                <strong class="aa-stat-value">
                    <?= number_format($authorStats['total']) ?>
                </strong>
            </div>

            <div class="aa-stat">
                <span class="aa-stat-label">Có truyện</span>

                <strong
                    class="aa-stat-value"
                    style="color:#6fdc9c"
                >
                    <?= number_format($authorStats['with_comics']) ?>
                </strong>
            </div>

            <div class="aa-stat">
                <span class="aa-stat-label">Chưa có truyện</span>

                <strong
                    class="aa-stat-value"
                    style="color:#f2f2f2"
                >
                    <?= number_format($authorStats['without_comics']) ?>
                </strong>
            </div>

        </section>

        <!-- TÌM KIẾM -->

        <div class="aa-toolbar">

            <form class="aa-search" method="get" action="authors.php">

                <input
                    type="search"
                    name="q"
                    value="<?= comic_admin_authors_escape($search) ?>"
                    placeholder="Tìm tên, slug hoặc tiểu sử..."
                    aria-label="Tìm tác giả"
                >

                <button class="aa-btn secondary" type="submit">
                    Tìm kiếm
                </button>

                <?php if ($search !== ''): ?>
                    <a class="aa-btn secondary" href="authors.php">
                        Xóa lọc
                    </a>
                <?php endif; ?>

            </form>

            <a class="aa-btn" href="authors.php?action=create">
                ＋ Thêm tác giả
            </a>

        </div>

        <!-- DANH SÁCH TÁC GIẢ -->

        <section class="aa-panel">

            <div class="aa-panel-head">
                <h2>Danh sách tác giả</h2>

                <span class="aa-muted">
                    <?= number_format($totalAuthors) ?> kết quả
                </span>
            </div>

            <?php if (!$dbReady): ?>

                <div class="aa-empty">
                    Cần kết nối cơ sở dữ liệu để xem danh sách.
                </div>

            <?php elseif (!$authorRows): ?>

                <div class="aa-empty">
                    <div style="font-size:30px;margin-bottom:10px">
                        ♙
                    </div>

                    Không tìm thấy tác giả phù hợp.

                    <div style="margin-top:14px">
                        <a
                            class="aa-btn"
                            href="authors.php?action=create"
                        >
                            Thêm tác giả đầu tiên
                        </a>
                    </div>
                </div>

            <?php else: ?>

                <div class="aa-table-wrap">

                    <table>
                        <thead>
                            <tr>
                                <th>Tác giả</th>
                                <th>Tiểu sử</th>
                                <th>Truyện</th>
                                <th>Bộ truyện</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php foreach ($authorRows as $author): ?>

                            <?php
                            $avatarUrl = comic_admin_authors_avatar_url(
                                (string) ($author['avatar'] ?? ''),
                                (string) ($author['name'] ?? '')
                            );

                            $initial = function_exists('mb_substr')
                                ? mb_strtoupper(
                                    mb_substr(
                                        (string) $author['name'],
                                        0,
                                        1,
                                        'UTF-8'
                                    ),
                                    'UTF-8'
                                )
                                : strtoupper(
                                    substr((string) $author['name'], 0, 1)
                                );

                            $comicCount = (int) (
                                $author['comic_count'] ?? 0
                            );

                            $seriesCount = (int) (
                                $author['series_count'] ?? 0
                            );
                            ?>

                            <tr>

                                <td>
                                    <div class="aa-author">

                                        <span class="aa-avatar">

                                            <?php if ($avatarUrl !== ''): ?>

                                                <img
                                                    src="<?= comic_admin_authors_escape($avatarUrl) ?>"
                                                    alt=""
                                                    loading="lazy"
                                                    onerror="this.style.display='none';this.parentElement.textContent='<?= comic_admin_authors_escape($initial) ?>';"
                                                >

                                            <?php else: ?>

                                                <?= comic_admin_authors_escape($initial) ?>

                                            <?php endif; ?>

                                        </span>

                                        <span>
                                            <span class="aa-name">
                                                <?= comic_admin_authors_escape($author['name']) ?>
                                            </span>

                                            <span class="aa-slug">
                                                <?= comic_admin_authors_escape($author['slug']) ?>
                                            </span>
                                        </span>

                                    </div>
                                </td>

                                <td>
                                    <div class="aa-bio">
                                        <?= comic_admin_authors_escape(
                                            $author['bio'] !== null &&
                                            $author['bio'] !== ''
                                                ? $author['bio']
                                                : 'Chưa có tiểu sử.'
                                        ) ?>
                                    </div>
                                </td>

                                <td>
                                    <span class="aa-count">
                                        <?= number_format($comicCount) ?>
                                    </span>
                                </td>

                                <td>
                                    <span class="aa-count">
                                        <?= number_format($seriesCount) ?>
                                    </span>
                                </td>

                                <td>
                                    <div class="aa-actions">

                                        <a
                                            class="aa-btn secondary"
                                            href="authors.php?action=edit&amp;id=<?= (int) $author['id'] ?>"
                                        >
                                            Sửa
                                        </a>

                                        <?php if (
                                            $comicCount === 0 &&
                                            $seriesCount === 0
                                        ): ?>

                                            <form
                                                method="post"
                                                action="authors.php"
                                                data-confirm="Bạn có chắc muốn xóa tác giả này? Thao tác không thể hoàn tác."
                                            >

                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?= comic_admin_authors_escape(
                                                        comic_admin_csrf_token()
                                                    ) ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="action"
                                                    value="delete"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="id"
                                                    value="<?= (int) $author['id'] ?>"
                                                >

                                                <button
                                                    class="aa-btn danger"
                                                    type="submit"
                                                >
                                                    Xóa
                                                </button>

                                            </form>

                                        <?php else: ?>

                                            <button
                                                class="aa-btn secondary"
                                                type="button"
                                                disabled
                                                title="Tác giả đang được sử dụng bởi truyện hoặc bộ truyện."
                                            >
                                                Đang sử dụng
                                            </button>

                                        <?php endif; ?>

                                    </div>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>
                    </table>

                </div>

                <!-- PHÂN TRANG -->

                <div class="aa-pagination">

                    <span class="aa-muted">
                        Hiển thị
                        <?= number_format(
                            min(
                                $totalAuthors,
                                $offset + ($totalAuthors > 0 ? 1 : 0)
                            )
                        ) ?>–<?= number_format(
                            min(
                                $totalAuthors,
                                $offset + count($authorRows)
                            )
                        ) ?>
                        trong <?= number_format($totalAuthors) ?> tác giả
                    </span>

                    <?php if ($totalPages > 1): ?>

                        <nav class="aa-pages" aria-label="Phân trang">

                            <?php
                            $queryBase = $search !== ''
                                ? ['q' => $search]
                                : [];

                            if ($page > 1) {
                                $prevUrl = 'authors.php?' .
                                    http_build_query(
                                        array_merge(
                                            $queryBase,
                                            ['page' => $page - 1]
                                        )
                                    );

                                echo '<a href="' .
                                    comic_admin_authors_escape($prevUrl) .
                                    '" aria-label="Trang trước">‹</a>';
                            }

                            $start = max(1, $page - 2);
                            $end = min($totalPages, $page + 2);

                            for ($i = $start; $i <= $end; $i++) {
                                $url = 'authors.php?' .
                                    http_build_query(
                                        array_merge(
                                            $queryBase,
                                            ['page' => $i]
                                        )
                                    );

                                if ($i === $page) {
                                    echo '<span class="current" aria-current="page">' .
                                        $i . '</span>';
                                } else {
                                    echo '<a href="' .
                                        comic_admin_authors_escape($url) .
                                        '">' . $i . '</a>';
                                }
                            }

                            if ($page < $totalPages) {
                                $nextUrl = 'authors.php?' .
                                    http_build_query(
                                        array_merge(
                                            $queryBase,
                                            ['page' => $page + 1]
                                        )
                                    );

                                echo '<a href="' .
                                    comic_admin_authors_escape($nextUrl) .
                                    '" aria-label="Trang sau">›</a>';
                            }
                            ?>

                        </nav>

                    <?php endif; ?>

                </div>

            <?php endif; ?>

        </section>


    <?php endif; ?>

</div>

<script>
(function () {
    'use strict';

    var nameInput = document.getElementById('author-name');
    var slugInput = document.getElementById('author-slug');

    if (!nameInput || !slugInput) {
        return;
    }

    var slugManuallyEdited = slugInput.value.trim() !== '';

    slugInput.addEventListener('input', function () {
        slugManuallyEdited = slugInput.value.trim() !== '';
    });

    nameInput.addEventListener('input', function () {
        if (slugManuallyEdited) {
            return;
        }

        var value = nameInput.value.replace(/[Đđ]/g, function (character) {
            return character === 'Đ' ? 'D' : 'd';
        });

        if (value.normalize) {
            value = value.normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '');
        }

        slugInput.value = value.toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '');
    });
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
