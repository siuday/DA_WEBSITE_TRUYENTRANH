<?php
declare(strict_types=1);

/**
 * COMIC SHOP
 * File: admin/reviews.php
 * Quản lý đánh giá truyện.
 *
 * Sử dụng các bảng có sẵn:
 * reviews, users, comics.
 */

require_once __DIR__ . '/includes/bootstrap.php';

if (!function_exists('comic_admin_media_url')) {
    require_once __DIR__ . '/includes/media.php';
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. KẾT NỐI DATABASE
========================================================= */

$reviewDb = null;

$reviewDbCandidates = [
    $GLOBALS['comic_shop_db'] ?? null,
    $GLOBALS['pdo'] ?? null,
    $GLOBALS['conn'] ?? null,
    $GLOBALS['mysqli'] ?? null,
    $GLOBALS['db'] ?? null,
    $pdo ?? null,
    $conn ?? null,
    $mysqli ?? null,
    $db ?? null,
];

foreach ($reviewDbCandidates as $candidate) {
    if (
        $candidate instanceof PDO ||
        (class_exists('mysqli') && $candidate instanceof mysqli)
    ) {
        $reviewDb = $candidate;
        break;
    }
}

$reviewDbReady = $reviewDb instanceof PDO ||
    (class_exists('mysqli') && $reviewDb instanceof mysqli);

/* =========================================================
   2. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_reviews_escape')) {
    function comic_reviews_escape($value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_reviews_query')) {
    function comic_reviews_query(
        $db,
        string $sql,
        array $params = []
    ): array {
        if ($db instanceof PDO) {
            $stmt = $db->prepare($sql);
            $stmt->execute($params);

            $rows = $stmt->columnCount() > 0
                ? $stmt->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $affected = $stmt->rowCount();
            $stmt->closeCursor();

            return [
                'rows' => $rows,
                'affected' => $affected,
            ];
        }

        if (class_exists('mysqli') && $db instanceof mysqli) {
            $stmt = $db->prepare($sql);

            if (!$stmt) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn database.'
                );
            }

            if ($params !== []) {
                $types = '';
                $bindParams = [];

                foreach ($params as $param) {
                    if (is_int($param) || is_bool($param)) {
                        $types .= 'i';
                    } elseif (is_float($param)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }
                }

                $bindParams[] = $types;

                foreach ($params as &$param) {
                    $bindParams[] = &$param;
                }

                unset($param);

                if (!call_user_func_array(
                    [$stmt, 'bind_param'],
                    $bindParams
                )) {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không thể gắn tham số truy vấn.'
                    );
                }
            }

            if (!$stmt->execute()) {
                $error = $stmt->error;
                $stmt->close();

                throw new RuntimeException(
                    $error ?: 'Truy vấn database thất bại.'
                );
            }

            $rows = [];

            if ($stmt->field_count > 0) {
                $result = $stmt->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không đọc được kết quả truy vấn.'
                    );
                }
            }

            $affected = $stmt->affected_rows;
            $stmt->close();

            return [
                'rows' => $rows,
                'affected' => $affected,
            ];
        }

        throw new RuntimeException(
            'Không tìm thấy kết nối PDO hoặc MySQLi.'
        );
    }
}

if (!function_exists('comic_reviews_flash')) {
    function comic_reviews_flash(
        string $type,
        string $message
    ): void {
        $_SESSION['comic_reviews_flash'] = [
            'type' => $type,
            'message' => $message,
        ];
    }
}

if (!function_exists('comic_reviews_redirect')) {
    function comic_reviews_redirect(): void
    {
        header('Location: reviews.php', true, 303);
        exit;
    }
}

if (!function_exists('comic_reviews_stars')) {
    function comic_reviews_stars(int $rating): string
    {
        return str_repeat('★', max(0, min(5, $rating)))
            . str_repeat('☆', 5 - max(0, min(5, $rating)));
    }
}

/* =========================================================
   3. CSRF VÀ THÔNG BÁO
========================================================= */

if (
    empty($_SESSION['comic_reviews_csrf']) ||
    !is_string($_SESSION['comic_reviews_csrf'])
) {
    $_SESSION['comic_reviews_csrf'] = bin2hex(random_bytes(32));
}

$reviewCsrf = $_SESSION['comic_reviews_csrf'];

$reviewFlash = $_SESSION['comic_reviews_flash'] ?? null;
unset($_SESSION['comic_reviews_flash']);

$reviewErrors = [];

/* =========================================================
   4. XỬ LÝ XÓA ĐÁNH GIÁ
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $postedToken = isset($_POST['csrf_token'])
        && is_string($_POST['csrf_token'])
        ? $_POST['csrf_token']
        : '';

    if (!hash_equals($reviewCsrf, $postedToken)) {
        comic_reviews_flash(
            'error',
            'Phiên làm việc đã hết hạn. Vui lòng tải lại trang.'
        );

        comic_reviews_redirect();
    }

    $postAction = isset($_POST['action'])
        && is_string($_POST['action'])
        ? $_POST['action']
        : '';

    $reviewId = (int)($_POST['id'] ?? 0);

    if (!$reviewDbReady) {
        comic_reviews_flash(
            'error',
            'Chưa kết nối được database. Hãy kiểm tra config/db.php.'
        );

        comic_reviews_redirect();
    }

    if ($postAction !== 'delete' || $reviewId < 1) {
        comic_reviews_flash(
            'error',
            'Thao tác hoặc ID đánh giá không hợp lệ.'
        );

        comic_reviews_redirect();
    }

    try {
        /*
         * Lấy thông tin đánh giá trước khi xóa để xác định
         * truyện cần tính lại điểm trung bình.
         */
        $existingRows = comic_reviews_query(
            $reviewDb,
            'SELECT id, comic_id
             FROM reviews
             WHERE id = ?
             LIMIT 1',
            [$reviewId]
        )['rows'];

        if (!$existingRows) {
            comic_reviews_flash(
                'error',
                'Đánh giá không tồn tại hoặc đã bị xóa.'
            );

            comic_reviews_redirect();
        }

        $comicId = (int)$existingRows[0]['comic_id'];

        comic_reviews_query(
            $reviewDb,
            'DELETE FROM reviews WHERE id = ?',
            [$reviewId]
        );

        /*
         * Đồng bộ lại điểm trung bình và số đánh giá trong comics.
         */
        comic_reviews_query(
            $reviewDb,
            'UPDATE comics
             SET
                rating_avg = (
                    SELECT COALESCE(ROUND(AVG(r.rating), 1), 0)
                    FROM reviews r
                    WHERE r.comic_id = ?
                ),
                review_count = (
                    SELECT COUNT(*)
                    FROM reviews r
                    WHERE r.comic_id = ?
                )
             WHERE id = ?',
            [$comicId, $comicId, $comicId]
        );

        comic_reviews_flash(
            'success',
            'Đã xóa đánh giá và cập nhật lại điểm trung bình của truyện.'
        );

        $_SESSION['comic_reviews_csrf'] =
            bin2hex(random_bytes(32));

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Reviews] ' . $exception->getMessage()
        );

        comic_reviews_flash(
            'error',
            'Không thể xóa đánh giá. Vui lòng kiểm tra database.'
        );
    }

    comic_reviews_redirect();
}

/* =========================================================
   5. TÌM KIẾM VÀ LỌC
========================================================= */

$search = isset($_GET['q']) && is_string($_GET['q'])
    ? trim($_GET['q'])
    : '';

$ratingFilter = isset($_GET['rating'])
    && is_string($_GET['rating'])
    ? $_GET['rating']
    : 'all';

if (!in_array(
    $ratingFilter,
    ['all', '1', '2', '3', '4', '5'],
    true
)) {
    $ratingFilter = 'all';
}

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 10;

$totalReviews = 0;
$totalPages = 1;
$reviewRows = [];

$reviewStats = [
    'total' => 0,
    'average' => 0,
    'five_star' => 0,
    'one_star' => 0,
];

/* =========================================================
   6. THỐNG KÊ ĐÁNH GIÁ
========================================================= */

if ($reviewDbReady) {
    try {
        $statsRows = comic_reviews_query(
            $reviewDb,
            'SELECT
                COUNT(*) AS total,
                COALESCE(ROUND(AVG(rating), 1), 0) AS average_rating,
                COALESCE(SUM(
                    CASE WHEN rating = 5 THEN 1 ELSE 0 END
                ), 0) AS five_star,
                COALESCE(SUM(
                    CASE WHEN rating = 1 THEN 1 ELSE 0 END
                ), 0) AS one_star
             FROM reviews'
        )['rows'];

        if ($statsRows) {
            $reviewStats['total'] = (int)$statsRows[0]['total'];

            $reviewStats['average'] =
                (float)$statsRows[0]['average_rating'];

            $reviewStats['five_star'] =
                (int)$statsRows[0]['five_star'];

            $reviewStats['one_star'] =
                (int)$statsRows[0]['one_star'];
        }

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Reviews] ' . $exception->getMessage()
        );

        $reviewErrors[] = 'Không tải được thống kê đánh giá.';
    }
}

/* =========================================================
   7. DANH SÁCH ĐÁNH GIÁ
========================================================= */

if ($reviewDbReady) {
    try {
        $conditions = [];
        $params = [];

        if ($search !== '') {
            $conditions[] = '(
                c.title LIKE ?
                OR u.full_name LIKE ?
                OR u.email LIKE ?
                OR r.comment LIKE ?
            )';

            $like = '%' . $search . '%';

            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        if ($ratingFilter !== 'all') {
            $conditions[] = 'r.rating = ?';
            $params[] = (int)$ratingFilter;
        }

        $whereSql = $conditions
            ? ' WHERE ' . implode(' AND ', $conditions)
            : '';

        $countRows = comic_reviews_query(
            $reviewDb,
            'SELECT COUNT(*) AS total
             FROM reviews r
             INNER JOIN comics c ON c.id = r.comic_id
             INNER JOIN users u ON u.id = r.user_id' .
             $whereSql,
            $params
        )['rows'];

        $totalReviews = (int)($countRows[0]['total'] ?? 0);

        $totalPages = max(
            1,
            (int)ceil($totalReviews / $perPage)
        );

        $page = min($page, $totalPages);
        $offset = ($page - 1) * $perPage;

        $listParams = $params;
        $listParams[] = $perPage;
        $listParams[] = $offset;

        $reviewRows = comic_reviews_query(
            $reviewDb,
            'SELECT
                r.id,
                r.comic_id,
                r.user_id,
                r.rating,
                r.comment,
                r.created_at,
                c.title AS comic_title,
                c.cover_image,
                u.full_name AS customer_name,
                u.email AS customer_email
             FROM reviews r
             INNER JOIN comics c ON c.id = r.comic_id
             INNER JOIN users u ON u.id = r.user_id' .
             $whereSql . '
             ORDER BY r.created_at DESC, r.id DESC
             LIMIT ? OFFSET ?',
            $listParams
        )['rows'];

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Reviews] ' . $exception->getMessage()
        );

        $reviewErrors[] =
            'Không tải được danh sách đánh giá. Hãy kiểm tra cấu trúc database.';
    }
}

/* =========================================================
   8. GIAO DIỆN
========================================================= */

$pageTitle = 'Quản lý đánh giá';
$pageDescription = 'Theo dõi và kiểm duyệt đánh giá truyện của khách hàng.';
$activeMenu = 'reviews';

require_once __DIR__ . '/includes/header.php';
?>

<style>
.reviews-admin{color:#f2f2f2}
.reviews-admin .rv-alert{margin-bottom:17px;padding:12px 15px;border:1px solid rgba(255,107,96,.4);border-left:4px solid #ff6b60;background:rgba(255,107,96,.14);color:#ff8f86;font-size:12px;line-height:1.7}
.reviews-admin .rv-alert.success{border-color:rgba(80,200,130,.4);border-left-color:#50c882;background:rgba(80,200,130,.16);color:#6fdc9c}
.reviews-admin .rv-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-bottom:20px}
.reviews-admin .rv-stat{padding:17px;border:1px solid #3d3d44;border-radius:20px;background:#232327;box-shadow:0 4px 18px rgba(0,0,0,0.18)}
.reviews-admin .rv-stat-label{display:block;color:#a9a9b2;font-size:11px;font-weight:700}
.reviews-admin .rv-stat-value{display:block;margin-top:8px;font-size:25px;font-weight:850}
.reviews-admin .rv-toolbar{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:17px}
.reviews-admin .rv-search{display:flex;flex:1;flex-wrap:wrap;gap:8px}
.reviews-admin .rv-search input,.reviews-admin .rv-search select{box-sizing:border-box;min-height:39px;padding:9px 12px;border:1px solid #3d3d44;border-radius:12px;background:#232327;color:#f2f2f2;font:inherit;font-size:12px}
.reviews-admin .rv-search input{min-width:200px;flex:1}
.reviews-admin .rv-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:35px;padding:8px 12px;border:1px solid transparent;border-radius:999px;background:#f2f2f2;color:#111111;font-size:12px;font-weight:800;text-decoration:none;cursor:pointer;white-space:nowrap}
.reviews-admin .rv-btn:hover{background:#ffffff;color:#111111}
.reviews-admin .rv-btn.secondary{border-color:#3d3d44;background:#232327;color:#d4d4da}
.reviews-admin .rv-btn.secondary:hover{border-color:#f2f2f2;color:#f2f2f2}
.reviews-admin .rv-btn.danger{border-color:rgba(255,107,96,.4);background:rgba(255,107,96,.14);color:#ff8f86}
.reviews-admin .rv-panel{overflow:hidden;border:1px solid #3d3d44;border-radius:20px;background:#232327;box-shadow:0 4px 18px rgba(0,0,0,0.2)}
.reviews-admin .rv-panel-head{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:17px 19px;border-bottom:1px solid #3d3d44}
.reviews-admin .rv-panel-head h2{margin:0;font-size:15px;font-weight:850}
.reviews-admin .rv-muted{color:#a9a9b2;font-size:11px;line-height:1.7}
.reviews-admin .rv-table-wrap{width:100%;overflow-x:auto}
.reviews-admin table{width:100%;min-width:850px;border-collapse:collapse}
.reviews-admin th{padding:12px 14px;background:#2c2c31;color:#a9a9b2;text-align:left;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.04em;white-space:nowrap}
.reviews-admin td{padding:14px;border-top:1px solid #3d3d44;vertical-align:top;font-size:12px}
.reviews-admin tbody tr:hover{background:#2c2c31}
.reviews-admin .rv-comic{display:flex;align-items:center;gap:10px;min-width:190px}
.reviews-admin .rv-cover{width:45px;height:58px;flex-shrink:0;overflow:hidden;border:1px solid #3d3d44;border-radius:5px;background:#2c2c31}
.reviews-admin .rv-cover img{width:100%;height:100%;object-fit:cover}
.reviews-admin .rv-comic-name{display:block;color:#f2f2f2;font-size:12px;font-weight:800;line-height:1.6}
.reviews-admin .rv-person{display:block;color:#f2f2f2;font-size:12px;font-weight:800}
.reviews-admin .rv-email{display:block;margin-top:4px;color:#a9a9b2;font-size:10px;overflow-wrap:anywhere}
.reviews-admin .rv-stars{color:#f2a900;font-size:16px;letter-spacing:1px;white-space:nowrap}
.reviews-admin .rv-rating-label{display:block;margin-top:4px;color:#a9a9b2;font-size:10px}
.reviews-admin .rv-comment{max-width:310px;color:#d4d4da;font-size:12px;line-height:1.7;white-space:pre-wrap;overflow-wrap:anywhere}
.reviews-admin .rv-no-comment{color:#a9a9b2;font-style:italic}
.reviews-admin .rv-actions{display:flex;align-items:center;gap:6px}
.reviews-admin .rv-actions form{margin:0}
.reviews-admin .rv-empty{padding:45px 20px;text-align:center;color:#a9a9b2;font-size:13px}
.reviews-admin .rv-pagination{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;padding:15px 18px;border-top:1px solid #3d3d44}
.reviews-admin .rv-pages{display:flex;align-items:center;gap:5px}
.reviews-admin .rv-pages a,.reviews-admin .rv-pages span{display:inline-flex;min-width:32px;height:32px;align-items:center;justify-content:center;border:1px solid #3d3d44;border-radius:6px;color:#d4d4da;text-decoration:none;font-size:12px}
.reviews-admin .rv-pages a:hover,.reviews-admin .rv-pages .current{border-color:#f2f2f2;background:#f2f2f2;color:#111111}
@media(max-width:900px){.reviews-admin .rv-stats{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:600px){.reviews-admin .rv-stats{grid-template-columns:1fr}.reviews-admin .rv-toolbar{align-items:stretch}.reviews-admin .rv-search{flex-basis:100%}}
</style>

<div class="reviews-admin">

    <?php if (is_array($reviewFlash) && !empty($reviewFlash['message'])): ?>
        <div class="rv-alert <?= ($reviewFlash['type'] ?? '') === 'success' ? 'success' : '' ?>" role="status">
            <?= comic_reviews_escape($reviewFlash['message']) ?>
        </div>
    <?php endif; ?>

    <?php if (!$reviewDbReady): ?>
        <div class="rv-alert" role="alert">
            Không tìm thấy kết nối database. Hãy kiểm tra
            <strong>config/db.php</strong> và
            <strong>admin/includes/bootstrap.php</strong>.
        </div>
    <?php endif; ?>

    <?php if ($reviewErrors): ?>
        <div class="rv-alert" role="alert">
            <strong>Cần kiểm tra:</strong>
            <ul style="margin:7px 0 0;padding-left:19px">
                <?php foreach ($reviewErrors as $error): ?>
                    <li><?= comic_reviews_escape($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <section class="rv-stats" aria-label="Thống kê đánh giá">
        <div class="rv-stat">
            <span class="rv-stat-label">Tổng đánh giá</span>
            <strong class="rv-stat-value">
                <?= number_format($reviewStats['total']) ?>
            </strong>
        </div>

        <div class="rv-stat">
            <span class="rv-stat-label">Điểm trung bình</span>
            <strong class="rv-stat-value" style="color:#e7a100">
                <?= number_format($reviewStats['average'], 1) ?>/5
            </strong>
        </div>

        <div class="rv-stat">
            <span class="rv-stat-label">Đánh giá 5 sao</span>
            <strong class="rv-stat-value" style="color:#6fdc9c">
                <?= number_format($reviewStats['five_star']) ?>
            </strong>
        </div>

        <div class="rv-stat">
            <span class="rv-stat-label">Đánh giá 1 sao</span>
            <strong class="rv-stat-value" style="color:#f2f2f2">
                <?= number_format($reviewStats['one_star']) ?>
            </strong>
        </div>
    </section>

    <div class="rv-toolbar">
        <form class="rv-search" method="get" action="reviews.php">
            <input
                type="search"
                name="q"
                value="<?= comic_reviews_escape($search) ?>"
                placeholder="Tìm tên truyện, khách hàng, email hoặc bình luận..."
                aria-label="Tìm kiếm đánh giá"
            >

            <select name="rating" aria-label="Lọc theo số sao">
                <option value="all" <?= $ratingFilter === 'all' ? 'selected' : '' ?>>
                    Tất cả số sao
                </option>

                <?php for ($stars = 5; $stars >= 1; $stars--): ?>
                    <option
                        value="<?= $stars ?>"
                        <?= $ratingFilter === (string)$stars ? 'selected' : '' ?>
                    >
                        <?= $stars ?> sao
                    </option>
                <?php endfor; ?>
            </select>

            <button class="rv-btn secondary" type="submit">
                Tìm kiếm
            </button>

            <?php if ($search !== '' || $ratingFilter !== 'all'): ?>
                <a class="rv-btn secondary" href="reviews.php">
                    Xóa bộ lọc
                </a>
            <?php endif; ?>
        </form>
    </div>

    <section class="rv-panel">
        <div class="rv-panel-head">
            <h2>Danh sách đánh giá</h2>

            <span class="rv-muted">
                <?= number_format($totalReviews) ?> kết quả
            </span>
        </div>

        <?php if (!$reviewDbReady): ?>

            <div class="rv-empty">
                Cần kết nối database để xem đánh giá.
            </div>

        <?php elseif (!$reviewRows): ?>

            <div class="rv-empty">
                <div style="font-size:30px;margin-bottom:10px">☆</div>
                Không tìm thấy đánh giá phù hợp.
            </div>

        <?php else: ?>

            <div class="rv-table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Truyện</th>
                            <th>Khách hàng</th>
                            <th>Đánh giá</th>
                            <th>Bình luận</th>
                            <th>Ngày gửi</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($reviewRows as $review): ?>
                            <?php
                            $rating = max(
                                1,
                                min(5, (int)$review['rating'])
                            );
                            ?>

                            <tr>
                                <td>
                                    <div class="rv-comic">
                                        <div class="rv-cover">
                                            <img
                                                src="<?= comic_reviews_escape(
                                                    comic_admin_media_url(
                                                        (string) ($review['cover_image'] ?? ''),
                                                        (string) ($review['comic_title'] ?? ''),
                                                        'cover'
                                                    )
                                                ) ?>"
                                                alt="<?= comic_reviews_escape($review['comic_title'] ?? '') ?>"
                                                loading="lazy"
                                            >
                                        </div>

                                        <div>
                                            <span class="rv-comic-name">
                                                <?= comic_reviews_escape($review['comic_title']) ?>
                                            </span>

                                            <span class="rv-muted">
                                                Mã truyện #<?= (int)$review['comic_id'] ?>
                                            </span>
                                        </div>
                                    </div>
                                </td>

                                <td>
                                    <span class="rv-person">
                                        <?= comic_reviews_escape($review['customer_name']) ?>
                                    </span>

                                    <span class="rv-email">
                                        <?= comic_reviews_escape($review['customer_email']) ?>
                                    </span>
                                </td>

                                <td>
                                    <span
                                        class="rv-stars"
                                        title="<?= $rating ?>/5 sao"
                                        aria-label="<?= $rating ?> trên 5 sao"
                                    >
                                        <?= comic_reviews_stars($rating) ?>
                                    </span>

                                    <span class="rv-rating-label">
                                        <?= $rating ?>/5 sao
                                    </span>
                                </td>

                                <td>
                                    <?php if (trim((string)$review['comment']) !== ''): ?>
                                        <div class="rv-comment"><?= comic_reviews_escape($review['comment']) ?></div>
                                    <?php else: ?>
                                        <span class="rv-no-comment">
                                            Không có bình luận
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?= comic_reviews_escape(
                                        date(
                                            'd/m/Y H:i',
                                            strtotime((string)$review['created_at'])
                                        )
                                    ) ?>
                                </td>

                                <td>
                                    <div class="rv-actions">
                                        <form
                                            method="post"
                                            action="reviews.php"
                                            data-confirm="Bạn có chắc muốn xóa đánh giá này? Điểm trung bình của truyện sẽ được tính lại."
                                        >
                                            <input
                                                type="hidden"
                                                name="csrf_token"
                                                value="<?= comic_reviews_escape($reviewCsrf) ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="action"
                                                value="delete"
                                            >

                                            <input
                                                type="hidden"
                                                name="id"
                                                value="<?= (int)$review['id'] ?>"
                                            >

                                            <button
                                                class="rv-btn danger"
                                                type="submit"
                                            >
                                                Xóa
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="rv-pagination">
                <span class="rv-muted">
                    Hiển thị
                    <?= number_format(($page - 1) * $perPage + 1) ?>–<?= number_format(min($totalReviews, ($page - 1) * $perPage + count($reviewRows))) ?>
                    trong <?= number_format($totalReviews) ?> đánh giá
                </span>

                <?php if ($totalPages > 1): ?>
                    <nav class="rv-pages" aria-label="Phân trang">
                        <?php
                        $queryBase = [];

                        if ($search !== '') {
                            $queryBase['q'] = $search;
                        }

                        if ($ratingFilter !== 'all') {
                            $queryBase['rating'] = $ratingFilter;
                        }

                        if ($page > 1) {
                            $url = 'reviews.php?' . http_build_query(
                                array_merge($queryBase, ['page' => $page - 1])
                            );

                            echo '<a href="' .
                                comic_reviews_escape($url) .
                                '" aria-label="Trang trước">‹</a>';
                        }

                        $startPage = max(1, $page - 2);
                        $endPage = min($totalPages, $page + 2);

                        for (
                            $pageNumber = $startPage;
                            $pageNumber <= $endPage;
                            $pageNumber++
                        ) {
                            $url = 'reviews.php?' . http_build_query(
                                array_merge(
                                    $queryBase,
                                    ['page' => $pageNumber]
                                )
                            );

                            if ($pageNumber === $page) {
                                echo '<span class="current" aria-current="page">' .
                                    $pageNumber . '</span>';
                            } else {
                                echo '<a href="' .
                                    comic_reviews_escape($url) .
                                    '">' . $pageNumber . '</a>';
                            }
                        }

                        if ($page < $totalPages) {
                            $url = 'reviews.php?' . http_build_query(
                                array_merge($queryBase, ['page' => $page + 1])
                            );

                            echo '<a href="' .
                                comic_reviews_escape($url) .
                                '" aria-label="Trang tiếp">›</a>';
                        }
                        ?>
                    </nav>
                <?php endif; ?>
            </div>

        <?php endif; ?>
    </section>

    <p class="rv-muted" style="margin-top:12px">
        Khi xóa một đánh giá, hệ thống sẽ cập nhật lại các trường
        <code>rating_avg</code> và <code>review_count</code> của truyện tương ứng.
        Thao tác này không xóa tài khoản khách hàng hay truyện.
    </p>

</div>

<script>
(function () {
    'use strict';

    document.querySelectorAll(
        '.reviews-admin form[data-confirm]'
    ).forEach(function (form) {
        form.addEventListener('submit', function (event) {
            var message = form.getAttribute('data-confirm');

            if (message && !window.confirm(message)) {
                event.preventDefault();
            }
        });
    });
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
