<?php
declare(strict_types=1);

/**
 * COMIC SHOP
 * File: admin/messages.php
 * Quản lý tin nhắn liên hệ của khách hàng.
 */

require_once __DIR__ . '/includes/bootstrap.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. KẾT NỐI DATABASE
========================================================= */

$messageDb = null;

$dbCandidates = [
    $GLOBALS['comic_shop_db'] ?? null,
    $GLOBALS['pdo'] ?? null,
    $GLOBALS['conn'] ?? null,
    $GLOBALS['mysqli'] ?? null,
    $GLOBALS['db'] ?? null,
    $pdo ?? null,
    $conn ?? null,
    $mysqli ?? null,
    $db ?? null,
];

foreach ($dbCandidates as $candidate) {
    if (
        $candidate instanceof PDO ||
        (class_exists('mysqli') && $candidate instanceof mysqli)
    ) {
        $messageDb = $candidate;
        break;
    }
}

$messageDbReady = $messageDb instanceof PDO ||
    (class_exists('mysqli') && $messageDb instanceof mysqli);

/* =========================================================
   2. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_messages_escape')) {
    function comic_messages_escape($value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_messages_query')) {
    function comic_messages_query(
        $db,
        string $sql,
        array $params = []
    ): array {
        if ($db instanceof PDO) {
            $stmt = $db->prepare($sql);
            $stmt->execute($params);

            $rows = $stmt->columnCount() > 0
                ? $stmt->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $affected = $stmt->rowCount();
            $stmt->closeCursor();

            return [
                'rows' => $rows,
                'affected' => $affected,
            ];
        }

        if (class_exists('mysqli') && $db instanceof mysqli) {
            $stmt = $db->prepare($sql);

            if (!$stmt) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn database.'
                );
            }

            if ($params !== []) {
                $types = '';
                $bindParams = [];

                foreach ($params as $param) {
                    if (is_int($param) || is_bool($param)) {
                        $types .= 'i';
                    } elseif (is_float($param)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }
                }

                $bindParams[] = $types;

                foreach ($params as &$param) {
                    $bindParams[] = &$param;
                }

                unset($param);

                if (!call_user_func_array(
                    [$stmt, 'bind_param'],
                    $bindParams
                )) {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không thể gắn tham số truy vấn.'
                    );
                }
            }

            if (!$stmt->execute()) {
                $error = $stmt->error;
                $stmt->close();

                throw new RuntimeException(
                    $error ?: 'Truy vấn database thất bại.'
                );
            }

            $rows = [];

            if ($stmt->field_count > 0) {
                $result = $stmt->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không đọc được kết quả truy vấn.'
                    );
                }
            }

            $affected = $stmt->affected_rows;
            $stmt->close();

            return [
                'rows' => $rows,
                'affected' => $affected,
            ];
        }

        throw new RuntimeException(
            'Không tìm thấy kết nối PDO hoặc MySQLi.'
        );
    }
}

if (!function_exists('comic_messages_flash')) {
    function comic_messages_flash(
        string $type,
        string $message
    ): void {
        $_SESSION['comic_messages_flash'] = [
            'type' => $type,
            'message' => $message,
        ];
    }
}

if (!function_exists('comic_messages_redirect')) {
    function comic_messages_redirect(string $url = 'messages.php'): void
    {
        header('Location: ' . $url, true, 303);
        exit;
    }
}

/* =========================================================
   3. CSRF VÀ THÔNG BÁO
========================================================= */

if (
    empty($_SESSION['comic_messages_csrf']) ||
    !is_string($_SESSION['comic_messages_csrf'])
) {
    $_SESSION['comic_messages_csrf'] = bin2hex(random_bytes(32));
}

$messageCsrf = $_SESSION['comic_messages_csrf'];

$messageFlash = $_SESSION['comic_messages_flash'] ?? null;
unset($_SESSION['comic_messages_flash']);

$messageErrors = [];

/* =========================================================
   4. XỬ LÝ ĐÁNH DẤU ĐỌC VÀ XÓA TIN NHẮN
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $token = isset($_POST['csrf_token'])
        && is_string($_POST['csrf_token'])
        ? $_POST['csrf_token']
        : '';

    if (!hash_equals($messageCsrf, $token)) {
        comic_messages_flash(
            'error',
            'Phiên làm việc hết hạn. Vui lòng thử lại.'
        );

        comic_messages_redirect();
    }

    $postAction = isset($_POST['action'])
        && is_string($_POST['action'])
        ? $_POST['action']
        : '';

    $id = (int)($_POST['id'] ?? 0);

    if (!$messageDbReady) {
        comic_messages_flash(
            'error',
            'Chưa kết nối được database. Hãy kiểm tra config/db.php.'
        );

        comic_messages_redirect();
    }

    if ($id < 1) {
        comic_messages_flash(
            'error',
            'ID tin nhắn không hợp lệ.'
        );

        comic_messages_redirect();
    }

    try {
        $existing = comic_messages_query(
            $messageDb,
            'SELECT id FROM contact_messages WHERE id = ? LIMIT 1',
            [$id]
        )['rows'];

        if (!$existing) {
            comic_messages_flash(
                'error',
                'Tin nhắn không tồn tại hoặc đã bị xóa.'
            );

            comic_messages_redirect();
        }

        if ($postAction === 'mark_read') {
            comic_messages_query(
                $messageDb,
                'UPDATE contact_messages SET is_read = 1 WHERE id = ?',
                [$id]
            );

            comic_messages_flash(
                'success',
                'Đã đánh dấu tin nhắn là đã đọc.'
            );

        } elseif ($postAction === 'mark_unread') {
            comic_messages_query(
                $messageDb,
                'UPDATE contact_messages SET is_read = 0 WHERE id = ?',
                [$id]
            );

            comic_messages_flash(
                'success',
                'Đã đánh dấu tin nhắn là chưa đọc.'
            );

        } elseif ($postAction === 'delete') {
            comic_messages_query(
                $messageDb,
                'DELETE FROM contact_messages WHERE id = ?',
                [$id]
            );

            comic_messages_flash(
                'success',
                'Đã xóa tin nhắn.'
            );

            $_SESSION['comic_messages_csrf'] =
                bin2hex(random_bytes(32));

        } else {
            comic_messages_flash(
                'error',
                'Thao tác không hợp lệ.'
            );
        }

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Messages] ' . $exception->getMessage()
        );

        comic_messages_flash(
            'error',
            'Không thể xử lý tin nhắn. Vui lòng thử lại.'
        );
    }

    $redirectId = $postAction !== 'delete' &&
        in_array($postAction, ['mark_read', 'mark_unread'], true)
        ? $id
        : 0;

    if ($redirectId > 0) {
        comic_messages_redirect(
            'messages.php?action=view&id=' . $redirectId
        );
    }

    comic_messages_redirect();
}

/* =========================================================
   5. THAM SỐ TÌM KIẾM VÀ LỌC
========================================================= */

$action = isset($_GET['action']) && is_string($_GET['action'])
    ? $_GET['action']
    : 'list';

if (!in_array($action, ['list', 'view'], true)) {
    $action = 'list';
}

$viewId = max(0, (int)($_GET['id'] ?? 0));

$search = isset($_GET['q']) && is_string($_GET['q'])
    ? trim($_GET['q'])
    : '';

$statusFilter = isset($_GET['status'])
    && is_string($_GET['status'])
    ? $_GET['status']
    : 'all';

if (!in_array($statusFilter, ['all', 'unread', 'read'], true)) {
    $statusFilter = 'all';
}

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 10;

$totalMessages = 0;
$totalPages = 1;
$messageRows = [];
$viewMessage = null;

$stats = [
    'total' => 0,
    'unread' => 0,
    'read' => 0,
];

/* =========================================================
   6. XEM CHI TIẾT TIN NHẮN
========================================================= */

if ($messageDbReady && $action === 'view' && $viewId > 0) {
    try {
        $viewRows = comic_messages_query(
            $messageDb,
            'SELECT id, full_name, email, subject, message, is_read, created_at
             FROM contact_messages
             WHERE id = ?
             LIMIT 1',
            [$viewId]
        )['rows'];

        $viewMessage = $viewRows[0] ?? null;

        if (!$viewMessage) {
            $action = 'list';

            comic_messages_flash(
                'error',
                'Không tìm thấy tin nhắn cần xem.'
            );

        }

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Messages] ' . $exception->getMessage()
        );

        $messageErrors[] = 'Không tải được nội dung tin nhắn.';
        $action = 'list';
    }
}

/* =========================================================
   7. THỐNG KÊ VÀ DANH SÁCH TIN NHẮN
========================================================= */

if ($messageDbReady && $action === 'list') {
    try {
        $statsRows = comic_messages_query(
            $messageDb,
            'SELECT
                COUNT(*) AS total,
                COALESCE(SUM(CASE WHEN is_read = 0 THEN 1 ELSE 0 END), 0)
                    AS unread,
                COALESCE(SUM(CASE WHEN is_read = 1 THEN 1 ELSE 0 END), 0)
                    AS read_count
             FROM contact_messages'
        )['rows'];

        if ($statsRows) {
            $stats['total'] = (int)$statsRows[0]['total'];
            $stats['unread'] = (int)$statsRows[0]['unread'];
            $stats['read'] = (int)$statsRows[0]['read_count'];
        }

        $conditions = [];
        $params = [];

        if ($search !== '') {
            $conditions[] = '(
                full_name LIKE ?
                OR email LIKE ?
                OR subject LIKE ?
                OR message LIKE ?
            )';

            $like = '%' . $search . '%';

            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        if ($statusFilter === 'unread') {
            $conditions[] = 'is_read = 0';

        } elseif ($statusFilter === 'read') {
            $conditions[] = 'is_read = 1';
        }

        $whereSql = $conditions
            ? ' WHERE ' . implode(' AND ', $conditions)
            : '';

        $countRows = comic_messages_query(
            $messageDb,
            'SELECT COUNT(*) AS total
             FROM contact_messages' . $whereSql,
            $params
        )['rows'];

        $totalMessages = (int)($countRows[0]['total'] ?? 0);

        $totalPages = max(
            1,
            (int)ceil($totalMessages / $perPage)
        );

        $page = min($page, $totalPages);
        $offset = ($page - 1) * $perPage;

        $listParams = $params;
        $listParams[] = $perPage;
        $listParams[] = $offset;

        $messageRows = comic_messages_query(
            $messageDb,
            'SELECT id, full_name, email, subject, message, is_read, created_at
             FROM contact_messages' . $whereSql . '
             ORDER BY is_read ASC, created_at DESC, id DESC
             LIMIT ? OFFSET ?',
            $listParams
        )['rows'];

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Messages] ' . $exception->getMessage()
        );

        $messageErrors[] =
            'Không tải được danh sách tin nhắn. Hãy kiểm tra cấu trúc database.';
    }
}

/* =========================================================
   8. CHUẨN BỊ GIAO DIỆN
========================================================= */

$pageTitle = $action === 'view'
    ? 'Chi tiết tin nhắn'
    : 'Tin nhắn liên hệ';

$pageDescription = 'Quản lý các câu hỏi và tin nhắn của khách hàng.';
$activeMenu = 'messages';

require_once __DIR__ . '/includes/header.php';
?>

<style>
.messages-admin{color:#f2f2f2}
.messages-admin .ma-alert{margin-bottom:17px;padding:12px 15px;border:1px solid rgba(255,107,96,.4);border-left:4px solid #ff6b60;background:rgba(255,107,96,.14);color:#ff8f86;font-size:12px;line-height:1.7}
.messages-admin .ma-alert.success{border-color:rgba(80,200,130,.4);border-left-color:#50c882;background:rgba(80,200,130,.16);color:#6fdc9c}
.messages-admin .ma-stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-bottom:20px}
.messages-admin .ma-stat{padding:17px;border:1px solid #3d3d44;border-radius:20px;background:#232327;box-shadow:0 4px 18px rgba(0,0,0,0.15)}
.messages-admin .ma-stat span{display:block;color:#a9a9b2;font-size:11px;font-weight:700}
.messages-admin .ma-stat strong{display:block;margin-top:7px;font-size:25px;font-weight:850}
.messages-admin .ma-toolbar{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:17px}
.messages-admin .ma-search{display:flex;flex:1;flex-wrap:wrap;gap:8px}
.messages-admin .ma-search input,.messages-admin .ma-search select{box-sizing:border-box;min-height:39px;padding:9px 12px;border:1px solid #3d3d44;border-radius:12px;background:#232327;color:#f2f2f2;font:inherit;font-size:12px}
.messages-admin .ma-search input{min-width:190px;flex:1}
.messages-admin .ma-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:35px;padding:8px 12px;border:1px solid transparent;border-radius:999px;background:#f2f2f2;color:#111111;font-size:12px;font-weight:800;text-decoration:none;cursor:pointer;white-space:nowrap}
.messages-admin .ma-btn:hover{background:#ffffff;color:#111111}
.messages-admin .ma-btn.secondary{border-color:#3d3d44;background:#232327;color:#d4d4da}
.messages-admin .ma-btn.secondary:hover{border-color:#f2f2f2;color:#f2f2f2}
.messages-admin .ma-btn.danger{border-color:rgba(255,107,96,.4);background:rgba(255,107,96,.14);color:#ff8f86}
.messages-admin .ma-panel{overflow:hidden;border:1px solid #3d3d44;border-radius:20px;background:#232327;box-shadow:0 4px 18px rgba(0,0,0,0.2)}
.messages-admin .ma-panel-head{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:17px 19px;border-bottom:1px solid #3d3d44}
.messages-admin .ma-panel-head h2{margin:0;font-size:15px;font-weight:850}
.messages-admin .ma-muted{color:#a9a9b2;font-size:11px;line-height:1.7}
.messages-admin .ma-table-wrap{width:100%;overflow-x:auto}
.messages-admin table{width:100%;min-width:740px;border-collapse:collapse}
.messages-admin th{padding:12px 14px;background:#2c2c31;color:#a9a9b2;text-align:left;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.04em}
.messages-admin td{padding:13px 14px;border-top:1px solid #3d3d44;vertical-align:middle;font-size:12px}
.messages-admin tbody tr.unread{background:#2c2c31}
.messages-admin .ma-person{display:block;color:#f2f2f2;font-size:12px;font-weight:850}
.messages-admin .ma-email{display:block;margin-top:5px;color:#a9a9b2;font-size:11px;overflow-wrap:anywhere}
.messages-admin .ma-subject{display:block;color:#303743;font-size:12px;font-weight:800}
.messages-admin .ma-preview{display:block;max-width:330px;margin-top:5px;color:#a9a9b2;font-size:11px;line-height:1.6}
.messages-admin .ma-status{display:inline-flex;padding:5px 8px;border-radius:5px;font-size:10px;font-weight:800;white-space:nowrap}
.messages-admin .ma-status.unread{background:rgba(255,107,96,.14);color:#ff8f86}
.messages-admin .ma-status.read{background:rgba(80,200,130,.16);color:#6fdc9c}
.messages-admin .ma-actions{display:flex;flex-wrap:wrap;gap:6px}
.messages-admin .ma-actions form{margin:0}
.messages-admin .ma-empty{padding:45px 20px;text-align:center;color:#a9a9b2;font-size:13px}
.messages-admin .ma-pagination{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;padding:15px 18px;border-top:1px solid #3d3d44}
.messages-admin .ma-pages{display:flex;align-items:center;gap:5px}
.messages-admin .ma-pages a,.messages-admin .ma-pages span{display:inline-flex;min-width:32px;height:32px;align-items:center;justify-content:center;border:1px solid #3d3d44;border-radius:6px;color:#d4d4da;text-decoration:none;font-size:12px}
.messages-admin .ma-pages a:hover,.messages-admin .ma-pages .current{border-color:#f2f2f2;background:#f2f2f2;color:#111111}
.messages-admin .ma-detail{padding:21px}
.messages-admin .ma-detail-meta{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-bottom:22px}
.messages-admin .ma-meta-item{padding:13px;border:1px solid #3d3d44;border-radius:8px;background:#2c2c31}
.messages-admin .ma-meta-label{display:block;margin-bottom:6px;color:#a9a9b2;font-size:10px;font-weight:800;text-transform:uppercase}
.messages-admin .ma-meta-value{font-size:13px;font-weight:700;overflow-wrap:anywhere}
.messages-admin .ma-message-body{padding:18px;border:1px solid #3d3d44;border-radius:9px;background:#fcfcfd;font-size:13px;line-height:1.9;white-space:pre-wrap;overflow-wrap:anywhere}
.messages-admin .ma-detail-actions{display:flex;align-items:center;flex-wrap:wrap;gap:8px;margin-top:20px}
.messages-admin .ma-detail-actions form{margin:0}
@media(max-width:700px){.messages-admin .ma-stats{grid-template-columns:1fr}.messages-admin .ma-toolbar{align-items:stretch}.messages-admin .ma-search{flex-basis:100%}.messages-admin .ma-detail-meta{grid-template-columns:1fr}}
</style>

<div class="messages-admin">

    <?php if (is_array($messageFlash) && !empty($messageFlash['message'])): ?>
        <div class="ma-alert <?= ($messageFlash['type'] ?? '') === 'success' ? 'success' : '' ?>" role="status">
            <?= comic_messages_escape($messageFlash['message']) ?>
        </div>
    <?php endif; ?>

    <?php if (!$messageDbReady): ?>
        <div class="ma-alert" role="alert">
            Không tìm thấy kết nối database. Hãy kiểm tra
            <strong>config/db.php</strong> và
            <strong>admin/includes/bootstrap.php</strong>.
        </div>
    <?php endif; ?>

    <?php if ($messageErrors): ?>
        <div class="ma-alert" role="alert">
            <strong>Cần kiểm tra:</strong>
            <ul style="margin:7px 0 0;padding-left:19px">
                <?php foreach ($messageErrors as $error): ?>
                    <li><?= comic_messages_escape($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($action === 'view' && is_array($viewMessage)): ?>

        <div class="ma-toolbar">
            <div>
                <h2 style="margin:0;font-size:20px;font-weight:850">
                    Chi tiết tin nhắn
                </h2>

                <p class="ma-muted" style="margin:5px 0 0">
                    Tin nhắn #<?= (int)$viewMessage['id'] ?>
                </p>
            </div>

            <a class="ma-btn secondary" href="messages.php">← Quay lại danh sách</a>
        </div>

        <section class="ma-panel">
            <div class="ma-panel-head">
                <h2>
                    <?= comic_messages_escape(
                        $viewMessage['subject'] ?: 'Không có tiêu đề'
                    ) ?>
                </h2>

                <?php if ((int)$viewMessage['is_read'] === 1): ?>
                    <span class="ma-status read">Đã đọc</span>
                <?php else: ?>
                    <span class="ma-status unread">Chưa đọc</span>
                <?php endif; ?>
            </div>

            <div class="ma-detail">
                <div class="ma-detail-meta">
                    <div class="ma-meta-item">
                        <span class="ma-meta-label">Người gửi</span>

                        <div class="ma-meta-value">
                            <?= comic_messages_escape($viewMessage['full_name']) ?>
                        </div>
                    </div>

                    <div class="ma-meta-item">
                        <span class="ma-meta-label">Email</span>

                        <div class="ma-meta-value">
                            <a href="mailto:<?= comic_messages_escape($viewMessage['email']) ?>">
                                <?= comic_messages_escape($viewMessage['email']) ?>
                            </a>
                        </div>
                    </div>

                    <div class="ma-meta-item">
                        <span class="ma-meta-label">Ngày gửi</span>

                        <div class="ma-meta-value">
                            <?= comic_messages_escape(
                                date(
                                    'd/m/Y H:i:s',
                                    strtotime((string)$viewMessage['created_at'])
                                )
                            ) ?>
                        </div>
                    </div>

                    <div class="ma-meta-item">
                        <span class="ma-meta-label">Trạng thái</span>

                        <div class="ma-meta-value">
                            <?= (int)$viewMessage['is_read'] === 1
                                ? 'Đã đọc'
                                : 'Chưa đọc' ?>
                        </div>
                    </div>
                </div>

                <h3 style="margin:0 0 10px;font-size:13px;font-weight:850">
                    Nội dung tin nhắn
                </h3>

                <div class="ma-message-body"><?= comic_messages_escape($viewMessage['message']) ?></div>

                <div class="ma-detail-actions">
                    <a
                        class="ma-btn"
                        href="mailto:<?= comic_messages_escape($viewMessage['email']) ?>?subject=<?= rawurlencode('Re: ' . (string)($viewMessage['subject'] ?? '')) ?>"
                    >
                        Trả lời qua email
                    </a>

                    <form method="post" action="messages.php">
                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= comic_messages_escape($messageCsrf) ?>"
                        >

                        <input
                            type="hidden"
                            name="id"
                            value="<?= (int)$viewMessage['id'] ?>"
                        >

                        <?php if ((int)$viewMessage['is_read'] === 1): ?>
                            <input type="hidden" name="action" value="mark_unread">

                            <button type="submit" class="ma-btn secondary">
                                Đánh dấu chưa đọc
                            </button>
                        <?php else: ?>
                            <input type="hidden" name="action" value="mark_read">

                            <button type="submit" class="ma-btn secondary">
                                Đánh dấu đã đọc
                            </button>
                        <?php endif; ?>
                    </form>

                    <form
                        method="post"
                        action="messages.php"
                        data-confirm="Bạn có chắc muốn xóa tin nhắn này? Thao tác không thể hoàn tác."
                    >
                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= comic_messages_escape($messageCsrf) ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="delete"
                        >

                        <input
                            type="hidden"
                            name="id"
                            value="<?= (int)$viewMessage['id'] ?>"
                        >

                        <button type="submit" class="ma-btn danger">
                            Xóa tin nhắn
                        </button>
                    </form>
                </div>
            </div>
        </section>

    <?php else: ?>

        <section class="ma-stats" aria-label="Thống kê tin nhắn">
            <div class="ma-stat">
                <span>Tổng tin nhắn</span>
                <strong><?= number_format($stats['total']) ?></strong>
            </div>

            <div class="ma-stat">
                <span>Chưa đọc</span>
                <strong style="color:#f2f2f2">
                    <?= number_format($stats['unread']) ?>
                </strong>
            </div>

            <div class="ma-stat">
                <span>Đã đọc</span>
                <strong style="color:#6fdc9c">
                    <?= number_format($stats['read']) ?>
                </strong>
            </div>
        </section>

        <div class="ma-toolbar">
            <form class="ma-search" method="get" action="messages.php">
                <input
                    type="search"
                    name="q"
                    value="<?= comic_messages_escape($search) ?>"
                    placeholder="Tìm tên, email, tiêu đề hoặc nội dung..."
                    aria-label="Tìm kiếm tin nhắn"
                >

                <select name="status" aria-label="Lọc trạng thái">
                    <option value="all" <?= $statusFilter === 'all' ? 'selected' : '' ?>>
                        Tất cả trạng thái
                    </option>

                    <option value="unread" <?= $statusFilter === 'unread' ? 'selected' : '' ?>>
                        Chưa đọc
                    </option>

                    <option value="read" <?= $statusFilter === 'read' ? 'selected' : '' ?>>
                        Đã đọc
                    </option>
                </select>

                <button type="submit" class="ma-btn secondary">
                    Tìm kiếm
                </button>

                <?php if ($search !== '' || $statusFilter !== 'all'): ?>
                    <a class="ma-btn secondary" href="messages.php">
                        Xóa bộ lọc
                    </a>
                <?php endif; ?>
            </form>
        </div>

        <section class="ma-panel">
            <div class="ma-panel-head">
                <h2>Danh sách tin nhắn khách hàng</h2>

                <span class="ma-muted">
                    <?= number_format($totalMessages) ?> kết quả
                </span>
            </div>

            <?php if (!$messageDbReady): ?>

                <div class="ma-empty">
                    Cần kết nối database để xem tin nhắn.
                </div>

            <?php elseif (!$messageRows): ?>

                <div class="ma-empty">
                    <div style="font-size:30px;margin-bottom:10px">✉</div>
                    Không tìm thấy tin nhắn nào phù hợp.
                </div>

            <?php else: ?>

                <div class="ma-table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>Người gửi</th>
                                <th>Nội dung</th>
                                <th>Ngày gửi</th>
                                <th>Trạng thái</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php foreach ($messageRows as $item): ?>
                                <?php
                                $isRead = (int)$item['is_read'] === 1;
                                $preview = trim((string)$item['message']);

                                if (function_exists('mb_strlen') && mb_strlen($preview, 'UTF-8') > 100) {
                                    $preview = mb_substr($preview, 0, 100, 'UTF-8') . '…';
                                } elseif (strlen($preview) > 100) {
                                    $preview = substr($preview, 0, 100) . '…';
                                }
                                ?>

                                <tr class="<?= $isRead ? '' : 'unread' ?>">
                                    <td>
                                        <span class="ma-person">
                                            <?= comic_messages_escape($item['full_name']) ?>
                                        </span>

                                        <span class="ma-email">
                                            <?= comic_messages_escape($item['email']) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <span class="ma-subject">
                                            <?= comic_messages_escape(
                                                $item['subject'] ?: 'Không có tiêu đề'
                                            ) ?>
                                        </span>

                                        <span class="ma-preview">
                                            <?= comic_messages_escape($preview) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <?= comic_messages_escape(
                                            date(
                                                'd/m/Y H:i',
                                                strtotime((string)$item['created_at'])
                                            )
                                        ) ?>
                                    </td>

                                    <td>
                                        <?php if ($isRead): ?>
                                            <span class="ma-status read">Đã đọc</span>
                                        <?php else: ?>
                                            <span class="ma-status unread">Chưa đọc</span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <div class="ma-actions">
                                            <a
                                                class="ma-btn secondary"
                                                href="messages.php?action=view&amp;id=<?= (int)$item['id'] ?>"
                                            >
                                                Xem
                                            </a>

                                            <form method="post" action="messages.php">
                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?= comic_messages_escape($messageCsrf) ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="id"
                                                    value="<?= (int)$item['id'] ?>"
                                                >

                                                <?php if ($isRead): ?>
                                                    <input type="hidden" name="action" value="mark_unread">

                                                    <button type="submit" class="ma-btn secondary">
                                                        Chưa đọc
                                                    </button>
                                                <?php else: ?>
                                                    <input type="hidden" name="action" value="mark_read">

                                                    <button type="submit" class="ma-btn secondary">
                                                        Đã đọc
                                                    </button>
                                                <?php endif; ?>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="ma-pagination">
                    <span class="ma-muted">
                        Hiển thị
                        <?= number_format(($page - 1) * $perPage + 1) ?>–<?= number_format(min($totalMessages, ($page - 1) * $perPage + count($messageRows))) ?>
                        trong <?= number_format($totalMessages) ?> tin nhắn
                    </span>

                    <?php if ($totalPages > 1): ?>
                        <nav class="ma-pages" aria-label="Phân trang">
                            <?php
                            $queryBase = [];

                            if ($search !== '') {
                                $queryBase['q'] = $search;
                            }

                            if ($statusFilter !== 'all') {
                                $queryBase['status'] = $statusFilter;
                            }

                            if ($page > 1) {
                                $url = 'messages.php?' . http_build_query(
                                    array_merge($queryBase, ['page' => $page - 1])
                                );

                                echo '<a href="' .
                                    comic_messages_escape($url) .
                                    '" aria-label="Trang trước">‹</a>';
                            }

                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);

                            for (
                                $pageNumber = $startPage;
                                $pageNumber <= $endPage;
                                $pageNumber++
                            ) {
                                $url = 'messages.php?' . http_build_query(
                                    array_merge(
                                        $queryBase,
                                        ['page' => $pageNumber]
                                    )
                                );

                                if ($pageNumber === $page) {
                                    echo '<span class="current" aria-current="page">' .
                                        $pageNumber . '</span>';
                                } else {
                                    echo '<a href="' .
                                        comic_messages_escape($url) .
                                        '">' . $pageNumber . '</a>';
                                }
                            }

                            if ($page < $totalPages) {
                                $url = 'messages.php?' . http_build_query(
                                    array_merge($queryBase, ['page' => $page + 1])
                                );

                                echo '<a href="' .
                                    comic_messages_escape($url) .
                                    '" aria-label="Trang tiếp">›</a>';
                            }
                            ?>
                        </nav>
                    <?php endif; ?>
                </div>

            <?php endif; ?>
        </section>

    <?php endif; ?>

</div>

<script>
(function () {
    'use strict';

    document.querySelectorAll(
        '.messages-admin form[data-confirm]'
    ).forEach(function (form) {
        form.addEventListener('submit', function (event) {
            var message = form.getAttribute('data-confirm');

            if (message && !window.confirm(message)) {
                event.preventDefault();
            }
        });
    });
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
