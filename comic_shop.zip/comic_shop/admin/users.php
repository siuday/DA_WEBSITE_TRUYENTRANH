<?php
declare(strict_types=1);

/**
 * Comic Shop - Admin User Management
 * File: admin/users.php
 *
 * Chức năng:
 * - Danh sách và tìm kiếm tài khoản.
 * - Lọc theo vai trò và trạng thái.
 * - Tạo tài khoản khách hàng / nhân viên.
 * - Chỉnh sửa thông tin tài khoản.
 * - Đặt lại mật khẩu cho tài khoản.
 * - Kích hoạt / vô hiệu hóa tài khoản.
 * - Bảo vệ tài khoản admin cuối cùng đang hoạt động.
 * - Xóa tài khoản nhân viên / khách hàng chưa có đơn hàng.
 *
 * Dùng bảng users trong comic_shop.sql.
 */

$pageTitle = 'Quản lý người dùng';
$pageDescription = 'Quản lý tài khoản khách hàng, nhân viên và quản trị viên.';
$activeMenu = 'users';

require_once __DIR__ . '/includes/bootstrap.php';

if (
    !function_exists('comic_admin_media_url') &&
    is_file(__DIR__ . '/includes/media.php')
) {
    require_once __DIR__ . '/includes/media.php';
}

/* Dự phòng nếu thiếu includes/media.php: chỉ trả về đường dẫn ảnh. */
if (!function_exists('comic_admin_media_url')) {
    function comic_admin_media_url(
        ?string $path,
        string $label = '',
        string $kind = 'cover'
    ): string {
        $path = trim(str_replace('\\', '/', (string) $path));

        if ($path === '' || preg_match('~^(https?:)?//|^data:~i', $path)) {
            return $path;
        }

        return '../' . ltrim($path, '/');
    }
}

$database = $GLOBALS['comic_shop_db'] ?? null;

$dbReady = $database instanceof PDO ||
    (class_exists('mysqli') && $database instanceof mysqli);

/* =========================================================
   1. HÀM TRUY VẤN DATABASE
========================================================= */

if (!function_exists('comic_admin_users_query')) {
    function comic_admin_users_query(
        $database,
        string $sql,
        array $params = []
    ): array {
        if ($database instanceof PDO) {
            $stmt = $database->prepare($sql);
            $stmt->execute($params);

            $rows = $stmt->columnCount() > 0
                ? $stmt->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $affected = $stmt->rowCount();

            $stmt->closeCursor();

            return [
                'rows' => $rows,
                'affected' => $affected,
            ];
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            $stmt = $database->prepare($sql);

            if (!$stmt) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn MySQL.'
                );
            }

            if ($params !== []) {
                $types = '';
                $values = [];

                foreach ($params as $index => $value) {
                    if (is_int($value) || is_bool($value)) {
                        $types .= 'i';
                    } elseif (is_float($value)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }

                    $values[$index] = $params[$index];
                }

                $arguments = [$types];

                foreach ($values as &$value) {
                    $arguments[] = &$value;
                }

                unset($value);

                if (!call_user_func_array(
                    [$stmt, 'bind_param'],
                    $arguments
                )) {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không thể gắn tham số truy vấn.'
                    );
                }
            }

            if (!$stmt->execute()) {
                $message = $stmt->error;
                $stmt->close();

                throw new RuntimeException(
                    $message ?: 'Truy vấn MySQL thất bại.'
                );
            }

            $rows = [];

            if ($stmt->field_count > 0) {
                $result = $stmt->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không thể đọc kết quả truy vấn.'
                    );
                }
            }

            $affected = $stmt->affected_rows;
            $stmt->close();

            return [
                'rows' => $rows,
                'affected' => $affected,
            ];
        }

        throw new RuntimeException(
            'Không có kết nối PDO/MySQLi hợp lệ.'
        );
    }
}

/* =========================================================
   2. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_admin_users_escape')) {
    function comic_admin_users_escape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_admin_users_redirect')) {
    function comic_admin_users_redirect(
        string $url = 'users.php'
    ): void {
        header('Location: ' . $url, true, 303);
        exit;
    }
}

if (!function_exists('comic_admin_users_flash')) {
    function comic_admin_users_flash(
        string $type,
        string $message
    ): void {
        $_SESSION['comic_users_flash'] = [
            'type' => $type,
            'message' => $message,
        ];
    }
}

if (!function_exists('comic_admin_users_role_info')) {
    function comic_admin_users_role_info(string $role): array
    {
        $roles = [
            'customer' => [
                'label' => 'Khách hàng',
                'class' => 'customer',
            ],
            'staff' => [
                'label' => 'Nhân viên',
                'class' => 'staff',
            ],
            'admin' => [
                'label' => 'Quản trị viên',
                'class' => 'admin',
            ],
        ];

        return $roles[$role] ?? [
            'label' => 'Không xác định',
            'class' => 'unknown',
        ];
    }
}

/**
 * Xác định ID của tài khoản admin đang đăng nhập.
 */
$currentAdminId = 0;

if (isset($_SESSION['admin_id'])) {
    $currentAdminId = (int) $_SESSION['admin_id'];
} elseif (
    isset($_SESSION['user']['id']) &&
    is_array($_SESSION['user'])
) {
    $currentAdminId = (int) $_SESSION['user']['id'];
} elseif (
    isset($_SESSION['admin']['id']) &&
    is_array($_SESSION['admin'])
) {
    $currentAdminId = (int) $_SESSION['admin']['id'];
}

/* =========================================================
   3. KHỞI TẠO TRẠNG THÁI
========================================================= */

$flash = $_SESSION['comic_users_flash'] ?? null;
unset($_SESSION['comic_users_flash']);

$errors = [];

$action = isset($_GET['action']) && is_string($_GET['action'])
    ? $_GET['action']
    : 'list';

$editId = max(0, (int) ($_GET['id'] ?? 0));

if (!in_array($action, ['list', 'create', 'edit'], true)) {
    $action = 'list';
}

$formData = [
    'full_name' => '',
    'email' => '',
    'phone' => '',
    'address' => '',
    'avatar' => '',
    'role' => 'customer',
    'is_active' => 1,
    'password' => '',
];

$hasSubmittedForm = false;

/* =========================================================
   4. XỬ LÝ FORM POST
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $token = isset($_POST['csrf_token']) &&
        is_string($_POST['csrf_token'])
            ? $_POST['csrf_token']
            : '';

    if (
        !function_exists('comic_admin_csrf_valid') ||
        !comic_admin_csrf_valid($token)
    ) {
        comic_admin_users_flash(
            'error',
            'Phiên làm việc đã hết hạn. Vui lòng thử lại.'
        );

        comic_admin_users_redirect();
    }

    $postAction = isset($_POST['action']) &&
        is_string($_POST['action'])
            ? $_POST['action']
            : '';

    if (!$dbReady) {
        comic_admin_users_flash(
            'error',
            'Chưa kết nối được cơ sở dữ liệu. Kiểm tra config/db.php.'
        );

        comic_admin_users_redirect();
    }

    if ($postAction === 'save') {
        $hasSubmittedForm = true;

        $mode = isset($_POST['form_mode']) &&
            $_POST['form_mode'] === 'edit'
                ? 'edit'
                : 'create';

        $action = $mode;
        $editId = (int) ($_POST['id'] ?? 0);

        $formData = [
            'full_name' => trim(
                (string) ($_POST['full_name'] ?? '')
            ),
            'email' => strtolower(
                trim((string) ($_POST['email'] ?? ''))
            ),
            'phone' => trim(
                (string) ($_POST['phone'] ?? '')
            ),
            'address' => trim(
                (string) ($_POST['address'] ?? '')
            ),
            'avatar' => trim(
                (string) ($_POST['avatar'] ?? '')
            ),
            'role' => isset($_POST['role']) &&
                is_string($_POST['role'])
                    ? $_POST['role']
                    : 'customer',
            'is_active' => isset($_POST['is_active'])
                ? 1
                : 0,
            'password' => isset($_POST['password']) &&
                is_string($_POST['password'])
                    ? $_POST['password']
                    : '',
        ];

        $name = $formData['full_name'];
        $email = $formData['email'];
        $phone = $formData['phone'];
        $address = $formData['address'];
        $avatar = $formData['avatar'];
        $role = $formData['role'];
        $isActive = (int) $formData['is_active'];
        $password = $formData['password'];

        $nameLength = function_exists('mb_strlen')
            ? mb_strlen($name, 'UTF-8')
            : strlen($name);

        /* Kiểm tra dữ liệu nhập. */

        if ($name === '' || $nameLength > 120) {
            $errors[] =
                'Họ tên là bắt buộc và không vượt quá 120 ký tự.';
        }

        if (
            $email === '' ||
            strlen($email) > 150 ||
            filter_var($email, FILTER_VALIDATE_EMAIL) === false
        ) {
            $errors[] = 'Địa chỉ email không hợp lệ.';
        }

        if (strlen($phone) > 20) {
            $errors[] =
                'Số điện thoại không được vượt quá 20 ký tự.';
        } elseif (
            $phone !== '' &&
            !preg_match('/^[0-9+\s().-]{7,20}$/', $phone)
        ) {
            $errors[] = 'Số điện thoại không đúng định dạng.';
        }

        if (strlen($address) > 255) {
            $errors[] =
                'Địa chỉ không được vượt quá 255 ký tự.';
        }

        if (strlen($avatar) > 255) {
            $errors[] =
                'Đường dẫn ảnh đại diện không được vượt quá 255 ký tự.';
        }

        if (!in_array(
            $role,
            ['customer', 'staff', 'admin'],
            true
        )) {
            $errors[] = 'Vai trò tài khoản không hợp lệ.';
        }

        /*
         * Không cho tạo admin thông qua form tạo tài khoản mới.
         * Quyền admin mới nên được cấp qua quy trình riêng.
         */
        if ($mode === 'create' && $role === 'admin') {
            $errors[] =
                'Không thể tạo tài khoản admin mới từ biểu mẫu này.';
        }

        if ($mode === 'create') {
            if (strlen($password) < 8 || strlen($password) > 72) {
                $errors[] =
                    'Mật khẩu phải có ít nhất 8 ký tự và tối đa 72 byte.';
            }
        } elseif (
            $password !== '' &&
            (
                strlen($password) < 8 ||
                strlen($password) > 72
            )
        ) {
            $errors[] =
                'Mật khẩu mới phải có ít nhất 8 ký tự và tối đa 72 byte.';
        }

        /*
         * Không cho tài khoản admin đang đăng nhập tự khóa
         * hoặc tự hạ quyền của chính mình.
         */
        if (
            $mode === 'edit' &&
            $editId > 0 &&
            $editId === $currentAdminId &&
            ($role !== 'admin' || $isActive !== 1)
        ) {
            $errors[] =
                'Bạn không thể tự hạ quyền hoặc vô hiệu hóa tài khoản đang đăng nhập.';
        }

        if (!$errors) {
            try {
                /*
                 * Kiểm tra email trùng trước khi ghi.
                 */
                if ($mode === 'edit') {
                    if ($editId < 1) {
                        $errors[] =
                            'ID tài khoản cần sửa không hợp lệ.';
                    } else {
                        $existingUser = comic_admin_users_query(
                            $database,
                            'SELECT id, role, is_active
                             FROM users
                             WHERE id = ?
                             LIMIT 1',
                            [$editId]
                        )['rows'][0] ?? null;

                        if (!$existingUser) {
                            $errors[] =
                                'Tài khoản cần sửa không còn tồn tại.';
                        }
                    }
                }

                if (!$errors) {
                    $emailSql = 'SELECT id
                        FROM users
                        WHERE email = ?';

                    $emailParams = [$email];

                    if ($mode === 'edit') {
                        $emailSql .= ' AND id <> ?';
                        $emailParams[] = $editId;
                    }

                    $emailSql .= ' LIMIT 1';

                    $duplicate = comic_admin_users_query(
                        $database,
                        $emailSql,
                        $emailParams
                    )['rows'];

                    if ($duplicate) {
                        $errors[] =
                            'Email này đã được tài khoản khác sử dụng.';
                    }
                }

                /*
                 * Không cho vô hiệu hóa hoặc hạ quyền admin cuối cùng.
                 */
                if (
                    !$errors &&
                    $mode === 'edit' &&
                    $existingUser &&
                    (string) $existingUser['role'] === 'admin' &&
                    (int) $existingUser['is_active'] === 1 &&
                    ($role !== 'admin' || $isActive !== 1)
                ) {
                    $otherAdmins = (int) (
                        comic_admin_users_query(
                            $database,
                            "SELECT COUNT(*) AS total
                             FROM users
                             WHERE role = 'admin'
                               AND is_active = 1
                               AND id <> ?",
                            [$editId]
                        )['rows'][0]['total'] ?? 0
                    );

                    if ($otherAdmins < 1) {
                        $errors[] =
                            'Không thể hạ quyền hoặc vô hiệu hóa admin cuối cùng đang hoạt động.';
                    }
                }

                if (!$errors && $mode === 'create') {
                    $passwordHash = password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    );

                    if ($passwordHash === false) {
                        throw new RuntimeException(
                            'Không thể mã hóa mật khẩu.'
                        );
                    }

                    comic_admin_users_query(
                        $database,
                        'INSERT INTO users (
                            full_name,
                            email,
                            password,
                            phone,
                            address,
                            role,
                            avatar,
                            is_active
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                        [
                            $name,
                            $email,
                            $passwordHash,
                            $phone !== '' ? $phone : null,
                            $address !== '' ? $address : null,
                            $role,
                            $avatar !== '' ? $avatar : null,
                            $isActive,
                        ]
                    );

                    comic_admin_users_flash(
                        'success',
                        'Đã tạo tài khoản "' . $name . '" thành công.'
                    );

                    $_SESSION['comic_admin_csrf'] =
                        bin2hex(random_bytes(32));

                    comic_admin_users_redirect();
                }

                if (!$errors && $mode === 'edit') {
                    if ($password !== '') {
                        $passwordHash = password_hash(
                            $password,
                            PASSWORD_DEFAULT
                        );

                        if ($passwordHash === false) {
                            throw new RuntimeException(
                                'Không thể mã hóa mật khẩu mới.'
                            );
                        }

                        comic_admin_users_query(
                            $database,
                            'UPDATE users
                             SET full_name = ?,
                                 email = ?,
                                 phone = ?,
                                 address = ?,
                                 role = ?,
                                 avatar = ?,
                                 is_active = ?,
                                 password = ?
                             WHERE id = ?',
                            [
                                $name,
                                $email,
                                $phone !== '' ? $phone : null,
                                $address !== '' ? $address : null,
                                $role,
                                $avatar !== '' ? $avatar : null,
                                $isActive,
                                $passwordHash,
                                $editId,
                            ]
                        );
                    } else {
                        comic_admin_users_query(
                            $database,
                            'UPDATE users
                             SET full_name = ?,
                                 email = ?,
                                 phone = ?,
                                 address = ?,
                                 role = ?,
                                 avatar = ?,
                                 is_active = ?
                             WHERE id = ?',
                            [
                                $name,
                                $email,
                                $phone !== '' ? $phone : null,
                                $address !== '' ? $address : null,
                                $role,
                                $avatar !== '' ? $avatar : null,
                                $isActive,
                                $editId,
                            ]
                        );
                    }

                    /*
                     * Đồng bộ thông tin trong session hiện tại nếu
                     * quản trị viên sửa chính hồ sơ của mình mà không
                     * thay đổi quyền hoặc trạng thái.
                     */
                    if ($editId === $currentAdminId) {
                        if (isset($_SESSION['user']) &&
                            is_array($_SESSION['user'])) {
                            $_SESSION['user']['full_name'] = $name;
                            $_SESSION['user']['email'] = $email;
                            $_SESSION['user']['phone'] = $phone;
                            $_SESSION['user']['address'] = $address;
                            $_SESSION['user']['avatar'] = $avatar;
                            $_SESSION['user']['role'] = 'admin';
                        }

                        if (isset($_SESSION['admin']) &&
                            is_array($_SESSION['admin'])) {
                            $_SESSION['admin']['full_name'] = $name;
                            $_SESSION['admin']['email'] = $email;
                            $_SESSION['admin']['phone'] = $phone;
                            $_SESSION['admin']['address'] = $address;
                            $_SESSION['admin']['avatar'] = $avatar;
                            $_SESSION['admin']['role'] = 'admin';
                        }
                    }

                    comic_admin_users_flash(
                        'success',
                        'Đã cập nhật tài khoản "' . $name . '".'
                    );

                    $_SESSION['comic_admin_csrf'] =
                        bin2hex(random_bytes(32));

                    comic_admin_users_redirect();
                }

            } catch (Throwable $exception) {
                error_log(
                    '[Comic Shop Admin Users] ' .
                    $exception->getMessage()
                );

                $errors[] =
                    'Không lưu được tài khoản. Hãy kiểm tra dữ liệu, '
                    . 'kết nối database và nhật ký PHP.';
            }
        }
    } elseif ($postAction === 'delete') {
        /*
         * Chỉ xóa tài khoản nhân viên hoặc khách hàng.
         * Không xóa admin, không xóa chính mình và không xóa
         * tài khoản đã có đơn hàng để bảo toàn lịch sử bán hàng.
         */
        $deleteId = (int) ($_POST['id'] ?? 0);

        try {
            if ($deleteId < 1) {
                comic_admin_users_flash(
                    'error',
                    'ID tài khoản không hợp lệ.'
                );

                comic_admin_users_redirect();
            }

            if ($currentAdminId > 0 && $deleteId === $currentAdminId) {
                comic_admin_users_flash(
                    'error',
                    'Bạn không thể xóa tài khoản đang đăng nhập.'
                );

                comic_admin_users_redirect();
            }

            $targetRows = comic_admin_users_query(
                $database,
                'SELECT id, full_name, role
                 FROM users
                 WHERE id = ?
                 LIMIT 1',
                [$deleteId]
            )['rows'];

            if (!$targetRows) {
                comic_admin_users_flash(
                    'error',
                    'Không tìm thấy tài khoản cần xóa.'
                );

                comic_admin_users_redirect();
            }

            $targetUser = $targetRows[0];

            if (
                !in_array(
                    (string) $targetUser['role'],
                    ['staff', 'customer'],
                    true
                )
            ) {
                comic_admin_users_flash(
                    'error',
                    'Chỉ có thể xóa tài khoản nhân viên hoặc khách hàng.'
                );

                comic_admin_users_redirect();
            }

            $orderTotal = (int) (
                comic_admin_users_query(
                    $database,
                    'SELECT COUNT(*) AS total
                     FROM orders
                     WHERE user_id = ?',
                    [$deleteId]
                )['rows'][0]['total'] ?? 0
            );

            if ($orderTotal > 0) {
                comic_admin_users_flash(
                    'error',
                    'Không thể xóa "' . (string) $targetUser['full_name'] .
                    '" vì đã có ' . $orderTotal . ' đơn hàng. ' .
                    'Hãy khóa tài khoản thay vì xóa để giữ lịch sử đơn hàng.'
                );

                comic_admin_users_redirect();
            }

            comic_admin_users_query(
                $database,
                "DELETE FROM users
                 WHERE id = ?
                   AND role IN ('staff', 'customer')",
                [$deleteId]
            );

            comic_admin_users_flash(
                'success',
                'Đã xóa tài khoản "' .
                (string) $targetUser['full_name'] . '".'
            );

            $_SESSION['comic_admin_csrf'] =
                bin2hex(random_bytes(32));

            comic_admin_users_redirect();

        } catch (Throwable $exception) {
            error_log(
                '[Comic Shop Admin Users] ' .
                $exception->getMessage()
            );

            comic_admin_users_flash(
                'error',
                'Không thể xóa tài khoản. Tài khoản có thể còn dữ liệu ' .
                'liên quan (đánh giá, giỏ hàng...). Hãy khóa tài khoản thay vì xóa.'
            );

            comic_admin_users_redirect();
        }
    } else {
        comic_admin_users_flash(
            'error',
            'Thao tác không hợp lệ.'
        );

        comic_admin_users_redirect();
    }
}

/* =========================================================
   5. TẢI TÀI KHOẢN CẦN CHỈNH SỬA
========================================================= */

$editUser = null;

if ($dbReady && $action === 'edit' && $editId > 0) {
    try {
        $editUser = comic_admin_users_query(
            $database,
            'SELECT
                id,
                full_name,
                email,
                phone,
                address,
                role,
                avatar,
                is_active,
                created_at
             FROM users
             WHERE id = ?
             LIMIT 1',
            [$editId]
        )['rows'][0] ?? null;

        if (!$editUser) {
            $action = 'list';
            $errors[] = 'Không tìm thấy tài khoản cần chỉnh sửa.';
        } elseif (!$hasSubmittedForm) {
            $formData = [
                'full_name' => (string) ($editUser['full_name'] ?? ''),
                'email' => (string) ($editUser['email'] ?? ''),
                'phone' => (string) ($editUser['phone'] ?? ''),
                'address' => (string) ($editUser['address'] ?? ''),
                'avatar' => (string) ($editUser['avatar'] ?? ''),
                'role' => (string) ($editUser['role'] ?? 'customer'),
                'is_active' => (int) ($editUser['is_active'] ?? 1),
                'password' => '',
            ];
        }
    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Admin Users] ' .
            $exception->getMessage()
        );

        $errors[] = 'Không tải được thông tin tài khoản.';
        $action = 'list';
    }
}

/* =========================================================
   6. THỐNG KÊ NGƯỜI DÙNG
========================================================= */

$stats = [
    'total' => 0,
    'active' => 0,
    'customers' => 0,
    'staff' => 0,
    'admins' => 0,
];

if ($dbReady) {
    try {
        $statRows = comic_admin_users_query(
            $database,
            "SELECT
                COUNT(*) AS total_users,
                COALESCE(SUM(is_active = 1), 0) AS active_users,
                COALESCE(SUM(role = 'customer'), 0) AS customers,
                COALESCE(SUM(role = 'staff'), 0) AS staff,
                COALESCE(SUM(role = 'admin'), 0) AS admins
             FROM users"
        )['rows'];

        if ($statRows) {
            $stats = [
                'total' => (int) $statRows[0]['total_users'],
                'active' => (int) $statRows[0]['active_users'],
                'customers' => (int) $statRows[0]['customers'],
                'staff' => (int) $statRows[0]['staff'],
                'admins' => (int) $statRows[0]['admins'],
            ];
        }
    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Admin Users Stats] ' .
            $exception->getMessage()
        );

        $errors[] = 'Không tải được số liệu tài khoản.';
    }
}

/* =========================================================
   7. TÌM KIẾM, LỌC VÀ PHÂN TRANG
========================================================= */

$search = isset($_GET['q']) && is_string($_GET['q'])
    ? trim($_GET['q'])
    : '';

$roleFilter = isset($_GET['role']) &&
    is_string($_GET['role'])
        ? $_GET['role']
        : 'all';

if (!in_array(
    $roleFilter,
    ['all', 'customer', 'staff', 'admin'],
    true
)) {
    $roleFilter = 'all';
}

$statusFilter = isset($_GET['status']) &&
    is_string($_GET['status'])
        ? $_GET['status']
        : 'all';

if (!in_array(
    $statusFilter,
    ['all', 'active', 'inactive'],
    true
)) {
    $statusFilter = 'all';
}

$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;

$totalUsers = 0;
$totalPages = 1;
$userRows = [];
$offset = 0;

if ($dbReady && $action === 'list') {
    try {
        $where = [];
        $params = [];

        if ($search !== '') {
            $where[] = '(
                u.full_name LIKE ?
                OR u.email LIKE ?
                OR u.phone LIKE ?
            )';

            $like = '%' . $search . '%';

            array_push(
                $params,
                $like,
                $like,
                $like
            );
        }

        if ($roleFilter !== 'all') {
            $where[] = 'u.role = ?';
            $params[] = $roleFilter;
        }

        if ($statusFilter === 'active') {
            $where[] = 'u.is_active = 1';
        } elseif ($statusFilter === 'inactive') {
            $where[] = 'u.is_active = 0';
        }

        $whereSql = $where
            ? ' WHERE ' . implode(' AND ', $where)
            : '';

        $countRows = comic_admin_users_query(
            $database,
            'SELECT COUNT(*) AS total
             FROM users u' . $whereSql,
            $params
        )['rows'];

        $totalUsers = (int) (
            $countRows[0]['total'] ?? 0
        );

        $totalPages = max(
            1,
            (int) ceil($totalUsers / $perPage)
        );

        $page = min($page, $totalPages);
        $offset = ($page - 1) * $perPage;

        $listParams = $params;
        $listParams[] = $perPage;
        $listParams[] = $offset;

        $userRows = comic_admin_users_query(
            $database,
            'SELECT
                u.id,
                u.full_name,
                u.email,
                u.phone,
                u.address,
                u.role,
                u.avatar,
                u.is_active,
                u.created_at,
                (
                    SELECT COUNT(*)
                    FROM orders o
                    WHERE o.user_id = u.id
                ) AS order_count
             FROM users u'
             . $whereSql .
            ' ORDER BY u.created_at DESC, u.id DESC
              LIMIT ? OFFSET ?',
            $listParams
        )['rows'];

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Admin Users List] ' .
            $exception->getMessage()
        );

        $errors[] = 'Không tải được danh sách người dùng.';
    }
}

if ($action === 'create') {
    $pageTitle = 'Thêm tài khoản';
    $pageDescription = 'Tạo tài khoản khách hàng hoặc nhân viên.';
} elseif ($action === 'edit') {
    $pageTitle = 'Chỉnh sửa tài khoản';
    $pageDescription = 'Cập nhật thông tin và quyền tài khoản.';
}

require_once __DIR__ . '/includes/header.php';
?>

<style>
.users-admin {
    color: #f2f2f2;
}

.users-admin .ua-alert {
    margin-bottom: 17px;
    padding: 12px 15px;
    border: 1px solid rgba(255,107,96,.4);
    border-left: 4px solid #ff6b60;
    background: rgba(255,107,96,.14);
    color: #ff8f86;
    font-size: 12px;
    line-height: 1.65;
}

.users-admin .ua-alert.success {
    border-color: rgba(80,200,130,.4);
    border-left-color: #50c882;
    background: rgba(80,200,130,.16);
    color: #6fdc9c;
}

.users-admin .ua-stats {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 13px;
    margin-bottom: 21px;
}

.users-admin .ua-stat {
    min-width: 0;
    padding: 17px;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.2);
}

.users-admin .ua-stat-label {
    color: #a9a9b2;
    font-size: 11px;
    font-weight: 700;
}

.users-admin .ua-stat-value {
    display: block;
    margin-top: 7px;
    font-size: 25px;
    font-weight: 850;
}

.users-admin .ua-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
    margin-bottom: 17px;
}

.users-admin .ua-search {
    display: flex;
    align-items: center;
    flex: 1;
    flex-wrap: wrap;
    gap: 8px;
}

.users-admin .ua-search input,
.users-admin .ua-search select {
    min-height: 39px;
    padding: 9px 12px;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    background: #232327;
    color: #f2f2f2;
    font: inherit;
    font-size: 12px;
}

.users-admin .ua-search input {
    min-width: 190px;
    flex: 1;
}

.users-admin .ua-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    min-height: 36px;
    padding: 8px 12px;
    border: 1px solid transparent;
    border-radius: 999px;
    background: #f2f2f2;
    color: #111111;
    font-size: 12px;
    font-weight: 800;
    text-decoration: none;
    cursor: pointer;
}

.users-admin .ua-btn:hover {
    background: #ffffff;
    color: #111111;
}

.users-admin .ua-btn.secondary {
    border-color: #3d3d44;
    background: #232327;
    color: #d4d4da;
}

.users-admin .ua-btn.secondary:hover {
    border-color: #f2f2f2;
    color: #f2f2f2;
}

.users-admin .ua-btn.danger {
    border-color: rgba(255,107,96,.4);
    background: rgba(255,107,96,.14);
    color: #ff8f86;
}

.users-admin .ua-btn:disabled {
    cursor: not-allowed;
    opacity: .55;
}

.users-admin .ua-panel {
    min-width: 0;
    margin-bottom: 21px;
    overflow: hidden;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.2);
}

.users-admin .ua-panel-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 10px;
    padding: 17px 20px;
    border-bottom: 1px solid #3d3d44;
}

.users-admin .ua-panel-head h2 {
    margin: 0;
    font-size: 14px;
    font-weight: 850;
}

.users-admin .ua-muted {
    color: #a9a9b2;
    font-size: 11px;
}

.users-admin .ua-table-wrap {
    width: 100%;
    overflow-x: auto;
}

.users-admin table {
    width: 100%;
    border-collapse: collapse;
}

.users-admin th {
    padding: 13px 14px;
    border-bottom: 1px solid #3d3d44;
    background: #2c2c31;
    color: #a9a9b2;
    font-size: 10px;
    font-weight: 850;
    letter-spacing: .5px;
    text-align: left;
    text-transform: uppercase;
    white-space: nowrap;
}

.users-admin td {
    padding: 13px 14px;
    border-bottom: 1px solid #3d3d44;
    color: #d4d4da;
    font-size: 12px;
    vertical-align: middle;
}

.users-admin tbody tr:last-child td {
    border-bottom: 0;
}

.users-admin tbody tr:hover {
    background: #2c2c31;
}

.users-admin .ua-user {
    display: flex;
    align-items: center;
    gap: 10px;
    min-width: 195px;
}

.users-admin .ua-avatar {
    display: grid;
    width: 42px;
    height: 42px;
    flex: 0 0 42px;
    place-items: center;
    overflow: hidden;
    border-radius: 50%;
    background: #36363c;
    color: #f2f2f2;
    font-size: 15px;
    font-weight: 850;
}

.users-admin .ua-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.users-admin .ua-name {
    display: block;
    max-width: 230px;
    overflow: hidden;
    color: #f2f2f2;
    font-weight: 800;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.users-admin .ua-subtitle {
    display: block;
    max-width: 230px;
    overflow: hidden;
    margin-top: 4px;
    color: #a9a9b2;
    font-size: 10px;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.users-admin .ua-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 5px 9px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: 800;
    white-space: nowrap;
}

.users-admin .ua-badge.customer {
    background: rgba(120,150,255,.16);
    color: #9db6ff;
}

.users-admin .ua-badge.staff {
    background: rgba(240,180,60,.15);
    color: #f0c36d;
}

.users-admin .ua-badge.admin {
    background: rgba(255,107,96,.14);
    color: #ff8f86;
}

.users-admin .ua-badge.active {
    background: rgba(80,200,130,.16);
    color: #6fdc9c;
}

.users-admin .ua-badge.inactive {
    background: #36363c;
    color: #b5b5bd;
}

.users-admin .ua-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
}

.users-admin .ua-empty {
    padding: 38px 18px;
    color: #a9a9b2;
    font-size: 12px;
    text-align: center;
}

.users-admin .ua-pagination {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
    padding: 14px 17px;
    border-top: 1px solid #3d3d44;
}

.users-admin .ua-pages {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
}

.users-admin .ua-pages a,
.users-admin .ua-pages span {
    display: grid;
    min-width: 32px;
    height: 32px;
    padding: 0 8px;
    place-items: center;
    border: 1px solid #3d3d44;
    border-radius: 6px;
    background: #232327;
    color: #d4d4da;
    font-size: 11px;
    text-decoration: none;
}

.users-admin .ua-pages .current {
    border-color: #f2f2f2;
    background: #f2f2f2;
    color: #111111;
}

.users-admin .ua-form {
    max-width: 850px;
    overflow: hidden;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.2);
}

.users-admin .ua-form-body {
    padding: 22px;
}

.users-admin .ua-form-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0,1fr));
    gap: 17px;
}

.users-admin .ua-field {
    min-width: 0;
    margin-bottom: 2px;
}

.users-admin .ua-field.full {
    grid-column: 1 / -1;
}

.users-admin .ua-field label {
    display: block;
    margin-bottom: 7px;
    color: #363d48;
    font-size: 11px;
    font-weight: 800;
}

.users-admin .ua-field input,
.users-admin .ua-field select,
.users-admin .ua-field textarea {
    display: block;
    width: 100%;
    min-height: 41px;
    padding: 10px 12px;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    outline: none;
    background: #232327;
    color: #f2f2f2;
    font: inherit;
    font-size: 12px;
}

.users-admin .ua-field textarea {
    min-height: 85px;
    resize: vertical;
}

.users-admin .ua-field input:focus,
.users-admin .ua-field select:focus,
.users-admin .ua-field textarea:focus {
    border-color: #f2f2f2;
    box-shadow: 0 0 0 3px rgba(239,67,56,.1);
}

.users-admin .ua-help {
    margin-top: 6px;
    color: #a9a9b2;
    font-size: 10px;
    line-height: 1.6;
}

.users-admin .ua-check {
    display: flex;
    align-items: center;
    gap: 9px;
    margin-top: 18px;
    padding: 13px;
    border: 1px solid #3d3d44;
    border-radius: 8px;
    background: #2c2c31;
    color: #d4d4da;
    font-size: 12px;
    font-weight: 650;
}

.users-admin .ua-check input {
    width: 16px;
    height: 16px;
    accent-color: #f2f2f2;
}

.users-admin .ua-form-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 9px;
    margin-top: 22px;
    padding-top: 17px;
    border-top: 1px solid #3d3d44;
}

@media(max-width:1100px) {
    .users-admin .ua-stats {
        grid-template-columns: repeat(2,minmax(0,1fr));
    }
}

@media(max-width:650px) {
    .users-admin .ua-stats {
        gap: 9px;
    }

    .users-admin .ua-stat {
        padding: 13px;
    }

    .users-admin .ua-stat-value {
        font-size: 22px;
    }

    .users-admin .ua-toolbar {
        align-items: stretch;
    }

    .users-admin .ua-search {
        width: 100%;
    }

    .users-admin .ua-search input {
        min-width: 0;
    }

    .users-admin .ua-form-grid {
        grid-template-columns: 1fr;
    }

    .users-admin .ua-field.full {
        grid-column: auto;
    }

    .users-admin .ua-form-body {
        padding: 15px;
    }
}
</style>

<div class="users-admin">

    <?php if (is_array($flash) && !empty($flash['message'])): ?>
        <div
            class="ua-alert <?= ($flash['type'] ?? '') === 'success' ? 'success' : '' ?>"
            role="status"
        >
            <?= comic_admin_users_escape($flash['message']) ?>
        </div>
    <?php endif; ?>

    <?php if (!$dbReady): ?>
        <div class="ua-alert" role="alert">
            Không tìm thấy kết nối cơ sở dữ liệu. Hãy kiểm tra
            config/db.php và admin/includes/bootstrap.php.
        </div>
    <?php endif; ?>

    <?php if ($errors): ?>
        <div class="ua-alert" role="alert">
            <strong>Cần kiểm tra:</strong>

            <ul style="margin:7px 0 0;padding-left:19px">
                <?php foreach ($errors as $error): ?>
                    <li><?= comic_admin_users_escape($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($action === 'create' || $action === 'edit'): ?>

        <div class="ua-toolbar">
            <div>
                <h2 style="margin:0;font-size:20px;font-weight:850">
                    <?= $action === 'edit'
                        ? 'Chỉnh sửa tài khoản'
                        : 'Tạo tài khoản mới' ?>
                </h2>

                <p class="ua-muted" style="margin:5px 0 0">
                    Không nhập mật khẩu mới nếu muốn giữ nguyên mật khẩu hiện tại.
                </p>
            </div>

            <a class="ua-btn secondary" href="users.php">
                ← Quay lại danh sách
            </a>
        </div>

        <section class="ua-form">

            <div class="ua-panel-head">
                <h2>Thông tin tài khoản</h2>
            </div>

            <div class="ua-form-body">

                <form method="post" action="users.php" autocomplete="off">

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= comic_admin_users_escape(
                            comic_admin_csrf_token()
                        ) ?>"
                    >

                    <input type="hidden" name="action" value="save">

                    <input
                        type="hidden"
                        name="form_mode"
                        value="<?= comic_admin_users_escape($action) ?>"
                    >

                    <input
                        type="hidden"
                        name="id"
                        value="<?= (int) $editId ?>"
                    >

                    <div class="ua-form-grid">

                        <div class="ua-field">
                            <label for="user-name">Họ và tên *</label>

                            <input
                                id="user-name"
                                type="text"
                                name="full_name"
                                maxlength="120"
                                required
                                value="<?= comic_admin_users_escape($formData['full_name']) ?>"
                                placeholder="Nguyễn Văn An"
                            >
                        </div>

                        <div class="ua-field">
                            <label for="user-email">Email *</label>

                            <input
                                id="user-email"
                                type="email"
                                name="email"
                                maxlength="150"
                                required
                                autocomplete="email"
                                value="<?= comic_admin_users_escape($formData['email']) ?>"
                                placeholder="email@example.com"
                            >
                        </div>

                        <div class="ua-field">
                            <label for="user-phone">Số điện thoại</label>

                            <input
                                id="user-phone"
                                type="tel"
                                name="phone"
                                maxlength="20"
                                autocomplete="tel"
                                value="<?= comic_admin_users_escape($formData['phone']) ?>"
                                placeholder="09xxxxxxxx"
                            >
                        </div>

                        <div class="ua-field">
                            <label for="user-role">Vai trò *</label>

                            <select id="user-role" name="role" required>

                                <option
                                    value="customer"
                                    <?= $formData['role'] === 'customer' ? 'selected' : '' ?>
                                >
                                    Khách hàng
                                </option>

                                <option
                                    value="staff"
                                    <?= $formData['role'] === 'staff' ? 'selected' : '' ?>
                                >
                                    Nhân viên
                                </option>

                                <?php if ($action === 'edit'): ?>
                                    <option
                                        value="admin"
                                        <?= $formData['role'] === 'admin' ? 'selected' : '' ?>
                                    >
                                        Quản trị viên
                                    </option>
                                <?php endif; ?>

                            </select>

                            <?php if ($action === 'create'): ?>
                                <div class="ua-help">
                                    Form tạo mới chỉ cho phép tạo khách hàng
                                    hoặc nhân viên. Không cấp quyền admin từ đây.
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="ua-field full">
                            <label for="user-address">Địa chỉ</label>

                            <textarea
                                id="user-address"
                                name="address"
                                maxlength="255"
                                rows="3"
                                placeholder="Địa chỉ liên hệ hoặc giao hàng"
                            ><?= comic_admin_users_escape($formData['address']) ?></textarea>
                        </div>

                        <div class="ua-field full">
                            <label for="user-avatar">
                                Đường dẫn ảnh đại diện
                            </label>

                            <input
                                id="user-avatar"
                                type="text"
                                name="avatar"
                                maxlength="255"
                                value="<?= comic_admin_users_escape($formData['avatar']) ?>"
                                placeholder="assets/images/avatars/user.jpg"
                            >

                            <div class="ua-help">
                                Trường này lưu đường dẫn ảnh, không tải ảnh lên máy chủ.
                            </div>
                        </div>

                        <div class="ua-field full">
                            <label for="user-password">
                                <?= $action === 'edit'
                                    ? 'Mật khẩu mới (không bắt buộc)'
                                    : 'Mật khẩu ban đầu *' ?>
                            </label>

                            <input
                                id="user-password"
                                type="password"
                                name="password"
                                minlength="8"
                                maxlength="72"
                                <?= $action === 'create' ? 'required' : '' ?>
                                autocomplete="new-password"
                                placeholder="<?= $action === 'edit'
                                    ? 'Để trống để giữ nguyên mật khẩu'
                                    : 'Ít nhất 8 ký tự' ?>"
                                value=""
                            >

                            <div class="ua-help">
                                Mật khẩu được lưu dưới dạng hash bằng password_hash().
                                Không hiển thị mật khẩu hiện tại.
                            </div>
                        </div>

                    </div>

                    <label class="ua-check">
                        <input
                            type="checkbox"
                            name="is_active"
                            value="1"
                            <?= (int) $formData['is_active'] === 1 ? 'checked' : '' ?>
                            <?= (int) $editId === $currentAdminId ? 'disabled' : '' ?>
                        >

                        <span>Tài khoản đang hoạt động</span>

                        <?php if ((int) $editId === $currentAdminId): ?>
                            <input
                                type="hidden"
                                name="is_active"
                                value="1"
                            >

                            <span class="ua-muted">
                                (Không thể tự khóa tài khoản)
                            </span>
                        <?php endif; ?>
                    </label>

                    <div class="ua-form-actions">

                        <button class="ua-btn" type="submit">
                            <?= $action === 'edit'
                                ? 'Lưu thay đổi'
                                : 'Tạo tài khoản' ?>
                        </button>

                        <a class="ua-btn secondary" href="users.php">
                            Hủy
                        </a>

                    </div>

                </form>
            </div>
        </section>

    <?php else: ?>

        <!-- THỐNG KÊ -->

        <section class="ua-stats" aria-label="Thống kê tài khoản">

            <article class="ua-stat">
                <span class="ua-stat-label">Tổng tài khoản</span>

                <strong class="ua-stat-value">
                    <?= number_format($stats['total']) ?>
                </strong>
            </article>

            <article class="ua-stat">
                <span class="ua-stat-label">Đang hoạt động</span>

                <strong class="ua-stat-value" style="color:#6fdc9c">
                    <?= number_format($stats['active']) ?>
                </strong>
            </article>

            <article class="ua-stat">
                <span class="ua-stat-label">Khách hàng</span>

                <strong class="ua-stat-value" style="color:#9db6ff">
                    <?= number_format($stats['customers']) ?>
                </strong>
            </article>

            <article class="ua-stat">
                <span class="ua-stat-label">Nhân viên / Admin</span>

                <strong class="ua-stat-value" style="color:#f2f2f2">
                    <?= number_format($stats['staff'] + $stats['admins']) ?>
                </strong>

                <span class="ua-muted">
                    <?= number_format($stats['staff']) ?> nhân viên ·
                    <?= number_format($stats['admins']) ?> admin
                </span>
            </article>

        </section>

        <!-- TÌM KIẾM VÀ LỌC -->

        <div class="ua-toolbar">

            <form class="ua-search" method="get" action="users.php">

                <input
                    type="search"
                    name="q"
                    value="<?= comic_admin_users_escape($search) ?>"
                    placeholder="Tìm tên, email hoặc số điện thoại..."
                    aria-label="Tìm người dùng"
                >

                <select name="role" aria-label="Lọc vai trò">
                    <option value="all">Tất cả vai trò</option>

                    <option
                        value="customer"
                        <?= $roleFilter === 'customer' ? 'selected' : '' ?>
                    >
                        Khách hàng
                    </option>

                    <option
                        value="staff"
                        <?= $roleFilter === 'staff' ? 'selected' : '' ?>
                    >
                        Nhân viên
                    </option>

                    <option
                        value="admin"
                        <?= $roleFilter === 'admin' ? 'selected' : '' ?>
                    >
                        Quản trị viên
                    </option>
                </select>

                <select name="status" aria-label="Lọc trạng thái">
                    <option
                        value="all"
                        <?= $statusFilter === 'all' ? 'selected' : '' ?>
                    >
                        Mọi trạng thái
                    </option>

                    <option
                        value="active"
                        <?= $statusFilter === 'active' ? 'selected' : '' ?>
                    >
                        Đang hoạt động
                    </option>

                    <option
                        value="inactive"
                        <?= $statusFilter === 'inactive' ? 'selected' : '' ?>
                    >
                        Đã khóa
                    </option>
                </select>

                <button class="ua-btn secondary" type="submit">
                    Tìm kiếm
                </button>

                <?php if (
                    $search !== '' ||
                    $roleFilter !== 'all' ||
                    $statusFilter !== 'all'
                ): ?>
                    <a class="ua-btn secondary" href="users.php">
                        Xóa lọc
                    </a>
                <?php endif; ?>

            </form>

            <a class="ua-btn" href="users.php?action=create">
                ＋ Thêm tài khoản
            </a>

        </div>

        <!-- DANH SÁCH TÀI KHOẢN -->

        <section class="ua-panel">

            <div class="ua-panel-head">
                <div>
                    <h2>Danh sách tài khoản</h2>

                    <div class="ua-muted" style="margin-top:4px">
                        Chỉ xóa được tài khoản nhân viên, khách hàng chưa có đơn hàng.
                    </div>
                </div>

                <span class="ua-muted">
                    <?= number_format($totalUsers) ?> kết quả
                </span>
            </div>

            <?php if (!$dbReady): ?>

                <div class="ua-empty">
                    Cần kết nối cơ sở dữ liệu để xem tài khoản.
                </div>

            <?php elseif (!$userRows): ?>

                <div class="ua-empty">
                    <div style="font-size:30px;margin-bottom:9px">
                        ♙
                    </div>

                    Không tìm thấy tài khoản phù hợp.

                    <div style="margin-top:14px">
                        <a class="ua-btn" href="users.php?action=create">
                            Thêm tài khoản đầu tiên
                        </a>
                    </div>
                </div>

            <?php else: ?>

                <div class="ua-table-wrap">

                    <table>

                        <thead>
                            <tr>
                                <th>Người dùng</th>
                                <th>Liên hệ</th>
                                <th>Vai trò</th>
                                <th>Đơn hàng</th>
                                <th>Trạng thái</th>
                                <th>Ngày tạo</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach ($userRows as $user): ?>

                                <?php
                                $roleInfo = comic_admin_users_role_info(
                                    (string) $user['role']
                                );

                                $active = (int) $user['is_active'] === 1;

                                $createdAt = !empty($user['created_at'])
                                    ? strtotime((string) $user['created_at'])
                                    : false;

                                $avatar = comic_admin_media_url(
                                    (string) ($user['avatar'] ?? ''),
                                    (string) ($user['full_name'] ?? ''),
                                    'avatar'
                                );

                                $initial = function_exists('mb_substr')
                                    ? mb_strtoupper(
                                        mb_substr(
                                            (string) $user['full_name'],
                                            0,
                                            1,
                                            'UTF-8'
                                        ),
                                        'UTF-8'
                                    )
                                    : strtoupper(
                                        substr(
                                            (string) $user['full_name'],
                                            0,
                                            1
                                        )
                                    );
                                ?>

                                <tr>

                                    <td>
                                        <div class="ua-user">

                                            <span class="ua-avatar">

                                                <?php if ($avatar !== ''): ?>

                                                    <img
                                                        src="<?= comic_admin_users_escape($avatar) ?>"
                                                        alt=""
                                                        loading="lazy"
                                                        onerror="this.style.display='none';this.parentElement.textContent='<?= comic_admin_users_escape($initial) ?>';"
                                                    >

                                                <?php else: ?>

                                                    <?= comic_admin_users_escape($initial) ?>

                                                <?php endif; ?>

                                            </span>

                                            <span>
                                                <span class="ua-name">
                                                    <?= comic_admin_users_escape(
                                                        $user['full_name']
                                                    ) ?>
                                                </span>

                                                <span class="ua-subtitle">
                                                    ID #<?= (int) $user['id'] ?>

                                                    <?php if ((int) $user['id'] === $currentAdminId): ?>
                                                        · Bạn
                                                    <?php endif; ?>
                                                </span>
                                            </span>

                                        </div>
                                    </td>

                                    <td>
                                        <span style="display:block;max-width:220px;overflow-wrap:anywhere">
                                            <?= comic_admin_users_escape(
                                                $user['email']
                                            ) ?>
                                        </span>

                                        <span class="ua-subtitle">
                                            <?= comic_admin_users_escape(
                                                $user['phone'] ?: 'Chưa có số điện thoại'
                                            ) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <span class="ua-badge <?= comic_admin_users_escape(
                                            $roleInfo['class']
                                        ) ?>">
                                            <?= comic_admin_users_escape(
                                                $roleInfo['label']
                                            ) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <strong>
                                            <?= number_format(
                                                (int) $user['order_count']
                                            ) ?>
                                        </strong>
                                    </td>

                                    <td>
                                        <span class="ua-badge <?= $active
                                            ? 'active'
                                            : 'inactive' ?>">
                                            <?= $active
                                                ? 'Đang hoạt động'
                                                : 'Đã khóa' ?>
                                        </span>
                                    </td>

                                    <td style="white-space:nowrap">
                                        <?= $createdAt
                                            ? comic_admin_users_escape(
                                                date('d/m/Y', $createdAt)
                                            )
                                            : '—' ?>
                                    </td>

                                    <td>
                                        <div class="ua-actions">

                                            <a
                                                class="ua-btn secondary"
                                                href="users.php?action=edit&amp;id=<?= (int) $user['id'] ?>"
                                            >
                                                Sửa
                                            </a>

                                            <?php
                                            $canDelete =
                                                in_array(
                                                    (string) $user['role'],
                                                    ['staff', 'customer'],
                                                    true
                                                ) &&
                                                (int) $user['id'] !== $currentAdminId;
                                            ?>

                                            <?php if ($canDelete && (int) $user['order_count'] === 0): ?>

                                                <form
                                                    method="post"
                                                    action="users.php"
                                                    style="margin:0"
                                                    data-confirm="Bạn có chắc muốn xóa tài khoản &quot;<?= comic_admin_users_escape($user['full_name']) ?>&quot;? Thao tác này không thể hoàn tác."
                                                >
                                                    <input
                                                        type="hidden"
                                                        name="csrf_token"
                                                        value="<?= comic_admin_users_escape(
                                                            comic_admin_csrf_token()
                                                        ) ?>"
                                                    >

                                                    <input type="hidden" name="action" value="delete">

                                                    <input
                                                        type="hidden"
                                                        name="id"
                                                        value="<?= (int) $user['id'] ?>"
                                                    >

                                                    <button class="ua-btn danger" type="submit">
                                                        Xóa
                                                    </button>
                                                </form>

                                            <?php elseif ($canDelete): ?>

                                                <button
                                                    class="ua-btn secondary"
                                                    type="button"
                                                    disabled
                                                    title="Tài khoản đã có đơn hàng nên không thể xóa. Hãy khóa tài khoản thay vì xóa."
                                                >
                                                    Có đơn hàng
                                                </button>

                                            <?php endif; ?>

                                        </div>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>
                    </table>

                </div>

                <!-- PHÂN TRANG -->

                <div class="ua-pagination">

                    <span class="ua-muted">
                        Hiển thị
                        <?= number_format(
                            min(
                                $totalUsers,
                                $offset + ($totalUsers > 0 ? 1 : 0)
                            )
                        ) ?>–<?= number_format(
                            min(
                                $totalUsers,
                                $offset + count($userRows)
                            )
                        ) ?>
                        trong <?= number_format($totalUsers) ?> tài khoản
                    </span>

                    <?php if ($totalPages > 1): ?>

                        <nav class="ua-pages" aria-label="Phân trang">

                            <?php
                            $queryBase = [];

                            if ($search !== '') {
                                $queryBase['q'] = $search;
                            }

                            if ($roleFilter !== 'all') {
                                $queryBase['role'] = $roleFilter;
                            }

                            if ($statusFilter !== 'all') {
                                $queryBase['status'] = $statusFilter;
                            }

                            if ($page > 1) {
                                $prevUrl = 'users.php?' .
                                    http_build_query(
                                        array_merge(
                                            $queryBase,
                                            ['page' => $page - 1]
                                        )
                                    );

                                echo '<a href="' .
                                    comic_admin_users_escape($prevUrl) .
                                    '" aria-label="Trang trước">‹</a>';
                            }

                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);

                            for (
                                $i = $startPage;
                                $i <= $endPage;
                                $i++
                            ) {
                                $pageUrl = 'users.php?' .
                                    http_build_query(
                                        array_merge(
                                            $queryBase,
                                            ['page' => $i]
                                        )
                                    );

                                if ($i === $page) {
                                    echo '<span class="current" aria-current="page">' .
                                        $i . '</span>';
                                } else {
                                    echo '<a href="' .
                                        comic_admin_users_escape($pageUrl) .
                                        '">' . $i . '</a>';
                                }
                            }

                            if ($page < $totalPages) {
                                $nextUrl = 'users.php?' .
                                    http_build_query(
                                        array_merge(
                                            $queryBase,
                                            ['page' => $page + 1]
                                        )
                                    );

                                echo '<a href="' .
                                    comic_admin_users_escape($nextUrl) .
                                    '" aria-label="Trang sau">›</a>';
                            }
                            ?>

                        </nav>

                    <?php endif; ?>

                </div>

            <?php endif; ?>

        </section>

    <?php endif; ?>

</div>

<script>
(function () {
    'use strict';

    var password = document.getElementById('user-password');

    if (!password) {
        return;
    }

    /*
     * Không gửi mật khẩu cũ ra trình duyệt.
     * Chỉ cung cấp nút hiện/ẩn nội dung người dùng đang nhập.
     */
    var wrapper = document.createElement('div');
    wrapper.style.position = 'relative';

    password.parentNode.insertBefore(wrapper, password);
    wrapper.appendChild(password);

    password.style.paddingRight = '66px';

    var toggle = document.createElement('button');

    toggle.type = 'button';
    toggle.textContent = 'Hiện';
    toggle.setAttribute('aria-label', 'Hiện hoặc ẩn mật khẩu');
    toggle.style.cssText = [
        'position:absolute',
        'right:10px',
        'top:50%',
        'transform:translateY(-50%)',
        'border:0',
        'background:transparent',
        'color:#78818f',
        'font-size:11px',
        'font-weight:800',
        'cursor:pointer'
    ].join(';');

    wrapper.appendChild(toggle);

    toggle.addEventListener('click', function () {
        var show = password.type === 'password';

        password.type = show ? 'text' : 'password';
        toggle.textContent = show ? 'Ẩn' : 'Hiện';
    });
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
