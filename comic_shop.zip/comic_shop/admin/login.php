<?php
declare(strict_types=1);

/**
 * Comic Shop - Admin Login
 * File: admin/login.php
 *
 * Dùng bảng users:
 * id, full_name, email, password, role, is_active, avatar
 *
 * Không include bootstrap.php ở đây vì người dùng
 * chưa đăng nhập sẽ bị bootstrap chuyển hướng trở lại login.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. NẠP KẾT NỐI CƠ SỞ DỮ LIỆU
========================================================= */

$projectRoot = dirname(__DIR__);
$dbFile = $projectRoot . '/config/db.php';
$dbReturn = null;

if (is_file($dbFile)) {
    try {
        $dbReturn = require_once $dbFile;
    } catch (Throwable $e) {
        error_log('[Comic Shop Admin Login] DB config: ' . $e->getMessage());
    }
}

$database = null;

$candidates = [
    $dbReturn,
    $pdo ?? null,
    $conn ?? null,
    $mysqli ?? null,
    $db ?? null,
    $connection ?? null,
    $GLOBALS['pdo'] ?? null,
    $GLOBALS['conn'] ?? null,
    $GLOBALS['mysqli'] ?? null,
    $GLOBALS['db'] ?? null,
];

foreach ($candidates as $candidate) {
    if (
        $candidate instanceof PDO ||
        (class_exists('mysqli') && $candidate instanceof mysqli)
    ) {
        $database = $candidate;
        break;
    }
}

/* =========================================================
   2. KHỞI TẠO CSRF VÀ HÀM HỖ TRỢ
========================================================= */

if (
    !isset($_SESSION['comic_admin_login_csrf']) ||
    !is_string($_SESSION['comic_admin_login_csrf'])
) {
    $_SESSION['comic_admin_login_csrf'] = bin2hex(random_bytes(32));
}

if (!function_exists('comic_admin_login_escape')) {
    function comic_admin_login_escape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_admin_login_redirect')) {
    function comic_admin_login_redirect(): void
    {
        header('Location: login.php', true, 303);
        exit;
    }
}

if (!function_exists('comic_admin_login_set_flash')) {
    function comic_admin_login_set_flash(
        string $type,
        string $message
    ): void {
        $_SESSION['comic_admin_login_flash'] = [
            'type' => $type,
            'message' => $message,
        ];

        $_SESSION['comic_admin_login_csrf'] = bin2hex(random_bytes(32));
    }
}

/* =========================================================
   3. KIỂM TRA PHIÊN ADMIN ĐÃ CÓ
========================================================= */

$currentRole = '';

if (
    isset($_SESSION['user']) &&
    is_array($_SESSION['user']) &&
    isset($_SESSION['user']['role'])
) {
    $currentRole = strtolower(
        trim((string) $_SESSION['user']['role'])
    );
} elseif (isset($_SESSION['role'])) {
    $currentRole = strtolower(trim((string) $_SESSION['role']));
}

$alreadyAdmin =
    (
        isset($_SESSION['admin_id']) &&
        (int) $_SESSION['admin_id'] > 0
    ) ||
    in_array(
        $currentRole,
        ['admin', 'administrator', 'super_admin', 'superadmin'],
        true
    );

if ($alreadyAdmin) {
    header('Location: dashboard.php', true, 303);
    exit;
}

/* =========================================================
   4. GIỚI HẠN SỐ LẦN ĐĂNG NHẬP SAI
========================================================= */

$now = time();

$attempts = $_SESSION['comic_admin_login_attempts'] ?? [];

if (!is_array($attempts)) {
    $attempts = [];
}

$attempts = array_values(array_filter(
    $attempts,
    static function ($timestamp) use ($now): bool {
        return is_int($timestamp) &&
            $timestamp > $now - 900;
    }
));

$_SESSION['comic_admin_login_attempts'] = $attempts;

/*
 * Giới hạn 5 lần thử trong 15 phút cho phiên hiện tại.
 * Đây là lớp bảo vệ bổ sung, không thay thế rate limiting
 * phía máy chủ hoặc reverse proxy.
 */
$rateLimited = count($attempts) >= 5;

/* =========================================================
   5. XỬ LÝ ĐĂNG NHẬP
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $submittedToken =
        isset($_POST['csrf_token']) && is_string($_POST['csrf_token'])
            ? $_POST['csrf_token']
            : '';

    $expectedToken = $_SESSION['comic_admin_login_csrf'] ?? '';

    if (
        !is_string($expectedToken) ||
        $submittedToken === '' ||
        !hash_equals($expectedToken, $submittedToken)
    ) {
        comic_admin_login_set_flash(
            'error',
            'Phiên đăng nhập đã hết hạn. Vui lòng thử lại.'
        );

        comic_admin_login_redirect();
    }

    $email =
        isset($_POST['email']) && is_string($_POST['email'])
            ? strtolower(trim($_POST['email']))
            : '';

    $password =
        isset($_POST['password']) && is_string($_POST['password'])
            ? $_POST['password']
            : '';

    $_SESSION['comic_admin_login_old_email'] = $email;

    if ($rateLimited) {
        comic_admin_login_set_flash(
            'error',
            'Bạn đã thử đăng nhập quá nhiều lần. Vui lòng đợi 15 phút.'
        );

        comic_admin_login_redirect();
    }

    if (
        $email === '' ||
        strlen($email) > 150 ||
        filter_var($email, FILTER_VALIDATE_EMAIL) === false ||
        $password === '' ||
        strlen($password) > 4096
    ) {
        comic_admin_login_set_flash(
            'error',
            'Vui lòng nhập email hợp lệ và mật khẩu.'
        );

        comic_admin_login_redirect();
    }

    if (
        !($database instanceof PDO) &&
        !(class_exists('mysqli') && $database instanceof mysqli)
    ) {
        error_log(
            '[Comic Shop Admin Login] Không tìm thấy kết nối PDO/MySQLi.'
        );

        comic_admin_login_set_flash(
            'error',
            'Chưa kết nối được cơ sở dữ liệu. Hãy kiểm tra config/db.php.'
        );

        comic_admin_login_redirect();
    }

    $user = null;

    try {
        if ($database instanceof PDO) {
            $database->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );

            $stmt = $database->prepare(
                'SELECT id, full_name, email, password, role, is_active, avatar
                 FROM users
                 WHERE email = :email
                 LIMIT 1'
            );

            $stmt->execute(['email' => $email]);

            $user = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
            $stmt->closeCursor();
        } else {
            $stmt = $database->prepare(
                'SELECT id, full_name, email, password, role, is_active, avatar
                 FROM users
                 WHERE email = ?
                 LIMIT 1'
            );

            if (!$stmt) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn đăng nhập.'
                );
            }

            $stmt->bind_param('s', $email);
            $stmt->execute();

            $stmt->bind_result(
                $id,
                $fullName,
                $userEmail,
                $passwordHash,
                $role,
                $isActive,
                $avatar
            );

            if ($stmt->fetch()) {
                $user = [
                    'id' => $id,
                    'full_name' => $fullName,
                    'email' => $userEmail,
                    'password' => $passwordHash,
                    'role' => $role,
                    'is_active' => $isActive,
                    'avatar' => $avatar,
                ];
            }

            $stmt->close();
        }

        $passwordCorrect =
            is_array($user) &&
            isset($user['password']) &&
            is_string($user['password']) &&
            password_verify($password, $user['password']);

        $active =
            is_array($user) &&
            (int) ($user['is_active'] ?? 0) === 1;

        $roleAllowed =
            is_array($user) &&
            strtolower(trim((string) ($user['role'] ?? ''))) === 'admin';

        if (!$passwordCorrect || !$active || !$roleAllowed) {
            $_SESSION['comic_admin_login_attempts'][] = time();

            comic_admin_login_set_flash(
                'error',
                'Email hoặc mật khẩu không đúng, hoặc tài khoản không có quyền quản trị.'
            );

            comic_admin_login_redirect();
        }

        /* Đăng nhập thành công: tạo session ID mới. */
        if (!session_regenerate_id(true)) {
            throw new RuntimeException(
                'Không thể làm mới session khi đăng nhập.'
            );
        }

        /*
         * Các khóa session này tương thích với bootstrap.php
         * đã tạo ở bước trước.
         */
        $_SESSION['admin_id'] = (int) $user['id'];
        $_SESSION['role'] = 'admin';
        $_SESSION['admin_role'] = 'admin';

        $_SESSION['user'] = [
            'id' => (int) $user['id'],
            'full_name' => (string) $user['full_name'],
            'email' => (string) $user['email'],
            'role' => 'admin',
            'avatar' => $user['avatar'] ?? null,
        ];

        $_SESSION['admin'] = $_SESSION['user'];

        unset(
            $_SESSION['comic_admin_login_attempts'],
            $_SESSION['comic_admin_login_old_email'],
            $_SESSION['comic_admin_login_flash'],
            $_SESSION['comic_admin_login_csrf'],
            $_SESSION['admin_auth_message']
        );

        /*
         * Tùy chọn: nâng cấp hash nếu thuật toán mặc định thay đổi.
         * Nếu cập nhật hash thất bại thì vẫn giữ phiên đăng nhập.
         */
        if (password_needs_rehash(
            (string) $user['password'],
            PASSWORD_DEFAULT
        )) {
            try {
                $newHash = password_hash($password, PASSWORD_DEFAULT);

                if ($newHash !== false) {
                    if ($database instanceof PDO) {
                        $update = $database->prepare(
                            'UPDATE users SET password = :password WHERE id = :id'
                        );

                        $update->execute([
                            'password' => $newHash,
                            'id' => (int) $user['id'],
                        ]);
                    } else {
                        $update = $database->prepare(
                            'UPDATE users SET password = ? WHERE id = ?'
                        );

                        if ($update) {
                            $userId = (int) $user['id'];
                            $update->bind_param('si', $newHash, $userId);
                            $update->execute();
                            $update->close();
                        }
                    }
                }
            } catch (Throwable $e) {
                error_log(
                    '[Comic Shop Admin Login] Không thể nâng cấp hash mật khẩu.'
                );
            }
        }

        header('Location: dashboard.php', true, 303);
        exit;

    } catch (Throwable $e) {
        error_log(
            '[Comic Shop Admin Login] Lỗi: ' . $e->getMessage()
        );

        comic_admin_login_set_flash(
            'error',
            'Đã xảy ra lỗi khi đăng nhập. Kiểm tra cơ sở dữ liệu và nhật ký PHP.'
        );

        comic_admin_login_redirect();
    }
}

/* =========================================================
   6. DỮ LIỆU HIỂN THỊ
========================================================= */

$flash = $_SESSION['comic_admin_login_flash'] ?? null;
unset($_SESSION['comic_admin_login_flash']);

$flashMessage = '';
$flashType = 'info';

if (is_array($flash)) {
    $flashMessage = (string) ($flash['message'] ?? '');
    $candidateType = (string) ($flash['type'] ?? 'info');

    if (in_array($candidateType, ['error', 'success', 'warning', 'info'], true)) {
        $flashType = $candidateType;
    }
}

$oldEmail =
    isset($_SESSION['comic_admin_login_old_email']) &&
    is_string($_SESSION['comic_admin_login_old_email'])
        ? $_SESSION['comic_admin_login_old_email']
        : '';

unset($_SESSION['comic_admin_login_old_email']);

$csrfToken = $_SESSION['comic_admin_login_csrf'];

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">

    <title>Đăng nhập quản trị | Comic Shop</title>

    <link rel="stylesheet" href="../assets/css/admin.css">

    <style>
        :root {
            --login-red: #f2f2f2;
            --login-dark: #232327;
            --login-text: #f2f2f2;
            --login-muted: #a9a9b2;
            --login-line: #3d3d44;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            color: var(--login-text);
            background: #1c1c1f;
            font-family: Inter, -apple-system, BlinkMacSystemFont,
                "Segoe UI", Arial, sans-serif;
        }

        .login-page {
            display: grid;
            min-height: 100vh;
            grid-template-columns: minmax(0, 1fr) minmax(360px, 470px);
        }

        .login-visual {
            position: relative;
            display: flex;
            min-height: 100%;
            flex-direction: column;
            justify-content: space-between;
            overflow: hidden;
            padding: clamp(30px, 6vw, 76px);
            color: #f2f2f2;
            background:
                radial-gradient(
                    circle at 78% 24%,
                    rgba(255, 255, 255, 0.12),
                    transparent 29%
                ),
                radial-gradient(
                    circle at 18% 82%,
                    rgba(116, 147, 122, .24),
                    transparent 34%
                ),
                linear-gradient(145deg, #171d23, #263b37 62%, #17232b);
        }

        .login-visual::before {
            content: "COMIC SHOP";
            position: absolute;
            top: 34%;
            left: -12px;
            color: rgba(255,255,255,.045);
            font-size: clamp(65px, 10vw, 150px);
            line-height: 1;
            font-weight: 950;
            letter-spacing: -.07em;
            transform: rotate(-8deg);
            pointer-events: none;
            white-space: nowrap;
        }

        .login-brand {
            position: relative;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 15px;
            font-weight: 900;
            letter-spacing: .16em;
        }

        .login-brand-mark {
            display: grid;
            width: 42px;
            height: 42px;
            place-items: center;
            border-radius: 11px;
            background: var(--login-red);
            color: #111111;
            font-size: 21px;
            letter-spacing: 0;
        }

        .login-visual-copy {
            position: relative;
            max-width: 540px;
            padding: 50px 0;
        }

        .login-kicker {
            color: #ffc3ba;
            font-size: 11px;
            font-weight: 800;
            letter-spacing: .2em;
            text-transform: uppercase;
        }

        .login-visual h1 {
            margin: 17px 0;
            font-size: clamp(36px, 5vw, 64px);
            line-height: 1.03;
            letter-spacing: -.055em;
        }

        .login-visual p {
            max-width: 410px;
            margin: 0;
            color: rgba(255,255,255,.72);
            font-size: 14px;
            line-height: 1.9;
        }

        .login-visual-footer {
            position: relative;
            color: rgba(255,255,255,.48);
            font-size: 11px;
            letter-spacing: .04em;
        }

        .login-panel {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: clamp(22px, 4vw, 52px);
            background: #232327;
        }

        .login-box {
            width: 100%;
            max-width: 380px;
        }

        .login-eyebrow {
            color: var(--login-red);
            font-size: 11px;
            font-weight: 900;
            letter-spacing: .22em;
            text-transform: uppercase;
        }

        .login-box h2 {
            margin: 14px 0 8px;
            color: var(--login-text);
            font-size: 30px;
            line-height: 1.15;
            letter-spacing: -.045em;
        }

        .login-lead {
            margin: 0 0 28px;
            color: var(--login-muted);
            font-size: 13px;
            line-height: 1.8;
        }

        .login-alert {
            margin-bottom: 18px;
            padding: 12px 14px;
            border: 1px solid #f3d0cc;
            border-left: 3px solid var(--login-red);
            background: rgba(255,107,96,.14);
            color: #932c25;
            font-size: 12px;
            line-height: 1.6;
        }

        .login-alert.success {
            border-color: rgba(80,200,130,.4);
            border-left-color: #50c882;
            background: rgba(80,200,130,.16);
            color: #6fdc9c;
        }

        .login-field {
            display: block;
            margin-bottom: 19px;
        }

        .login-field label {
            display: block;
            margin-bottom: 8px;
            color: #373e49;
            font-size: 11px;
            font-weight: 850;
            letter-spacing: .06em;
            text-transform: uppercase;
        }

        .login-field input {
            display: block;
            width: 100%;
            min-height: 48px;
            padding: 12px 14px;
            border: 1px solid #dfe2e7;
            border-radius: 12px;
            outline: none;
            background: #232327;
            color: var(--login-text);
            font: inherit;
            font-size: 13px;
            transition: border-color .2s, box-shadow .2s;
        }

        .login-field input:focus {
            border-color: var(--login-red);
            box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.03);
        }

        .login-password-wrap {
            position: relative;
        }

        .login-password-wrap input {
            padding-right: 70px;
        }

        .login-show-password {
            position: absolute;
            top: 50%;
            right: 11px;
            transform: translateY(-50%);
            padding: 5px;
            border: 0;
            background: transparent;
            color: #707987;
            font-size: 11px;
            font-weight: 750;
            cursor: pointer;
        }

        .login-show-password:hover {
            color: var(--login-red);
        }

        .login-submit {
            display: flex;
            width: 100%;
            min-height: 49px;
            align-items: center;
            justify-content: center;
            margin-top: 7px;
            padding: 13px 16px;
            border: 0;
            border-radius: 6px;
            background: var(--login-red);
            color: #111111;
            font-size: 12px;
            font-weight: 900;
            letter-spacing: .13em;
            text-transform: uppercase;
            cursor: pointer;
            transition: background .2s, transform .2s;
        }

        .login-submit:hover {
            background: #ffffff;
            transform: translateY(-1px);
        }

        .login-submit:disabled {
            cursor: wait;
            opacity: .7;
            transform: none;
        }

        .login-links {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 22px;
            font-size: 12px;
        }

        .login-links a {
            color: var(--login-muted);
            text-decoration: none;
        }

        .login-links a:hover {
            color: var(--login-red);
        }

        .login-note {
            margin-top: 27px;
            padding-top: 17px;
            border-top: 1px solid var(--login-line);
            color: #8b929d;
            font-size: 11px;
            line-height: 1.7;
        }

        @media (max-width: 850px) {
            .login-page {
                grid-template-columns: 1fr;
                grid-template-rows: auto 1fr;
            }

            .login-visual {
                min-height: 240px;
                padding: 24px;
            }

            .login-visual-copy {
                padding: 30px 0 12px;
            }

            .login-visual h1 {
                font-size: 34px;
            }

            .login-visual p {
                font-size: 12px;
            }

            .login-visual-footer {
                display: none;
            }

            .login-panel {
                align-items: flex-start;
                padding: 35px 22px;
            }

            .login-box {
                max-width: 460px;
                margin: 0 auto;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                transition: none !important;
            }
        }
    </style>
</head>

<body>

<div class="login-page">

    <section class="login-visual">
        <div class="login-brand">
            <span class="login-brand-mark">C</span>
            <span>COMIC SHOP</span>
        </div>

        <div class="login-visual-copy">
            <div class="login-kicker">Administration portal</div>

            <h1>
                Quản lý tốt hơn.<br>
                Phục vụ tốt hơn.
            </h1>

            <p>
                Đăng nhập vào khu vực quản trị để quản lý truyện,
                tác giả, kho hàng, đơn hàng và hoạt động của cửa hàng.
            </p>
        </div>

        <div class="login-visual-footer">
            &copy; <?= date('Y') ?> Comic Shop · Admin Portal
        </div>
    </section>

    <section class="login-panel">
        <div class="login-box">

            <div class="login-eyebrow">Welcome back</div>

            <h2>Đăng nhập quản trị</h2>

            <p class="login-lead">
                Nhập tài khoản quản trị để tiếp tục.
            </p>

            <?php if ($flashMessage !== ''): ?>
                <div
                    class="login-alert <?= $flashType === 'success' ? 'success' : '' ?>"
                    role="<?= $flashType === 'error' ? 'alert' : 'status' ?>"
                >
                    <?= comic_admin_login_escape($flashMessage) ?>
                </div>
            <?php endif; ?>

            <?php if ($rateLimited): ?>
                <div class="login-alert" role="alert">
                    Phiên này đã có quá nhiều lần đăng nhập thất bại.
                    Vui lòng chờ 15 phút trước khi thử lại.
                </div>
            <?php endif; ?>

            <form method="post" action="login.php" autocomplete="on">

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= comic_admin_login_escape($csrfToken) ?>"
                >

                <label class="login-field">
                    <span> Email quản trị </span>

                    <input
                        type="email"
                        name="email"
                        value="<?= comic_admin_login_escape($oldEmail) ?>"
                        maxlength="150"
                        placeholder="admin@example.com"
                        autocomplete="username"
                        required
                        <?= $rateLimited ? 'disabled' : '' ?>
                    >
                </label>

                <div class="login-field">
                    <label for="admin-password">Mật khẩu</label>

                    <div class="login-password-wrap">
                        <input
                            id="admin-password"
                            type="password"
                            name="password"
                            placeholder="Nhập mật khẩu"
                            autocomplete="current-password"
                            required
                            <?= $rateLimited ? 'disabled' : '' ?>
                        >

                        <button
                            class="login-show-password"
                            type="button"
                            id="toggle-admin-password"
                            aria-controls="admin-password"
                            aria-pressed="false"
                            <?= $rateLimited ? 'disabled' : '' ?>
                        >
                            Hiện
                        </button>
                    </div>
                </div>

                <button
                    class="login-submit"
                    type="submit"
                    <?= $rateLimited ? 'disabled' : '' ?>
                >
                    Đăng nhập
                </button>

            </form>

            <div class="login-links">
                <a href="../forgot-password.php">
                    Quên mật khẩu?
                </a>

                <a href="../index.php">
                    ← Về website
                </a>
            </div>

            <div class="login-note">
                Khu vực chỉ dành cho tài khoản có quyền quản trị.
                Hãy đăng xuất sau khi hoàn tất công việc trên thiết bị
                dùng chung.
            </div>

        </div>
    </section>

</div>

<script>
(function () {
    'use strict';

    var password = document.getElementById('admin-password');
    var toggle = document.getElementById('toggle-admin-password');

    if (!password || !toggle) {
        return;
    }

    toggle.addEventListener('click', function () {
        var isPassword = password.type === 'password';

        password.type = isPassword ? 'text' : 'password';
        toggle.textContent = isPassword ? 'Ẩn' : 'Hiện';

        toggle.setAttribute(
            'aria-pressed',
            isPassword ? 'true' : 'false'
        );
    });
})();
</script>

</body>
</html>
