<?php
declare(strict_types=1);

/**
 * Comic Shop - Admin Categories
 * File: admin/categories.php
 *
 * Chức năng:
 * - Xem và tìm kiếm thể loại.
 * - Thêm, chỉnh sửa thể loại.
 * - Xóa thể loại chưa có truyện sử dụng.
 * - Thống kê số truyện thuộc từng thể loại.
 *
 * Dựa trên bảng categories trong comic_shop.sql.
 */

$pageTitle = 'Quản lý thể loại';
$pageDescription = 'Tổ chức và quản lý các thể loại truyện.';
$activeMenu = 'categories';

require_once __DIR__ . '/includes/bootstrap.php';

if (
    !function_exists('comic_admin_media_url') &&
    is_file(__DIR__ . '/includes/media.php')
) {
    require_once __DIR__ . '/includes/media.php';
}

/* Dự phòng nếu thiếu includes/media.php: chỉ trả về đường dẫn ảnh. */
if (!function_exists('comic_admin_media_url')) {
    function comic_admin_media_url(
        ?string $path,
        string $label = '',
        string $kind = 'cover'
    ): string {
        $path = trim(str_replace('\\', '/', (string) $path));

        if ($path === '' || preg_match('~^(https?:)?//|^data:~i', $path)) {
            return $path;
        }

        return '../' . ltrim($path, '/');
    }
}

$database = $GLOBALS['comic_shop_db'] ?? null;

$dbReady = $database instanceof PDO ||
    (class_exists('mysqli') && $database instanceof mysqli);

/* =========================================================
   1. HÀM DATABASE
========================================================= */

if (!function_exists('comic_admin_categories_query')) {
    function comic_admin_categories_query(
        $database,
        string $sql,
        array $params = []
    ): array {
        if ($database instanceof PDO) {
            $stmt = $database->prepare($sql);
            $stmt->execute($params);

            $rows = $stmt->columnCount() > 0
                ? $stmt->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $affected = $stmt->rowCount();
            $insertId = $database->lastInsertId();

            $stmt->closeCursor();

            return [
                'rows' => $rows,
                'affected' => $affected,
                'insert_id' => $insertId,
            ];
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            $stmt = $database->prepare($sql);

            if (!$stmt) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn MySQL.'
                );
            }

            if ($params !== []) {
                $types = '';
                $bindParams = [];

                foreach ($params as $index => $value) {
                    if (is_int($value) || is_bool($value)) {
                        $types .= 'i';
                    } elseif (is_float($value)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }

                    $bindParams[$index] = $params[$index];
                }

                $arguments = [$types];

                foreach ($bindParams as $index => &$value) {
                    $arguments[] = &$value;
                }

                unset($value);

                if (
                    !call_user_func_array(
                        [$stmt, 'bind_param'],
                        $arguments
                    )
                ) {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không thể gắn tham số MySQL.'
                    );
                }
            }

            if (!$stmt->execute()) {
                $message = $stmt->error;
                $stmt->close();

                throw new RuntimeException(
                    $message ?: 'Truy vấn MySQL thất bại.'
                );
            }

            $rows = [];

            if ($stmt->field_count > 0) {
                $result = $stmt->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không đọc được dữ liệu MySQL.'
                    );
                }
            }

            $affected = $stmt->affected_rows;
            $insertId = $stmt->insert_id;

            $stmt->close();

            return [
                'rows' => $rows,
                'affected' => $affected,
                'insert_id' => $insertId,
            ];
        }

        throw new RuntimeException(
            'Chưa có kết nối PDO hoặc MySQLi.'
        );
    }
}

/* =========================================================
   2. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_admin_categories_escape')) {
    function comic_admin_categories_escape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_admin_categories_slug')) {
    function comic_admin_categories_slug(string $value): string
    {
        $value = trim($value);

        if (function_exists('iconv')) {
            $converted = @iconv(
                'UTF-8',
                'ASCII//TRANSLIT//IGNORE',
                $value
            );

            if ($converted !== false) {
                $value = $converted;
            }
        }

        $value = strtolower($value);
        $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';

        return trim($value, '-');
    }
}

if (!function_exists('comic_admin_categories_image_url')) {
    function comic_admin_categories_image_url(string $path, string $label = ''): string
    {
        return comic_admin_media_url($path, $label, 'category');
    }
}

if (!function_exists('comic_admin_categories_redirect')) {
    function comic_admin_categories_redirect(): void
    {
        header('Location: categories.php', true, 303);
        exit;
    }
}

if (!function_exists('comic_admin_categories_set_flash')) {
    function comic_admin_categories_set_flash(
        string $type,
        string $message
    ): void {
        $_SESSION['comic_categories_flash'] = [
            'type' => $type,
            'message' => $message,
        ];
    }
}

/* =========================================================
   3. KHỞI TẠO
========================================================= */

$flash = $_SESSION['comic_categories_flash'] ?? null;
unset($_SESSION['comic_categories_flash']);

$errors = [];
$action = isset($_GET['action']) && is_string($_GET['action'])
    ? $_GET['action']
    : 'list';

if (!in_array($action, ['list', 'create', 'edit'], true)) {
    $action = 'list';
}

$editId = max(0, (int) ($_GET['id'] ?? 0));

$formData = [
    'name' => '',
    'slug' => '',
    'description' => '',
    'image' => '',
];

/* =========================================================
   4. XỬ LÝ POST
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $token = isset($_POST['csrf_token']) &&
        is_string($_POST['csrf_token'])
            ? $_POST['csrf_token']
            : '';

    if (
        !function_exists('comic_admin_csrf_valid') ||
        !comic_admin_csrf_valid($token)
    ) {
        comic_admin_categories_set_flash(
            'error',
            'Phiên làm việc hết hạn. Vui lòng thử lại.'
        );

        comic_admin_categories_redirect();
    }

    $postAction = isset($_POST['action']) &&
        is_string($_POST['action'])
            ? $_POST['action']
            : '';

    if (!$dbReady) {
        $errors[] =
            'Không có kết nối cơ sở dữ liệu. Kiểm tra config/db.php.';
    } elseif ($postAction === 'delete') {
        /*
         * Không xóa thể loại nếu còn truyện sử dụng nó.
         * comics.category_id là khóa ngoại tới categories.id.
         */
        $id = (int) ($_POST['id'] ?? 0);

        if ($id < 1) {
            comic_admin_categories_set_flash(
                'error',
                'ID thể loại không hợp lệ.'
            );

            comic_admin_categories_redirect();
        }

        try {
            $existing = comic_admin_categories_query(
                $database,
                'SELECT id, name FROM categories WHERE id = ? LIMIT 1',
                [$id]
            )['rows'];

            if (!$existing) {
                comic_admin_categories_set_flash(
                    'error',
                    'Không tìm thấy thể loại cần xóa.'
                );

                comic_admin_categories_redirect();
            }

            $countRows = comic_admin_categories_query(
                $database,
                'SELECT COUNT(*) AS total
                 FROM comics
                 WHERE category_id = ?',
                [$id]
            )['rows'];

            $comicCount = (int) ($countRows[0]['total'] ?? 0);

            if ($comicCount > 0) {
                comic_admin_categories_set_flash(
                    'error',
                    'Không thể xóa thể loại "' .
                    (string) $existing[0]['name'] .
                    '" vì đang có ' . $comicCount .
                    ' truyện sử dụng. Hãy chuyển truyện sang thể loại khác trước.'
                );

                comic_admin_categories_redirect();
            }

            comic_admin_categories_query(
                $database,
                'DELETE FROM categories WHERE id = ?',
                [$id]
            );

            comic_admin_categories_set_flash(
                'success',
                'Đã xóa thể loại thành công.'
            );

            $_SESSION['comic_admin_csrf'] =
                bin2hex(random_bytes(32));

            comic_admin_categories_redirect();

        } catch (Throwable $exception) {
            error_log(
                '[Comic Shop Categories] ' .
                $exception->getMessage()
            );

            comic_admin_categories_set_flash(
                'error',
                'Không thể xóa thể loại. Hãy kiểm tra dữ liệu liên quan.'
            );

            comic_admin_categories_redirect();
        }

    } elseif ($postAction === 'save') {
        $mode = isset($_POST['form_mode']) &&
            $_POST['form_mode'] === 'edit'
                ? 'edit'
                : 'create';

        $action = $mode;
        $editId = (int) ($_POST['id'] ?? 0);

        $formData = [
            'name' => trim((string) ($_POST['name'] ?? '')),
            'slug' => trim((string) ($_POST['slug'] ?? '')),
            'description' => trim(
                (string) ($_POST['description'] ?? '')
            ),
            'image' => trim((string) ($_POST['image'] ?? '')),
        ];

        $name = $formData['name'];

        $slug = $formData['slug'] !== ''
            ? comic_admin_categories_slug($formData['slug'])
            : comic_admin_categories_slug($name);

        if ($slug === '' && $name !== '') {
            $slug = 'category-' . bin2hex(random_bytes(4));
        }

        $nameLength = function_exists('mb_strlen')
            ? mb_strlen($name, 'UTF-8')
            : strlen($name);

        if ($name === '' || $nameLength > 100) {
            $errors[] =
                'Tên thể loại là bắt buộc và không vượt quá 100 ký tự.';
        }

        if ($slug === '' || strlen($slug) > 120) {
            $errors[] =
                'Slug phải hợp lệ và không vượt quá 120 ký tự.';
        }

        if (strlen($formData['image']) > 255) {
            $errors[] =
                'Đường dẫn ảnh không vượt quá 255 ký tự.';
        }

        if (!$errors) {
            try {
                $slugSql =
                    'SELECT id FROM categories WHERE slug = ?';

                $slugParams = [$slug];

                if ($mode === 'edit') {
                    if ($editId < 1) {
                        $errors[] =
                            'ID thể loại cần chỉnh sửa không hợp lệ.';
                    } else {
                        $slugSql .= ' AND id <> ?';
                        $slugParams[] = $editId;
                    }
                }

                $slugSql .= ' LIMIT 1';

                if (
                    !$errors &&
                    comic_admin_categories_query(
                        $database,
                        $slugSql,
                        $slugParams
                    )['rows']
                ) {
                    $errors[] =
                        'Slug đã được sử dụng. Hãy chọn slug khác.';
                }

                if (!$errors) {
                    if ($mode === 'edit') {
                        $existing = comic_admin_categories_query(
                            $database,
                            'SELECT id FROM categories WHERE id = ? LIMIT 1',
                            [$editId]
                        )['rows'];

                        if (!$existing) {
                            $errors[] =
                                'Thể loại cần chỉnh sửa không còn tồn tại.';
                        } else {
                            comic_admin_categories_query(
                                $database,
                                'UPDATE categories
                                 SET name = ?, slug = ?, description = ?, image = ?
                                 WHERE id = ?',
                                [
                                    $name,
                                    $slug,
                                    $formData['description'] !== ''
                                        ? $formData['description']
                                        : null,
                                    $formData['image'] !== ''
                                        ? $formData['image']
                                        : null,
                                    $editId,
                                ]
                            );

                            comic_admin_categories_set_flash(
                                'success',
                                'Đã cập nhật thể loại "' . $name . '".'
                            );

                            $_SESSION['comic_admin_csrf'] =
                                bin2hex(random_bytes(32));

                            comic_admin_categories_redirect();
                        }
                    } else {
                        comic_admin_categories_query(
                            $database,
                            'INSERT INTO categories
                                (name, slug, description, image)
                             VALUES (?, ?, ?, ?)',
                            [
                                $name,
                                $slug,
                                $formData['description'] !== ''
                                    ? $formData['description']
                                    : null,
                                $formData['image'] !== ''
                                    ? $formData['image']
                                    : null,
                            ]
                        );

                        comic_admin_categories_set_flash(
                            'success',
                            'Đã thêm thể loại "' . $name . '".'
                        );

                        $_SESSION['comic_admin_csrf'] =
                            bin2hex(random_bytes(32));

                        comic_admin_categories_redirect();
                    }
                }
            } catch (Throwable $exception) {
                error_log(
                    '[Comic Shop Categories] ' .
                    $exception->getMessage()
                );

                $errors[] =
                    'Không lưu được thể loại. Kiểm tra dữ liệu và kết nối database.';
            }
        }
    } else {
        comic_admin_categories_set_flash(
            'error',
            'Thao tác không hợp lệ.'
        );

        comic_admin_categories_redirect();
    }
}

/* =========================================================
   5. TẢI THỂ LOẠI CẦN SỬA
========================================================= */

$editCategory = null;

if ($dbReady && $action === 'edit' && $editId > 0) {
    try {
        $rows = comic_admin_categories_query(
            $database,
            'SELECT id, name, slug, description, image, created_at
             FROM categories
             WHERE id = ?
             LIMIT 1',
            [$editId]
        )['rows'];

        $editCategory = $rows[0] ?? null;

        if (!$editCategory) {
            $action = 'list';

            $errors[] =
                'Không tìm thấy thể loại cần chỉnh sửa.';
        } elseif ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $formData = [
                'name' => (string) ($editCategory['name'] ?? ''),
                'slug' => (string) ($editCategory['slug'] ?? ''),
                'description' => (string) ($editCategory['description'] ?? ''),
                'image' => (string) ($editCategory['image'] ?? ''),
            ];
        }
    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Categories] ' .
            $exception->getMessage()
        );

        $errors[] = 'Không tải được thông tin thể loại.';
        $action = 'list';
    }
}

/* =========================================================
   6. DANH SÁCH / TÌM KIẾM / PHÂN TRANG
========================================================= */

$search = isset($_GET['q']) && is_string($_GET['q'])
    ? trim($_GET['q'])
    : '';

$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;
$totalCategories = 0;
$totalPages = 1;
$categoryRows = [];
$categoryStats = [
    'total' => 0,
    'with_comics' => 0,
    'without_comics' => 0,
];

if ($dbReady) {
    try {
        $statRows = comic_admin_categories_query(
            $database,
            'SELECT
                COUNT(*) AS total,
                COALESCE(SUM(
                    (SELECT COUNT(*)
                     FROM comics c
                     WHERE c.category_id = categories.id) > 0
                ), 0) AS with_comics
             FROM categories'
        )['rows'];

        if ($statRows) {
            $categoryStats['total'] = (int) $statRows[0]['total'];
            $categoryStats['with_comics'] =
                (int) $statRows[0]['with_comics'];
            $categoryStats['without_comics'] =
                $categoryStats['total'] -
                $categoryStats['with_comics'];
        }

        $whereSql = '';
        $params = [];

        if ($search !== '') {
            $whereSql = ' WHERE (
                c.name LIKE ?
                OR c.slug LIKE ?
                OR c.description LIKE ?
            )';

            $like = '%' . $search . '%';
            $params = [$like, $like, $like];
        }

        $countRows = comic_admin_categories_query(
            $database,
            'SELECT COUNT(*) AS total
             FROM categories c' . $whereSql,
            $params
        )['rows'];

        $totalCategories = (int) (
            $countRows[0]['total'] ?? 0
        );

        $totalPages = max(
            1,
            (int) ceil($totalCategories / $perPage)
        );

        $page = min($page, $totalPages);
        $offset = ($page - 1) * $perPage;

        $listParams = $params;
        $listParams[] = $perPage;
        $listParams[] = $offset;

        $categoryRows = comic_admin_categories_query(
            $database,
            'SELECT
                c.id,
                c.name,
                c.slug,
                c.description,
                c.image,
                c.created_at,
                (
                    SELECT COUNT(*)
                    FROM comics cm
                    WHERE cm.category_id = c.id
                ) AS comic_count
             FROM categories c' . $whereSql . '
             ORDER BY c.name ASC
             LIMIT ? OFFSET ?',
            $listParams
        )['rows'];

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Categories] ' .
            $exception->getMessage()
        );

        $errors[] = 'Không tải được danh sách thể loại.';
    }
}

if ($action === 'create') {
    $pageTitle = 'Thêm thể loại';
    $pageDescription = 'Tạo một thể loại truyện mới.';
} elseif ($action === 'edit') {
    $pageTitle = 'Chỉnh sửa thể loại';
    $pageDescription = 'Cập nhật thông tin thể loại.';
}

require_once __DIR__ . '/includes/header.php';
?>

<style>
.ca-categories {
    color: #f2f2f2;
}

.ca-categories .cc-alert {
    margin-bottom: 17px;
    padding: 12px 15px;
    border: 1px solid rgba(255,107,96,.4);
    border-left: 4px solid #ff6b60;
    background: rgba(255,107,96,.14);
    color: #ff8f86;
    font-size: 12px;
    line-height: 1.65;
}

.ca-categories .cc-alert.success {
    border-color: rgba(80,200,130,.4);
    border-left-color: #50c882;
    background: rgba(80,200,130,.16);
    color: #6fdc9c;
}

.ca-categories .cc-stats {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 14px;
    margin-bottom: 21px;
}

.ca-categories .cc-stat {
    padding: 17px;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.18);
}

.ca-categories .cc-stat-label {
    color: #a9a9b2;
    font-size: 11px;
    font-weight: 700;
}

.ca-categories .cc-stat-value {
    display: block;
    margin-top: 6px;
    font-size: 25px;
    font-weight: 850;
}

.ca-categories .cc-toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
    margin-bottom: 17px;
}

.ca-categories .cc-search {
    display: flex;
    flex: 1;
    flex-wrap: wrap;
    gap: 8px;
}

.ca-categories .cc-search input {
    min-width: 200px;
    min-height: 39px;
    flex: 1;
    padding: 9px 12px;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    background: #232327;
    color: #f2f2f2;
    font: inherit;
    font-size: 12px;
}

.ca-categories .cc-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    min-height: 36px;
    padding: 8px 12px;
    border: 1px solid transparent;
    border-radius: 999px;
    background: #f2f2f2;
    color: #111111;
    font-size: 12px;
    font-weight: 800;
    text-decoration: none;
    cursor: pointer;
}

.ca-categories .cc-btn:hover {
    background: #ffffff;
    color: #111111;
}

.ca-categories .cc-btn:disabled {
    opacity: .5;
    cursor: not-allowed;
}

.ca-categories .cc-btn.secondary {
    border-color: #3d3d44;
    background: #232327;
    color: #d4d4da;
}

.ca-categories .cc-btn.secondary:hover {
    border-color: #f2f2f2;
    background: #2c2c31;
    color: #f2f2f2;
}

.ca-categories .cc-btn.danger {
    border-color: rgba(255,107,96,.4);
    background: rgba(255,107,96,.14);
    color: #ff8f86;
}

.ca-categories .cc-panel {
    overflow: hidden;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.22);
}

.ca-categories .cc-panel-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 10px;
    padding: 17px 20px;
    border-bottom: 1px solid #3d3d44;
}

.ca-categories .cc-panel-head h2 {
    margin: 0;
    font-size: 14px;
    font-weight: 850;
}

.ca-categories .cc-muted {
    color: #a9a9b2;
    font-size: 11px;
}

.ca-categories .cc-table-wrap {
    overflow-x: auto;
}

.ca-categories table {
    width: 100%;
    border-collapse: collapse;
}

.ca-categories th {
    padding: 13px 15px;
    background: #2c2c31;
    border-bottom: 1px solid #3d3d44;
    color: #a9a9b2;
    font-size: 10px;
    font-weight: 850;
    letter-spacing: .5px;
    text-align: left;
    text-transform: uppercase;
    white-space: nowrap;
}

.ca-categories td {
    padding: 14px 15px;
    border-bottom: 1px solid #3d3d44;
    color: #d4d4da;
    font-size: 12px;
    vertical-align: middle;
}

.ca-categories tbody tr:last-child td {
    border-bottom: 0;
}

.ca-categories tbody tr:hover {
    background: #2c2c31;
}

.ca-categories .cc-category {
    display: flex;
    align-items: center;
    gap: 11px;
    min-width: 180px;
}

.ca-categories .cc-image {
    display: grid;
    width: 44px;
    height: 44px;
    flex: 0 0 44px;
    place-items: center;
    overflow: hidden;
    border-radius: 9px;
    background: #2c2c31;
    color: #f2f2f2;
    font-size: 19px;
}

.ca-categories .cc-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.ca-categories .cc-name {
    display: block;
    color: #f2f2f2;
    font-weight: 800;
}

.ca-categories .cc-slug {
    display: block;
    margin-top: 4px;
    color: #a9a9b2;
    font-size: 10px;
}

.ca-categories .cc-description {
    min-width: 190px;
    max-width: 330px;
    color: #a9a9b2;
    line-height: 1.6;
    overflow-wrap: anywhere;
}

.ca-categories .cc-count {
    display: inline-flex;
    min-width: 32px;
    min-height: 29px;
    align-items: center;
    justify-content: center;
    padding: 4px 8px;
    border-radius: 20px;
    background: #36363c;
    color: #f2f2f2;
    font-size: 11px;
    font-weight: 850;
}

.ca-categories .cc-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
}

.ca-categories .cc-actions form {
    margin: 0;
}

.ca-categories .cc-empty {
    padding: 40px 18px;
    color: #a9a9b2;
    font-size: 12px;
    text-align: center;
}

.ca-categories .cc-pagination {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
    padding: 15px 18px;
    border-top: 1px solid #3d3d44;
}

.ca-categories .cc-pages {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
}

.ca-categories .cc-pages a,
.ca-categories .cc-pages span {
    display: grid;
    min-width: 33px;
    height: 33px;
    padding: 0 9px;
    place-items: center;
    border: 1px solid #3d3d44;
    border-radius: 6px;
    background: #232327;
    color: #d4d4da;
    font-size: 11px;
    text-decoration: none;
}

.ca-categories .cc-pages .current {
    border-color: #f2f2f2;
    background: #f2f2f2;
    color: #111111;
}

.ca-categories .cc-form {
    max-width: 850px;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    overflow: hidden;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.22);
}

.ca-categories .cc-form-body {
    padding: 22px;
}

.ca-categories .cc-field {
    margin-bottom: 19px;
}

.ca-categories .cc-field label {
    display: block;
    margin-bottom: 7px;
    color: #d4d4da;
    font-size: 11px;
    font-weight: 800;
}

.ca-categories .cc-field input,
.ca-categories .cc-field textarea {
    display: block;
    width: 100%;
    min-height: 42px;
    padding: 10px 12px;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    background: #232327;
    color: #f2f2f2;
    font: inherit;
    font-size: 12px;
    outline: none;
}

.ca-categories .cc-field textarea {
    min-height: 120px;
    resize: vertical;
}

.ca-categories .cc-field input:focus,
.ca-categories .cc-field textarea:focus {
    border-color: #f2f2f2;
    box-shadow: 0 0 0 3px rgba(239,67,56,.1);
}

.ca-categories .cc-help {
    margin-top: 6px;
    color: #a9a9b2;
    font-size: 10px;
    line-height: 1.6;
}

.ca-categories .cc-preview {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-top: 10px;
}

.ca-categories .cc-preview img {
    width: 75px;
    height: 75px;
    object-fit: cover;
    border: 1px solid #3d3d44;
    border-radius: 8px;
    background: #2c2c31;
}

.ca-categories .cc-form-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 9px;
    padding-top: 17px;
    border-top: 1px solid #3d3d44;
}

@media(max-width:900px) {
    .ca-categories .cc-stats {
        grid-template-columns: repeat(3,minmax(0,1fr));
    }
}

@media(max-width:650px) {
    .ca-categories .cc-stats {
        grid-template-columns: 1fr 1fr;
        gap: 9px;
    }

    .ca-categories .cc-stat {
        padding: 13px;
    }

    .ca-categories .cc-stat-value {
        font-size: 22px;
    }

    .ca-categories .cc-form-body {
        padding: 15px;
    }

    .ca-categories .cc-toolbar {
        align-items: stretch;
    }

    .ca-categories .cc-search {
        width: 100%;
    }

    .ca-categories .cc-search input {
        min-width: 0;
    }
}
</style>

<div class="ca-categories">

    <?php if (is_array($flash) && !empty($flash['message'])): ?>
        <?php
        $flashType = (string) ($flash['type'] ?? 'info');
        ?>

        <div
            class="cc-alert <?= $flashType === 'success' ? 'success' : '' ?>"
            role="status"
        >
            <?= comic_admin_categories_escape($flash['message']) ?>
        </div>
    <?php endif; ?>

    <?php if (!$dbReady): ?>
        <div class="cc-alert" role="alert">
            Không tìm thấy kết nối cơ sở dữ liệu. Hãy kiểm tra
            <strong>config/db.php</strong> và
            <strong>admin/includes/bootstrap.php</strong>.
        </div>
    <?php endif; ?>

    <?php if ($errors): ?>
        <div class="cc-alert" role="alert">
            <strong>Cần kiểm tra:</strong>

            <ul style="margin:7px 0 0;padding-left:19px">
                <?php foreach ($errors as $error): ?>
                    <li><?= comic_admin_categories_escape($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if (in_array($action, ['create', 'edit'], true)): ?>

        <div class="cc-toolbar">
            <div>
                <h2 style="margin:0;font-size:20px;font-weight:850">
                    <?= $action === 'edit'
                        ? 'Chỉnh sửa thể loại'
                        : 'Thêm thể loại mới' ?>
                </h2>

                <p class="cc-muted" style="margin:5px 0 0">
                    Tên thể loại và slug phải duy nhất.
                </p>
            </div>

            <a class="cc-btn secondary" href="categories.php">
                ← Quay lại
            </a>
        </div>

        <section class="cc-form">

            <div class="cc-panel-head">
                <h2>
                    <?= $action === 'edit'
                        ? 'Thông tin thể loại'
                        : 'Thông tin thể loại mới' ?>
                </h2>
            </div>

            <div class="cc-form-body">

                <form method="post" action="categories.php">

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= comic_admin_categories_escape(
                            comic_admin_csrf_token()
                        ) ?>"
                    >

                    <input type="hidden" name="action" value="save">

                    <input
                        type="hidden"
                        name="form_mode"
                        value="<?= comic_admin_categories_escape($action) ?>"
                    >

                    <input
                        type="hidden"
                        name="id"
                        value="<?= (int) $editId ?>"
                    >

                    <div class="cc-field">
                        <label for="category-name">
                            Tên thể loại *
                        </label>

                        <input
                            id="category-name"
                            type="text"
                            name="name"
                            maxlength="100"
                            required
                            value="<?= comic_admin_categories_escape($formData['name']) ?>"
                            placeholder="Ví dụ: Hành động"
                        >
                    </div>

                    <div class="cc-field">
                        <label for="category-slug">
                            Slug
                        </label>

                        <input
                            id="category-slug"
                            type="text"
                            name="slug"
                            maxlength="120"
                            value="<?= comic_admin_categories_escape($formData['slug']) ?>"
                            placeholder="hanh-dong"
                        >

                        <div class="cc-help">
                            Để trống để tự tạo slug từ tên thể loại.
                            Chỉ sử dụng chữ cái không dấu, số và dấu gạch ngang.
                        </div>
                    </div>

                    <div class="cc-field">
                        <label for="category-description">
                            Mô tả
                        </label>

                        <textarea
                            id="category-description"
                            name="description"
                            rows="4"
                            placeholder="Mô tả ngắn về thể loại này..."
                        ><?= comic_admin_categories_escape($formData['description']) ?></textarea>
                    </div>

                    <div class="cc-field">
                        <label for="category-image">
                            Đường dẫn ảnh thể loại
                        </label>

                        <input
                            id="category-image"
                            type="text"
                            name="image"
                            maxlength="255"
                            value="<?= comic_admin_categories_escape($formData['image']) ?>"
                            placeholder="assets/images/covers/action.jpg"
                        >

                        <div class="cc-help">
                            Nhập URL ảnh hoặc đường dẫn tương đối từ thư mục
                            gốc comic_shop. File này lưu đường dẫn, không tải
                            file ảnh lên máy chủ.
                        </div>

                        <?php if ($formData['image'] !== ''): ?>
                            <div class="cc-preview">
                                <img
                                    src="<?= comic_admin_categories_escape(
                                        comic_admin_categories_image_url(
                                            (string) $formData['image']
                                        )
                                    ) ?>"
                                    alt="Ảnh thể loại xem trước"
                                    onerror="this.style.display='none'"
                                >

                                <span class="cc-muted">
                                    Ảnh xem trước
                                </span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="cc-form-actions">
                        <button class="cc-btn" type="submit">
                            <?= $action === 'edit'
                                ? 'Lưu thay đổi'
                                : 'Tạo thể loại' ?>
                        </button>

                        <a class="cc-btn secondary" href="categories.php">
                            Hủy
                        </a>
                    </div>

                </form>

            </div>
        </section>

    <?php else: ?>

        <section class="cc-stats" aria-label="Thống kê thể loại">

            <div class="cc-stat">
                <span class="cc-stat-label">
                    Tổng thể loại
                </span>

                <strong class="cc-stat-value">
                    <?= number_format($categoryStats['total']) ?>
                </strong>
            </div>

            <div class="cc-stat">
                <span class="cc-stat-label">
                    Có truyện
                </span>

                <strong
                    class="cc-stat-value"
                    style="color:#6fdc9c"
                >
                    <?= number_format($categoryStats['with_comics']) ?>
                </strong>
            </div>

            <div class="cc-stat">
                <span class="cc-stat-label">
                    Chưa có truyện
                </span>

                <strong
                    class="cc-stat-value"
                    style="color:#f2f2f2"
                >
                    <?= number_format($categoryStats['without_comics']) ?>
                </strong>
            </div>

        </section>

        <div class="cc-toolbar">

            <form class="cc-search" method="get" action="categories.php">

                <input
                    type="search"
                    name="q"
                    value="<?= comic_admin_categories_escape($search) ?>"
                    placeholder="Tìm tên, slug hoặc mô tả..."
                    aria-label="Tìm thể loại"
                >

                <button class="cc-btn secondary" type="submit">
                    Tìm kiếm
                </button>

                <?php if ($search !== ''): ?>
                    <a class="cc-btn secondary" href="categories.php">
                        Xóa lọc
                    </a>
                <?php endif; ?>

            </form>

            <a class="cc-btn" href="categories.php?action=create">
                ＋ Thêm thể loại
            </a>

        </div>

        <section class="cc-panel">

            <div class="cc-panel-head">
                <h2>Danh sách thể loại</h2>

                <span class="cc-muted">
                    <?= number_format($totalCategories) ?> kết quả
                </span>
            </div>

            <?php if (!$dbReady): ?>

                <div class="cc-empty">
                    Cần kết nối cơ sở dữ liệu để xem danh sách.
                </div>

            <?php elseif (!$categoryRows): ?>

                <div class="cc-empty">
                    <div style="font-size:30px;margin-bottom:10px">
                        ▧
                    </div>

                    Không tìm thấy thể loại phù hợp.

                    <div style="margin-top:14px">
                        <a class="cc-btn" href="categories.php?action=create">
                            Tạo thể loại đầu tiên
                        </a>
                    </div>
                </div>

            <?php else: ?>

                <div class="cc-table-wrap">

                    <table>

                        <thead>
                            <tr>
                                <th>Thể loại</th>
                                <th>Mô tả</th>
                                <th>Số truyện</th>
                                <th>Ngày tạo</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach ($categoryRows as $category): ?>

                                <?php
                                $imageUrl = comic_admin_categories_image_url(
                                    (string) ($category['image'] ?? ''),
                                    (string) ($category['name'] ?? '')
                                );

                                $createdAt = !empty($category['created_at'])
                                    ? strtotime((string) $category['created_at'])
                                    : false;

                                $comicCount = (int) (
                                    $category['comic_count'] ?? 0
                                );
                                ?>

                                <tr>

                                    <td>
                                        <div class="cc-category">

                                            <span class="cc-image">

                                                <?php if ($imageUrl !== ''): ?>
                                                    <img
                                                        src="<?= comic_admin_categories_escape($imageUrl) ?>"
                                                        alt=""
                                                        loading="lazy"
                                                        onerror="this.remove();this.parentElement.textContent='▧';"
                                                    >
                                                <?php else: ?>
                                                    ▧
                                                <?php endif; ?>

                                            </span>

                                            <span>
                                                <span class="cc-name">
                                                    <?= comic_admin_categories_escape($category['name']) ?>
                                                </span>

                                                <span class="cc-slug">
                                                    <?= comic_admin_categories_escape($category['slug']) ?>
                                                </span>
                                            </span>

                                        </div>
                                    </td>

                                    <td>
                                        <div class="cc-description">
                                            <?= comic_admin_categories_escape(
                                                $category['description'] !== null &&
                                                $category['description'] !== ''
                                                    ? $category['description']
                                                    : 'Chưa có mô tả.'
                                            ) ?>
                                        </div>
                                    </td>

                                    <td>
                                        <span class="cc-count">
                                            <?= number_format($comicCount) ?>
                                        </span>
                                    </td>

                                    <td style="white-space:nowrap">
                                        <?= $createdAt
                                            ? comic_admin_categories_escape(
                                                date('d/m/Y', $createdAt)
                                            )
                                            : '—' ?>
                                    </td>

                                    <td>
                                        <div class="cc-actions">

                                            <a
                                                class="cc-btn secondary"
                                                href="categories.php?action=edit&amp;id=<?= (int) $category['id'] ?>"
                                            >
                                                Sửa
                                            </a>

                                            <?php if ($comicCount === 0): ?>

                                                <form
                                                    method="post"
                                                    action="categories.php"
                                                    data-confirm="Bạn có chắc muốn xóa thể loại này? Thao tác này không thể hoàn tác."
                                                >

                                                    <input
                                                        type="hidden"
                                                        name="csrf_token"
                                                        value="<?= comic_admin_categories_escape(
                                                            comic_admin_csrf_token()
                                                        ) ?>"
                                                    >

                                                    <input
                                                        type="hidden"
                                                        name="action"
                                                        value="delete"
                                                    >

                                                    <input
                                                        type="hidden"
                                                        name="id"
                                                        value="<?= (int) $category['id'] ?>"
                                                    >

                                                    <button
                                                        class="cc-btn danger"
                                                        type="submit"
                                                    >
                                                        Xóa
                                                    </button>

                                                </form>

                                            <?php else: ?>

                                                <button
                                                    class="cc-btn secondary"
                                                    type="button"
                                                    disabled
                                                    title="Hãy chuyển các truyện sang thể loại khác trước khi xóa."
                                                >
                                                    Đang sử dụng
                                                </button>

                                            <?php endif; ?>

                                        </div>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>
                    </table>

                </div>

                <div class="cc-pagination">

                    <span class="cc-muted">
                        Trang <?= $page ?> / <?= $totalPages ?>
                    </span>

                    <?php if ($totalPages > 1): ?>

                        <nav class="cc-pages" aria-label="Phân trang">

                            <?php
                            $baseQuery = [];

                            if ($search !== '') {
                                $baseQuery['q'] = $search;
                            }

                            if ($page > 1):
                                $previousUrl = 'categories.php?' .
                                    http_build_query(
                                        array_merge(
                                            $baseQuery,
                                            ['page' => $page - 1]
                                        )
                                    );
                            ?>

                                <a href="<?= comic_admin_categories_escape($previousUrl) ?>">
                                    ‹
                                </a>

                            <?php endif; ?>

                            <?php
                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);

                            for (
                                $i = $startPage;
                                $i <= $endPage;
                                $i++
                            ):
                                $pageUrl = 'categories.php?' .
                                    http_build_query(
                                        array_merge(
                                            $baseQuery,
                                            ['page' => $i]
                                        )
                                    );
                            ?>

                                <?php if ($i === $page): ?>
                                    <span class="current" aria-current="page">
                                        <?= $i ?>
                                    </span>
                                <?php else: ?>
                                    <a href="<?= comic_admin_categories_escape($pageUrl) ?>">
                                        <?= $i ?>
                                    </a>
                                <?php endif; ?>

                            <?php endfor; ?>

                            <?php if ($page < $totalPages):
                                $nextUrl = 'categories.php?' .
                                    http_build_query(
                                        array_merge(
                                            $baseQuery,
                                            ['page' => $page + 1]
                                        )
                                    );
                            ?>

                                <a href="<?= comic_admin_categories_escape($nextUrl) ?>">
                                    ›
                                </a>

                            <?php endif; ?>

                        </nav>

                    <?php endif; ?>

                </div>

            <?php endif; ?>

        </section>


    <?php endif; ?>

</div>

<script>
(function () {
    'use strict';

    var nameInput = document.getElementById('category-name');
    var slugInput = document.getElementById('category-slug');

    if (!nameInput || !slugInput) {
        return;
    }

    var slugManuallyEdited = slugInput.value.trim() !== '';

    slugInput.addEventListener('input', function () {
        slugManuallyEdited = slugInput.value.trim() !== '';
    });

    nameInput.addEventListener('input', function () {
        if (slugManuallyEdited) {
            return;
        }

        var value = nameInput.value;

        if (value.normalize) {
            value = value.normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '');
        }

        value = value
            .replace(/đ/g, 'd')
            .replace(/Đ/g, 'D')
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '');

        slugInput.value = value;
    });
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
