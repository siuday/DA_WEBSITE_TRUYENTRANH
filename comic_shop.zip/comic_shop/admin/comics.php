<?php
declare(strict_types=1);

/**
 * Comic Shop - Quản lý truyện.
 * File: admin/comics.php
 *
 * Chức năng:
 * - Danh sách, tìm kiếm, lọc truyện.
 * - Thêm và chỉnh sửa truyện.
 * - Hiện/ẩn truyện khỏi cửa hàng.
 * - Quản lý giá, ảnh bìa, tồn kho, thể loại, tác giả.
 *
 * Dựa trên schema trong comic_shop.sql.
 */

$pageTitle = 'Quản lý truyện';
$pageDescription = 'Thêm, cập nhật và quản lý danh mục truyện.';
$activeMenu = 'comics';

require_once __DIR__ . '/includes/bootstrap.php';

if (
    !function_exists('comic_admin_media_url') &&
    is_file(__DIR__ . '/includes/media.php')
) {
    require_once __DIR__ . '/includes/media.php';
}

/* Dự phòng nếu thiếu includes/media.php: chỉ trả về đường dẫn ảnh. */
if (!function_exists('comic_admin_media_url')) {
    function comic_admin_media_url(
        ?string $path,
        string $label = '',
        string $kind = 'cover'
    ): string {
        $path = trim(str_replace('\\', '/', (string) $path));

        if ($path === '' || preg_match('~^(https?:)?//|^data:~i', $path)) {
            return $path;
        }

        return '../' . ltrim($path, '/');
    }
}

$database = $GLOBALS['comic_shop_db'] ?? null;

/* =========================================================
   1. HÀM DATABASE - HỖ TRỢ PDO VÀ MYSQLI
========================================================= */

if (!function_exists('comic_admin_comics_query')) {
    function comic_admin_comics_query(
        $database,
        string $sql,
        array $params = []
    ): array {
        if ($database instanceof PDO) {
            $statement = $database->prepare($sql);
            $statement->execute($params);

            $rows = $statement->columnCount() > 0
                ? $statement->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $affected = $statement->rowCount();
            $insertId = $database->lastInsertId();

            $statement->closeCursor();

            return [
                'rows' => $rows,
                'affected' => $affected,
                'insert_id' => $insertId,
            ];
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            $statement = $database->prepare($sql);

            if (!$statement) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn MySQL.'
                );
            }

            if ($params !== []) {
                $types = '';

                foreach ($params as $param) {
                    if (is_int($param) || is_bool($param)) {
                        $types .= 'i';
                    } elseif (is_float($param)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }
                }

                $bindArgs = [$types];

                foreach ($params as $key => &$param) {
                    $bindArgs[] = &$param;
                }

                unset($param);

                if (
                    !call_user_func_array(
                        [$statement, 'bind_param'],
                        $bindArgs
                    )
                ) {
                    $statement->close();

                    throw new RuntimeException(
                        'Không thể gắn dữ liệu vào truy vấn MySQL.'
                    );
                }
            }

            if (!$statement->execute()) {
                $message = $statement->error
                    ?: 'Truy vấn MySQL thất bại.';

                $statement->close();

                throw new RuntimeException($message);
            }

            $rows = [];

            if ($statement->field_count > 0) {
                $result = $statement->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $statement->close();

                    throw new RuntimeException(
                        'Không lấy được kết quả MySQL. '
                        . 'Hãy kiểm tra PHP có bật mysqlnd.'
                    );
                }
            }

            $affected = $statement->affected_rows;
            $insertId = $statement->insert_id;

            $statement->close();

            return [
                'rows' => $rows,
                'affected' => $affected,
                'insert_id' => $insertId,
            ];
        }

        throw new RuntimeException(
            'Không có kết nối PDO/MySQLi hợp lệ.'
        );
    }
}

/* =========================================================
   2. HÀM TIỆN ÍCH
========================================================= */

if (!function_exists('comic_admin_comics_escape')) {
    function comic_admin_comics_escape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_admin_comics_money')) {
    function comic_admin_comics_money($value): string
    {
        return number_format(
            (float) $value,
            0,
            ',',
            '.'
        ) . ' ₫';
    }
}

if (!function_exists('comic_admin_comics_slug')) {
    function comic_admin_comics_slug(string $value): string
    {
        $value = trim($value);

        if (function_exists('iconv')) {
            $converted = iconv(
                'UTF-8',
                'ASCII//TRANSLIT//IGNORE',
                $value
            );

            if ($converted !== false) {
                $value = $converted;
            }
        }

        $value = strtolower($value);
        $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';

        return trim($value, '-');
    }
}

if (!function_exists('comic_admin_comics_cover_url')) {
    function comic_admin_comics_cover_url(string $path, string $label = ''): string
    {
        return comic_admin_media_url($path, $label, 'cover');
    }
}

if (!function_exists('comic_admin_comics_redirect')) {
    function comic_admin_comics_redirect(): void
    {
        header('Location: comics.php', true, 303);
        exit;
    }
}

if (!function_exists('comic_admin_comics_flash')) {
    function comic_admin_comics_flash(
        string $type,
        string $message
    ): void {
        $_SESSION['comic_comics_flash'] = [
            'type' => $type,
            'message' => $message,
        ];
    }
}

/* =========================================================
   3. KHỞI TẠO DỮ LIỆU
========================================================= */

$flash = $_SESSION['comic_comics_flash'] ?? null;
unset($_SESSION['comic_comics_flash']);

$dbReady =
    $database instanceof PDO ||
    (
        class_exists('mysqli') &&
        $database instanceof mysqli
    );

$errors = [];

$action = isset($_GET['action']) && is_string($_GET['action'])
    ? $_GET['action']
    : 'list';

$editId = isset($_GET['id'])
    ? (int) $_GET['id']
    : 0;

$formData = [];
$hasSubmittedForm = false;

$allowedActions = ['list', 'create', 'edit'];

if (!in_array($action, $allowedActions, true)) {
    $action = 'list';
}

/* =========================================================
   4. XỬ LÝ FORM POST
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {

    $postedToken =
        isset($_POST['csrf_token']) &&
        is_string($_POST['csrf_token'])
            ? $_POST['csrf_token']
            : '';

    if (
        !function_exists('comic_admin_csrf_valid') ||
        !comic_admin_csrf_valid($postedToken)
    ) {
        comic_admin_comics_flash(
            'error',
            'Phiên làm việc hết hạn. Vui lòng tải lại trang.'
        );

        comic_admin_comics_redirect();
    }

    $postAction =
        isset($_POST['action']) &&
        is_string($_POST['action'])
            ? $_POST['action']
            : '';

    if (!$dbReady) {
        $errors[] =
            'Chưa kết nối được cơ sở dữ liệu. '
            . 'Hãy kiểm tra config/db.php.';

        $action = 'list';
    }

    /* -----------------------------------------------------
       4.1. HIỆN / ẨN TRUYỆN
    ----------------------------------------------------- */

    elseif ($postAction === 'set_active') {

        $id = isset($_POST['id'])
            ? (int) $_POST['id']
            : 0;

        $active = isset($_POST['is_active'])
            ? (int) $_POST['is_active']
            : -1;

        if ($id < 1 || !in_array($active, [0, 1], true)) {
            comic_admin_comics_flash(
                'error',
                'Yêu cầu cập nhật trạng thái không hợp lệ.'
            );

            comic_admin_comics_redirect();
        }

        try {
            $result = comic_admin_comics_query(
                $database,
                'UPDATE comics SET is_active = ? WHERE id = ?',
                [$active, $id]
            );

            if ($result['affected'] < 0) {
                throw new RuntimeException(
                    'Không cập nhật được trạng thái truyện.'
                );
            }

            comic_admin_comics_flash(
                'success',
                $active === 1
                    ? 'Đã hiển thị truyện trên cửa hàng.'
                    : 'Đã ẩn truyện khỏi cửa hàng.'
            );

            $_SESSION['comic_admin_csrf'] =
                bin2hex(random_bytes(32));

        } catch (Throwable $exception) {
            error_log(
                '[Comic Shop Admin Comics] '
                . $exception->getMessage()
            );

            comic_admin_comics_flash(
                'error',
                'Không cập nhật được trạng thái truyện.'
            );
        }

        comic_admin_comics_redirect();
    }

    /* -----------------------------------------------------
       4.2. THÊM / CẬP NHẬT TRUYỆN
    ----------------------------------------------------- */

    elseif ($postAction === 'save') {

        $hasSubmittedForm = true;

        $formMode =
            isset($_POST['form_mode']) &&
            $_POST['form_mode'] === 'edit'
                ? 'edit'
                : 'create';

        $editId = isset($_POST['id'])
            ? (int) $_POST['id']
            : 0;

        $action = $formMode;

        $formData = [
            'title' => trim((string) ($_POST['title'] ?? '')),
            'slug' => trim((string) ($_POST['slug'] ?? '')),
            'category_id' => (int) ($_POST['category_id'] ?? 0),
            'author_id' => trim((string) ($_POST['author_id'] ?? '')),
            'publisher_id' => trim((string) ($_POST['publisher_id'] ?? '')),
            'series_id' => trim((string) ($_POST['series_id'] ?? '')),
            'volume_number' => trim((string) ($_POST['volume_number'] ?? '')),
            'price' => trim((string) ($_POST['price'] ?? '')),
            'sale_price' => trim((string) ($_POST['sale_price'] ?? '')),
            'cover_image' => trim((string) ($_POST['cover_image'] ?? '')),
            'description' => trim((string) ($_POST['description'] ?? '')),
            'isbn' => trim((string) ($_POST['isbn'] ?? '')),
            'pages' => trim((string) ($_POST['pages'] ?? '')),
            'language' => trim((string) ($_POST['language'] ?? 'Tiếng Việt')),
            'cover_type' => (string) ($_POST['cover_type'] ?? 'paperback'),
            'age_rating' => (string) ($_POST['age_rating'] ?? 'all'),
            'release_date' => trim((string) ($_POST['release_date'] ?? '')),
            'stock' => trim((string) ($_POST['stock'] ?? '0')),
            'is_featured' => isset($_POST['is_featured']) ? 1 : 0,
            'is_new' => isset($_POST['is_new']) ? 1 : 0,
            'is_discount' => isset($_POST['is_discount']) ? 1 : 0,
            'is_active' => isset($_POST['is_active']) ? 1 : 0,
        ];

        $title = $formData['title'];

        $slug = $formData['slug'] !== ''
            ? comic_admin_comics_slug($formData['slug'])
            : comic_admin_comics_slug($title);

        if ($slug === '' && $title !== '') {
            $slug = 'comic-' . bin2hex(random_bytes(4));
        }

        $categoryId = (int) $formData['category_id'];

        $authorId = $formData['author_id'] !== ''
            ? (int) $formData['author_id']
            : null;

        $publisherId = $formData['publisher_id'] !== ''
            ? (int) $formData['publisher_id']
            : null;

        $seriesId = $formData['series_id'] !== ''
            ? (int) $formData['series_id']
            : null;

        $volumeRaw = $formData['volume_number'];
        $pagesRaw = $formData['pages'];

        $volume = $volumeRaw !== '' &&
            filter_var($volumeRaw, FILTER_VALIDATE_INT) !== false
                ? (int) $volumeRaw
                : null;

        $pages = $pagesRaw !== '' &&
            filter_var($pagesRaw, FILTER_VALIDATE_INT) !== false
                ? (int) $pagesRaw
                : null;

        $isbn = $formData['isbn'] !== ''
            ? $formData['isbn']
            : null;

        $releaseDate = $formData['release_date'] !== ''
            ? $formData['release_date']
            : null;

        $salePriceRaw = $formData['sale_price'];

        $salePrice = $salePriceRaw !== '' &&
            is_numeric($salePriceRaw)
                ? (float) $salePriceRaw
                : null;

        $price = is_numeric($formData['price'])
            ? (float) $formData['price']
            : -1;

        $stock = filter_var(
            $formData['stock'],
            FILTER_VALIDATE_INT
        );

        $coverTypes = ['paperback', 'hardcover', 'boxset'];
        $ageRatings = ['all', '13+', '16+', '18+'];

        $titleLength = function_exists('mb_strlen')
            ? mb_strlen($title, 'UTF-8')
            : strlen($title);

        if ($title === '' || $titleLength > 220) {
            $errors[] =
                'Tên truyện là bắt buộc và không vượt quá 220 ký tự.';
        }

        if ($slug === '' || strlen($slug) > 240) {
            $errors[] =
                'Slug không hợp lệ hoặc vượt quá 240 ký tự.';
        }

        if ($categoryId < 1) {
            $errors[] = 'Vui lòng chọn thể loại truyện.';
        }

        if ($price < 0) {
            $errors[] =
                'Giá bán phải là số và không được âm.';
        }

        if ($salePriceRaw !== '' && !is_numeric($salePriceRaw)) {
            $errors[] = 'Giá khuyến mãi phải là số hợp lệ.';
        } elseif (
            $salePrice !== null &&
            ($salePrice < 0 || $salePrice > $price)
        ) {
            $errors[] =
                'Giá khuyến mãi phải từ 0 đến không lớn hơn giá bán.';
        }

        if ($stock === false || $stock < 0) {
            $errors[] =
                'Tồn kho phải là số nguyên không âm.';
        }

        if (
            $volumeRaw !== '' &&
            (
                filter_var($volumeRaw, FILTER_VALIDATE_INT) === false ||
                $volume === null ||
                $volume < 1
            )
        ) {
            $errors[] = 'Số tập phải là số nguyên dương.';
        }

        if (
            $pagesRaw !== '' &&
            (
                filter_var($pagesRaw, FILTER_VALIDATE_INT) === false ||
                $pages === null ||
                $pages < 1
            )
        ) {
            $errors[] = 'Số trang phải là số nguyên dương.';
        }

        if ($authorId !== null && $authorId < 1) {
            $errors[] = 'Tác giả không hợp lệ.';
        }

        if ($publisherId !== null && $publisherId < 1) {
            $errors[] = 'Nhà xuất bản không hợp lệ.';
        }

        if ($seriesId !== null && $seriesId < 1) {
            $errors[] = 'Bộ truyện không hợp lệ.';
        }

        if (strlen((string) $isbn) > 20) {
            $errors[] = 'ISBN không được dài quá 20 ký tự.';
        }

        if (strlen($formData['cover_image']) > 255) {
            $errors[] =
                'Đường dẫn ảnh bìa không được dài quá 255 ký tự.';
        }

        if (
            strlen($formData['language']) > 30 ||
            $formData['language'] === ''
        ) {
            $errors[] =
                'Ngôn ngữ không được để trống và tối đa 30 ký tự.';
        }

        if (!in_array($formData['cover_type'], $coverTypes, true)) {
            $errors[] = 'Loại bìa không hợp lệ.';
        }

        if (!in_array($formData['age_rating'], $ageRatings, true)) {
            $errors[] = 'Độ tuổi phù hợp không hợp lệ.';
        }

        if ($releaseDate !== null) {
            $date = DateTime::createFromFormat(
                '!Y-m-d',
                $releaseDate
            );

            if (
                !$date ||
                $date->format('Y-m-d') !== $releaseDate
            ) {
                $errors[] =
                    'Ngày phát hành phải có định dạng YYYY-MM-DD.';
            }
        }

        /* Xác minh các khóa ngoại và giá trị duy nhất. */
        if (!$errors) {
            try {
                $categoryCheck = comic_admin_comics_query(
                    $database,
                    'SELECT id FROM categories WHERE id = ? LIMIT 1',
                    [$categoryId]
                );

                if (!$categoryCheck['rows']) {
                    $errors[] =
                        'Thể loại được chọn không tồn tại.';
                }

                if ($authorId !== null && !$errors) {
                    $check = comic_admin_comics_query(
                        $database,
                        'SELECT id FROM authors WHERE id = ? LIMIT 1',
                        [$authorId]
                    );

                    if (!$check['rows']) {
                        $errors[] =
                            'Tác giả được chọn không tồn tại.';
                    }
                }

                if ($publisherId !== null && !$errors) {
                    $check = comic_admin_comics_query(
                        $database,
                        'SELECT id FROM publishers WHERE id = ? LIMIT 1',
                        [$publisherId]
                    );

                    if (!$check['rows']) {
                        $errors[] =
                            'Nhà xuất bản được chọn không tồn tại.';
                    }
                }

                if ($seriesId !== null && !$errors) {
                    $check = comic_admin_comics_query(
                        $database,
                        'SELECT id FROM series WHERE id = ? LIMIT 1',
                        [$seriesId]
                    );

                    if (!$check['rows']) {
                        $errors[] =
                            'Bộ truyện được chọn không tồn tại.';
                    }
                }

                if (!$errors) {
                    $slugSql =
                        'SELECT id FROM comics WHERE slug = ?';

                    $slugParams = [$slug];

                    if ($formMode === 'edit' && $editId > 0) {
                        $slugSql .= ' AND id <> ?';
                        $slugParams[] = $editId;
                    }

                    $slugSql .= ' LIMIT 1';

                    if (
                        comic_admin_comics_query(
                            $database,
                            $slugSql,
                            $slugParams
                        )['rows']
                    ) {
                        $errors[] =
                            'Slug đã được sử dụng. Hãy nhập slug khác.';
                    }
                }

                if (!$errors && $isbn !== null) {
                    $isbnSql =
                        'SELECT id FROM comics WHERE isbn = ?';

                    $isbnParams = [$isbn];

                    if ($formMode === 'edit' && $editId > 0) {
                        $isbnSql .= ' AND id <> ?';
                        $isbnParams[] = $editId;
                    }

                    $isbnSql .= ' LIMIT 1';

                    if (
                        comic_admin_comics_query(
                            $database,
                            $isbnSql,
                            $isbnParams
                        )['rows']
                    ) {
                        $errors[] =
                            'ISBN đã tồn tại trong cửa hàng.';
                    }
                }

                if (!$errors) {
                    $values = [
                        $categoryId,
                        $authorId,
                        $publisherId,
                        $seriesId,
                        $volume,
                        $title,
                        $slug,
                        $price,
                        $salePrice,
                        $formData['cover_image'] !== ''
                            ? $formData['cover_image']
                            : null,
                        $formData['description'] !== ''
                            ? $formData['description']
                            : null,
                        $isbn,
                        $pages,
                        $formData['language'],
                        $formData['cover_type'],
                        $formData['age_rating'],
                        $releaseDate,
                        (int) $stock,
                        $formData['is_featured'],
                        $formData['is_new'],
                        $formData['is_discount'],
                        $formData['is_active'],
                    ];

                    if ($formMode === 'edit') {
                        if ($editId < 1) {
                            $errors[] =
                                'ID truyện cần cập nhật không hợp lệ.';
                        } else {
                            $updateSql = 'UPDATE comics SET
                                category_id = ?,
                                author_id = ?,
                                publisher_id = ?,
                                series_id = ?,
                                volume_number = ?,
                                title = ?,
                                slug = ?,
                                price = ?,
                                sale_price = ?,
                                cover_image = ?,
                                description = ?,
                                isbn = ?,
                                pages = ?,
                                language = ?,
                                cover_type = ?,
                                age_rating = ?,
                                release_date = ?,
                                stock = ?,
                                is_featured = ?,
                                is_new = ?,
                                is_discount = ?,
                                is_active = ?
                                WHERE id = ?';

                            $values[] = $editId;

                            comic_admin_comics_query(
                                $database,
                                $updateSql,
                                $values
                            );

                            comic_admin_comics_flash(
                                'success',
                                'Đã cập nhật thông tin truyện.'
                            );

                            $_SESSION['comic_admin_csrf'] =
                                bin2hex(random_bytes(32));

                            comic_admin_comics_redirect();
                        }
                    } else {
                        $insertSql = 'INSERT INTO comics (
                            category_id,
                            author_id,
                            publisher_id,
                            series_id,
                            volume_number,
                            title,
                            slug,
                            price,
                            sale_price,
                            cover_image,
                            description,
                            isbn,
                            pages,
                            language,
                            cover_type,
                            age_rating,
                            release_date,
                            stock,
                            is_featured,
                            is_new,
                            is_discount,
                            is_active
                        ) VALUES (
                            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                        )';

                        comic_admin_comics_query(
                            $database,
                            $insertSql,
                            $values
                        );

                        comic_admin_comics_flash(
                            'success',
                            'Đã thêm truyện mới vào cửa hàng.'
                        );

                        $_SESSION['comic_admin_csrf'] =
                            bin2hex(random_bytes(32));

                        comic_admin_comics_redirect();
                    }
                }
            } catch (Throwable $exception) {
                error_log(
                    '[Comic Shop Admin Comics] '
                    . $exception->getMessage()
                );

                $errors[] =
                    'Không lưu được truyện. Hãy kiểm tra dữ liệu '
                    . 'và nhật ký lỗi PHP.';
            }
        }
    } else {
        comic_admin_comics_flash(
            'error',
            'Thao tác không hợp lệ.'
        );

        comic_admin_comics_redirect();
    }
}

/* =========================================================
   5. TẢI THỂ LOẠI / TÁC GIẢ / NHÀ XUẤT BẢN / BỘ TRUYỆN
========================================================= */

$categories = [];
$authors = [];
$publishers = [];
$seriesList = [];
$editComic = null;

if ($dbReady) {
    try {
        $categories = comic_admin_comics_query(
            $database,
            'SELECT id, name FROM categories ORDER BY name ASC'
        )['rows'];

        $authors = comic_admin_comics_query(
            $database,
            'SELECT id, name FROM authors ORDER BY name ASC'
        )['rows'];

        $publishers = comic_admin_comics_query(
            $database,
            'SELECT id, name FROM publishers ORDER BY name ASC'
        )['rows'];

        $seriesList = comic_admin_comics_query(
            $database,
            'SELECT id, title FROM series ORDER BY title ASC'
        )['rows'];

        if (
            $action === 'edit' &&
            $editId > 0 &&
            !$hasSubmittedForm
        ) {
            $editRows = comic_admin_comics_query(
                $database,
                'SELECT * FROM comics WHERE id = ? LIMIT 1',
                [$editId]
            )['rows'];

            $editComic = $editRows[0] ?? null;

            if (!$editComic) {
                comic_admin_comics_flash(
                    'error',
                    'Không tìm thấy truyện cần sửa.'
                );

                comic_admin_comics_redirect();
            }
        }
    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Admin Comics] '
            . $exception->getMessage()
        );

        $errors[] =
            'Không tải được dữ liệu thể loại, tác giả hoặc truyện.';
    }
}

/* =========================================================
   6. GIÁ TRỊ MẶC ĐỊNH CHO FORM
========================================================= */

$defaultForm = [
    'title' => '',
    'slug' => '',
    'category_id' => '',
    'author_id' => '',
    'publisher_id' => '',
    'series_id' => '',
    'volume_number' => '',
    'price' => '',
    'sale_price' => '',
    'cover_image' => '',
    'description' => '',
    'isbn' => '',
    'pages' => '',
    'language' => 'Tiếng Việt',
    'cover_type' => 'paperback',
    'age_rating' => 'all',
    'release_date' => '',
    'stock' => '0',
    'is_featured' => 0,
    'is_new' => 0,
    'is_discount' => 0,
    'is_active' => 1,
];

if ($action === 'edit' && is_array($editComic)) {
    foreach ($defaultForm as $key => $value) {
        if (array_key_exists($key, $editComic)) {
            $defaultForm[$key] = $editComic[$key] === null
                ? ''
                : $editComic[$key];
        }
    }
}

if ($hasSubmittedForm && $formData !== []) {
    $defaultForm = array_merge($defaultForm, $formData);
}

$formData = $defaultForm;

/* =========================================================
   7. TÌM KIẾM / LỌC / PHÂN TRANG
========================================================= */

$search = isset($_GET['q']) && is_string($_GET['q'])
    ? trim($_GET['q'])
    : '';

$statusFilter = isset($_GET['status']) &&
    is_string($_GET['status'])
        ? $_GET['status']
        : 'all';

if (!in_array(
    $statusFilter,
    ['all', 'active', 'inactive', 'low_stock'],
    true
)) {
    $statusFilter = 'all';
}

$currentPage = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;

$totalComics = 0;
$totalPages = 1;
$comicRows = [];

$summary = [
    'all' => 0,
    'active' => 0,
    'inactive' => 0,
    'low_stock' => 0,
];

$offset = 0;

if ($dbReady && $action === 'list') {
    try {
        $summaryRows = comic_admin_comics_query(
            $database,
            'SELECT
                COUNT(*) AS total_count,
                COALESCE(SUM(is_active = 1), 0) AS active_count,
                COALESCE(SUM(is_active = 0), 0) AS inactive_count,
                COALESCE(
                    SUM(is_active = 1 AND stock <= 5),
                    0
                ) AS low_stock_count
             FROM comics'
        )['rows'];

        if ($summaryRows) {
            $summary = [
                'all' => (int) $summaryRows[0]['total_count'],
                'active' => (int) $summaryRows[0]['active_count'],
                'inactive' => (int) $summaryRows[0]['inactive_count'],
                'low_stock' => (int) $summaryRows[0]['low_stock_count'],
            ];
        }

        $where = [];
        $params = [];

        if ($search !== '') {
            $where[] = '(
                c.title LIKE ?
                OR c.slug LIKE ?
                OR c.isbn LIKE ?
                OR a.name LIKE ?
            )';

            $like = '%' . $search . '%';

            array_push(
                $params,
                $like,
                $like,
                $like,
                $like
            );
        }

        if ($statusFilter === 'active') {
            $where[] = 'c.is_active = 1';
        } elseif ($statusFilter === 'inactive') {
            $where[] = 'c.is_active = 0';
        } elseif ($statusFilter === 'low_stock') {
            $where[] = 'c.is_active = 1 AND c.stock <= 5';
        }

        $whereSql = $where
            ? ' WHERE ' . implode(' AND ', $where)
            : '';

        $countSql = 'SELECT COUNT(*) AS total_count
            FROM comics c
            LEFT JOIN authors a ON a.id = c.author_id'
            . $whereSql;

        $countRows = comic_admin_comics_query(
            $database,
            $countSql,
            $params
        )['rows'];

        $totalComics = (int) (
            $countRows[0]['total_count'] ?? 0
        );

        $totalPages = max(
            1,
            (int) ceil($totalComics / $perPage)
        );

        $currentPage = min($currentPage, $totalPages);
        $offset = ($currentPage - 1) * $perPage;

        $listSql = 'SELECT
                c.id,
                c.title,
                c.slug,
                c.price,
                c.sale_price,
                c.cover_image,
                c.stock,
                c.sold_count,
                c.is_active,
                c.is_featured,
                c.is_new,
                c.is_discount,
                c.created_at,
                cat.name AS category_name,
                a.name AS author_name,
                p.name AS publisher_name
            FROM comics c
            LEFT JOIN categories cat ON cat.id = c.category_id
            LEFT JOIN authors a ON a.id = c.author_id
            LEFT JOIN publishers p ON p.id = c.publisher_id'
            . $whereSql .
            ' ORDER BY c.created_at DESC, c.id DESC
              LIMIT ? OFFSET ?';

        $listParams = $params;
        $listParams[] = $perPage;
        $listParams[] = $offset;

        $comicRows = comic_admin_comics_query(
            $database,
            $listSql,
            $listParams
        )['rows'];

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Admin Comics] '
            . $exception->getMessage()
        );

        $errors[] =
            'Không tải được danh sách truyện. '
            . 'Hãy kiểm tra schema và kết nối cơ sở dữ liệu.';
    }
}

if ($action === 'create') {
    $pageTitle = 'Thêm truyện mới';
    $pageDescription = 'Thêm sản phẩm truyện vào cửa hàng.';
} elseif ($action === 'edit') {
    $pageTitle = 'Chỉnh sửa truyện';
    $pageDescription = 'Cập nhật thông tin sản phẩm truyện.';
}

require_once __DIR__ . '/includes/header.php';
?>

<style>
.comics-admin {
    color: #f2f2f2;
}

.comics-admin .ca-alert {
    margin-bottom: 18px;
    padding: 12px 15px;
    border: 1px solid #f2d1cd;
    border-left: 4px solid #ff6b60;
    background: rgba(255,107,96,.14);
    color: #ff8f86;
    font-size: 12px;
    line-height: 1.6;
}

.comics-admin .ca-alert.success {
    border-color: rgba(80,200,130,.4);
    border-left-color: #50c882;
    background: rgba(80,200,130,.16);
    color: #6fdc9c;
}

.comics-admin .ca-alert.warning {
    border-color: #f4e2b7;
    border-left-color: #d48b18;
    background: rgba(240,180,60,.15);
    color: #795617;
}

.comics-admin .ca-stats {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 13px;
    margin-bottom: 20px;
}

.comics-admin .ca-stat {
    padding: 16px;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    background: #232327;
}

.comics-admin .ca-stat-label {
    color: #a9a9b2;
    font-size: 11px;
    font-weight: 700;
}

.comics-admin .ca-stat-value {
    display: block;
    margin-top: 6px;
    color: #f2f2f2;
    font-size: 25px;
    font-weight: 850;
}

.comics-admin .ca-toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
    margin-bottom: 17px;
}

.comics-admin .ca-search {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 8px;
    flex: 1;
}

.comics-admin .ca-search input,
.comics-admin .ca-search select {
    min-height: 39px;
    max-width: 100%;
    padding: 9px 12px;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    background: #232327;
    color: #f2f2f2;
    font: inherit;
    font-size: 12px;
}

.comics-admin .ca-search input {
    min-width: 220px;
    flex: 1;
}

.comics-admin .ca-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    min-height: 36px;
    padding: 8px 12px;
    border: 1px solid transparent;
    border-radius: 999px;
    background: #f2f2f2;
    color: #111111;
    font-size: 12px;
    font-weight: 800;
    text-decoration: none;
    cursor: pointer;
}

.comics-admin .ca-btn:hover {
    background: #ffffff;
    color: #111111;
}

.comics-admin .ca-btn.secondary {
    border-color: #3d3d44;
    background: #232327;
    color: #d4d4da;
}

.comics-admin .ca-btn.secondary:hover {
    border-color: #f2f2f2;
    color: #f2f2f2;
}

.comics-admin .ca-btn.danger {
    border-color: #f1d0d0;
    background: rgba(255,107,96,.14);
    color: #ff8f86;
}

.comics-admin .ca-btn.danger:hover {
    background: rgba(255,107,96,.14);
}

.comics-admin .ca-table-panel {
    overflow: hidden;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.22);
}

.comics-admin .ca-table-wrap {
    width: 100%;
    overflow-x: auto;
}

.comics-admin .ca-table {
    width: 100%;
    border-collapse: collapse;
}

.comics-admin .ca-table th {
    padding: 13px 15px;
    background: #2c2c31;
    border-bottom: 1px solid #3d3d44;
    color: #a9a9b2;
    font-size: 10px;
    text-align: left;
    text-transform: uppercase;
    letter-spacing: .5px;
    white-space: nowrap;
}

.comics-admin .ca-table td {
    padding: 13px 15px;
    border-bottom: 1px solid #3d3d44;
    color: #444c58;
    font-size: 12px;
    vertical-align: middle;
}

.comics-admin .ca-table tbody tr:last-child td {
    border-bottom: 0;
}

.comics-admin .ca-table tbody tr:hover {
    background: #2c2c31;
}

.comics-admin .ca-product {
    display: flex;
    min-width: 200px;
    align-items: center;
    gap: 11px;
}

.comics-admin .ca-cover {
    width: 44px;
    height: 58px;
    flex: 0 0 44px;
    object-fit: cover;
    border-radius: 5px;
    background: #36363c;
}

.comics-admin .ca-cover-empty {
    display: grid;
    place-items: center;
    width: 44px;
    height: 58px;
    flex: 0 0 44px;
    border-radius: 5px;
    background: rgba(255,107,96,.14);
    color: #f2f2f2;
    font-size: 18px;
}

.comics-admin .ca-product-title {
    display: block;
    max-width: 260px;
    color: #f2f2f2;
    font-weight: 800;
    line-height: 1.45;
}

.comics-admin .ca-subtitle {
    display: block;
    margin-top: 4px;
    color: #a9a9b2;
    font-size: 10px;
}

.comics-admin .ca-price {
    white-space: nowrap;
    color: #f2f2f2;
    font-weight: 800;
}

.comics-admin .ca-old-price {
    display: block;
    margin-top: 3px;
    color: #9299a4;
    font-size: 10px;
    font-weight: 500;
    text-decoration: line-through;
}

.comics-admin .ca-badge {
    display: inline-flex;
    padding: 5px 8px;
    border-radius: 24px;
    font-size: 10px;
    font-weight: 800;
    white-space: nowrap;
}

.comics-admin .ca-badge.active {
    background: rgba(80,200,130,.16);
    color: #6fdc9c;
}

.comics-admin .ca-badge.inactive {
    background: #36363c;
    color: #b5b5bd;
}

.comics-admin .ca-badge.low {
    background: rgba(255,107,96,.14);
    color: #b52827;
}

.comics-admin .ca-actions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 6px;
}

.comics-admin .ca-mini-form {
    display: inline;
    margin: 0;
}

.comics-admin .ca-empty {
    padding: 38px 18px;
    color: #a9a9b2;
    text-align: center;
    font-size: 12px;
}

.comics-admin .ca-pagination {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
    padding: 15px 17px;
    border-top: 1px solid #3d3d44;
}

.comics-admin .ca-pages {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
}

.comics-admin .ca-pages a,
.comics-admin .ca-pages span {
    display: grid;
    min-width: 33px;
    height: 33px;
    padding: 0 8px;
    place-items: center;
    border: 1px solid #3d3d44;
    border-radius: 6px;
    background: #232327;
    color: #525b68;
    font-size: 11px;
    text-decoration: none;
}

.comics-admin .ca-pages .current {
    border-color: #f2f2f2;
    background: #f2f2f2;
    color: #111111;
}

.comics-admin .ca-muted {
    color: #a9a9b2;
    font-size: 11px;
}

.comics-admin .ca-form-panel {
    max-width: 1100px;
    overflow: hidden;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.22);
}

.comics-admin .ca-form-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
    padding: 18px 22px;
    border-bottom: 1px solid #3d3d44;
}

.comics-admin .ca-form-head h2 {
    margin: 0;
    font-size: 15px;
    font-weight: 850;
}

.comics-admin .ca-form-body {
    padding: 22px;
}

.comics-admin .ca-form-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 17px;
}

.comics-admin .ca-field {
    min-width: 0;
}

.comics-admin .ca-field.full {
    grid-column: 1 / -1;
}

.comics-admin .ca-field label,
.comics-admin .ca-field > span {
    display: block;
    margin-bottom: 7px;
    color: #363d48;
    font-size: 11px;
    font-weight: 800;
}

.comics-admin .ca-field input:not([type=checkbox]),
.comics-admin .ca-field select,
.comics-admin .ca-field textarea {
    display: block;
    width: 100%;
    min-height: 41px;
    padding: 10px 12px;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    outline: none;
    background: #232327;
    color: #f2f2f2;
    font: inherit;
    font-size: 12px;
}

.comics-admin .ca-field textarea {
    min-height: 110px;
    resize: vertical;
}

.comics-admin .ca-field input:focus,
.comics-admin .ca-field select:focus,
.comics-admin .ca-field textarea:focus {
    border-color: #f2f2f2;
    box-shadow: 0 0 0 3px rgba(239,67,56,.1);
}

.comics-admin .ca-checks {
    display: flex;
    flex-wrap: wrap;
    gap: 14px 22px;
    padding: 14px;
    border: 1px solid #3d3d44;
    border-radius: 8px;
    background: #2c2c31;
}

.comics-admin .ca-check {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #d4d4da;
    font-size: 12px;
    font-weight: 650;
}

.comics-admin .ca-check input {
    accent-color: #f2f2f2;
}

.comics-admin .ca-help {
    margin-top: 5px;
    color: #a9a9b2;
    font-size: 10px;
    line-height: 1.5;
}

.comics-admin .ca-form-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 9px;
    margin-top: 23px;
    padding-top: 18px;
    border-top: 1px solid #3d3d44;
}

@media (max-width: 1100px) {
    .comics-admin .ca-stats {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 700px) {
    .comics-admin .ca-stats {
        gap: 9px;
    }

    .comics-admin .ca-stat {
        padding: 13px;
    }

    .comics-admin .ca-stat-value {
        font-size: 22px;
    }

    .comics-admin .ca-form-body {
        padding: 15px;
    }

    .comics-admin .ca-form-grid {
        grid-template-columns: 1fr;
    }

    .comics-admin .ca-field.full {
        grid-column: auto;
    }

    .comics-admin .ca-toolbar {
        align-items: stretch;
    }

    .comics-admin .ca-search {
        width: 100%;
    }

    .comics-admin .ca-search input {
        min-width: 0;
    }
}

@media (max-width: 380px) {
    .comics-admin .ca-stats {
        grid-template-columns: 1fr 1fr;
    }
}
</style>

<div class="comics-admin">

    <?php if (is_array($flash) && !empty($flash['message'])): ?>
        <?php $flashType = (string) ($flash['type'] ?? 'info'); ?>

        <div
            class="ca-alert <?= $flashType === 'success' ? 'success' : ($flashType === 'warning' ? 'warning' : '') ?>"
            role="status"
        >
            <?= comic_admin_comics_escape($flash['message']) ?>
        </div>
    <?php endif; ?>

    <?php if (!$dbReady): ?>
        <div class="ca-alert">
            Không tìm thấy kết nối cơ sở dữ liệu. Hãy kiểm tra
            <strong>config/db.php</strong> và cách bootstrap.php
            lưu kết nối.
        </div>
    <?php endif; ?>

    <?php if ($errors): ?>
        <div class="ca-alert" role="alert">
            <strong>Cần kiểm tra:</strong>

            <ul style="margin:7px 0 0;padding-left:19px">
                <?php foreach ($errors as $error): ?>
                    <li><?= comic_admin_comics_escape($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($action === 'create' || $action === 'edit'): ?>

        <div class="ca-toolbar">
            <div>
                <h2 style="margin:0;font-size:19px;font-weight:850">
                    <?= $action === 'edit' ? 'Chỉnh sửa truyện' : 'Thêm truyện mới' ?>
                </h2>

                <p class="ca-muted" style="margin:5px 0 0">
                    Các trường có dấu * là bắt buộc.
                </p>
            </div>

            <a class="ca-btn secondary" href="comics.php">
                ← Quay lại danh sách
            </a>
        </div>

        <section class="ca-form-panel">

            <div class="ca-form-head">
                <h2>Thông tin sản phẩm</h2>
                <span class="ca-muted">Comic Shop · Catalog</span>
            </div>

            <div class="ca-form-body">

                <form method="post" action="comics.php" autocomplete="off">

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= comic_admin_comics_escape(comic_admin_csrf_token()) ?>"
                    >

                    <input type="hidden" name="action" value="save">

                    <input
                        type="hidden"
                        name="form_mode"
                        value="<?= comic_admin_comics_escape($action) ?>"
                    >

                    <input type="hidden" name="id" value="<?= (int) $editId ?>">

                    <div class="ca-form-grid">

                        <div class="ca-field full">
                            <label for="comic-title">Tên truyện *</label>

                            <input
                                id="comic-title"
                                name="title"
                                maxlength="220"
                                required
                                value="<?= comic_admin_comics_escape($formData['title']) ?>"
                                placeholder="Ví dụ: One Piece - Tập 1"
                            >
                        </div>

                        <div class="ca-field">
                            <label for="comic-slug">Slug</label>

                            <input
                                id="comic-slug"
                                name="slug"
                                maxlength="240"
                                value="<?= comic_admin_comics_escape($formData['slug']) ?>"
                                placeholder="one-piece-tap-1"
                            >

                            <div class="ca-help">
                                Để trống để tự tạo từ tên truyện.
                                Slug phải duy nhất.
                            </div>
                        </div>

                        <div class="ca-field">
                            <label for="comic-category">Thể loại *</label>

                            <select id="comic-category" name="category_id" required>
                                <option value="">-- Chọn thể loại --</option>

                                <?php foreach ($categories as $category): ?>
                                    <option
                                        value="<?= (int) $category['id'] ?>"
                                        <?= (string) $formData['category_id'] === (string) $category['id'] ? 'selected' : '' ?>
                                    >
                                        <?= comic_admin_comics_escape($category['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="ca-field">
                            <label for="comic-author">Tác giả</label>

                            <select id="comic-author" name="author_id">
                                <option value="">-- Chưa chọn --</option>

                                <?php foreach ($authors as $author): ?>
                                    <option
                                        value="<?= (int) $author['id'] ?>"
                                        <?= (string) $formData['author_id'] === (string) $author['id'] ? 'selected' : '' ?>
                                    >
                                        <?= comic_admin_comics_escape($author['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="ca-field">
                            <label for="comic-publisher">Nhà xuất bản</label>

                            <select id="comic-publisher" name="publisher_id">
                                <option value="">-- Chưa chọn --</option>

                                <?php foreach ($publishers as $publisher): ?>
                                    <option
                                        value="<?= (int) $publisher['id'] ?>"
                                        <?= (string) $formData['publisher_id'] === (string) $publisher['id'] ? 'selected' : '' ?>
                                    >
                                        <?= comic_admin_comics_escape($publisher['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="ca-field">
                            <label for="comic-series">Bộ truyện</label>

                            <select id="comic-series" name="series_id">
                                <option value="">-- Chưa chọn --</option>

                                <?php foreach ($seriesList as $series): ?>
                                    <option
                                        value="<?= (int) $series['id'] ?>"
                                        <?= (string) $formData['series_id'] === (string) $series['id'] ? 'selected' : '' ?>
                                    >
                                        <?= comic_admin_comics_escape($series['title']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="ca-field">
                            <label for="comic-volume">Số tập</label>

                            <input
                                id="comic-volume"
                                name="volume_number"
                                type="number"
                                min="1"
                                step="1"
                                value="<?= comic_admin_comics_escape($formData['volume_number']) ?>"
                                placeholder="Ví dụ: 1"
                            >
                        </div>

                        <div class="ca-field">
                            <label for="comic-price">Giá bán (VNĐ) *</label>

                            <input
                                id="comic-price"
                                name="price"
                                type="number"
                                min="0"
                                step="1000"
                                required
                                value="<?= comic_admin_comics_escape($formData['price']) ?>"
                                placeholder="25000"
                            >
                        </div>

                        <div class="ca-field">
                            <label for="comic-sale-price">
                                Giá khuyến mãi (VNĐ)
                            </label>

                            <input
                                id="comic-sale-price"
                                name="sale_price"
                                type="number"
                                min="0"
                                step="1000"
                                value="<?= comic_admin_comics_escape($formData['sale_price']) ?>"
                                placeholder="Để trống nếu không giảm giá"
                            >
                        </div>

                        <div class="ca-field">
                            <label for="comic-stock">Số lượng tồn kho *</label>

                            <input
                                id="comic-stock"
                                name="stock"
                                type="number"
                                min="0"
                                step="1"
                                required
                                value="<?= comic_admin_comics_escape($formData['stock']) ?>"
                            >
                        </div>

                        <div class="ca-field">
                            <label for="comic-isbn">ISBN</label>

                            <input
                                id="comic-isbn"
                                name="isbn"
                                maxlength="20"
                                value="<?= comic_admin_comics_escape($formData['isbn']) ?>"
                                placeholder="Mã ISBN, nếu có"
                            >
                        </div>

                        <div class="ca-field">
                            <label for="comic-pages">Số trang</label>

                            <input
                                id="comic-pages"
                                name="pages"
                                type="number"
                                min="1"
                                step="1"
                                value="<?= comic_admin_comics_escape($formData['pages']) ?>"
                            >
                        </div>

                        <div class="ca-field">
                            <label for="comic-language">Ngôn ngữ *</label>

                            <input
                                id="comic-language"
                                name="language"
                                maxlength="30"
                                required
                                value="<?= comic_admin_comics_escape($formData['language']) ?>"
                            >
                        </div>

                        <div class="ca-field">
                            <label for="comic-cover-type">Loại bìa</label>

                            <select id="comic-cover-type" name="cover_type">
                                <?php
                                $coverTypeLabels = [
                                    'paperback' => 'Bìa mềm',
                                    'hardcover' => 'Bìa cứng',
                                    'boxset' => 'Bộ hộp',
                                ];
                                ?>

                                <?php foreach ($coverTypeLabels as $key => $label): ?>
                                    <option
                                        value="<?= comic_admin_comics_escape($key) ?>"
                                        <?= $formData['cover_type'] === $key ? 'selected' : '' ?>
                                    >
                                        <?= comic_admin_comics_escape($label) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="ca-field">
                            <label for="comic-age">Độ tuổi</label>

                            <select id="comic-age" name="age_rating">
                                <?php
                                $ageLabels = [
                                    'all' => 'Mọi lứa tuổi',
                                    '13+' => '13+',
                                    '16+' => '16+',
                                    '18+' => '18+',
                                ];
                                ?>

                                <?php foreach ($ageLabels as $key => $label): ?>
                                    <option
                                        value="<?= comic_admin_comics_escape($key) ?>"
                                        <?= $formData['age_rating'] === $key ? 'selected' : '' ?>
                                    >
                                        <?= comic_admin_comics_escape($label) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="ca-field">
                            <label for="comic-release">Ngày phát hành</label>

                            <input
                                id="comic-release"
                                name="release_date"
                                type="date"
                                value="<?= comic_admin_comics_escape($formData['release_date']) ?>"
                            >
                        </div>

                        <div class="ca-field full">
                            <label for="comic-cover">Đường dẫn ảnh bìa</label>

                            <input
                                id="comic-cover"
                                name="cover_image"
                                maxlength="255"
                                value="<?= comic_admin_comics_escape($formData['cover_image']) ?>"
                                placeholder="assets/images/covers/one-piece-1.jpg"
                            >

                            <div class="ca-help">
                                Nhập đường dẫn tương đối từ thư mục gốc
                                comic_shop hoặc URL ảnh.
                            </div>
                        </div>

                        <div class="ca-field full">
                            <label for="comic-description">Mô tả</label>

                            <textarea
                                id="comic-description"
                                name="description"
                                rows="4"
                                placeholder="Giới thiệu ngắn về truyện..."
                            ><?= comic_admin_comics_escape($formData['description']) ?></textarea>
                        </div>

                        <div class="ca-field full">
                            <span>Hiển thị và phân loại</span>

                            <div class="ca-checks">
                                <label class="ca-check">
                                    <input
                                        type="checkbox"
                                        name="is_active"
                                        value="1"
                                        <?= (int) $formData['is_active'] === 1 ? 'checked' : '' ?>
                                    >
                                    Đang hiển thị
                                </label>

                                <label class="ca-check">
                                    <input
                                        type="checkbox"
                                        name="is_featured"
                                        value="1"
                                        <?= (int) $formData['is_featured'] === 1 ? 'checked' : '' ?>
                                    >
                                    Nổi bật
                                </label>

                                <label class="ca-check">
                                    <input
                                        type="checkbox"
                                        name="is_new"
                                        value="1"
                                        <?= (int) $formData['is_new'] === 1 ? 'checked' : '' ?>
                                    >
                                    Truyện mới
                                </label>

                                <label class="ca-check">
                                    <input
                                        type="checkbox"
                                        name="is_discount"
                                        value="1"
                                        <?= (int) $formData['is_discount'] === 1 ? 'checked' : '' ?>
                                    >
                                    Khuyến mãi
                                </label>
                            </div>
                        </div>

                    </div>

                    <div class="ca-form-actions">
                        <button class="ca-btn" type="submit">
                            Lưu truyện
                        </button>

                        <a class="ca-btn secondary" href="comics.php">
                            Hủy
                        </a>
                    </div>

                </form>
            </div>
        </section>

    <?php else: ?>

        <!-- THỐNG KÊ -->
        <section class="ca-stats" aria-label="Tổng quan danh sách truyện">

            <div class="ca-stat">
                <span class="ca-stat-label">Tất cả truyện</span>
                <strong class="ca-stat-value">
                    <?= number_format($summary['all']) ?>
                </strong>
            </div>

            <div class="ca-stat">
                <span class="ca-stat-label">Đang hiển thị</span>
                <strong class="ca-stat-value" style="color:#6fdc9c">
                    <?= number_format($summary['active']) ?>
                </strong>
            </div>

            <div class="ca-stat">
                <span class="ca-stat-label">Đang ẩn</span>
                <strong class="ca-stat-value" style="color:#a9a9b2">
                    <?= number_format($summary['inactive']) ?>
                </strong>
            </div>

            <div class="ca-stat">
                <span class="ca-stat-label">Sắp hết hàng</span>
                <strong class="ca-stat-value" style="color:#f2f2f2">
                    <?= number_format($summary['low_stock']) ?>
                </strong>
            </div>

        </section>

        <!-- THANH TÌM KIẾM -->
        <div class="ca-toolbar">

            <form class="ca-search" method="get" action="comics.php">

                <input
                    type="search"
                    name="q"
                    value="<?= comic_admin_comics_escape($search) ?>"
                    placeholder="Tìm tên truyện, slug, ISBN, tác giả..."
                    aria-label="Tìm truyện"
                >

                <select name="status" aria-label="Lọc trạng thái">
                    <option
                        value="all"
                        <?= $statusFilter === 'all' ? 'selected' : '' ?>
                    >
                        Tất cả trạng thái
                    </option>

                    <option
                        value="active"
                        <?= $statusFilter === 'active' ? 'selected' : '' ?>
                    >
                        Đang hiển thị
                    </option>

                    <option
                        value="inactive"
                        <?= $statusFilter === 'inactive' ? 'selected' : '' ?>
                    >
                        Đang ẩn
                    </option>

                    <option
                        value="low_stock"
                        <?= $statusFilter === 'low_stock' ? 'selected' : '' ?>
                    >
                        Sắp hết hàng
                    </option>
                </select>

                <button class="ca-btn secondary" type="submit">
                    Tìm kiếm
                </button>

                <?php if ($search !== '' || $statusFilter !== 'all'): ?>
                    <a class="ca-btn secondary" href="comics.php">
                        Xóa lọc
                    </a>
                <?php endif; ?>

            </form>

            <a class="ca-btn" href="comics.php?action=create">
                ＋ Thêm truyện
            </a>

        </div>

        <!-- DANH SÁCH TRUYỆN -->
        <section class="ca-table-panel">

            <?php if (!$dbReady): ?>

                <div class="ca-empty">
                    Không thể hiển thị danh sách khi chưa có kết nối
                    cơ sở dữ liệu.
                </div>

            <?php elseif (!$comicRows): ?>

                <div class="ca-empty">
                    <div
                        style="font-size:30px;margin-bottom:8px;color:#b9c0ca"
                        aria-hidden="true"
                    >▣</div>

                    Không tìm thấy truyện phù hợp.

                    <div style="margin-top:12px">
                        <a class="ca-btn" href="comics.php?action=create">
                            Thêm truyện đầu tiên
                        </a>
                    </div>
                </div>

            <?php else: ?>

                <div class="ca-table-wrap">

                    <table class="ca-table">

                        <thead>
                            <tr>
                                <th>Truyện</th>
                                <th>Thể loại / Tác giả</th>
                                <th>Giá bán</th>
                                <th>Tồn kho</th>
                                <th>Đã bán</th>
                                <th>Trạng thái</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach ($comicRows as $comic): ?>

                                <?php
                                $coverUrl = comic_admin_comics_cover_url(
                                    (string) ($comic['cover_image'] ?? ''),
                                    (string) ($comic['title'] ?? '')
                                );

                                $salePriceValue =
                                    $comic['sale_price'] !== null &&
                                    $comic['sale_price'] !== ''
                                        ? (float) $comic['sale_price']
                                        : null;

                                $displayPrice = $salePriceValue
                                    ?? (float) ($comic['price'] ?? 0);

                                $active = (int) ($comic['is_active'] ?? 0) === 1;
                                $stock = (int) ($comic['stock'] ?? 0);
                                ?>

                                <tr>

                                    <td>
                                        <div class="ca-product">

                                            <?php if ($coverUrl !== ''): ?>

                                                <img
                                                    class="ca-cover"
                                                    src="<?= comic_admin_comics_escape($coverUrl) ?>"
                                                    alt="Bìa <?= comic_admin_comics_escape($comic['title'] ?? '') ?>"
                                                    loading="lazy"
                                                    onerror="this.style.display='none';this.nextElementSibling.style.display='grid';"
                                                >

                                                <span
                                                    class="ca-cover-empty"
                                                    style="display:none"
                                                    aria-hidden="true"
                                                >▣</span>

                                            <?php else: ?>

                                                <span
                                                    class="ca-cover-empty"
                                                    aria-hidden="true"
                                                >▣</span>

                                            <?php endif; ?>

                                            <span>
                                                <span class="ca-product-title">
                                                    <?= comic_admin_comics_escape($comic['title'] ?? '') ?>
                                                </span>

                                                <span class="ca-subtitle">
                                                    #<?= (int) ($comic['id'] ?? 0) ?>
                                                    ·
                                                    <?= comic_admin_comics_escape($comic['slug'] ?? '') ?>
                                                </span>

                                                <?php if ((int) ($comic['is_featured'] ?? 0) === 1): ?>
                                                    <span
                                                        class="ca-badge"
                                                        style="margin-top:5px;background:rgba(240,180,60,.15);color:#956415"
                                                    >
                                                        Nổi bật
                                                    </span>
                                                <?php endif; ?>
                                            </span>

                                        </div>
                                    </td>

                                    <td>
                                        <strong>
                                            <?= comic_admin_comics_escape(
                                                $comic['category_name'] ?? 'Chưa phân loại'
                                            ) ?>
                                        </strong>

                                        <span class="ca-subtitle">
                                            <?= comic_admin_comics_escape(
                                                $comic['author_name'] ?? 'Chưa có tác giả'
                                            ) ?>
                                        </span>

                                        <?php if (!empty($comic['publisher_name'])): ?>
                                            <span class="ca-subtitle">
                                                <?= comic_admin_comics_escape(
                                                    $comic['publisher_name']
                                                ) ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <span class="ca-price">
                                            <?= comic_admin_comics_escape(
                                                comic_admin_comics_money($displayPrice)
                                            ) ?>
                                        </span>

                                        <?php if ($salePriceValue !== null): ?>
                                            <span class="ca-old-price">
                                                <?= comic_admin_comics_escape(
                                                    comic_admin_comics_money($comic['price'])
                                                ) ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <?php if ($stock <= 5): ?>
                                            <span class="ca-badge low">
                                                <?= number_format($stock) ?> cuốn
                                            </span>
                                        <?php else: ?>
                                            <strong>
                                                <?= number_format($stock) ?>
                                            </strong>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <?= number_format(
                                            (int) ($comic['sold_count'] ?? 0)
                                        ) ?>
                                    </td>

                                    <td>
                                        <span class="ca-badge <?= $active ? 'active' : 'inactive' ?>">
                                            <?= $active ? 'Đang hiển thị' : 'Đang ẩn' ?>
                                        </span>
                                    </td>

                                    <td>
                                        <div class="ca-actions">

                                            <a
                                                class="ca-btn secondary"
                                                href="comics.php?action=edit&amp;id=<?= (int) $comic['id'] ?>"
                                            >
                                                Sửa
                                            </a>

                                            <form
                                                class="ca-mini-form"
                                                method="post"
                                                action="comics.php"
                                                data-confirm="<?= $active ? 'Ẩn truyện này khỏi cửa hàng?' : 'Hiển thị lại truyện này?' ?>"
                                            >

                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?= comic_admin_comics_escape(
                                                        comic_admin_csrf_token()
                                                    ) ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="action"
                                                    value="set_active"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="id"
                                                    value="<?= (int) $comic['id'] ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="is_active"
                                                    value="<?= $active ? 0 : 1 ?>"
                                                >

                                                <button
                                                    class="ca-btn <?= $active ? 'danger' : '' ?>"
                                                    type="submit"
                                                >
                                                    <?= $active ? 'Ẩn' : 'Hiện' ?>
                                                </button>

                                            </form>

                                        </div>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>
                    </table>
                </div>

                <!-- PHÂN TRANG -->
                <div class="ca-pagination">

                    <div class="ca-muted">
                        Hiển thị
                        <?= number_format(
                            min($totalComics, $offset + 1)
                        ) ?>–<?= number_format(
                            min($totalComics, $offset + count($comicRows))
                        ) ?>
                        trong <?= number_format($totalComics) ?> truyện
                    </div>

                    <?php if ($totalPages > 1): ?>

                        <nav class="ca-pages" aria-label="Phân trang">

                            <?php
                            $queryBase = [];

                            if ($search !== '') {
                                $queryBase['q'] = $search;
                            }

                            if ($statusFilter !== 'all') {
                                $queryBase['status'] = $statusFilter;
                            }

                            $previousPage = max(1, $currentPage - 1);
                            $nextPage = min($totalPages, $currentPage + 1);
                            ?>

                            <?php if ($currentPage > 1): ?>
                                <?php
                                $prevQuery = http_build_query(
                                    array_merge(
                                        $queryBase,
                                        ['page' => $previousPage]
                                    )
                                );
                                ?>

                                <a
                                    href="comics.php?<?= comic_admin_comics_escape($prevQuery) ?>"
                                    aria-label="Trang trước"
                                >‹</a>
                            <?php endif; ?>

                            <?php
                            $startPage = max(1, $currentPage - 2);
                            $endPage = min($totalPages, $currentPage + 2);

                            for (
                                $i = $startPage;
                                $i <= $endPage;
                                $i++
                            ):
                                $pageQuery = http_build_query(
                                    array_merge(
                                        $queryBase,
                                        ['page' => $i]
                                    )
                                );
                            ?>

                                <?php if ($i === $currentPage): ?>
                                    <span class="current" aria-current="page">
                                        <?= $i ?>
                                    </span>
                                <?php else: ?>
                                    <a href="comics.php?<?= comic_admin_comics_escape($pageQuery) ?>">
                                        <?= $i ?>
                                    </a>
                                <?php endif; ?>

                            <?php endfor; ?>

                            <?php if ($currentPage < $totalPages): ?>
                                <?php
                                $nextQuery = http_build_query(
                                    array_merge(
                                        $queryBase,
                                        ['page' => $nextPage]
                                    )
                                );
                                ?>

                                <a
                                    href="comics.php?<?= comic_admin_comics_escape($nextQuery) ?>"
                                    aria-label="Trang sau"
                                >›</a>
                            <?php endif; ?>

                        </nav>

                    <?php endif; ?>

                </div>

            <?php endif; ?>

        </section>


    <?php endif; ?>

</div>

<script>
(function () {
    'use strict';

    var title = document.getElementById('comic-title');
    var slug = document.getElementById('comic-slug');

    if (!title || !slug) {
        return;
    }

    var slugWasEdited = slug.value.trim() !== '';

    slug.addEventListener('input', function () {
        slugWasEdited = slug.value.trim() !== '';
    });

    title.addEventListener('input', function () {
        if (slugWasEdited) {
            return;
        }

        var value = title.value;

        if (value.normalize) {
            value = value.normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '');
        }

        value = value.toLowerCase()
            .replace(/đ/g, 'd')
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '');

        slug.value = value;
    });
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
