<?php
declare(strict_types=1);

/**
 * Comic Shop - Admin Dashboard
 * File: admin/dashboard.php
 * Sử dụng schema từ comic_shop.sql.
 */

$pageTitle = 'Tổng quan';
$pageDescription = 'Theo dõi hoạt động cửa hàng Comic Shop.';
$activeMenu = 'dashboard';

require_once __DIR__ . '/includes/bootstrap.php';

if (!function_exists('comic_admin_media_url')) {
    require_once __DIR__ . '/includes/media.php';
}

$database = $GLOBALS['comic_shop_db'] ?? null;
$GLOBALS['comic_dashboard_query_error'] = false;

/* =========================================================
   1. HÀM TRUY VẤN DỮ LIỆU
========================================================= */

if (!function_exists('comic_dashboard_rows')) {
    function comic_dashboard_rows($database, string $sql): array
    {
        if (
            !($database instanceof PDO) &&
            !(class_exists('mysqli') && $database instanceof mysqli)
        ) {
            return [];
        }

        try {
            if ($database instanceof PDO) {
                $statement = $database->query($sql);

                if ($statement === false) {
                    $GLOBALS['comic_dashboard_query_error'] = true;
                    return [];
                }

                $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
                $statement->closeCursor();

                return is_array($rows) ? $rows : [];
            }

            $result = $database->query($sql);

            if (!($result instanceof mysqli_result)) {
                $GLOBALS['comic_dashboard_query_error'] = true;
                return [];
            }

            $rows = [];

            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }

            $result->free();

            return $rows;

        } catch (Throwable $exception) {
            $GLOBALS['comic_dashboard_query_error'] = true;

            error_log(
                '[Comic Shop Dashboard] ' .
                $exception->getMessage()
            );

            return [];
        }
    }
}

if (!function_exists('comic_dashboard_value')) {
    function comic_dashboard_value(
        $database,
        string $sql,
        $default = 0
    ) {
        $rows = comic_dashboard_rows($database, $sql);

        if (!$rows) {
            return $default;
        }

        $row = $rows[0];

        if (!is_array($row) || !$row) {
            return $default;
        }

        $value = reset($row);

        return $value === null ? $default : $value;
    }
}

/* =========================================================
   2. HÀM HIỂN THỊ
========================================================= */

if (!function_exists('comic_dashboard_escape')) {
    function comic_dashboard_escape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_dashboard_money')) {
    function comic_dashboard_money($amount): string
    {
        return number_format(
            (float) $amount,
            0,
            ',',
            '.'
        ) . ' ₫';
    }
}

if (!function_exists('comic_dashboard_status')) {
    function comic_dashboard_status(string $status): array
    {
        $map = [
            'pending' => ['Chờ xác nhận', 'warning'],
            'processing' => ['Đang xử lý', 'info'],
            'shipping' => ['Đang giao', 'info'],
            'completed' => ['Hoàn thành', 'success'],
            'cancelled' => ['Đã hủy', 'danger'],
        ];

        return $map[$status] ??
            ['Không xác định', 'secondary'];
    }
}

if (!function_exists('comic_dashboard_cover')) {
    function comic_dashboard_cover(string $path, string $label = ''): string
    {
        return comic_admin_media_url($path, $label, 'cover');
    }
}

/* =========================================================
   3. SỐ LIỆU TỔNG QUAN
========================================================= */

$dashboardStats = [
    'comics' => (int) comic_dashboard_value(
        $database,
        'SELECT COUNT(*)
         FROM comics
         WHERE is_active = 1',
        0
    ),

    'orders' => (int) comic_dashboard_value(
        $database,
        'SELECT COUNT(*)
         FROM orders',
        0
    ),

    'customers' => (int) comic_dashboard_value(
        $database,
        "SELECT COUNT(*)
         FROM users
         WHERE role = 'customer'
           AND is_active = 1",
        0
    ),

    'revenue' => (float) comic_dashboard_value(
        $database,
        "SELECT COALESCE(SUM(total_amount), 0)
         FROM orders
         WHERE payment_status = 'completed'
           AND status <> 'cancelled'",
        0
    ),

    'pending' => (int) comic_dashboard_value(
        $database,
        "SELECT COUNT(*)
         FROM orders
         WHERE status = 'pending'",
        0
    ),

    'low_stock' => (int) comic_dashboard_value(
        $database,
        'SELECT COUNT(*)
         FROM comics
         WHERE is_active = 1
           AND stock <= 5',
        0
    ),

    'authors' => (int) comic_dashboard_value(
        $database,
        'SELECT COUNT(*) FROM authors',
        0
    ),

    'categories' => (int) comic_dashboard_value(
        $database,
        'SELECT COUNT(*) FROM categories',
        0
    ),
];

/* =========================================================
   4. ĐƠN HÀNG MỚI NHẤT
========================================================= */

$recentOrders = comic_dashboard_rows(
    $database,
    'SELECT
        id,
        order_code,
        full_name,
        total_amount,
        status,
        payment_status,
        created_at
     FROM orders
     ORDER BY created_at DESC, id DESC
     LIMIT 8'
);

/* =========================================================
   5. TRUYỆN BÁN CHẠY
========================================================= */

$topComics = comic_dashboard_rows(
    $database,
    'SELECT
        id,
        title,
        cover_image,
        sold_count,
        stock,
        price,
        sale_price
     FROM comics
     WHERE is_active = 1
     ORDER BY sold_count DESC, id DESC
     LIMIT 5'
);

/* =========================================================
   6. DOANH THU 7 NGÀY GẦN NHẤT
========================================================= */

$dailySalesRows = comic_dashboard_rows(
    $database,
    "SELECT
        DATE(created_at) AS sale_date,
        COALESCE(
            SUM(
                CASE
                    WHEN payment_status = 'completed'
                     AND status <> 'cancelled'
                    THEN total_amount
                    ELSE 0
                END
            ),
            0
        ) AS revenue,
        COUNT(*) AS order_count
     FROM orders
     WHERE created_at >= CURDATE() - INTERVAL 6 DAY
       AND created_at < CURDATE() + INTERVAL 1 DAY
     GROUP BY DATE(created_at)
     ORDER BY sale_date ASC"
);

$dailySalesByDate = [];

foreach ($dailySalesRows as $saleRow) {
    if (!empty($saleRow['sale_date'])) {
        $dailySalesByDate[(string) $saleRow['sale_date']] = [
            'revenue' => (float) ($saleRow['revenue'] ?? 0),
            'orders' => (int) ($saleRow['order_count'] ?? 0),
        ];
    }
}

/* Bổ sung ngày không có đơn để biểu đồ luôn đủ 7 ngày. */
$dailySales = [];

for ($daysAgo = 6; $daysAgo >= 0; $daysAgo--) {
    $timestamp = strtotime('-' . $daysAgo . ' days');
    $dateKey = date('Y-m-d', $timestamp);

    $item = $dailySalesByDate[$dateKey] ?? [
        'revenue' => 0.0,
        'orders' => 0,
    ];

    $dailySales[] = [
        'date' => $dateKey,
        'label' => date('d/m', $timestamp),
        'revenue' => (float) $item['revenue'],
        'orders' => (int) $item['orders'],
    ];
}

$maxDailyRevenue = 0.0;

foreach ($dailySales as $dailySale) {
    $maxDailyRevenue = max(
        $maxDailyRevenue,
        $dailySale['revenue']
    );
}

/* Nạp header quản trị sau khi đã lấy dữ liệu. */
require_once __DIR__ . '/includes/header.php';
?>

<style>
.cs-dashboard {
    color: #f2f2f2;
}

.cs-dashboard .dashboard-welcome {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 14px;
    margin: 0 0 22px;
}

.cs-dashboard .dashboard-welcome h2 {
    margin: 0;
    font-size: 20px;
    font-weight: 850;
    letter-spacing: -.4px;
}

.cs-dashboard .dashboard-welcome p {
    margin: 5px 0 0;
    color: #a9a9b2;
    font-size: 12px;
}

.cs-dashboard .dashboard-date {
    color: #a9a9b2;
    font-size: 12px;
    white-space: nowrap;
}

.cs-dashboard .dashboard-stat-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 16px;
    margin-bottom: 22px;
}

.cs-dashboard .dashboard-stat {
    min-width: 0;
    padding: 19px;
    background: #232327;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    box-shadow: 0 4px 18px rgba(0,0,0,0.22);
}

.cs-dashboard .dashboard-stat-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 8px;
}

.cs-dashboard .dashboard-stat-label {
    color: #a9a9b2;
    font-size: 12px;
    font-weight: 650;
}

.cs-dashboard .dashboard-stat-icon {
    width: 40px;
    height: 40px;
    flex: 0 0 40px;
    display: grid;
    place-items: center;
    border-radius: 20px;
    background: #36363c;
    color: #f2f2f2;
    font-size: 18px;
}

.cs-dashboard .dashboard-stat-icon.dark {
    background: rgba(120,150,255,.16);
    color: #9db6ff;
}

.cs-dashboard .dashboard-stat-icon.green {
    background: #e9f7ef;
    color: #6fdc9c;
}

.cs-dashboard .dashboard-stat-icon.amber {
    background: rgba(240,180,60,.15);
    color: #b47a11;
}

.cs-dashboard .dashboard-stat-value {
    display: block;
    margin-top: 10px;
    font-size: clamp(22px,2.1vw,29px);
    font-weight: 850;
    line-height: 1.15;
    overflow-wrap: anywhere;
}

.cs-dashboard .dashboard-stat-foot {
    margin-top: 9px;
    color: #a9a9b2;
    font-size: 11px;
}

.cs-dashboard .dashboard-layout-grid {
    display: grid;
    grid-template-columns: minmax(0,1.45fr) minmax(300px,1fr);
    gap: 20px;
    align-items: stretch;
    margin-bottom: 22px;
}

.cs-dashboard .dashboard-panel {
    min-width: 0;
    margin-bottom: 22px;
    overflow: hidden;
    background: #232327;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    box-shadow: 0 4px 18px rgba(0,0,0,0.22);
}

.cs-dashboard .dashboard-layout-grid .dashboard-panel {
    margin-bottom: 0;
}

.cs-dashboard .dashboard-panel-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
    padding: 18px 20px;
    border-bottom: 1px solid #3d3d44;
}

.cs-dashboard .dashboard-panel-head h3 {
    margin: 0;
    font-size: 14px;
    font-weight: 850;
}

.cs-dashboard .dashboard-panel-subtitle {
    margin-top: 4px;
    color: #a9a9b2;
    font-size: 11px;
}

.cs-dashboard .dashboard-panel-link {
    color: #f2f2f2;
    font-size: 11px;
    font-weight: 800;
    white-space: nowrap;
}

.cs-dashboard .dashboard-panel-body {
    padding: 18px 20px;
}

/* Biểu đồ doanh thu */
.cs-dashboard .sales-chart {
    min-height: 222px;
    display: flex;
    align-items: stretch;
    gap: 10px;
    padding-top: 9px;
}

.cs-dashboard .sales-day {
    min-width: 0;
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: flex-end;
    gap: 9px;
}

.cs-dashboard .sales-value {
    max-width: 100%;
    min-height: 15px;
    color: #a9a9b2;
    font-size: 9px;
    text-align: center;
    overflow-wrap: anywhere;
}

.cs-dashboard .sales-bar-area {
    width: 100%;
    height: 150px;
    display: flex;
    align-items: flex-end;
    justify-content: center;
    border-bottom: 1px solid #3d3d44;
    background:
        linear-gradient(
            to bottom,
            transparent 32.9%,
            #36363c 33%,
            transparent 33.5%,
            transparent 65.9%,
            #36363c 66%,
            transparent 66.5%
        );
}

.cs-dashboard .sales-bar {
    width: min(26px,75%);
    min-height: 3px;
    border-radius: 5px 5px 0 0;
    background: linear-gradient(180deg,#36363c,#2c2c31);
    transition: height .25s ease;
}

.cs-dashboard .sales-date {
    color: #a9a9b2;
    font-size: 10px;
}

/* Bảng dữ liệu */
.cs-dashboard .dashboard-table-wrap {
    overflow-x: auto;
}

.cs-dashboard .dashboard-table {
    width: 100%;
    border-collapse: collapse;
}

.cs-dashboard .dashboard-table th {
    padding: 12px 15px;
    background: #2c2c31;
    color: #a9a9b2;
    font-size: 10px;
    letter-spacing: .5px;
    text-transform: uppercase;
    text-align: left;
    white-space: nowrap;
}

.cs-dashboard .dashboard-table td {
    padding: 13px 15px;
    border-bottom: 1px solid #3d3d44;
    font-size: 12px;
    vertical-align: middle;
}

.cs-dashboard .dashboard-table tbody tr:last-child td {
    border-bottom: 0;
}

.cs-dashboard .dashboard-table tbody tr:hover {
    background: #2c2c31;
}

.cs-dashboard .dashboard-order-code {
    color: #f2f2f2;
    font-weight: 800;
    white-space: nowrap;
}

.cs-dashboard .dashboard-customer {
    display: block;
    max-width: 190px;
    overflow: hidden;
    color: #a9a9b2;
    font-size: 11px;
    text-overflow: ellipsis;
    white-space: nowrap;
    margin-top: 3px;
}

.cs-dashboard .dashboard-amount {
    white-space: nowrap;
    font-weight: 800;
}

.cs-dashboard .dashboard-comic {
    display: flex;
    align-items: center;
    gap: 11px;
    min-width: 180px;
}

.cs-dashboard .dashboard-cover {
    width: 39px;
    height: 52px;
    flex: 0 0 39px;
    object-fit: cover;
    border-radius: 4px;
    background: #36363c;
}

.cs-dashboard .dashboard-cover-placeholder {
    width: 39px;
    height: 52px;
    flex: 0 0 39px;
    display: grid;
    place-items: center;
    border-radius: 4px;
    background: rgba(255,107,96,.14);
    color: #f2f2f2;
    font-size: 18px;
}

.cs-dashboard .dashboard-comic-title {
    display: block;
    max-width: 220px;
    color: #f2f2f2;
    font-weight: 750;
    line-height: 1.45;
}

.cs-dashboard .dashboard-comic-subtitle {
    display: block;
    margin-top: 4px;
    color: #a9a9b2;
    font-size: 10px;
}

.cs-dashboard .dashboard-sold {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 100px;
}

.cs-dashboard .dashboard-progress {
    width: 58px;
    height: 5px;
    overflow: hidden;
    border-radius: 8px;
    background: #36363c;
}

.cs-dashboard .dashboard-progress span {
    display: block;
    height: 100%;
    border-radius: 8px;
    background: #f2f2f2;
}

/* Lối tắt */
.cs-dashboard .dashboard-shortcuts {
    display: grid;
    grid-template-columns: repeat(4,minmax(0,1fr));
    gap: 13px;
    margin-bottom: 22px;
}

.cs-dashboard .dashboard-shortcut {
    display: flex;
    align-items: center;
    gap: 12px;
    min-width: 0;
    padding: 15px;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    background: #232327;
    color: #f2f2f2;
    transition: transform .2s,border-color .2s;
}

.cs-dashboard .dashboard-shortcut:hover {
    transform: translateY(-2px);
    border-color: #f0b5b0;
    color: #f2f2f2;
}

.cs-dashboard .dashboard-shortcut-icon {
    width: 36px;
    height: 36px;
    flex: 0 0 36px;
    display: grid;
    place-items: center;
    border-radius: 20px;
    background: #36363c;
    color: #f2f2f2;
    font-size: 17px;
}

.cs-dashboard .dashboard-shortcut strong {
    display: block;
    font-size: 12px;
    line-height: 1.4;
}

.cs-dashboard .dashboard-shortcut small {
    display: block;
    margin-top: 3px;
    color: #a9a9b2;
    font-size: 10px;
}

.cs-dashboard .dashboard-empty {
    padding: 30px 18px;
    color: #a9a9b2;
    text-align: center;
    font-size: 12px;
}

.cs-dashboard .dashboard-db-warning {
    margin-bottom: 20px;
    padding: 13px 16px;
    border: 1px solid rgba(240,180,60,.4);
    border-left: 4px solid #d48b18;
    background: rgba(240,180,60,.15);
    color: #795617;
    font-size: 12px;
    line-height: 1.6;
}

.cs-dashboard .dashboard-bottom-note {
    margin-top: 12px;
    color: #8a929e;
    font-size: 10px;
    line-height: 1.6;
}

/* Responsive */
@media(max-width:1200px) {
    .cs-dashboard .dashboard-stat-grid {
        grid-template-columns: repeat(2,minmax(0,1fr));
    }

    .cs-dashboard .dashboard-layout-grid {
        grid-template-columns: 1fr;
    }

    .cs-dashboard .dashboard-shortcuts {
        grid-template-columns: repeat(2,minmax(0,1fr));
    }
}

@media(max-width:700px) {
    .cs-dashboard .dashboard-stat-grid {
        gap: 11px;
    }

    .cs-dashboard .dashboard-stat {
        padding: 14px;
    }

    .cs-dashboard .dashboard-stat-icon {
        width: 34px;
        height: 34px;
        flex-basis: 34px;
    }

    .cs-dashboard .dashboard-panel-head,
    .cs-dashboard .dashboard-panel-body {
        padding: 15px;
    }

    .cs-dashboard .sales-chart {
        gap: 5px;
    }

    .cs-dashboard .sales-value {
        font-size: 8px;
    }

    .cs-dashboard .dashboard-shortcuts {
        gap: 9px;
    }

    .cs-dashboard .dashboard-shortcut {
        padding: 11px;
        gap: 8px;
    }

    .cs-dashboard .dashboard-shortcut-icon {
        width: 31px;
        height: 31px;
        flex-basis: 31px;
    }
}

@media(max-width:420px) {
    .cs-dashboard .dashboard-stat-grid {
        grid-template-columns: 1fr 1fr;
    }

    .cs-dashboard .dashboard-shortcuts {
        grid-template-columns: 1fr;
    }
}

@media(prefers-reduced-motion:reduce) {
    .cs-dashboard *,
    .cs-dashboard *::before,
    .cs-dashboard *::after {
        transition: none !important;
    }
}
</style>

<div class="cs-dashboard">

    <?php
    $hasDatabase =
        $database instanceof PDO ||
        (class_exists('mysqli') && $database instanceof mysqli);
    ?>

    <?php if (!$hasDatabase): ?>
        <div class="dashboard-db-warning" role="alert">
            Chưa tìm thấy kết nối cơ sở dữ liệu dùng chung.
            Hãy kiểm tra <strong>config/db.php</strong> và bảo đảm
            bootstrap.php đặt kết nối vào
            <strong>$GLOBALS['comic_shop_db']</strong>.
        </div>
    <?php elseif (!empty($GLOBALS['comic_dashboard_query_error'])): ?>
        <div class="dashboard-db-warning" role="alert">
            Một số truy vấn thống kê chưa chạy được.
            Hãy kiểm tra cấu trúc bảng, quyền truy cập MySQL
            và nhật ký lỗi PHP.
        </div>
    <?php endif; ?>

    <div class="dashboard-welcome">
        <div>
            <h2>Chào mừng trở lại 👋</h2>
            <p>
                Tổng quan nhanh về tình hình kinh doanh của cửa hàng.
            </p>
        </div>

        <div class="dashboard-date">
            <?= comic_dashboard_escape(date('d/m/Y')) ?>
        </div>
    </div>

    <!-- THẺ THỐNG KÊ -->
    <section
        class="dashboard-stat-grid"
        aria-label="Chỉ số tổng quan"
    >

        <article class="dashboard-stat">
            <div class="dashboard-stat-top">
                <span class="dashboard-stat-label">
                    Truyện đang bán
                </span>
                <span class="dashboard-stat-icon" aria-hidden="true">▣</span>
            </div>

            <strong class="dashboard-stat-value">
                <?= number_format($dashboardStats['comics']) ?>
            </strong>

            <div class="dashboard-stat-foot">
                Sản phẩm có trạng thái hoạt động
            </div>
        </article>

        <article class="dashboard-stat">
            <div class="dashboard-stat-top">
                <span class="dashboard-stat-label">
                    Tổng đơn hàng
                </span>
                <span class="dashboard-stat-icon dark" aria-hidden="true">▤</span>
            </div>

            <strong class="dashboard-stat-value">
                <?= number_format($dashboardStats['orders']) ?>
            </strong>

            <div class="dashboard-stat-foot">
                <?= number_format($dashboardStats['pending']) ?>
                đơn chờ xác nhận
            </div>
        </article>

        <article class="dashboard-stat">
            <div class="dashboard-stat-top">
                <span class="dashboard-stat-label">
                    Khách hàng
                </span>
                <span class="dashboard-stat-icon green" aria-hidden="true">♙</span>
            </div>

            <strong class="dashboard-stat-value">
                <?= number_format($dashboardStats['customers']) ?>
            </strong>

            <div class="dashboard-stat-foot">
                Tài khoản khách đang hoạt động
            </div>
        </article>

        <article class="dashboard-stat">
            <div class="dashboard-stat-top">
                <span class="dashboard-stat-label">
                    Doanh thu đã thanh toán
                </span>
                <span class="dashboard-stat-icon amber" aria-hidden="true">₫</span>
            </div>

            <strong
                class="dashboard-stat-value"
                style="font-size:clamp(18px,1.8vw,25px)"
            >
                <?= comic_dashboard_escape(
                    comic_dashboard_money($dashboardStats['revenue'])
                ) ?>
            </strong>

            <div class="dashboard-stat-foot">
                Không tính đơn chưa thanh toán hoặc đã hủy
            </div>
        </article>

    </section>

    <!-- LỐI TẮT -->
    <section
        class="dashboard-shortcuts"
        aria-label="Lối tắt quản trị"
    >
        <a class="dashboard-shortcut" href="comics.php">
            <span class="dashboard-shortcut-icon" aria-hidden="true">＋</span>
            <span>
                <strong>Quản lý truyện</strong>
                <small>Danh mục sản phẩm</small>
            </span>
        </a>

        <a class="dashboard-shortcut" href="orders.php">
            <span class="dashboard-shortcut-icon" aria-hidden="true">▤</span>
            <span>
                <strong>Đơn hàng</strong>
                <small>Xử lý đơn mới</small>
            </span>
        </a>

        <a class="dashboard-shortcut" href="users.php">
            <span class="dashboard-shortcut-icon" aria-hidden="true">♙</span>
            <span>
                <strong>Khách hàng</strong>
                <small>Tài khoản người dùng</small>
            </span>
        </a>

        <a class="dashboard-shortcut" href="inventory.php">
            <span class="dashboard-shortcut-icon" aria-hidden="true">▥</span>
            <span>
                <strong>Kho hàng</strong>
                <small>
                    <?= number_format($dashboardStats['low_stock']) ?>
                    truyện sắp hết
                </small>
            </span>
        </a>
    </section>

    <!-- BIỂU ĐỒ VÀ THÔNG TIN CẦN CHÚ Ý -->
    <section class="dashboard-layout-grid">

        <article class="dashboard-panel">
            <div class="dashboard-panel-head">
                <div>
                    <h3>Doanh thu 7 ngày gần nhất</h3>
                    <div class="dashboard-panel-subtitle">
                        Chỉ tính đơn đã thanh toán thành công
                    </div>
                </div>

                <span class="dashboard-panel-link">7 ngày</span>
            </div>

            <div class="dashboard-panel-body">

                <div
                    class="sales-chart"
                    role="img"
                    aria-label="Biểu đồ doanh thu 7 ngày"
                >
                    <?php foreach ($dailySales as $sale): ?>
                        <?php
                        $height = $maxDailyRevenue > 0
                            ? (int) round(
                                ($sale['revenue'] / $maxDailyRevenue) * 100
                            )
                            : 0;

                        if ($sale['revenue'] > 0 && $height < 5) {
                            $height = 5;
                        }
                        ?>

                        <div
                            class="sales-day"
                            title="<?= comic_dashboard_escape($sale['date']) ?>:
                            <?= comic_dashboard_escape(
                                comic_dashboard_money($sale['revenue'])
                            ) ?>"
                        >
                            <div class="sales-value">
                                <?php if ($sale['revenue'] > 0): ?>
                                    <?= comic_dashboard_escape(
                                        comic_dashboard_money($sale['revenue'])
                                    ) ?>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </div>

                            <div class="sales-bar-area">
                                <div
                                    class="sales-bar"
                                    style="height:<?= $height ?>%"
                                ></div>
                            </div>

                            <div class="sales-date">
                                <?= comic_dashboard_escape($sale['label']) ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="dashboard-bottom-note">
                    Dữ liệu tổng hợp theo ngày tạo đơn; doanh thu được cộng
                    khi payment_status = completed.
                </div>

            </div>
        </article>

        <article class="dashboard-panel">
            <div class="dashboard-panel-head">
                <div>
                    <h3>Cần chú ý</h3>
                    <div class="dashboard-panel-subtitle">
                        Các mục có thể cần xử lý sớm
                    </div>
                </div>
            </div>

            <div class="dashboard-panel-body">

                <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 0;border-bottom:1px solid #3d3d44">
                    <div>
                        <div style="font-size:12px;font-weight:800">
                            Đơn chờ xác nhận
                        </div>
                        <div style="margin-top:4px;color:#a9a9b2;font-size:11px">
                            Kiểm tra và cập nhật trạng thái
                        </div>
                    </div>

                    <strong style="font-size:20px;color:#d48b18">
                        <?= number_format($dashboardStats['pending']) ?>
                    </strong>
                </div>

                <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 0;border-bottom:1px solid #3d3d44">
                    <div>
                        <div style="font-size:12px;font-weight:800">
                            Truyện sắp hết hàng
                        </div>
                        <div style="margin-top:4px;color:#a9a9b2;font-size:11px">
                            Tồn kho từ 5 cuốn trở xuống
                        </div>
                    </div>

                    <strong style="font-size:20px;color:#f2f2f2">
                        <?= number_format($dashboardStats['low_stock']) ?>
                    </strong>
                </div>

                <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 0;border-bottom:1px solid #3d3d44">
                    <div>
                        <div style="font-size:12px;font-weight:800">
                            Tác giả
                        </div>
                        <div style="margin-top:4px;color:#a9a9b2;font-size:11px">
                            Danh sách tác giả trong hệ thống
                        </div>
                    </div>

                    <strong style="font-size:20px;color:#9db6ff">
                        <?= number_format($dashboardStats['authors']) ?>
                    </strong>
                </div>

                <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 0">
                    <div>
                        <div style="font-size:12px;font-weight:800">
                            Thể loại
                        </div>
                        <div style="margin-top:4px;color:#a9a9b2;font-size:11px">
                            Nhóm truyện đang quản lý
                        </div>
                    </div>

                    <strong style="font-size:20px;color:#6fdc9c">
                        <?= number_format($dashboardStats['categories']) ?>
                    </strong>
                </div>

            </div>
        </article>

    </section>

    <!-- ĐƠN HÀNG GẦN ĐÂY -->
    <section class="dashboard-panel">

        <div class="dashboard-panel-head">
            <div>
                <h3>Đơn hàng gần đây</h3>
                <div class="dashboard-panel-subtitle">
                    8 đơn hàng được tạo gần nhất
                </div>
            </div>

            <a class="dashboard-panel-link" href="orders.php">
                Xem tất cả →
            </a>
        </div>

        <?php if (!$recentOrders): ?>

            <div class="dashboard-empty">
                Chưa có đơn hàng để hiển thị.
            </div>

        <?php else: ?>

            <div class="dashboard-table-wrap">
                <table class="dashboard-table">
                    <thead>
                        <tr>
                            <th>Mã đơn / Khách hàng</th>
                            <th>Ngày tạo</th>
                            <th>Tổng tiền</th>
                            <th>Trạng thái</th>
                            <th>Thanh toán</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($recentOrders as $order): ?>
                            <?php
                            [$statusLabel, $statusColor] =
                                comic_dashboard_status(
                                    (string) ($order['status'] ?? '')
                                );

                            $paymentStatus =
                                (string) ($order['payment_status'] ?? 'pending');

                            $paymentMap = [
                                'pending' => ['Chưa thanh toán', 'warning'],
                                'completed' => ['Đã thanh toán', 'success'],
                                'failed' => ['Thất bại', 'danger'],
                            ];

                            [$paymentLabel, $paymentColor] =
                                $paymentMap[$paymentStatus] ??
                                ['Không rõ', 'secondary'];

                            $createdAt = !empty($order['created_at'])
                                ? strtotime((string) $order['created_at'])
                                : false;
                            ?>

                            <tr>
                                <td>
                                    <span class="dashboard-order-code">
                                        <?= comic_dashboard_escape(
                                            $order['order_code'] ??
                                            ('#' . ($order['id'] ?? ''))
                                        ) ?>
                                    </span>

                                    <span class="dashboard-customer">
                                        <?= comic_dashboard_escape(
                                            $order['full_name'] ?? 'Khách hàng'
                                        ) ?>
                                    </span>
                                </td>

                                <td style="white-space:nowrap">
                                    <?= $createdAt
                                        ? comic_dashboard_escape(
                                            date('d/m/Y H:i', $createdAt)
                                        )
                                        : '—' ?>
                                </td>

                                <td class="dashboard-amount">
                                    <?= comic_dashboard_escape(
                                        comic_dashboard_money(
                                            $order['total_amount'] ?? 0
                                        )
                                    ) ?>
                                </td>

                                <td>
                                    <span class="badge badge-<?= comic_dashboard_escape($statusColor) ?>">
                                        <?= comic_dashboard_escape($statusLabel) ?>
                                    </span>
                                </td>

                                <td>
                                    <span class="badge badge-<?= comic_dashboard_escape($paymentColor) ?>">
                                        <?= comic_dashboard_escape($paymentLabel) ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php endif; ?>

    </section>

    <!-- TRUYỆN BÁN CHẠY -->
    <section class="dashboard-panel">

        <div class="dashboard-panel-head">
            <div>
                <h3>Truyện bán chạy</h3>
                <div class="dashboard-panel-subtitle">
                    Xếp theo sold_count trong bảng comics
                </div>
            </div>

            <a class="dashboard-panel-link" href="comics.php">
                Quản lý truyện →
            </a>
        </div>

        <?php if (!$topComics): ?>

            <div class="dashboard-empty">
                Chưa có dữ liệu truyện để hiển thị.
            </div>

        <?php else: ?>

            <div class="dashboard-table-wrap">
                <table class="dashboard-table">
                    <thead>
                        <tr>
                            <th>Truyện</th>
                            <th>Giá bán</th>
                            <th>Đã bán</th>
                            <th>Tồn kho</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        $maxSold = 0;

                        foreach ($topComics as $comic) {
                            $maxSold = max(
                                $maxSold,
                                (int) ($comic['sold_count'] ?? 0)
                            );
                        }
                        ?>

                        <?php foreach ($topComics as $comic): ?>
                            <?php
                            $sold = (int) ($comic['sold_count'] ?? 0);

                            $soldPercent = $maxSold > 0
                                ? (int) round(($sold / $maxSold) * 100)
                                : 0;

                            $cover = comic_dashboard_cover(
                                (string) ($comic['cover_image'] ?? ''),
                                (string) ($comic['title'] ?? '')
                            );

                            $stock = (int) ($comic['stock'] ?? 0);

                            $price = (
                                isset($comic['sale_price']) &&
                                $comic['sale_price'] !== null &&
                                $comic['sale_price'] !== ''
                            )
                                ? $comic['sale_price']
                                : ($comic['price'] ?? 0);
                            ?>

                            <tr>
                                <td>
                                    <div class="dashboard-comic">

                                        <?php if ($cover !== ''): ?>

                                            <img
                                                class="dashboard-cover"
                                                src="<?= comic_dashboard_escape($cover) ?>"
                                                alt="Bìa <?= comic_dashboard_escape($comic['title'] ?? '') ?>"
                                                loading="lazy"
                                                onerror="this.style.display='none';this.nextElementSibling.style.display='grid';"
                                            >

                                            <span
                                                class="dashboard-cover-placeholder"
                                                style="display:none"
                                                aria-hidden="true"
                                            >▣</span>

                                        <?php else: ?>

                                            <span
                                                class="dashboard-cover-placeholder"
                                                aria-hidden="true"
                                            >▣</span>

                                        <?php endif; ?>

                                        <span>
                                            <span class="dashboard-comic-title">
                                                <?= comic_dashboard_escape(
                                                    $comic['title'] ?? ''
                                                ) ?>
                                            </span>

                                            <span class="dashboard-comic-subtitle">
                                                Mã truyện #<?= (int) ($comic['id'] ?? 0) ?>
                                            </span>
                                        </span>

                                    </div>
                                </td>

                                <td class="dashboard-amount">
                                    <?= comic_dashboard_escape(
                                        comic_dashboard_money($price)
                                    ) ?>
                                </td>

                                <td>
                                    <div class="dashboard-sold">
                                        <strong><?= number_format($sold) ?></strong>

                                        <span
                                            class="dashboard-progress"
                                            aria-hidden="true"
                                        >
                                            <span style="width:<?= $soldPercent ?>%"></span>
                                        </span>
                                    </div>
                                </td>

                                <td>
                                    <?php if ($stock <= 5): ?>
                                        <span class="badge badge-danger">
                                            <?= number_format($stock) ?> cuốn
                                        </span>
                                    <?php else: ?>
                                        <span class="badge badge-success">
                                            <?= number_format($stock) ?> cuốn
                                        </span>
                                    <?php endif; ?>
                                </td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php endif; ?>

    </section>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
