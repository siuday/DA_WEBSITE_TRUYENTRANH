<?php
declare(strict_types=1);

/**
 * Comic Shop - Admin Logout
 *
 * File: admin/logout.php
 *
 * Chức năng:
 * - Hiển thị xác nhận đăng xuất.
 * - Kiểm tra CSRF khi gửi yêu cầu POST.
 * - Xóa session đăng nhập quản trị.
 * - Xóa cookie session.
 * - Chuyển về login.php sau khi đăng xuất.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_admin_logout_escape')) {
    function comic_admin_logout_escape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (
    !isset($_SESSION['comic_admin_logout_csrf']) ||
    !is_string($_SESSION['comic_admin_logout_csrf'])
) {
    $_SESSION['comic_admin_logout_csrf'] =
        bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['comic_admin_logout_csrf'];
$errorMessage = '';

/* =========================================================
   2. XỬ LÝ ĐĂNG XUẤT
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {

    $submittedToken =
        isset($_POST['csrf_token']) &&
        is_string($_POST['csrf_token'])
            ? $_POST['csrf_token']
            : '';

    if (
        $submittedToken === '' ||
        !isset($_SESSION['comic_admin_logout_csrf']) ||
        !is_string($_SESSION['comic_admin_logout_csrf']) ||
        !hash_equals(
            $_SESSION['comic_admin_logout_csrf'],
            $submittedToken
        )
    ) {
        http_response_code(403);

        $errorMessage =
            'Phiên đăng xuất không hợp lệ hoặc đã hết hạn. ' .
            'Vui lòng tải lại trang và thử lại.';

        $_SESSION['comic_admin_logout_csrf'] =
            bin2hex(random_bytes(32));

        $csrfToken = $_SESSION['comic_admin_logout_csrf'];

    } else {

        /*
         * Lưu tham số cookie trước khi hủy session.
         */
        $sessionName = session_name();
        $cookieParams = session_get_cookie_params();

        /*
         * Xóa toàn bộ dữ liệu session ở phía máy chủ.
         */
        $_SESSION = [];

        /*
         * Hết hạn cookie session ở trình duyệt.
         * Giữ các thuộc tính bảo mật tương ứng với cấu hình PHP.
         */
        if (ini_get('session.use_cookies')) {

            $cookieOptions = [
                'expires' => time() - 42000,
                'path' => $cookieParams['path'] ?: '/',
                'domain' => $cookieParams['domain'],
                'secure' => (bool) $cookieParams['secure'],
                'httponly' => (bool) $cookieParams['httponly'],
                'samesite' => $cookieParams['samesite'] ?? 'Lax',
            ];

            setcookie(
                $sessionName,
                '',
                $cookieOptions
            );
        }

        /*
         * Hủy session hiện tại.
         */
        session_destroy();

        /*
         * Bỏ cookie cũ khỏi dữ liệu request hiện tại để PHP
         * không tiếp tục sử dụng session ID cũ.
         */
        unset($_COOKIE[$sessionName]);

        /*
         * Tạo session mới chỉ để hiển thị thông báo đăng xuất
         * thành công trên trang login.php.
         */
        session_start();

        session_regenerate_id(true);

        $_SESSION['comic_admin_login_flash'] = [
            'type' => 'success',
            'message' => 'Bạn đã đăng xuất khỏi khu vực quản trị.',
        ];

        $_SESSION['comic_admin_login_csrf'] =
            bin2hex(random_bytes(32));

        header('Location: login.php', true, 303);
        exit;
    }
}

/* =========================================================
   3. GIAO DIỆN XÁC NHẬN ĐĂNG XUẤT
========================================================= */

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >
    <meta name="robots" content="noindex, nofollow">

    <title>Đăng xuất quản trị | Comic Shop</title>

    <link rel="stylesheet" href="../assets/css/admin.css">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: grid;
            place-items: center;
            padding: 22px;
            background: #1c1c1f;
            color: #f2f2f2;
            font-family:
                Inter,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                Arial,
                sans-serif;
        }

        .logout-card {
            width: 100%;
            max-width: 460px;
            padding: clamp(25px, 5vw, 42px);
            background: #232327;
            border: 1px solid #3d3d44;
            box-shadow: 0 18px 55px rgba(0,0,0,0.4);
            text-align: center;
        }

        .logout-brand {
            color: #f2f2f2;
            font-size: 12px;
            font-weight: 900;
            letter-spacing: .2em;
        }

        .logout-icon {
            display: grid;
            width: 68px;
            height: 68px;
            margin: 27px auto 19px;
            place-items: center;
            border-radius: 50%;
            background: #36363c;
            color: #f2f2f2;
            font-size: 32px;
        }

        .logout-card h1 {
            margin: 0 0 12px;
            font-size: clamp(23px, 4vw, 29px);
            line-height: 1.2;
            letter-spacing: -.04em;
        }

        .logout-description {
            margin: 0 auto 25px;
            max-width: 340px;
            color: #a9a9b2;
            font-size: 13px;
            line-height: 1.8;
        }

        .logout-alert {
            margin-bottom: 19px;
            padding: 12px;
            border: 1px solid rgba(255,107,96,.4);
            background: rgba(255,107,96,.14);
            color: #ff8f86;
            font-size: 12px;
            line-height: 1.6;
            text-align: left;
        }

        .logout-actions {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .logout-button {
            min-height: 45px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 12px 14px;
            border: 1px solid transparent;
            border-radius: 999px;
            font: inherit;
            font-size: 12px;
            font-weight: 800;
            text-decoration: none;
            cursor: pointer;
            transition:
                background .2s,
                color .2s,
                border-color .2s;
        }

        .logout-button-danger {
            background: #f2f2f2;
            color: #111111;
        }

        .logout-button-danger:hover {
            background: #ffffff;
            color: #111111;
        }

        .logout-button-secondary {
            border-color: #3d3d44;
            background: #232327;
            color: #d4d4da;
        }

        .logout-button-secondary:hover {
            border-color: #5a5a63;
            background: #2c2c31;
            color: #f2f2f2;
        }

        .logout-footer {
            margin-top: 24px;
            color: #a9a9b2;
            font-size: 11px;
            line-height: 1.7;
        }

        @media (max-width: 390px) {
            .logout-actions {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

<main class="logout-card">

    <div class="logout-brand">COMIC SHOP · ADMIN</div>

    <div class="logout-icon" aria-hidden="true">
        ↗
    </div>

    <h1>Xác nhận đăng xuất</h1>

    <p class="logout-description">
        Bạn có chắc chắn muốn đăng xuất khỏi khu vực quản trị
        của Comic Shop không?
    </p>

    <?php if ($errorMessage !== ''): ?>
        <div class="logout-alert" role="alert">
            <?= comic_admin_logout_escape($errorMessage) ?>
        </div>
    <?php endif; ?>

    <form method="post" action="logout.php">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= comic_admin_logout_escape($csrfToken) ?>"
        >

        <div class="logout-actions">

            <button
                class="logout-button logout-button-danger"
                type="submit"
            >
                Xác nhận đăng xuất
            </button>

            <a
                class="logout-button logout-button-secondary"
                href="dashboard.php"
            >
                Quay lại quản trị
            </a>

        </div>
    </form>

    <div class="logout-footer">
        &copy; <?= date('Y') ?> Comic Shop.
        Hãy đăng xuất sau khi hoàn tất công việc
        trên thiết bị dùng chung.
    </div>

</main>

</body>
</html>
