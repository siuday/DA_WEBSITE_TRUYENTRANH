<?php
/**
 * Comic Shop - Admin Bootstrap
 *
 * File: admin/includes/bootstrap.php
 *
 * Sử dụng trong các trang admin cần đăng nhập:
 * require_once __DIR__ . '/includes/bootstrap.php';
 *
 * Không include file này trong login.php hoặc logout.php.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. XÁC ĐỊNH ĐƯỜNG DẪN DỰ ÁN
========================================================= */

$comicShopRoot = dirname(__DIR__, 2);

if (!defined('COMIC_SHOP_ROOT')) {
    define('COMIC_SHOP_ROOT', $comicShopRoot);
}

if (!defined('COMIC_SHOP_ADMIN_ROOT')) {
    define('COMIC_SHOP_ADMIN_ROOT', dirname(__DIR__));
}

/* =========================================================
   2. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_admin_bootstrap_escape')) {
    function comic_admin_bootstrap_escape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

/**
 * Xác định người dùng hiện tại có quyền admin hay không.
 *
 * Hỗ trợ một số tên session thường gặp trong dự án.
 * Chỉ dựa vào dữ liệu session phía máy chủ, không dựa
 * vào tham số role do trình duyệt gửi lên.
 */
if (!function_exists('comic_admin_bootstrap_is_authorized')) {
    function comic_admin_bootstrap_is_authorized(): bool
    {
        $session = $_SESSION;

        /* Session đăng nhập quản trị chuyên biệt. */
        if (
            isset($session['admin_id']) &&
            (int) $session['admin_id'] > 0
        ) {
            return true;
        }

        if (
            isset($session['admin_logged_in']) &&
            $session['admin_logged_in'] === true
        ) {
            return true;
        }

        if (
            isset($session['is_admin']) &&
            (
                $session['is_admin'] === true ||
                $session['is_admin'] === 1 ||
                $session['is_admin'] === '1'
            )
        ) {
            return true;
        }

        /* Kiểm tra role trong các cấu trúc session phổ biến. */
        $roles = [];

        foreach (['user_role', 'role', 'admin_role'] as $key) {
            if (
                isset($session[$key]) &&
                is_string($session[$key])
            ) {
                $roles[] = strtolower(trim($session[$key]));
            }
        }

        if (
            isset($session['user']) &&
            is_array($session['user']) &&
            isset($session['user']['role']) &&
            is_string($session['user']['role'])
        ) {
            $roles[] = strtolower(
                trim($session['user']['role'])
            );
        }

        if (
            isset($session['admin']) &&
            is_array($session['admin']) &&
            isset($session['admin']['role']) &&
            is_string($session['admin']['role'])
        ) {
            $roles[] = strtolower(
                trim($session['admin']['role'])
            );
        }

        $allowedRoles = [
            'admin',
            'administrator',
            'super_admin',
            'superadmin',
        ];

        foreach ($roles as $role) {
            if (in_array($role, $allowedRoles, true)) {
                return true;
            }
        }

        return false;
    }
}

/* =========================================================
   3. KIỂM TRA QUYỀN TRUY CẬP ADMIN
========================================================= */

if (!comic_admin_bootstrap_is_authorized()) {
    /*
     * Ví dụ:
     * /comic_shop/admin/dashboard.php
     * sẽ chuyển đến:
     * /comic_shop/admin/login.php
     */
    $scriptName = str_replace(
        '\\',
        '/',
        (string) ($_SERVER['SCRIPT_NAME'] ?? '')
    );

    $adminUrl = rtrim(dirname($scriptName), '/');

    if ($adminUrl === '') {
        $adminUrl = '/admin';
    }

    $projectUrl = rtrim(dirname($adminUrl), '/');

    if ($projectUrl === '.' || $projectUrl === '/') {
        $projectUrl = '';
    }

    $_SESSION['admin_auth_message'] =
        'Vui lòng đăng nhập bằng tài khoản quản trị.';

    header(
        'Location: ' . $projectUrl . '/admin/login.php',
        true,
        303
    );
    exit;
}

/* =========================================================
   4. NẠP KẾT NỐI CƠ SỞ DỮ LIỆU
========================================================= */

$dbConfigFile = COMIC_SHOP_ROOT
    . DIRECTORY_SEPARATOR
    . 'config'
    . DIRECTORY_SEPARATOR
    . 'db.php';

$comicShopDbResult = null;

if (is_file($dbConfigFile)) {
    /*
     * db.php có thể return PDO/MySQLi hoặc tạo các biến
     * như $pdo, $conn, $mysqli, $db.
     */
    $comicShopDbResult = require_once $dbConfigFile;
} else {
    error_log(
        '[Comic Shop Admin] Không tìm thấy config/db.php'
    );
}

/* Tìm đối tượng kết nối do db.php tạo ra. */
$comicShopConnection = null;

$connectionCandidates = [
    $comicShopDbResult ?? null,
    $pdo ?? null,
    $conn ?? null,
    $mysqli ?? null,
    $db ?? null,
    $connection ?? null,
    $GLOBALS['pdo'] ?? null,
    $GLOBALS['conn'] ?? null,
    $GLOBALS['mysqli'] ?? null,
    $GLOBALS['db'] ?? null,
];

foreach ($connectionCandidates as $candidate) {
    if (
        $candidate instanceof PDO ||
        (
            class_exists('mysqli') &&
            $candidate instanceof mysqli
        )
    ) {
        $comicShopConnection = $candidate;
        break;
    }
}

/* Công bố kết nối dùng chung cho các trang quản trị. */
$GLOBALS['comic_shop_db'] = $comicShopConnection;

if ($comicShopConnection instanceof PDO) {
    if (!isset($GLOBALS['pdo'])) {
        $GLOBALS['pdo'] = $comicShopConnection;
    }

    if (!isset($GLOBALS['db'])) {
        $GLOBALS['db'] = $comicShopConnection;
    }
} elseif (
    class_exists('mysqli') &&
    $comicShopConnection instanceof mysqli
) {
    if (!isset($GLOBALS['conn'])) {
        $GLOBALS['conn'] = $comicShopConnection;
    }

    if (!isset($GLOBALS['mysqli'])) {
        $GLOBALS['mysqli'] = $comicShopConnection;
    }

    if (!isset($GLOBALS['db'])) {
        $GLOBALS['db'] = $comicShopConnection;
    }
}

/* =========================================================
   5. NẠP HÀM DÙNG CHUNG
========================================================= */

$sharedFunctionsFile = COMIC_SHOP_ROOT
    . DIRECTORY_SEPARATOR
    . 'includes'
    . DIRECTORY_SEPARATOR
    . 'functions.php';

if (is_file($sharedFunctionsFile)) {
    require_once $sharedFunctionsFile;
}

/* =========================================================
   6. THÔNG TIN TÀI KHOẢN ADMIN
========================================================= */

$comicShopAdminName = 'Quản trị viên';
$comicShopAdminRole = 'admin';

if (
    isset($_SESSION['user']) &&
    is_array($_SESSION['user'])
) {
    $currentUser = $_SESSION['user'];

    foreach (
        ['full_name', 'name', 'username', 'email']
        as $nameKey
    ) {
        if (
            isset($currentUser[$nameKey]) &&
            is_string($currentUser[$nameKey]) &&
            trim($currentUser[$nameKey]) !== ''
        ) {
            $comicShopAdminName =
                trim($currentUser[$nameKey]);
            break;
        }
    }

    if (
        isset($currentUser['role']) &&
        is_string($currentUser['role'])
    ) {
        $comicShopAdminRole =
            strtolower(trim($currentUser['role']));
    }
} elseif (
    isset($_SESSION['admin']) &&
    is_array($_SESSION['admin'])
) {
    $currentAdmin = $_SESSION['admin'];

    foreach (['full_name', 'name', 'username', 'email'] as $nameKey) {
        if (
            isset($currentAdmin[$nameKey]) &&
            is_string($currentAdmin[$nameKey]) &&
            trim($currentAdmin[$nameKey]) !== ''
        ) {
            $comicShopAdminName =
                trim($currentAdmin[$nameKey]);
            break;
        }
    }

    if (
        isset($currentAdmin['role']) &&
        is_string($currentAdmin['role'])
    ) {
        $comicShopAdminRole =
            strtolower(trim($currentAdmin['role']));
    }
} else {
    foreach (
        ['full_name', 'username', 'user_name']
        as $nameKey
    ) {
        if (
            isset($_SESSION[$nameKey]) &&
            is_string($_SESSION[$nameKey]) &&
            trim($_SESSION[$nameKey]) !== ''
        ) {
            $comicShopAdminName =
                trim($_SESSION[$nameKey]);
            break;
        }
    }

    if (
        isset($_SESSION['role']) &&
        is_string($_SESSION['role'])
    ) {
        $comicShopAdminRole =
            strtolower(trim($_SESSION['role']));
    }
}

/* =========================================================
   7. HÀM KIỂM TRA CSRF CHO FORM QUẢN TRỊ
========================================================= */

if (!function_exists('comic_admin_csrf_token')) {
    function comic_admin_csrf_token(): string
    {
        if (
            !isset($_SESSION['comic_admin_csrf']) ||
            !is_string($_SESSION['comic_admin_csrf'])
        ) {
            $_SESSION['comic_admin_csrf'] =
                bin2hex(random_bytes(32));
        }

        return $_SESSION['comic_admin_csrf'];
    }
}

if (!function_exists('comic_admin_csrf_valid')) {
    function comic_admin_csrf_valid($token): bool
    {
        if (
            !is_string($token) ||
            $token === '' ||
            !isset($_SESSION['comic_admin_csrf']) ||
            !is_string($_SESSION['comic_admin_csrf'])
        ) {
            return false;
        }

        return hash_equals(
            $_SESSION['comic_admin_csrf'],
            $token
        );
    }
}

/* =========================================================
   8. FLASH MESSAGE
========================================================= */

if (!function_exists('comic_admin_set_flash')) {
    function comic_admin_set_flash(
        string $type,
        string $message
    ): void {
        $allowedTypes = [
            'success',
            'error',
            'warning',
            'info',
        ];

        if (!in_array($type, $allowedTypes, true)) {
            $type = 'info';
        }

        $_SESSION['comic_admin_flash'] = [
            'type' => $type,
            'message' => $message,
        ];
    }
}

if (!function_exists('comic_admin_get_flash')) {
    function comic_admin_get_flash(): ?array
    {
        if (
            !isset($_SESSION['comic_admin_flash']) ||
            !is_array($_SESSION['comic_admin_flash'])
        ) {
            return null;
        }

        $flash = $_SESSION['comic_admin_flash'];

        unset($_SESSION['comic_admin_flash']);

        return [
            'type' => (string) ($flash['type'] ?? 'info'),
            'message' => (string) ($flash['message'] ?? ''),
        ];
    }
}

/* =========================================================
   9. HÀM ẢNH DÙNG CHUNG
========================================================= */

if (!function_exists('comic_admin_media_url')) {
    require_once __DIR__ . '/media.php';
}
