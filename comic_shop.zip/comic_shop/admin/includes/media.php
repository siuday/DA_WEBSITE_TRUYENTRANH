<?php
/**
 * Comic Shop - Admin media helpers
 *
 * File: admin/includes/media.php
 *
 * Tìm file ảnh thật hoặc tạo ảnh thay thế (SVG) để luôn hiển thị ảnh.
 * Được nạp bởi bootstrap.php và các trang admin có dùng ảnh.
 */

/* =========================================================
   9. ẢNH: TÌM FILE THẬT HOẶC TẠO ẢNH THAY THẾ
========================================================= */

/**
 * Tạo ảnh SVG (data URI) làm ảnh thay thế khi không có file ảnh.
 * Nhờ vậy mọi khu vực quản trị luôn hiển thị một ảnh.
 */
if (!function_exists('comic_admin_placeholder_image')) {
    function comic_admin_placeholder_image(
        string $label = '',
        string $kind = 'cover'
    ): string {
        $label = trim(preg_replace('/\s+/u', ' ', $label) ?? '');

        $palettes = [
            ['#3b2f4a', '#6d4c7d'],
            ['#2f3e4a', '#4c6d7d'],
            ['#4a2f2f', '#7d4c4c'],
            ['#2f4a3b', '#4c7d65'],
            ['#4a432f', '#7d724c'],
            ['#2f2f4a', '#4c4c7d'],
        ];

        $palette = $palettes[
            crc32($label !== '' ? $label : $kind) % count($palettes)
        ];

        $initials = '';
        $count = 0;

        foreach (preg_split('/\s+/u', $label, -1, PREG_SPLIT_NO_EMPTY) ?: [] as $word) {
            if (!preg_match('/[\p{L}\p{N}]/u', $word)) {
                continue;
            }

            $initials .= function_exists('mb_substr')
                ? mb_strtoupper(mb_substr($word, 0, 1, 'UTF-8'), 'UTF-8')
                : strtoupper(substr($word, 0, 1));

            if (++$count >= 2) {
                break;
            }
        }

        if ($initials === '') {
            $initials = '?';
        }

        $isCover = $kind === 'cover';
        $width = $isCover ? 300 : 200;
        $height = $isCover ? 400 : 200;
        $fontSize = $isCover ? 110 : 84;
        $textY = $isCover ? 215 : 118;

        $caption = '';

        if ($isCover && $label !== '') {
            $short = function_exists('mb_substr')
                ? mb_substr($label, 0, 18, 'UTF-8')
                : substr($label, 0, 18);

            $caption = '<text x="150" y="340" text-anchor="middle" '
                . 'font-family="Arial,sans-serif" font-size="20" '
                . 'fill="#ffffff" fill-opacity=".75">'
                . htmlspecialchars($short, ENT_XML1 | ENT_QUOTES, 'UTF-8')
                . '</text>';
        }

        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '
            . $width . ' ' . $height . '">'
            . '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">'
            . '<stop offset="0" stop-color="' . $palette[0] . '"/>'
            . '<stop offset="1" stop-color="' . $palette[1] . '"/>'
            . '</linearGradient></defs>'
            . '<rect width="' . $width . '" height="' . $height
            . '" fill="url(#g)"/>'
            . '<text x="' . ($width / 2) . '" y="' . $textY
            . '" text-anchor="middle" font-family="Arial,sans-serif" '
            . 'font-weight="700" font-size="' . $fontSize
            . '" fill="#ffffff">'
            . htmlspecialchars($initials, ENT_XML1 | ENT_QUOTES, 'UTF-8')
            . '</text>' . $caption . '</svg>';

        return 'data:image/svg+xml;charset=UTF-8,' . rawurlencode($svg);
    }
}

/**
 * Trả về URL ảnh dùng được trong trang admin.
 *
 * - URL http(s)/data: giữ nguyên.
 * - Đường dẫn tương đối: kiểm tra file có thật trong thư mục dự án,
 *   thử thêm các thư mục ảnh thường dùng và các đuôi jpg/png/webp...
 * - Không tìm thấy: trả về ảnh thay thế (SVG) để vẫn hiện ảnh.
 *
 * $kind: cover | avatar | category | blog
 */
if (!function_exists('comic_admin_media_url')) {
    function comic_admin_media_url(
        ?string $path,
        string $label = '',
        string $kind = 'cover'
    ): string {
        static $cache = [];

        $path = trim(str_replace('\\', '/', (string) $path));

        if (
            $path !== '' &&
            preg_match('~^(https?:)?//|^data:image/~i', $path)
        ) {
            return $path;
        }

        $cacheKey = $kind . '|' . $path;

        if (!array_key_exists($cacheKey, $cache)) {
            $cache[$cacheKey] = '';

            $root = defined('COMIC_SHOP_ROOT')
                ? COMIC_SHOP_ROOT
                : dirname(__DIR__, 2);

            $clean = preg_replace('~[?#].*$~', '', $path) ?? '';
            $clean = preg_replace('~^(\.{1,2}/)+~', '', $clean) ?? '';
            $clean = ltrim($clean, '/');

            $rootName = basename((string) $root);

            if (
                $rootName !== '' &&
                stripos($clean, $rootName . '/') === 0
            ) {
                $clean = substr($clean, strlen($rootName) + 1);
            }

            $segments = array_values(array_filter(
                explode('/', $clean),
                static function ($segment) {
                    return $segment !== '' &&
                        $segment !== '.' &&
                        $segment !== '..';
                }
            ));

            $clean = implode('/', $segments);

            $dirsByKind = [
                'cover' => [
                    'assets/images/covers', 'assets/images/comics',
                    'assets/images', 'assets/uploads/covers',
                    'assets/uploads', 'uploads/covers', 'uploads/comics',
                    'uploads', 'images/covers', 'images',
                ],
                'avatar' => [
                    'assets/images/avatars', 'assets/images/authors',
                    'assets/images/users', 'assets/images',
                    'assets/uploads/avatars', 'uploads/avatars',
                    'uploads/authors', 'uploads/users', 'uploads',
                ],
                'category' => [
                    'assets/images/categories', 'assets/images/covers',
                    'assets/images', 'uploads/categories', 'uploads',
                ],
                'blog' => [
                    'assets/images/blog', 'assets/images/blogs',
                    'assets/images/posts', 'assets/images',
                    'uploads/blog', 'uploads/posts', 'uploads',
                ],
            ];

            $dirs = $dirsByKind[$kind] ?? $dirsByKind['cover'];
            $extensions = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'avif'];
            $candidates = [];

            if ($clean !== '') {
                $candidates[] = $clean;

                $base = basename($clean);
                $name = pathinfo($base, PATHINFO_FILENAME);
                $ownDir = trim(dirname($clean), './');

                foreach ($dirs as $dir) {
                    $candidates[] = $dir . '/' . $base;
                }

                $searchDirs = $ownDir !== ''
                    ? array_merge([$ownDir], $dirs)
                    : $dirs;

                foreach ($searchDirs as $dir) {
                    foreach ($extensions as $ext) {
                        $candidates[] = $dir . '/' . $name . '.' . $ext;
                    }
                }
            }

            foreach ($candidates as $candidate) {
                if (is_file($root . '/' . $candidate)) {
                    $cache[$cacheKey] = implode(
                        '/',
                        array_map('rawurlencode', explode('/', $candidate))
                    );
                    break;
                }
            }
        }

        if ($cache[$cacheKey] !== '') {
            return '../' . $cache[$cacheKey];
        }

        return comic_admin_placeholder_image($label, $kind);
    }
}
