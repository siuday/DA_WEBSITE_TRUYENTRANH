<?php
/**
 * Comic Shop - Admin Footer
 *
 * File: admin/includes/footer.php
 *
 * Dùng cùng admin/includes/header.php.
 * Header mở .admin-layout, .cs-admin-main và
 * .cs-admin-content; footer đóng các phần tử đó.
 */

if (!function_exists('comic_admin_footer_escape')) {
    function comic_admin_footer_escape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

$adminFooterYear = date('Y');
$adminFooterAppName = 'Comic Shop';

/*
 * Đọc flash message do bootstrap.php tạo ra.
 * Các trang có thể gọi comic_admin_set_flash()
 * trước khi chuyển hướng về trang quản trị.
 */
$adminFooterFlash = null;

if (function_exists('comic_admin_get_flash')) {
    $adminFooterFlash = comic_admin_get_flash();
} elseif (
    isset($_SESSION['comic_admin_flash']) &&
    is_array($_SESSION['comic_admin_flash'])
) {
    $adminFooterFlash = $_SESSION['comic_admin_flash'];
    unset($_SESSION['comic_admin_flash']);
}

$adminFooterFlashType = 'info';
$adminFooterFlashMessage = '';

if (is_array($adminFooterFlash)) {
    $allowedFlashTypes = [
        'success',
        'error',
        'warning',
        'info',
    ];

    $candidateType = (string) (
        $adminFooterFlash['type'] ?? 'info'
    );

    if (in_array($candidateType, $allowedFlashTypes, true)) {
        $adminFooterFlashType = $candidateType;
    }

    $adminFooterFlashMessage = (string) (
        $adminFooterFlash['message'] ?? ''
    );
}
?>

<?php if ($adminFooterFlashMessage !== ''): ?>
    <div
        class="admin-alert admin-alert-<?= comic_admin_footer_escape($adminFooterFlashType) ?>"
        role="<?= $adminFooterFlashType === 'error' ? 'alert' : 'status' ?>"
        style="margin: 0 28px 16px;"
    >
        <div style="display:flex;align-items:flex-start;gap:12px;">
            <div style="flex:1;">
                <?= nl2br(
                    comic_admin_footer_escape($adminFooterFlashMessage)
                ) ?>
            </div>

            <button
                type="button"
                data-dismiss-alert
                aria-label="Đóng thông báo"
                style="border:0;background:transparent;color:inherit;font-size:20px;line-height:1;cursor:pointer;"
            >
                &times;
            </button>
        </div>
    </div>
<?php endif; ?>

</main><!-- /.cs-admin-content -->

</div><!-- /.cs-admin-main -->
</div><!-- /.admin-layout -->

<script>
(function () {
    'use strict';

    /*
     * Đóng thông báo khi nhấn nút có data-dismiss-alert.
     */
    document.addEventListener('click', function (event) {
        var button = event.target.closest('[data-dismiss-alert]');

        if (!button) {
            return;
        }

        var alertBox = button.closest('.alert, .admin-alert');

        if (alertBox) {
            alertBox.remove();
        }
    });

    /*
     * Xác nhận trước khi chuyển đến liên kết nguy hiểm.
     *
     * Ví dụ:
     * <a href="comics.php?action=delete&id=1"
     *    data-confirm="Bạn có chắc muốn xóa truyện này?">
     *    Xóa
     * </a>
     *
     * Với thao tác xóa thực tế, nên ưu tiên POST và kiểm tra
     * CSRF ở phía máy chủ thay vì xóa bằng GET.
     */
    document.addEventListener('click', function (event) {
        var link = event.target.closest('a[data-confirm]');

        if (!link) {
            return;
        }

        var message = link.getAttribute('data-confirm') ||
            'Bạn có chắc chắn muốn thực hiện thao tác này?';

        if (!window.confirm(message)) {
            event.preventDefault();
            event.stopPropagation();
        }
    });

    /*
     * Xác nhận khi gửi form được gắn data-confirm.
     *
     * Ví dụ:
     * <form method="post" data-confirm="Bạn muốn xóa mục này?">
     */
    document.addEventListener('submit', function (event) {
        var form = event.target;

        if (
            !(form instanceof HTMLFormElement) ||
            !form.hasAttribute('data-confirm')
        ) {
            return;
        }

        var message = form.getAttribute('data-confirm') ||
            'Bạn có chắc chắn muốn tiếp tục?';

        if (!window.confirm(message)) {
            event.preventDefault();
        }
    });

    /*
     * Ngăn nhấn nút nhiều lần do vô tình.
     *
     * Chỉ áp dụng khi biểu mẫu có data-prevent-double-submit.
     * Không tự khóa toàn bộ form để tránh ảnh hưởng upload
     * hoặc các form xử lý riêng.
     */
    function bindDoubleSubmit(root) {
        (root || document).querySelectorAll(
            'form[data-prevent-double-submit]'
        ).forEach(function (form) {
            if (form.dataset.doubleSubmitBound) {
                return;
            }

            form.dataset.doubleSubmitBound = '1';

            form.addEventListener('submit', function () {
                if (!form.checkValidity()) {
                    return;
                }

                var buttons = form.querySelectorAll(
                    'button[type="submit"], input[type="submit"]'
                );

                buttons.forEach(function (button) {
                    button.disabled = true;

                    if (button.tagName === 'BUTTON') {
                        if (!button.dataset.originalText) {
                            button.dataset.originalText =
                                button.textContent;
                        }

                        button.textContent = 'Đang xử lý...';
                    }
                });
            });
        });
    }

    bindDoubleSubmit(document);

    /*
     * Ảnh dự phòng: khi ảnh lỗi (URL hỏng, file bị xóa...) thay bằng
     * ảnh SVG tạo tại chỗ để khu vực nào cũng hiển thị ảnh.
     * Listener ở pha capture nên chạy trước onerror gắn sẵn trong HTML.
     */
    var PALETTES = [
        ['#3b2f4a', '#6d4c7d'], ['#2f3e4a', '#4c6d7d'],
        ['#4a2f2f', '#7d4c4c'], ['#2f4a3b', '#4c7d65'],
        ['#4a432f', '#7d724c'], ['#2f2f4a', '#4c4c7d']
    ];

    function fallbackImage(label) {
        label = (label || '').trim();

        var hash = 0;

        for (var i = 0; i < label.length; i++) {
            hash = (hash * 31 + label.charCodeAt(i)) >>> 0;
        }

        var palette = PALETTES[hash % PALETTES.length];

        var words = label.split(/\s+/).filter(function (word) {
            return /[A-Za-z0-9\u00C0-\u1EF9]/.test(word);
        });

        var initials = words.slice(0, 2).map(function (word) {
            return word.charAt(0).toUpperCase();
        }).join('') || '?';

        var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">' +
            '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' +
            '<stop offset="0" stop-color="' + palette[0] + '"/>' +
            '<stop offset="1" stop-color="' + palette[1] + '"/>' +
            '</linearGradient></defs>' +
            '<rect width="200" height="200" fill="url(#g)"/>' +
            '<text x="100" y="118" text-anchor="middle" ' +
            'font-family="Arial,sans-serif" font-weight="700" ' +
            'font-size="84" fill="#fff">' +
            initials.replace(/&/g, '&amp;').replace(/</g, '&lt;') +
            '</text></svg>';

        return 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg);
    }

    function applyFallback(img) {
        if (img.dataset.fallbackApplied) {
            return;
        }

        img.dataset.fallbackApplied = '1';
        img.style.display = '';
        img.src = fallbackImage(img.getAttribute('alt') || '');

        var next = img.nextElementSibling;

        if (next && next.getAttribute('aria-hidden') === 'true') {
            next.style.display = 'none';
        }
    }

    document.addEventListener('error', function (event) {
        var img = event.target;

        if (
            !(img instanceof HTMLImageElement) ||
            img.dataset.fallbackApplied
        ) {
            return;
        }

        event.stopPropagation();
        applyFallback(img);
    }, true);

    function fixBrokenImages(root) {
        (root || document).querySelectorAll('img').forEach(function (img) {
            if (img.complete && img.naturalWidth === 0 && img.src) {
                applyFallback(img);
            }
        });
    }

    fixBrokenImages(document);

    /*
     * Chuyển trang không tải lại toàn bộ.
     *
     * Bấm menu/liên kết/biểu mẫu trong khu vực admin sẽ tải nội dung
     * bằng fetch rồi thay vào .cs-admin-main; sidebar, CSS và
     * script dùng chung được giữ nguyên. Thêm data-no-ajax vào
     * liên kết hoặc form nếu muốn tải lại trang như bình thường.
     */
    var currentRequest = null;
    var progress = document.createElement('div');

    progress.setAttribute('aria-hidden', 'true');
    progress.style.cssText =
        'position:fixed;top:0;left:0;height:3px;width:0;z-index:99999;' +
        'background:#f2f2f2;opacity:0;pointer-events:none;' +
        'transition:width .25s ease,opacity .25s ease;';

    document.body.appendChild(progress);

    var progressTimer = null;

    function progressStart() {
        clearTimeout(progressTimer);
        progress.style.opacity = '1';
        progress.style.width = '25%';

        progressTimer = setTimeout(function () {
            progress.style.width = '70%';
        }, 150);
    }

    function progressDone() {
        clearTimeout(progressTimer);
        progress.style.width = '100%';

        progressTimer = setTimeout(function () {
            progress.style.opacity = '0';

            setTimeout(function () {
                progress.style.width = '0';
            }, 250);
        }, 150);
    }

    function dirOf(pathname) {
        return pathname.replace(/[^\/]*$/, '');
    }

    function isAdminPageUrl(url) {
        if (url.origin !== location.origin) {
            return false;
        }

        if (!/\.php$/i.test(url.pathname)) {
            return false;
        }

        if (dirOf(url.pathname) !== dirOf(location.pathname)) {
            return false;
        }

        var file = url.pathname.split('/').pop().toLowerCase();

        return file !== 'login.php' && file !== 'logout.php';
    }

    function revive(root) {
        root.querySelectorAll('script').forEach(function (old) {
            var script = document.createElement('script');

            Array.prototype.forEach.call(old.attributes, function (attr) {
                script.setAttribute(attr.name, attr.value);
            });

            script.text = old.textContent;
            old.parentNode.replaceChild(script, old);
        });
    }

    function swapPage(doc, newMain, finalUrl, push) {
        var main = document.querySelector('.cs-admin-main');

        if (!main) {
            location.href = finalUrl;
            return;
        }

        /* Cập nhật mục menu đang chọn. */
        var currentLinks = document.querySelectorAll('.admin-sidebar nav a');
        var newLinks = doc.querySelectorAll('.admin-sidebar nav a');

        if (currentLinks.length === newLinks.length) {
            currentLinks.forEach(function (link, index) {
                var source = newLinks[index];

                link.className = source.className;

                if (source.hasAttribute('aria-current')) {
                    link.setAttribute(
                        'aria-current',
                        source.getAttribute('aria-current')
                    );
                } else {
                    link.removeAttribute('aria-current');
                }
            });
        }

        document.title = doc.title;
        main.innerHTML = newMain.innerHTML;

        revive(main);
        bindDoubleSubmit(main);
        fixBrokenImages(main);

        if (push) {
            history.pushState({ csAjax: true }, '', finalUrl);
        }

        window.scrollTo(0, 0);
    }

    function loadPage(url, options) {
        options = options || {};

        if (currentRequest) {
            currentRequest.abort();
        }

        currentRequest = new AbortController();

        var init = {
            credentials: 'same-origin',
            signal: currentRequest.signal,
            headers: { 'X-Requested-With': 'fetch' }
        };

        if (options.method && options.method !== 'GET') {
            init.method = options.method;
            init.body = options.body;
        }

        progressStart();

        return fetch(url, init).then(function (response) {
            var finalUrl = response.url || url;
            var type = response.headers.get('content-type') || '';

            if (type.indexOf('text/html') === -1) {
                location.href = finalUrl;
                return null;
            }

            return response.text().then(function (html) {
                var doc = new DOMParser().parseFromString(html, 'text/html');
                var newMain = doc.querySelector('.cs-admin-main');

                /* Trang không có khung admin (ví dụ login) -> tải đầy đủ. */
                if (!newMain) {
                    location.href = finalUrl;
                    return;
                }

                swapPage(doc, newMain, finalUrl, options.push !== false);
            });
        }).catch(function (error) {
            if (error && error.name === 'AbortError') {
                return;
            }

            location.href = url;
        }).then(progressDone);
    }

    history.replaceState({ csAjax: true }, '', location.href);

    document.addEventListener('click', function (event) {
        if (
            event.defaultPrevented ||
            event.button !== 0 ||
            event.metaKey || event.ctrlKey ||
            event.shiftKey || event.altKey
        ) {
            return;
        }

        var link = event.target.closest('a[href]');

        if (
            !link ||
            (link.target && link.target !== '_self') ||
            link.hasAttribute('download') ||
            link.hasAttribute('data-no-ajax')
        ) {
            return;
        }

        var url;

        try {
            url = new URL(link.href, location.href);
        } catch (e) {
            return;
        }

        if (!isAdminPageUrl(url)) {
            return;
        }

        if (
            url.pathname === location.pathname &&
            url.search === location.search &&
            url.hash !== ''
        ) {
            return;
        }

        event.preventDefault();
        loadPage(url.href);
    });

    document.addEventListener('submit', function (event) {
        var form = event.target;

        if (
            event.defaultPrevented ||
            !(form instanceof HTMLFormElement) ||
            form.hasAttribute('data-no-ajax') ||
            (form.target && form.target !== '_self')
        ) {
            return;
        }

        var submitter = event.submitter || null;

        var action = (submitter && submitter.getAttribute('formaction')) ||
            form.getAttribute('action') ||
            location.href;

        var url;

        try {
            url = new URL(action, location.href);
        } catch (e) {
            return;
        }

        if (!isAdminPageUrl(url)) {
            return;
        }

        var method = (
            (submitter && submitter.getAttribute('formmethod')) ||
            form.getAttribute('method') ||
            'get'
        ).toUpperCase();

        var data = new FormData(form);

        if (submitter && submitter.name) {
            data.append(submitter.name, submitter.value);
        }

        event.preventDefault();

        if (method === 'POST') {
            loadPage(url.href, { method: 'POST', body: data });
            return;
        }

        var query = new URLSearchParams();

        data.forEach(function (value, key) {
            if (typeof value === 'string') {
                query.append(key, value);
            }
        });

        url.search = query.toString();
        loadPage(url.href);
    });

    window.addEventListener('popstate', function () {
        loadPage(location.href, { push: false });
    });

})();
</script>
</body>
</html>
<?php
/*
 * Kết thúc admin/includes/footer.php.
 * Không thêm thẻ HTML nào sau đây.
 */
?>
