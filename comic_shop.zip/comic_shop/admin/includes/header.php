<?php
/**
 * Comic Shop - Admin shared header
 *
 * File: admin/includes/header.php
 *
 * Các biến tùy chọn khai báo trước khi include:
 * $pageTitle       Tiêu đề trang
 * $pageDescription Mô tả ngắn
 * $activeMenu      Menu đang chọn
 *
 * Ví dụ:
 * $pageTitle = 'Tổng quan';
 * $activeMenu = 'dashboard';
 * require_once __DIR__ . '/includes/header.php';
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* ---------- Hàm escape an toàn ---------- */

if (!function_exists('comic_admin_escape')) {
    function comic_admin_escape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

/* ---------- Thông tin trang ---------- */

$adminPageTitle = isset($pageTitle) && is_string($pageTitle)
    ? trim($pageTitle)
    : 'Quản trị hệ thống';

if ($adminPageTitle === '') {
    $adminPageTitle = 'Quản trị hệ thống';
}

$adminPageDescription =
    isset($pageDescription) && is_string($pageDescription)
        ? trim($pageDescription)
        : '';

$adminActiveMenu =
    isset($activeMenu) && is_string($activeMenu)
        ? $activeMenu
        : pathinfo($_SERVER['PHP_SELF'] ?? '', PATHINFO_FILENAME);

/* ---------- Thông tin tài khoản hiện tại ---------- */

$adminName = 'Quản trị viên';
$adminRole = 'Administrator';

if (!empty($_SESSION['user']) && is_array($_SESSION['user'])) {
    $sessionUser = $_SESSION['user'];

    foreach (['full_name', 'name', 'username', 'email'] as $key) {
        if (!empty($sessionUser[$key]) && is_string($sessionUser[$key])) {
            $adminName = $sessionUser[$key];
            break;
        }
    }

    if (!empty($sessionUser['role']) && is_string($sessionUser['role'])) {
        $adminRole = $sessionUser['role'];
    }
} else {
    foreach (['full_name', 'user_name', 'username', 'name'] as $key) {
        if (!empty($_SESSION[$key]) && is_string($_SESSION[$key])) {
            $adminName = $_SESSION[$key];
            break;
        }
    }

    if (!empty($_SESSION['role']) && is_string($_SESSION['role'])) {
        $adminRole = $_SESSION['role'];
    }
}

$adminInitial = 'A';

if ($adminName !== '') {
    if (function_exists('mb_substr')) {
        $adminInitial = mb_strtoupper(
            mb_substr($adminName, 0, 1, 'UTF-8'),
            'UTF-8'
        );
    } else {
        $adminInitial = strtoupper(substr($adminName, 0, 1));
    }
}

/* ---------- Danh sách menu quản trị ---------- */

$adminMenus = [
    [
        'section' => 'TỔNG QUAN',
        'items' => [
            [
                'key' => 'dashboard',
                'label' => 'Tổng quan',
                'icon' => '▦',
                'url' => 'dashboard.php',
            ],
            [
                'key' => 'reports',
                'label' => 'Báo cáo thống kê',
                'icon' => '▤',
                'url' => 'reports.php',
            ],
        ],
    ],
    [
        'section' => 'QUẢN LÝ TRUYỆN',
        'items' => [
            [
                'key' => 'comics',
                'label' => 'Danh sách truyện',
                'icon' => '▣',
                'url' => 'comics.php',
            ],
            [
                'key' => 'authors',
                'label' => 'Tác giả',
                'icon' => '✎',
                'url' => 'authors.php',
            ],
            [
                'key' => 'categories',
                'label' => 'Thể loại',
                'icon' => '▧',
                'url' => 'categories.php',
            ],
            [
                'key' => 'inventory',
                'label' => 'Kho hàng',
                'icon' => '▥',
                'url' => 'inventory.php',
            ],
        ],
    ],
    [
        'section' => 'BÁN HÀNG',
        'items' => [
            [
                'key' => 'orders',
                'label' => 'Đơn hàng',
                'icon' => '▣',
                'url' => 'orders.php',
            ],
            [
                'key' => 'reviews',
                'label' => 'Đánh giá',
                'icon' => '☆',
                'url' => 'reviews.php',
            ],
            [
                'key' => 'messages',
                'label' => 'Tin nhắn liên hệ',
                'icon' => '✉',
                'url' => 'messages.php',
            ],
        ],
    ],
    [
        'section' => 'NỘI DUNG & TÀI KHOẢN',
        'items' => [
            [
                'key' => 'users',
                'label' => 'Người dùng',
                'icon' => '♙',
                'url' => 'users.php',
            ],
        ],
    ],
];

/* ---------- Chỉ render khung giao diện ---------- */

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <meta
        name="robots"
        content="noindex, nofollow"
    >

    <title>
        <?= comic_admin_escape($adminPageTitle) ?> | Comic Shop Admin
    </title>

    <link
        rel="stylesheet"
        href="../assets/css/admin.css"
    >

    <style>
        .cs-admin-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 16px;
            margin: -28px -28px 28px;
            padding: 17px 28px;
            min-height: 76px;
            background: #232327;
            border-bottom: 1px solid #3d3d44;
        }

        .cs-admin-top-title {
            min-width: 0;
        }

        .cs-admin-top-title h1 {
            margin: 0;
            color: #f2f2f2;
            font-size: 21px;
            line-height: 1.35;
            font-weight: 800;
        }

        .cs-admin-top-title p {
            margin: 4px 0 0;
            color: #a9a9b2;
            font-size: 12px;
        }

        .cs-admin-top-actions {
            display: flex;
            align-items: center;
            gap: 13px;
        }

        .cs-admin-home-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 36px;
            padding: 8px 12px;
            border: 1px solid #3d3d44;
            border-radius: 999px;
            color: #d4d4da;
            font-size: 12px;
            font-weight: 700;
            text-decoration: none;
        }

        .cs-admin-home-link:hover {
            border-color: #f2f2f2;
            color: #f2f2f2;
        }

        .cs-admin-profile {
            display: flex;
            align-items: center;
            gap: 10px;
            min-width: 0;
        }

        .cs-admin-profile-avatar {
            display: grid;
            width: 39px;
            height: 39px;
            flex: 0 0 39px;
            place-items: center;
            border-radius: 50%;
            background: #36363c;
            color: #f2f2f2;
            font-size: 15px;
            font-weight: 850;
        }

        .cs-admin-profile-name {
            max-width: 180px;
            overflow: hidden;
            color: #f2f2f2;
            font-size: 12px;
            font-weight: 800;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .cs-admin-profile-role {
            margin-top: 2px;
            color: #a9a9b2;
            font-size: 11px;
        }

        .cs-admin-main {
            min-width: 0;
            flex: 1;
            padding: 28px;
            background: #1c1c1f;
        }

        .cs-admin-content {
            width: 100%;
            max-width: 1600px;
            margin: 0 auto;
        }

        .cs-admin-brand-subtitle {
            display: block;
            margin-top: 3px;
            color: #a9a9b2;
            font-size: 10px;
            font-weight: 500;
            letter-spacing: 1.1px;
        }

        .cs-admin-menu-icon {
            display: inline-flex;
            width: 20px;
            flex: 0 0 20px;
            align-items: center;
            justify-content: center;
            font-size: 17px;
            line-height: 1;
        }

        .cs-admin-logout {
            color: #ffc4bd !important;
        }

        .cs-admin-logout:hover {
            background: rgba(239, 67, 56, .16) !important;
            color: #f2f2f2 !important;
        }

        @media (max-width: 700px) {
            .cs-admin-main {
                padding: 16px;
            }

            .cs-admin-top {
                margin: -16px -16px 20px;
                padding: 14px 16px;
            }

            .cs-admin-top-title h1 {
                font-size: 18px;
            }

            .cs-admin-home-link {
                display: none;
            }

            .cs-admin-profile-name {
                max-width: 115px;
            }
        }
    </style>

    <link
        rel="stylesheet"
        href="../assets/css/admin-dark.css"
    >
</head>

<body>

<div class="admin-layout">

    <aside class="admin-sidebar">

        <a
            href="dashboard.php"
            class="sidebar-brand"
            style="text-decoration:none"
        >
            <span class="brand-icon" aria-hidden="true">C</span>

            <span>
                COMIC SHOP
                <span class="cs-admin-brand-subtitle">
                    ADMINISTRATION
                </span>
            </span>
        </a>

        <nav aria-label="Menu quản trị">

            <?php foreach ($adminMenus as $menuGroup): ?>

                <div class="sidebar-heading">
                    <?= comic_admin_escape($menuGroup['section']) ?>
                </div>

                <?php foreach ($menuGroup['items'] as $menuItem): ?>

                    <?php
                    $isActive = $adminActiveMenu === $menuItem['key'];
                    ?>

                    <a
                        href="<?= comic_admin_escape($menuItem['url']) ?>"
                        class="<?= $isActive ? 'active' : '' ?>"
                        <?= $isActive ? 'aria-current="page"' : '' ?>
                    >
                        <span
                            class="cs-admin-menu-icon"
                            aria-hidden="true"
                        ><?= comic_admin_escape($menuItem['icon']) ?></span>

                        <span><?= comic_admin_escape($menuItem['label']) ?></span>
                    </a>

                <?php endforeach; ?>

            <?php endforeach; ?>

            <div class="sidebar-heading">HỆ THỐNG</div>

            <a href="../index.php" target="_blank" rel="noopener">
                <span class="cs-admin-menu-icon" aria-hidden="true">↗</span>
                <span>Xem website</span>
            </a>

            <a href="logout.php" class="cs-admin-logout">
                <span class="cs-admin-menu-icon" aria-hidden="true">⇥</span>
                <span>Đăng xuất</span>
            </a>

        </nav>

    </aside>

    <div class="cs-admin-main">

        <header class="cs-admin-top">

            <div class="cs-admin-top-title">
                <h1><?= comic_admin_escape($adminPageTitle) ?></h1>

                <?php if ($adminPageDescription !== ''): ?>
                    <p><?= comic_admin_escape($adminPageDescription) ?></p>
                <?php else: ?>
                    <p>Quản lý cửa hàng truyện Comic Shop</p>
                <?php endif; ?>
            </div>

            <div class="cs-admin-top-actions">

                <a
                    href="../index.php"
                    class="cs-admin-home-link"
                    target="_blank"
                    rel="noopener"
                >
                    ↗ Xem website
                </a>

                <div class="cs-admin-profile">

                    <span class="cs-admin-profile-avatar">
                        <?= comic_admin_escape($adminInitial) ?>
                    </span>

                    <span>
                        <span class="cs-admin-profile-name">
                            <?= comic_admin_escape($adminName) ?>
                        </span>

                        <span class="cs-admin-profile-role">
                            <?= comic_admin_escape($adminRole) ?>
                        </span>
                    </span>

                </div>

            </div>

        </header>

        <main class="cs-admin-content">
