<?php
declare(strict_types=1);

/**
 * Comic Shop - Quản lý kho truyện
 *
 * File: admin/inventory.php
 *
 * Các bảng sử dụng:
 * - comics
 * - categories
 * - stock_imports
 * - users
 *
 * Hỗ trợ PDO và MySQLi.
 */

$pageTitle = 'Quản lý kho hàng';
$pageDescription = 'Theo dõi tồn kho và lịch sử nhập truyện.';
$activeMenu = 'inventory';

require_once __DIR__ . '/includes/bootstrap.php';

if (!function_exists('comic_admin_media_url')) {
    require_once __DIR__ . '/includes/media.php';
}

$database = $GLOBALS['comic_shop_db'] ?? null;

$dbReady = $database instanceof PDO ||
    (class_exists('mysqli') && $database instanceof mysqli);

/* =========================================================
   1. DATABASE HELPER
========================================================= */

if (!function_exists('comic_admin_inventory_query')) {
    function comic_admin_inventory_query(
        $database,
        string $sql,
        array $params = []
    ): array {
        if ($database instanceof PDO) {
            $stmt = $database->prepare($sql);
            $stmt->execute($params);

            $rows = $stmt->columnCount() > 0
                ? $stmt->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $affected = $stmt->rowCount();
            $insertId = $database->lastInsertId();

            $stmt->closeCursor();

            return [
                'rows' => $rows,
                'affected' => $affected,
                'insert_id' => $insertId,
            ];
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            $stmt = $database->prepare($sql);

            if (!$stmt) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn MySQL.'
                );
            }

            if ($params !== []) {
                $types = '';
                $bindValues = [];

                foreach ($params as $index => $value) {
                    if (is_int($value) || is_bool($value)) {
                        $types .= 'i';
                    } elseif (is_float($value)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }

                    $bindValues[$index] = $params[$index];
                }

                $arguments = [$types];

                foreach ($bindValues as &$value) {
                    $arguments[] = &$value;
                }

                unset($value);

                if (!call_user_func_array(
                    [$stmt, 'bind_param'],
                    $arguments
                )) {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không thể gắn tham số truy vấn.'
                    );
                }
            }

            if (!$stmt->execute()) {
                $error = $stmt->error;
                $stmt->close();

                throw new RuntimeException(
                    $error ?: 'Truy vấn MySQL thất bại.'
                );
            }

            $rows = [];

            if ($stmt->field_count > 0) {
                $result = $stmt->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không đọc được kết quả truy vấn.'
                    );
                }
            }

            $affected = $stmt->affected_rows;
            $insertId = $stmt->insert_id;
            $stmt->close();

            return [
                'rows' => $rows,
                'affected' => $affected,
                'insert_id' => $insertId,
            ];
        }

        throw new RuntimeException(
            'Không tìm thấy kết nối PDO/MySQLi.'
        );
    }
}

/* =========================================================
   2. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_admin_inventory_escape')) {
    function comic_admin_inventory_escape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_admin_inventory_money')) {
    function comic_admin_inventory_money($value): string
    {
        return number_format(
            (float) $value,
            0,
            ',',
            '.'
        ) . ' ₫';
    }
}

if (!function_exists('comic_admin_inventory_redirect')) {
    function comic_admin_inventory_redirect(): void
    {
        header('Location: inventory.php', true, 303);
        exit;
    }
}

if (!function_exists('comic_admin_inventory_flash')) {
    function comic_admin_inventory_flash(
        string $type,
        string $message
    ): void {
        $_SESSION['comic_inventory_flash'] = [
            'type' => $type,
            'message' => $message,
        ];
    }
}

/* =========================================================
   3. XỬ LÝ NHẬP KHO
========================================================= */

$flash = $_SESSION['comic_inventory_flash'] ?? null;
unset($_SESSION['comic_inventory_flash']);

$errors = [];

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $token = isset($_POST['csrf_token']) &&
        is_string($_POST['csrf_token'])
            ? $_POST['csrf_token']
            : '';

    if (
        !function_exists('comic_admin_csrf_valid') ||
        !comic_admin_csrf_valid($token)
    ) {
        comic_admin_inventory_flash(
            'error',
            'Phiên làm việc đã hết hạn. Vui lòng thử lại.'
        );

        comic_admin_inventory_redirect();
    }

    $action = isset($_POST['action']) &&
        is_string($_POST['action'])
            ? $_POST['action']
            : '';

    if ($action !== 'import_stock') {
        comic_admin_inventory_flash(
            'error',
            'Thao tác không hợp lệ.'
        );

        comic_admin_inventory_redirect();
    }

    if (!$dbReady) {
        comic_admin_inventory_flash(
            'error',
            'Chưa kết nối được cơ sở dữ liệu. Kiểm tra config/db.php.'
        );

        comic_admin_inventory_redirect();
    }

    $comicId = (int) ($_POST['comic_id'] ?? 0);

    $quantityRaw = isset($_POST['quantity']) &&
        is_string($_POST['quantity'])
            ? trim($_POST['quantity'])
            : '';

    $unitCostRaw = isset($_POST['unit_cost']) &&
        is_string($_POST['unit_cost'])
            ? trim($_POST['unit_cost'])
            : '';

    $supplier = isset($_POST['supplier']) &&
        is_string($_POST['supplier'])
            ? trim($_POST['supplier'])
            : '';

    $note = isset($_POST['note']) &&
        is_string($_POST['note'])
            ? trim($_POST['note'])
            : '';

    $quantity = filter_var(
        $quantityRaw,
        FILTER_VALIDATE_INT
    );

    $unitCostValid = $unitCostRaw !== '' &&
        is_numeric($unitCostRaw);

    $unitCost = $unitCostValid
        ? (float) $unitCostRaw
        : -1;

    if ($comicId < 1) {
        $errors[] = 'Vui lòng chọn truyện cần nhập kho.';
    }

    if (
        $quantity === false ||
        $quantity < 1 ||
        $quantity > 1000000
    ) {
        $errors[] =
            'Số lượng nhập phải là số nguyên từ 1 đến 1.000.000.';
    }

    if (
        !$unitCostValid ||
        $unitCost < 0 ||
        $unitCost > 9999999999.99
    ) {
        $errors[] = 'Đơn giá nhập không hợp lệ.';
    }

    if (strlen($supplier) > 150) {
        $errors[] =
            'Tên nhà cung cấp không được vượt quá 150 byte.';
    }

    if (strlen($note) > 60000) {
        $errors[] = 'Ghi chú nhập kho quá dài.';
    }

    if (!$errors) {
        $inTransaction = false;

        try {
            /*
             * Cập nhật tồn kho và lưu lịch sử phải nằm trong
             * cùng một transaction để dữ liệu không bị lệch.
             */
            if ($database instanceof PDO) {
                $database->beginTransaction();
            } else {
                $database->begin_transaction();
            }

            $inTransaction = true;

            /*
             * Khóa hàng truyện trong thời gian nhập kho để tránh
             * hai thao tác đồng thời làm sai số lượng tồn kho.
             */
            $comicRows = comic_admin_inventory_query(
                $database,
                'SELECT id, title, stock
                 FROM comics
                 WHERE id = ?
                 FOR UPDATE',
                [$comicId]
            )['rows'];

            if (!$comicRows) {
                throw new RuntimeException(
                    'Không tìm thấy truyện cần nhập kho.'
                );
            }

            $comic = $comicRows[0];
            $currentStock = (int) $comic['stock'];

            if ($currentStock + $quantity > 2147483647) {
                throw new RuntimeException(
                    'Số lượng tồn kho vượt quá giới hạn cho phép.'
                );
            }

            /*
             * Chỉ tăng tồn kho bằng số lượng thực nhập.
             * Giá bán không bị thay đổi.
             */
            comic_admin_inventory_query(
                $database,
                'UPDATE comics
                 SET stock = stock + ?
                 WHERE id = ?',
                [$quantity, $comicId]
            );

            /*
             * Xác định ID tài khoản quản trị để lưu lịch sử.
             * admin_id chấp nhận NULL theo schema của dự án.
             */
            $adminId = null;

            if (
                isset($_SESSION['admin_id']) &&
                (int) $_SESSION['admin_id'] > 0
            ) {
                $adminId = (int) $_SESSION['admin_id'];
            } elseif (
                isset($_SESSION['user']['id']) &&
                (int) $_SESSION['user']['id'] > 0
            ) {
                $adminId = (int) $_SESSION['user']['id'];
            } elseif (
                isset($_SESSION['admin']['id']) &&
                (int) $_SESSION['admin']['id'] > 0
            ) {
                $adminId = (int) $_SESSION['admin']['id'];
            }

            comic_admin_inventory_query(
                $database,
                'INSERT INTO stock_imports (
                    comic_id,
                    comic_title,
                    quantity,
                    unit_cost,
                    supplier,
                    note,
                    admin_id
                 ) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [
                    $comicId,
                    (string) $comic['title'],
                    $quantity,
                    $unitCost,
                    $supplier !== '' ? $supplier : null,
                    $note !== '' ? $note : null,
                    $adminId,
                ]
            );

            if ($database instanceof PDO) {
                $database->commit();
            } else {
                $database->commit();
            }

            $inTransaction = false;

            $_SESSION['comic_admin_csrf'] =
                bin2hex(random_bytes(32));

            comic_admin_inventory_flash(
                'success',
                'Đã nhập ' . number_format($quantity) .
                ' cuốn "' . (string) $comic['title'] .
                '". Tồn kho mới: ' .
                number_format($currentStock + $quantity) .
                ' cuốn.'
            );

        } catch (Throwable $exception) {
            if ($inTransaction) {
                try {
                    if ($database instanceof PDO) {
                        if ($database->inTransaction()) {
                            $database->rollBack();
                        }
                    } else {
                        $database->rollback();
                    }
                } catch (Throwable $rollbackException) {
                    error_log(
                        '[Comic Shop Inventory] Rollback thất bại.'
                    );
                }
            }

            error_log(
                '[Comic Shop Inventory] ' .
                $exception->getMessage()
            );

            comic_admin_inventory_flash(
                'error',
                'Không thể nhập kho. Vui lòng kiểm tra dữ liệu và nhật ký lỗi.'
            );
        }
    } else {
        comic_admin_inventory_flash(
            'error',
            implode(' ', $errors)
        );
    }

    comic_admin_inventory_redirect();
}

/* =========================================================
   4. TÌM KIẾM VÀ LỌC
========================================================= */

$search = isset($_GET['q']) && is_string($_GET['q'])
    ? trim($_GET['q'])
    : '';

$stockFilter = isset($_GET['stock']) &&
    is_string($_GET['stock'])
        ? $_GET['stock']
        : 'all';

if (!in_array(
    $stockFilter,
    ['all', 'low', 'out'],
    true
)) {
    $stockFilter = 'all';
}

$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;

$totalItems = 0;
$totalPages = 1;
$comicRows = [];
$historyRows = [];
$comicOptions = [];

$stats = [
    'comics' => 0,
    'stock_units' => 0,
    'low_stock' => 0,
    'imported_units' => 0,
    'import_cost' => 0,
];

$offset = 0;

if ($dbReady) {
    try {
        /* Thống kê kho. */
        $statRows = comic_admin_inventory_query(
            $database,
            'SELECT
                COUNT(*) AS comic_count,
                COALESCE(SUM(stock), 0) AS stock_units,
                COALESCE(
                    SUM(CASE WHEN stock <= 5 THEN 1 ELSE 0 END),
                    0
                ) AS low_stock_count
             FROM comics'
        )['rows'];

        if ($statRows) {
            $stats['comics'] =
                (int) $statRows[0]['comic_count'];

            $stats['stock_units'] =
                (int) $statRows[0]['stock_units'];

            $stats['low_stock'] =
                (int) $statRows[0]['low_stock_count'];
        }

        $importStats = comic_admin_inventory_query(
            $database,
            'SELECT
                COALESCE(SUM(quantity), 0) AS imported_units,
                COALESCE(SUM(quantity * unit_cost), 0) AS import_cost
             FROM stock_imports'
        )['rows'];

        if ($importStats) {
            $stats['imported_units'] =
                (int) $importStats[0]['imported_units'];

            $stats['import_cost'] =
                (float) $importStats[0]['import_cost'];
        }

        /* Dữ liệu lựa chọn cho biểu mẫu nhập kho. */
        $comicOptions = comic_admin_inventory_query(
            $database,
            'SELECT id, title, stock
             FROM comics
             ORDER BY title ASC'
        )['rows'];

        /* Điều kiện tìm kiếm. */
        $where = [];
        $params = [];

        if ($search !== '') {
            $where[] = '(
                c.title LIKE ?
                OR c.slug LIKE ?
                OR c.isbn LIKE ?
            )';

            $like = '%' . $search . '%';

            array_push(
                $params,
                $like,
                $like,
                $like
            );
        }

        if ($stockFilter === 'low') {
            $where[] = 'c.stock > 0 AND c.stock <= 5';
        } elseif ($stockFilter === 'out') {
            $where[] = 'c.stock <= 0';
        }

        $whereSql = $where
            ? ' WHERE ' . implode(' AND ', $where)
            : '';

        $countRows = comic_admin_inventory_query(
            $database,
            'SELECT COUNT(*) AS total
             FROM comics c' . $whereSql,
            $params
        )['rows'];

        $totalItems = (int) ($countRows[0]['total'] ?? 0);

        $totalPages = max(
            1,
            (int) ceil($totalItems / $perPage)
        );

        $page = min($page, $totalPages);
        $offset = ($page - 1) * $perPage;

        $listParams = $params;
        $listParams[] = $perPage;
        $listParams[] = $offset;

        $comicRows = comic_admin_inventory_query(
            $database,
            'SELECT
                c.id,
                c.title,
                c.slug,
                c.cover_image,
                c.stock,
                c.price,
                c.sale_price,
                c.sold_count,
                c.is_active,
                cat.name AS category_name
             FROM comics c
             LEFT JOIN categories cat
                ON cat.id = c.category_id'
             . $whereSql .
            ' ORDER BY
                CASE WHEN c.stock <= 5 THEN 0 ELSE 1 END,
                c.stock ASC,
                c.title ASC
             LIMIT ? OFFSET ?',
            $listParams
        )['rows'];

        /* Lịch sử 8 lần nhập kho gần nhất. */
        $historyRows = comic_admin_inventory_query(
            $database,
            'SELECT
                si.id,
                si.comic_title,
                si.quantity,
                si.unit_cost,
                si.supplier,
                si.note,
                si.created_at,
                u.full_name AS admin_name
             FROM stock_imports si
             LEFT JOIN users u ON u.id = si.admin_id
             ORDER BY si.created_at DESC, si.id DESC
             LIMIT 8'
        )['rows'];

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Inventory] ' .
            $exception->getMessage()
        );

        $errors[] =
            'Không thể tải một phần dữ liệu kho. ' .
            'Hãy kiểm tra kết nối và schema cơ sở dữ liệu.';
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<style>
.inventory-admin {
    color: #f2f2f2;
}

.inventory-admin .ia-alert {
    margin-bottom: 18px;
    padding: 12px 15px;
    border: 1px solid #f1d1cd;
    border-left: 4px solid #ff6b60;
    background: rgba(255,107,96,.14);
    color: #ff8f86;
    font-size: 12px;
    line-height: 1.65;
}

.inventory-admin .ia-alert.success {
    border-color: rgba(80,200,130,.4);
    border-left-color: #50c882;
    background: rgba(80,200,130,.16);
    color: #6fdc9c;
}

.inventory-admin .ia-stats {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}

.inventory-admin .ia-stat {
    padding: 17px;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.2);
}

.inventory-admin .ia-stat-label {
    color: #a9a9b2;
    font-size: 11px;
    font-weight: 700;
}

.inventory-admin .ia-stat-value {
    display: block;
    margin-top: 8px;
    font-size: clamp(20px,2vw,27px);
    font-weight: 850;
    line-height: 1.25;
    overflow-wrap: anywhere;
}

.inventory-admin .ia-stat-note {
    margin-top: 6px;
    color: #a9a9b2;
    font-size: 10px;
    line-height: 1.5;
}

.inventory-admin .ia-grid {
    display: grid;
    grid-template-columns: minmax(0,1.2fr) minmax(280px,.8fr);
    align-items: start;
    gap: 20px;
    margin-bottom: 22px;
}

.inventory-admin .ia-panel {
    min-width: 0;
    margin-bottom: 22px;
    overflow: hidden;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.2);
}

.inventory-admin .ia-grid .ia-panel {
    margin-bottom: 0;
}

.inventory-admin .ia-panel-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 10px;
    padding: 17px 20px;
    border-bottom: 1px solid #3d3d44;
}

.inventory-admin .ia-panel-head h2 {
    margin: 0;
    font-size: 14px;
    font-weight: 850;
}

.inventory-admin .ia-panel-subtitle {
    margin-top: 4px;
    color: #a9a9b2;
    font-size: 11px;
}

.inventory-admin .ia-panel-body {
    padding: 20px;
}

.inventory-admin .ia-field {
    margin-bottom: 16px;
}

.inventory-admin .ia-field label {
    display: block;
    margin-bottom: 7px;
    color: #363d48;
    font-size: 11px;
    font-weight: 800;
}

.inventory-admin .ia-field input,
.inventory-admin .ia-field select,
.inventory-admin .ia-field textarea {
    display: block;
    width: 100%;
    min-height: 41px;
    padding: 10px 12px;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    outline: none;
    background: #232327;
    color: #f2f2f2;
    font: inherit;
    font-size: 12px;
}

.inventory-admin .ia-field textarea {
    min-height: 80px;
    resize: vertical;
}

.inventory-admin .ia-field input:focus,
.inventory-admin .ia-field select:focus,
.inventory-admin .ia-field textarea:focus {
    border-color: #f2f2f2;
    box-shadow: 0 0 0 3px rgba(239,67,56,.1);
}

.inventory-admin .ia-help {
    margin-top: 6px;
    color: #a9a9b2;
    font-size: 10px;
    line-height: 1.6;
}

.inventory-admin .ia-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    min-height: 37px;
    padding: 9px 13px;
    border: 1px solid transparent;
    border-radius: 999px;
    background: #f2f2f2;
    color: #111111;
    font-size: 12px;
    font-weight: 800;
    text-decoration: none;
    cursor: pointer;
}

.inventory-admin .ia-btn:hover {
    background: #ffffff;
    color: #111111;
}

.inventory-admin .ia-btn.secondary {
    border-color: #3d3d44;
    background: #232327;
    color: #d4d4da;
}

.inventory-admin .ia-btn.secondary:hover {
    border-color: #f2f2f2;
    color: #f2f2f2;
}

.inventory-admin .ia-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
    margin-bottom: 17px;
}

.inventory-admin .ia-search {
    display: flex;
    align-items: center;
    flex: 1;
    flex-wrap: wrap;
    gap: 8px;
}

.inventory-admin .ia-search input,
.inventory-admin .ia-search select {
    min-height: 39px;
    padding: 9px 12px;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    background: #232327;
    color: #f2f2f2;
    font: inherit;
    font-size: 12px;
}

.inventory-admin .ia-search input {
    min-width: 200px;
    flex: 1;
}

.inventory-admin .ia-table-wrap {
    width: 100%;
    overflow-x: auto;
}

.inventory-admin table {
    width: 100%;
    border-collapse: collapse;
}

.inventory-admin th {
    padding: 13px 15px;
    border-bottom: 1px solid #3d3d44;
    background: #2c2c31;
    color: #a9a9b2;
    font-size: 10px;
    font-weight: 850;
    letter-spacing: .5px;
    text-align: left;
    text-transform: uppercase;
    white-space: nowrap;
}

.inventory-admin td {
    padding: 13px 15px;
    border-bottom: 1px solid #3d3d44;
    color: #d4d4da;
    font-size: 12px;
    vertical-align: middle;
}

.inventory-admin tbody tr:last-child td {
    border-bottom: 0;
}

.inventory-admin tbody tr:hover {
    background: #2c2c31;
}

.inventory-admin .ia-comic {
    display: flex;
    align-items: center;
    gap: 11px;
    min-width: 190px;
}

.inventory-admin .ia-cover {
    width: 42px;
    height: 56px;
    flex: 0 0 42px;
    object-fit: cover;
    border-radius: 4px;
    background: #36363c;
}

.inventory-admin .ia-cover-empty {
    display: grid;
    width: 42px;
    height: 56px;
    flex: 0 0 42px;
    place-items: center;
    border-radius: 4px;
    background: rgba(255,107,96,.14);
    color: #f2f2f2;
    font-size: 18px;
}

.inventory-admin .ia-comic-name {
    display: block;
    max-width: 230px;
    color: #f2f2f2;
    font-weight: 800;
    line-height: 1.45;
}

.inventory-admin .ia-muted {
    display: block;
    margin-top: 4px;
    color: #a9a9b2;
    font-size: 10px;
}

.inventory-admin .ia-stock-badge {
    display: inline-flex;
    padding: 5px 9px;
    border-radius: 20px;
    background: rgba(80,200,130,.16);
    color: #6fdc9c;
    font-size: 10px;
    font-weight: 850;
    white-space: nowrap;
}

.inventory-admin .ia-stock-badge.low {
    background: rgba(240,180,60,.15);
    color: #f0c36d;
}

.inventory-admin .ia-stock-badge.out {
    background: rgba(255,107,96,.14);
    color: #b52827;
}

.inventory-admin .ia-empty {
    padding: 34px 18px;
    color: #a9a9b2;
    font-size: 12px;
    text-align: center;
}

.inventory-admin .ia-pagination {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
    padding: 14px 17px;
    border-top: 1px solid #3d3d44;
}

.inventory-admin .ia-pages {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
}

.inventory-admin .ia-pages a,
.inventory-admin .ia-pages span {
    display: grid;
    min-width: 32px;
    height: 32px;
    padding: 0 8px;
    place-items: center;
    border: 1px solid #3d3d44;
    border-radius: 6px;
    background: #232327;
    color: #d4d4da;
    font-size: 11px;
    text-decoration: none;
}

.inventory-admin .ia-pages .current {
    border-color: #f2f2f2;
    background: #f2f2f2;
    color: #111111;
}

.inventory-admin .ia-history-total {
    color: #f2f2f2;
    font-weight: 800;
    white-space: nowrap;
}

.inventory-admin .ia-history-note {
    padding: 13px 18px;
    border-top: 1px solid #3d3d44;
    background: #2c2c31;
    color: #a9a9b2;
    font-size: 10px;
    line-height: 1.6;
}

@media(max-width:1100px) {
    .inventory-admin .ia-stats {
        grid-template-columns: repeat(2,minmax(0,1fr));
    }

    .inventory-admin .ia-grid {
        grid-template-columns: 1fr;
    }
}

@media(max-width:650px) {
    .inventory-admin .ia-stats {
        gap: 9px;
    }

    .inventory-admin .ia-stat {
        padding: 13px;
    }

    .inventory-admin .ia-panel-body {
        padding: 15px;
    }

    .inventory-admin .ia-toolbar {
        align-items: stretch;
    }

    .inventory-admin .ia-search {
        width: 100%;
    }

    .inventory-admin .ia-search input {
        min-width: 0;
    }
}
</style>

<div class="inventory-admin">

    <?php if (is_array($flash) && !empty($flash['message'])): ?>
        <div
            class="ia-alert <?= ($flash['type'] ?? '') === 'success' ? 'success' : '' ?>"
            role="status"
        >
            <?= comic_admin_inventory_escape($flash['message']) ?>
        </div>
    <?php endif; ?>

    <?php if (!$dbReady): ?>
        <div class="ia-alert" role="alert">
            Không tìm thấy kết nối cơ sở dữ liệu.
            Hãy kiểm tra config/db.php và bootstrap.php.
        </div>
    <?php endif; ?>

    <?php foreach ($errors as $error): ?>
        <div class="ia-alert" role="alert">
            <?= comic_admin_inventory_escape($error) ?>
        </div>
    <?php endforeach; ?>

    <!-- THỐNG KÊ KHO -->
    <section class="ia-stats" aria-label="Thống kê kho hàng">

        <article class="ia-stat">
            <span class="ia-stat-label">Tổng đầu truyện</span>

            <strong class="ia-stat-value">
                <?= number_format($stats['comics']) ?>
            </strong>

            <span class="ia-stat-note">
                Tất cả sản phẩm trong hệ thống
            </span>
        </article>

        <article class="ia-stat">
            <span class="ia-stat-label">Tổng tồn kho</span>

            <strong
                class="ia-stat-value"
                style="color:#6fdc9c"
            >
                <?= number_format($stats['stock_units']) ?>
            </strong>

            <span class="ia-stat-note">
                Tổng số cuốn hiện có
            </span>
        </article>

        <article class="ia-stat">
            <span class="ia-stat-label">Cần chú ý</span>

            <strong
                class="ia-stat-value"
                style="color:#f2f2f2"
            >
                <?= number_format($stats['low_stock']) ?>
            </strong>

            <span class="ia-stat-note">
                Đầu truyện có tồn kho từ 5 cuốn trở xuống
            </span>
        </article>

        <article class="ia-stat">
            <span class="ia-stat-label">Đã nhập tích lũy</span>

            <strong
                class="ia-stat-value"
                style="color:#9db6ff"
            >
                <?= number_format($stats['imported_units']) ?>
            </strong>

            <span class="ia-stat-note">
                Tổng số lượng ghi nhận trong lịch sử nhập kho
            </span>
        </article>

    </section>

    <!-- FORM NHẬP KHO -->
    <section class="ia-grid">

        <article class="ia-panel">

            <div class="ia-panel-head">
                <div>
                    <h2>Nhập thêm hàng</h2>

                    <div class="ia-panel-subtitle">
                        Tăng tồn kho và lưu lịch sử nhập trong một giao dịch.
                    </div>
                </div>
            </div>

            <div class="ia-panel-body">

                <?php if (!$dbReady): ?>

                    <div class="ia-empty">
                        Cần kết nối cơ sở dữ liệu để nhập kho.
                    </div>

                <?php elseif (!$comicOptions): ?>

                    <div class="ia-empty">
                        Chưa có truyện. Hãy tạo sản phẩm trước khi nhập kho.
                        <br><br>
                        <a class="ia-btn" href="comics.php?action=create">
                            ＋ Thêm truyện
                        </a>
                    </div>

                <?php else: ?>

                    <form
                        method="post"
                        action="inventory.php"
                        data-confirm="Xác nhận nhập số lượng truyện này vào kho?"
                    >

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= comic_admin_inventory_escape(
                                comic_admin_csrf_token()
                            ) ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="import_stock"
                        >

                        <div class="ia-field">
                            <label for="stock-comic">
                                Chọn truyện *
                            </label>

                            <select
                                id="stock-comic"
                                name="comic_id"
                                required
                            >
                                <option value="">
                                    -- Chọn truyện cần nhập --
                                </option>

                                <?php foreach ($comicOptions as $option): ?>
                                    <option value="<?= (int) $option['id'] ?>">
                                        <?= comic_admin_inventory_escape(
                                            $option['title']
                                        ) ?>
                                        · Tồn:
                                        <?= number_format(
                                            (int) $option['stock']
                                        ) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="ia-field">
                            <label for="stock-quantity">
                                Số lượng nhập *
                            </label>

                            <input
                                id="stock-quantity"
                                type="number"
                                name="quantity"
                                min="1"
                                max="1000000"
                                step="1"
                                required
                                placeholder="Ví dụ: 100"
                            >
                        </div>

                        <div class="ia-field">
                            <label for="stock-unit-cost">
                                Giá nhập mỗi cuốn (VNĐ) *
                            </label>

                            <input
                                id="stock-unit-cost"
                                type="number"
                                name="unit_cost"
                                min="0"
                                max="9999999999.99"
                                step="0.01"
                                required
                                placeholder="Ví dụ: 17000"
                            >

                            <div class="ia-help">
                                Giá nhập được lưu vào lịch sử, không làm thay đổi
                                giá bán sản phẩm.
                            </div>
                        </div>

                        <div class="ia-field">
                            <label for="stock-supplier">
                                Nhà cung cấp
                            </label>

                            <input
                                id="stock-supplier"
                                type="text"
                                name="supplier"
                                maxlength="150"
                                placeholder="Ví dụ: NXB Kim Đồng"
                            >
                        </div>

                        <div class="ia-field">
                            <label for="stock-note">Ghi chú</label>

                            <textarea
                                id="stock-note"
                                name="note"
                                rows="3"
                                maxlength="60000"
                                placeholder="Số hóa đơn, đợt nhập, ghi chú..."
                            ></textarea>
                        </div>

                        <button class="ia-btn" type="submit">
                            ＋ Xác nhận nhập kho
                        </button>

                    </form>

                <?php endif; ?>

            </div>
        </article>

        <!-- TÓM TẮT CHI PHÍ -->
        <article class="ia-panel">

            <div class="ia-panel-head">
                <div>
                    <h2>Tổng quan nhập hàng</h2>

                    <div class="ia-panel-subtitle">
                        Tổng hợp theo dữ liệu lịch sử nhập kho
                    </div>
                </div>
            </div>

            <div class="ia-panel-body">

                <div style="padding:14px 0;border-bottom:1px solid #3d3d44">
                    <span style="display:block;color:#a9a9b2;font-size:11px">
                        Tổng giá trị nhập ghi nhận
                    </span>

                    <strong style="display:block;margin-top:7px;color:#f2f2f2;font-size:24px;overflow-wrap:anywhere">
                        <?= comic_admin_inventory_escape(
                            comic_admin_inventory_money($stats['import_cost'])
                        ) ?>
                    </strong>

                    <span class="ia-help">
                        Tổng quantity × unit_cost của các phiếu nhập,
                        không phải số tiền thanh toán thực tế đã đối soát.
                    </span>
                </div>

                <div style="padding:14px 0;border-bottom:1px solid #3d3d44">
                    <span style="display:block;color:#a9a9b2;font-size:11px">
                        Đơn vị hàng đã nhập
                    </span>

                    <strong style="display:block;margin-top:7px;font-size:22px">
                        <?= number_format($stats['imported_units']) ?> cuốn
                    </strong>
                </div>

                <div style="padding:14px 0">
                    <span style="display:block;color:#a9a9b2;font-size:11px">
                        Nguyên tắc cập nhật tồn kho
                    </span>

                    <p style="margin:7px 0 0;font-size:12px;line-height:1.7">
                        Khi xác nhận nhập hàng, hệ thống tăng
                        <code>comics.stock</code> và tạo bản ghi
                        trong <code>stock_imports</code> cùng một giao dịch.
                    </p>
                </div>

            </div>
        </article>

    </section>

    <!-- BỘ LỌC TỒN KHO -->
    <div class="ia-toolbar">

        <form
            class="ia-search"
            method="get"
            action="inventory.php"
        >

            <input
                type="search"
                name="q"
                value="<?= comic_admin_inventory_escape($search) ?>"
                placeholder="Tìm tên truyện, slug hoặc ISBN..."
                aria-label="Tìm sản phẩm trong kho"
            >

            <select name="stock" aria-label="Lọc tồn kho">
                <option
                    value="all"
                    <?= $stockFilter === 'all' ? 'selected' : '' ?>
                >
                    Tất cả mức tồn kho
                </option>

                <option
                    value="low"
                    <?= $stockFilter === 'low' ? 'selected' : '' ?>
                >
                    Sắp hết hàng (1–5)
                </option>

                <option
                    value="out"
                    <?= $stockFilter === 'out' ? 'selected' : '' ?>
                >
                    Hết hàng (0)
                </option>
            </select>

            <button class="ia-btn secondary" type="submit">
                Tìm kiếm
            </button>

            <?php if ($search !== '' || $stockFilter !== 'all'): ?>
                <a class="ia-btn secondary" href="inventory.php">
                    Xóa lọc
                </a>
            <?php endif; ?>

        </form>

        <a class="ia-btn secondary" href="comics.php">
            Quản lý sản phẩm →
        </a>

    </div>

    <!-- DANH SÁCH TỒN KHO -->
    <section class="ia-panel">

        <div class="ia-panel-head">
            <div>
                <h2>Danh sách tồn kho</h2>

                <div class="ia-panel-subtitle">
                    Ưu tiên hiển thị sản phẩm sắp hết hàng.
                </div>
            </div>

            <span class="ia-muted">
                <?= number_format($totalItems) ?> sản phẩm
            </span>
        </div>

        <?php if (!$dbReady): ?>

            <div class="ia-empty">
                Không thể tải dữ liệu tồn kho khi chưa kết nối database.
            </div>

        <?php elseif (!$comicRows): ?>

            <div class="ia-empty">
                Không tìm thấy sản phẩm phù hợp với bộ lọc.
            </div>

        <?php else: ?>

            <div class="ia-table-wrap">

                <table>

                    <thead>
                        <tr>
                            <th>Truyện</th>
                            <th>Thể loại</th>
                            <th>Giá bán</th>
                            <th>Tồn kho</th>
                            <th>Đã bán</th>
                            <th>Trạng thái</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php foreach ($comicRows as $comic): ?>

                            <?php
                            $stock = (int) ($comic['stock'] ?? 0);

                            $cover = comic_admin_media_url(
                                (string) ($comic['cover_image'] ?? ''),
                                (string) ($comic['title'] ?? ''),
                                'cover'
                            );

                            $salePrice =
                                $comic['sale_price'] !== null &&
                                $comic['sale_price'] !== ''
                                    ? (float) $comic['sale_price']
                                    : null;

                            $price = $salePrice ??
                                (float) ($comic['price'] ?? 0);
                            ?>

                            <tr>

                                <td>
                                    <div class="ia-comic">

                                        <?php if ($cover !== ''): ?>

                                            <img
                                                class="ia-cover"
                                                src="<?= comic_admin_inventory_escape($cover) ?>"
                                                alt=""
                                                loading="lazy"
                                                onerror="this.style.display='none';this.nextElementSibling.style.display='grid';"
                                            >

                                            <span
                                                class="ia-cover-empty"
                                                style="display:none"
                                                aria-hidden="true"
                                            >▣</span>

                                        <?php else: ?>

                                            <span
                                                class="ia-cover-empty"
                                                aria-hidden="true"
                                            >▣</span>

                                        <?php endif; ?>

                                        <span>
                                            <span class="ia-comic-name">
                                                <?= comic_admin_inventory_escape(
                                                    $comic['title']
                                                ) ?>
                                            </span>

                                            <span class="ia-muted">
                                                Mã truyện #<?= (int) $comic['id'] ?>
                                            </span>
                                        </span>

                                    </div>
                                </td>

                                <td>
                                    <?= comic_admin_inventory_escape(
                                        $comic['category_name'] ??
                                        'Chưa phân loại'
                                    ) ?>
                                </td>

                                <td style="white-space:nowrap">
                                    <strong>
                                        <?= comic_admin_inventory_escape(
                                            comic_admin_inventory_money($price)
                                        ) ?>
                                    </strong>

                                    <?php if ($salePrice !== null): ?>
                                        <span
                                            class="ia-muted"
                                            style="text-decoration:line-through"
                                        >
                                            <?= comic_admin_inventory_escape(
                                                comic_admin_inventory_money(
                                                    $comic['price']
                                                )
                                            ) ?>
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php if ($stock <= 0): ?>
                                        <span class="ia-stock-badge out">
                                            Hết hàng
                                        </span>
                                    <?php elseif ($stock <= 5): ?>
                                        <span class="ia-stock-badge low">
                                            <?= number_format($stock) ?> cuốn
                                        </span>
                                    <?php else: ?>
                                        <span class="ia-stock-badge">
                                            <?= number_format($stock) ?> cuốn
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?= number_format(
                                        (int) ($comic['sold_count'] ?? 0)
                                    ) ?>
                                </td>

                                <td>
                                    <?php if ((int) $comic['is_active'] === 1): ?>
                                        <span class="ia-stock-badge">
                                            Đang bán
                                        </span>
                                    <?php else: ?>
                                        <span
                                            class="ia-stock-badge"
                                            style="background:#36363c;color:#b5b5bd"
                                        >
                                            Đang ẩn
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <a
                                        class="ia-btn secondary"
                                        href="comics.php?action=edit&amp;id=<?= (int) $comic['id'] ?>"
                                    >
                                        Sửa truyện
                                    </a>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

            <div class="ia-pagination">

                <span class="ia-muted">
                    Hiển thị
                    <?= number_format(
                        min(
                            $totalItems,
                            $offset + ($totalItems > 0 ? 1 : 0)
                        )
                    ) ?>–<?= number_format(
                        min(
                            $totalItems,
                            $offset + count($comicRows)
                        )
                    ) ?>
                    trong <?= number_format($totalItems) ?> sản phẩm
                </span>

                <?php if ($totalPages > 1): ?>

                    <nav class="ia-pages" aria-label="Phân trang">

                        <?php
                        $queryBase = [];

                        if ($search !== '') {
                            $queryBase['q'] = $search;
                        }

                        if ($stockFilter !== 'all') {
                            $queryBase['stock'] = $stockFilter;
                        }

                        if ($page > 1) {
                            $prevUrl = 'inventory.php?' .
                                http_build_query(
                                    array_merge(
                                        $queryBase,
                                        ['page' => $page - 1]
                                    )
                                );

                            echo '<a href="' .
                                comic_admin_inventory_escape($prevUrl) .
                                '" aria-label="Trang trước">‹</a>';
                        }

                        $startPage = max(1, $page - 2);
                        $endPage = min($totalPages, $page + 2);

                        for (
                            $i = $startPage;
                            $i <= $endPage;
                            $i++
                        ) {
                            $pageUrl = 'inventory.php?' .
                                http_build_query(
                                    array_merge(
                                        $queryBase,
                                        ['page' => $i]
                                    )
                                );

                            if ($i === $page) {
                                echo '<span class="current" aria-current="page">' .
                                    $i . '</span>';
                            } else {
                                echo '<a href="' .
                                    comic_admin_inventory_escape($pageUrl) .
                                    '">' . $i . '</a>';
                            }
                        }

                        if ($page < $totalPages) {
                            $nextUrl = 'inventory.php?' .
                                http_build_query(
                                    array_merge(
                                        $queryBase,
                                        ['page' => $page + 1]
                                    )
                                );

                            echo '<a href="' .
                                comic_admin_inventory_escape($nextUrl) .
                                '" aria-label="Trang sau">›</a>';
                        }
                        ?>

                    </nav>

                <?php endif; ?>

            </div>

        <?php endif; ?>

    </section>

    <!-- LỊCH SỬ NHẬP KHO -->
    <section class="ia-panel">

        <div class="ia-panel-head">
            <div>
                <h2>Lịch sử nhập kho gần đây</h2>

                <div class="ia-panel-subtitle">
                    8 phiếu nhập được ghi nhận gần nhất.
                </div>
            </div>
        </div>

        <?php if (!$dbReady || !$historyRows): ?>

            <div class="ia-empty">
                Chưa có lịch sử nhập kho để hiển thị.
            </div>

        <?php else: ?>

            <div class="ia-table-wrap">

                <table>
                    <thead>
                        <tr>
                            <th>Thời gian</th>
                            <th>Tên truyện</th>
                            <th>Số lượng</th>
                            <th>Giá nhập/cuốn</th>
                            <th>Thành tiền tham khảo</th>
                            <th>Nhà cung cấp</th>
                            <th>Người nhập</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php foreach ($historyRows as $history): ?>

                            <?php
                            $quantity = (int) ($history['quantity'] ?? 0);
                            $unitCost = (float) ($history['unit_cost'] ?? 0);

                            $createdTimestamp = !empty($history['created_at'])
                                ? strtotime((string) $history['created_at'])
                                : false;
                            ?>

                            <tr>

                                <td style="white-space:nowrap">
                                    <?= $createdTimestamp
                                        ? comic_admin_inventory_escape(
                                            date(
                                                'd/m/Y H:i',
                                                $createdTimestamp
                                            )
                                        )
                                        : '—' ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= comic_admin_inventory_escape(
                                            $history['comic_title']
                                        ) ?>
                                    </strong>

                                    <?php if (!empty($history['note'])): ?>
                                        <span class="ia-muted">
                                            <?= comic_admin_inventory_escape(
                                                $history['note']
                                            ) ?>
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <strong style="color:#6fdc9c">
                                        +<?= number_format($quantity) ?>
                                    </strong>
                                </td>

                                <td style="white-space:nowrap">
                                    <?= comic_admin_inventory_escape(
                                        comic_admin_inventory_money($unitCost)
                                    ) ?>
                                </td>

                                <td class="ia-history-total">
                                    <?= comic_admin_inventory_escape(
                                        comic_admin_inventory_money(
                                            $quantity * $unitCost
                                        )
                                    ) ?>
                                </td>

                                <td>
                                    <?= comic_admin_inventory_escape(
                                        $history['supplier'] ?: '—'
                                    ) ?>
                                </td>

                                <td>
                                    <?= comic_admin_inventory_escape(
                                        $history['admin_name'] ?: '—'
                                    ) ?>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    </tbody>
                </table>

            </div>

            <div class="ia-history-note">
                Lịch sử nhập kho là bản ghi tích lũy. Việc nhập hàng
                mới tăng tồn kho hiện tại và không xóa lịch sử cũ.
            </div>

        <?php endif; ?>

    </section>

</div>

<script>
(function () {
    'use strict';

    var form = document.querySelector(
        '.inventory-admin form[data-confirm]'
    );

    var comicSelect = document.getElementById('stock-comic');
    var quantityInput = document.getElementById('stock-quantity');
    var unitCostInput = document.getElementById('stock-unit-cost');

    /*
     * Hiển thị cảnh báo tổng giá trị lô nhập để giảm nhầm lẫn.
     * Đây chỉ là thông tin hỗ trợ trên giao diện; máy chủ vẫn
     * tự xác thực mọi dữ liệu trước khi ghi vào database.
     */
    if (!form || !quantityInput || !unitCostInput) {
        return;
    }

    var estimate = document.createElement('p');
    estimate.className = 'ia-help';
    estimate.setAttribute('aria-live', 'polite');

    unitCostInput.parentNode.appendChild(estimate);

    function updateEstimate() {
        var quantity = Number(quantityInput.value);
        var unitCost = Number(unitCostInput.value);

        if (
            !Number.isSafeInteger(quantity) ||
            quantity < 1 ||
            !Number.isFinite(unitCost) ||
            unitCost < 0
        ) {
            estimate.textContent = '';
            return;
        }

        var total = quantity * unitCost;

        estimate.textContent =
            'Giá trị lô nhập tham khảo: ' +
            new Intl.NumberFormat('vi-VN', {
                style: 'currency',
                currency: 'VND',
                maximumFractionDigits: 0
            }).format(total);
    }

    quantityInput.addEventListener('input', updateEstimate);
    unitCostInput.addEventListener('input', updateEstimate);

    form.addEventListener('submit', function (event) {
        var quantity = Number(quantityInput.value);

        if (
            !comicSelect ||
            comicSelect.value === '' ||
            !Number.isSafeInteger(quantity) ||
            quantity < 1 ||
            unitCostInput.value === ''
        ) {
            event.preventDefault();
            window.alert('Vui lòng kiểm tra truyện, số lượng và giá nhập.');
            return;
        }

        var message = form.getAttribute('data-confirm') ||
            'Bạn có chắc chắn muốn nhập kho?';

        if (!window.confirm(message)) {
            event.preventDefault();
        }
    });
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
