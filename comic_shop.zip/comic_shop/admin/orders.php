<?php
declare(strict_types=1);

/**
 * Comic Shop - Admin Orders
 *
 * File: admin/orders.php
 *
 * Bảng sử dụng:
 * - orders
 * - order_items
 * - comics
 *
 * Hỗ trợ PDO và MySQLi.
 */

$pageTitle = 'Quản lý đơn hàng';
$pageDescription = 'Theo dõi đơn hàng, thanh toán và giao hàng.';
$activeMenu = 'orders';

require_once __DIR__ . '/includes/bootstrap.php';

if (!function_exists('comic_admin_media_url')) {
    require_once __DIR__ . '/includes/media.php';
}

$database = $GLOBALS['comic_shop_db'] ?? null;

$dbReady = $database instanceof PDO ||
    (class_exists('mysqli') && $database instanceof mysqli);

/* =========================================================
   1. DATABASE HELPER
========================================================= */

if (!function_exists('comic_admin_orders_query')) {
    function comic_admin_orders_query(
        $database,
        string $sql,
        array $params = []
    ): array {
        if ($database instanceof PDO) {
            $stmt = $database->prepare($sql);
            $stmt->execute($params);

            $rows = $stmt->columnCount() > 0
                ? $stmt->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $affected = $stmt->rowCount();
            $stmt->closeCursor();

            return [
                'rows' => $rows,
                'affected' => $affected,
            ];
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            $stmt = $database->prepare($sql);

            if (!$stmt) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn MySQL.'
                );
            }

            if ($params !== []) {
                $types = '';
                $bindValues = [];

                foreach ($params as $index => $value) {
                    if (is_int($value) || is_bool($value)) {
                        $types .= 'i';
                    } elseif (is_float($value)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }

                    $bindValues[$index] = $params[$index];
                }

                $arguments = [$types];

                foreach ($bindValues as &$value) {
                    $arguments[] = &$value;
                }

                unset($value);

                if (!call_user_func_array(
                    [$stmt, 'bind_param'],
                    $arguments
                )) {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không thể gắn tham số vào truy vấn.'
                    );
                }
            }

            if (!$stmt->execute()) {
                $error = $stmt->error;
                $stmt->close();

                throw new RuntimeException(
                    $error ?: 'Truy vấn MySQL thất bại.'
                );
            }

            $rows = [];

            if ($stmt->field_count > 0) {
                $result = $stmt->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không đọc được kết quả truy vấn.'
                    );
                }
            }

            $affected = $stmt->affected_rows;
            $stmt->close();

            return [
                'rows' => $rows,
                'affected' => $affected,
            ];
        }

        throw new RuntimeException(
            'Chưa có kết nối PDO hoặc MySQLi hợp lệ.'
        );
    }
}

/* =========================================================
   2. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_admin_orders_escape')) {
    function comic_admin_orders_escape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_admin_orders_money')) {
    function comic_admin_orders_money($amount): string
    {
        return number_format(
            (float) $amount,
            0,
            ',',
            '.'
        ) . ' ₫';
    }
}

if (!function_exists('comic_admin_orders_redirect')) {
    function comic_admin_orders_redirect(
        string $url = 'orders.php'
    ): void {
        header('Location: ' . $url, true, 303);
        exit;
    }
}

if (!function_exists('comic_admin_orders_flash')) {
    function comic_admin_orders_flash(
        string $type,
        string $message
    ): void {
        $_SESSION['comic_orders_flash'] = [
            'type' => $type,
            'message' => $message,
        ];
    }
}

if (!function_exists('comic_admin_orders_status_info')) {
    function comic_admin_orders_status_info(string $status): array
    {
        $statuses = [
            'pending' => [
                'label' => 'Chờ xác nhận',
                'class' => 'warning',
            ],
            'processing' => [
                'label' => 'Đang xử lý',
                'class' => 'info',
            ],
            'shipping' => [
                'label' => 'Đang giao hàng',
                'class' => 'info',
            ],
            'completed' => [
                'label' => 'Hoàn thành',
                'class' => 'success',
            ],
            'cancelled' => [
                'label' => 'Đã hủy',
                'class' => 'danger',
            ],
        ];

        return $statuses[$status] ?? [
            'label' => 'Không xác định',
            'class' => 'secondary',
        ];
    }
}

if (!function_exists('comic_admin_orders_payment_info')) {
    function comic_admin_orders_payment_info(string $status): array
    {
        $statuses = [
            'pending' => [
                'label' => 'Chưa thanh toán',
                'class' => 'warning',
            ],
            'completed' => [
                'label' => 'Đã thanh toán',
                'class' => 'success',
            ],
            'failed' => [
                'label' => 'Thanh toán thất bại',
                'class' => 'danger',
            ],
        ];

        return $statuses[$status] ?? [
            'label' => 'Không xác định',
            'class' => 'secondary',
        ];
    }
}

/* =========================================================
   3. TRẠNG THÁI HỢP LỆ THEO ENUM SQL
========================================================= */

$orderStatuses = [
    'pending',
    'processing',
    'shipping',
    'completed',
    'cancelled',
];

$paymentStatuses = [
    'pending',
    'completed',
    'failed',
];

/* =========================================================
   4. KHỞI TẠO
========================================================= */

$flash = $_SESSION['comic_orders_flash'] ?? null;
unset($_SESSION['comic_orders_flash']);

$errors = [];

$action = isset($_GET['action']) && is_string($_GET['action'])
    ? $_GET['action']
    : 'list';

$orderId = max(0, (int) ($_GET['id'] ?? 0));

if (!in_array($action, ['list', 'view'], true)) {
    $action = 'list';
}

/* =========================================================
   5. XỬ LÝ CẬP NHẬT ĐƠN HÀNG
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $token = isset($_POST['csrf_token']) &&
        is_string($_POST['csrf_token'])
            ? $_POST['csrf_token']
            : '';

    if (
        !function_exists('comic_admin_csrf_valid') ||
        !comic_admin_csrf_valid($token)
    ) {
        comic_admin_orders_flash(
            'error',
            'Phiên làm việc đã hết hạn. Vui lòng thử lại.'
        );

        comic_admin_orders_redirect();
    }

    $postAction = isset($_POST['action']) &&
        is_string($_POST['action'])
            ? $_POST['action']
            : '';

    if ($postAction !== 'update_status') {
        comic_admin_orders_flash(
            'error',
            'Thao tác không hợp lệ.'
        );

        comic_admin_orders_redirect();
    }

    if (!$dbReady) {
        comic_admin_orders_flash(
            'error',
            'Chưa kết nối được cơ sở dữ liệu. Kiểm tra config/db.php.'
        );

        comic_admin_orders_redirect();
    }

    $orderId = (int) ($_POST['order_id'] ?? 0);

    $newStatus = isset($_POST['status']) &&
        is_string($_POST['status'])
            ? $_POST['status']
            : '';

    $newPaymentStatus = isset($_POST['payment_status']) &&
        is_string($_POST['payment_status'])
            ? $_POST['payment_status']
            : '';

    if (
        $orderId < 1 ||
        !in_array($newStatus, $orderStatuses, true) ||
        !in_array($newPaymentStatus, $paymentStatuses, true)
    ) {
        comic_admin_orders_flash(
            'error',
            'Trạng thái hoặc mã đơn hàng không hợp lệ.'
        );

        comic_admin_orders_redirect();
    }

    $inTransaction = false;

    try {
        /*
         * Đọc và cập nhật trong transaction để tránh ghi đè
         * khi nhiều người cùng thao tác trên một đơn.
         */
        if ($database instanceof PDO) {
            $database->beginTransaction();
        } else {
            $database->begin_transaction();
        }

        $inTransaction = true;

        $existingRows = comic_admin_orders_query(
            $database,
            'SELECT id, order_code, status, payment_status
             FROM orders
             WHERE id = ?
             FOR UPDATE',
            [$orderId]
        )['rows'];

        if (!$existingRows) {
            throw new RuntimeException(
                'Không tìm thấy đơn hàng cần cập nhật.'
            );
        }

        $existingOrder = $existingRows[0];

        $oldStatus = (string) $existingOrder['status'];

        /*
         * Đơn đã hủy không được tự động mở lại ở màn hình này.
         * Việc mở lại đơn cần quy trình riêng để đối soát kho.
         */
        if (
            $oldStatus === 'cancelled' &&
            $newStatus !== 'cancelled'
        ) {
            throw new RuntimeException(
                'Đơn đã hủy không thể mở lại trực tiếp. '
                . 'Hãy kiểm tra tồn kho và tạo quy trình khôi phục riêng.'
            );
        }

        /*
         * Cập nhật tình trạng đơn và thanh toán.
         * Không tự cộng/trừ stock ở đây.
         */
        comic_admin_orders_query(
            $database,
            'UPDATE orders
             SET status = ?, payment_status = ?
             WHERE id = ?',
            [
                $newStatus,
                $newPaymentStatus,
                $orderId,
            ]
        );

        if ($database instanceof PDO) {
            $database->commit();
        } else {
            $database->commit();
        }

        $inTransaction = false;

        $_SESSION['comic_admin_csrf'] =
            bin2hex(random_bytes(32));

        comic_admin_orders_flash(
            'success',
            'Đã cập nhật đơn ' .
            (string) $existingOrder['order_code'] .
            ' thành công.'
        );

        comic_admin_orders_redirect(
            'orders.php?action=view&id=' . $orderId
        );

    } catch (Throwable $exception) {
        if ($inTransaction) {
            try {
                if ($database instanceof PDO) {
                    if ($database->inTransaction()) {
                        $database->rollBack();
                    }
                } else {
                    $database->rollback();
                }
            } catch (Throwable $rollbackException) {
                error_log(
                    '[Comic Shop Orders] Rollback thất bại.'
                );
            }
        }

        error_log(
            '[Comic Shop Orders] ' .
            $exception->getMessage()
        );

        comic_admin_orders_flash(
            'error',
            $exception instanceof RuntimeException
                ? $exception->getMessage()
                : 'Không thể cập nhật đơn hàng. Hãy kiểm tra nhật ký lỗi.'
        );

        if ($orderId > 0) {
            comic_admin_orders_redirect(
                'orders.php?action=view&id=' . $orderId
            );
        }

        comic_admin_orders_redirect();
    }
}

/* =========================================================
   6. THỐNG KÊ ĐƠN HÀNG
========================================================= */

$stats = [
    'total' => 0,
    'pending' => 0,
    'shipping' => 0,
    'completed' => 0,
    'revenue' => 0.0,
];

if ($dbReady) {
    try {
        $statsRows = comic_admin_orders_query(
            $database,
            "SELECT
                COUNT(*) AS total_orders,
                COALESCE(
                    SUM(status = 'pending'),
                    0
                ) AS pending_orders,
                COALESCE(
                    SUM(status = 'shipping'),
                    0
                ) AS shipping_orders,
                COALESCE(
                    SUM(status = 'completed'),
                    0
                ) AS completed_orders,
                COALESCE(
                    SUM(
                        CASE
                            WHEN payment_status = 'completed'
                             AND status <> 'cancelled'
                            THEN total_amount
                            ELSE 0
                        END
                    ),
                    0
                ) AS paid_revenue
             FROM orders"
        )['rows'];

        if ($statsRows) {
            $stats = [
                'total' => (int) $statsRows[0]['total_orders'],
                'pending' => (int) $statsRows[0]['pending_orders'],
                'shipping' => (int) $statsRows[0]['shipping_orders'],
                'completed' => (int) $statsRows[0]['completed_orders'],
                'revenue' => (float) $statsRows[0]['paid_revenue'],
            ];
        }
    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Orders Stats] ' .
            $exception->getMessage()
        );

        $errors[] = 'Không tải được số liệu thống kê đơn hàng.';
    }
}

/* =========================================================
   7. CHI TIẾT ĐƠN HÀNG
========================================================= */

$order = null;
$orderItems = [];

if ($dbReady && $action === 'view') {
    if ($orderId < 1) {
        $errors[] = 'Mã đơn hàng không hợp lệ.';
    } else {
        try {
            $orderRows = comic_admin_orders_query(
                $database,
                'SELECT
                    id,
                    order_code,
                    user_id,
                    full_name,
                    email,
                    phone,
                    address,
                    note,
                    total_amount,
                    payment_method,
                    payment_status,
                    status,
                    created_at,
                    updated_at
                 FROM orders
                 WHERE id = ?
                 LIMIT 1',
                [$orderId]
            )['rows'];

            $order = $orderRows[0] ?? null;

            if ($order) {
                $orderItems = comic_admin_orders_query(
                    $database,
                    'SELECT
                        oi.id,
                        oi.comic_id,
                        oi.comic_title,
                        oi.price,
                        oi.quantity,
                        oi.total,
                        c.cover_image
                     FROM order_items oi
                     LEFT JOIN comics c
                        ON c.id = oi.comic_id
                     WHERE oi.order_id = ?
                     ORDER BY oi.id ASC',
                    [$orderId]
                )['rows'];
            } else {
                $errors[] = 'Không tìm thấy đơn hàng.';
            }

        } catch (Throwable $exception) {
            error_log(
                '[Comic Shop Order Detail] ' .
                $exception->getMessage()
            );

            $errors[] = 'Không tải được chi tiết đơn hàng.';
        }
    }
}

/* =========================================================
   8. TÌM KIẾM / LỌC / PHÂN TRANG
========================================================= */

$search = isset($_GET['q']) && is_string($_GET['q'])
    ? trim($_GET['q'])
    : '';

$statusFilter = isset($_GET['status']) &&
    is_string($_GET['status'])
        ? $_GET['status']
        : 'all';

$paymentFilter = isset($_GET['payment']) &&
    is_string($_GET['payment'])
        ? $_GET['payment']
        : 'all';

if (
    $statusFilter !== 'all' &&
    !in_array($statusFilter, $orderStatuses, true)
) {
    $statusFilter = 'all';
}

if (
    $paymentFilter !== 'all' &&
    !in_array($paymentFilter, $paymentStatuses, true)
) {
    $paymentFilter = 'all';
}

$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;

$totalOrders = 0;
$totalPages = 1;
$orderRows = [];
$offset = 0;

if ($dbReady && $action === 'list') {
    try {
        $where = [];
        $params = [];

        if ($search !== '') {
            $where[] = '(
                order_code LIKE ?
                OR full_name LIKE ?
                OR email LIKE ?
                OR phone LIKE ?
            )';

            $like = '%' . $search . '%';

            array_push(
                $params,
                $like,
                $like,
                $like,
                $like
            );
        }

        if ($statusFilter !== 'all') {
            $where[] = 'status = ?';
            $params[] = $statusFilter;
        }

        if ($paymentFilter !== 'all') {
            $where[] = 'payment_status = ?';
            $params[] = $paymentFilter;
        }

        $whereSql = $where
            ? ' WHERE ' . implode(' AND ', $where)
            : '';

        $countRows = comic_admin_orders_query(
            $database,
            'SELECT COUNT(*) AS total
             FROM orders' . $whereSql,
            $params
        )['rows'];

        $totalOrders = (int) ($countRows[0]['total'] ?? 0);

        $totalPages = max(
            1,
            (int) ceil($totalOrders / $perPage)
        );

        $page = min($page, $totalPages);
        $offset = ($page - 1) * $perPage;

        $listParams = $params;
        $listParams[] = $perPage;
        $listParams[] = $offset;

        $orderRows = comic_admin_orders_query(
            $database,
            'SELECT
                id,
                order_code,
                full_name,
                email,
                phone,
                total_amount,
                payment_method,
                payment_status,
                status,
                created_at
             FROM orders' . $whereSql . '
             ORDER BY created_at DESC, id DESC
             LIMIT ? OFFSET ?',
            $listParams
        )['rows'];

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Orders List] ' .
            $exception->getMessage()
        );

        $errors[] = 'Không tải được danh sách đơn hàng.';
    }
}

if ($action === 'view') {
    $pageTitle = 'Chi tiết đơn hàng';
    $pageDescription = $order
        ? 'Đơn hàng ' . (string) $order['order_code']
        : 'Xem thông tin đơn hàng.';
}

require_once __DIR__ . '/includes/header.php';
?>

<style>
.orders-admin {
    color: #f2f2f2;
}

.orders-admin .oa-alert {
    margin-bottom: 17px;
    padding: 12px 15px;
    border: 1px solid rgba(255,107,96,.4);
    border-left: 4px solid #ff6b60;
    background: rgba(255,107,96,.14);
    color: #ff8f86;
    font-size: 12px;
    line-height: 1.65;
}

.orders-admin .oa-alert.success {
    border-color: rgba(80,200,130,.4);
    border-left-color: #50c882;
    background: rgba(80,200,130,.16);
    color: #6fdc9c;
}

.orders-admin .oa-stats {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 13px;
    margin-bottom: 21px;
}

.orders-admin .oa-stat {
    min-width: 0;
    padding: 17px;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.2);
}

.orders-admin .oa-stat-label {
    color: #a9a9b2;
    font-size: 11px;
    font-weight: 700;
}

.orders-admin .oa-stat-value {
    display: block;
    margin-top: 7px;
    font-size: clamp(20px,2vw,26px);
    font-weight: 850;
    overflow-wrap: anywhere;
}

.orders-admin .oa-stat-note {
    margin-top: 5px;
    color: #a9a9b2;
    font-size: 10px;
}

.orders-admin .oa-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
    margin-bottom: 17px;
}

.orders-admin .oa-search {
    display: flex;
    align-items: center;
    flex: 1;
    flex-wrap: wrap;
    gap: 8px;
}

.orders-admin .oa-search input,
.orders-admin .oa-search select {
    min-height: 39px;
    padding: 9px 12px;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    background: #232327;
    color: #f2f2f2;
    font: inherit;
    font-size: 12px;
}

.orders-admin .oa-search input {
    min-width: 190px;
    flex: 1;
}

.orders-admin .oa-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    min-height: 36px;
    padding: 8px 12px;
    border: 1px solid transparent;
    border-radius: 999px;
    background: #f2f2f2;
    color: #111111;
    font-size: 12px;
    font-weight: 800;
    text-decoration: none;
    cursor: pointer;
}

.orders-admin .oa-btn:hover {
    background: #ffffff;
    color: #111111;
}

.orders-admin .oa-btn.secondary {
    border-color: #3d3d44;
    background: #232327;
    color: #d4d4da;
}

.orders-admin .oa-btn.secondary:hover {
    border-color: #f2f2f2;
    color: #f2f2f2;
}

.orders-admin .oa-panel {
    min-width: 0;
    margin-bottom: 21px;
    overflow: hidden;
    border: 1px solid #3d3d44;
    border-radius: 20px;
    background: #232327;
    box-shadow: 0 4px 18px rgba(0,0,0,0.2);
}

.orders-admin .oa-panel-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 10px;
    padding: 17px 20px;
    border-bottom: 1px solid #3d3d44;
}

.orders-admin .oa-panel-head h2 {
    margin: 0;
    font-size: 14px;
    font-weight: 850;
}

.orders-admin .oa-muted {
    color: #a9a9b2;
    font-size: 11px;
}

.orders-admin .oa-table-wrap {
    width: 100%;
    overflow-x: auto;
}

.orders-admin table {
    width: 100%;
    border-collapse: collapse;
}

.orders-admin th {
    padding: 13px 14px;
    border-bottom: 1px solid #3d3d44;
    background: #2c2c31;
    color: #a9a9b2;
    font-size: 10px;
    font-weight: 850;
    letter-spacing: .5px;
    text-align: left;
    text-transform: uppercase;
    white-space: nowrap;
}

.orders-admin td {
    padding: 13px 14px;
    border-bottom: 1px solid #3d3d44;
    color: #d4d4da;
    font-size: 12px;
    vertical-align: middle;
}

.orders-admin tbody tr:last-child td {
    border-bottom: 0;
}

.orders-admin tbody tr:hover {
    background: #2c2c31;
}

.orders-admin .oa-code {
    display: block;
    color: #f2f2f2;
    font-weight: 850;
    white-space: nowrap;
}

.orders-admin .oa-customer {
    display: block;
    margin-top: 4px;
    color: #a9a9b2;
    font-size: 10px;
}

.orders-admin .oa-money {
    color: #f2f2f2;
    font-weight: 850;
    white-space: nowrap;
}

.orders-admin .oa-badge {
    display: inline-flex;
    padding: 5px 9px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: 800;
    line-height: 1.4;
    white-space: nowrap;
}

.orders-admin .oa-badge.warning {
    background: rgba(240,180,60,.15);
    color: #f0c36d;
}

.orders-admin .oa-badge.info {
    background: #eaf5ff;
    color: #17669a;
}

.orders-admin .oa-badge.success {
    background: rgba(80,200,130,.16);
    color: #6fdc9c;
}

.orders-admin .oa-badge.danger {
    background: rgba(255,107,96,.14);
    color: #b52827;
}

.orders-admin .oa-badge.secondary {
    background: #36363c;
    color: #b5b5bd;
}

.orders-admin .oa-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
}

.orders-admin .oa-empty {
    padding: 38px 18px;
    color: #a9a9b2;
    font-size: 12px;
    text-align: center;
}

.orders-admin .oa-pagination {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px;
    padding: 14px 17px;
    border-top: 1px solid #3d3d44;
}

.orders-admin .oa-pages {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
}

.orders-admin .oa-pages a,
.orders-admin .oa-pages span {
    display: grid;
    min-width: 32px;
    height: 32px;
    padding: 0 8px;
    place-items: center;
    border: 1px solid #3d3d44;
    border-radius: 6px;
    background: #232327;
    color: #d4d4da;
    font-size: 11px;
    text-decoration: none;
}

.orders-admin .oa-pages .current {
    border-color: #f2f2f2;
    background: #f2f2f2;
    color: #111111;
}

.orders-admin .oa-detail-grid {
    display: grid;
    grid-template-columns: minmax(0,1.2fr) minmax(280px,.8fr);
    gap: 20px;
    align-items: start;
}

.orders-admin .oa-detail-block {
    padding: 20px;
}

.orders-admin .oa-detail-row {
    display: grid;
    grid-template-columns: 125px minmax(0,1fr);
    gap: 12px;
    padding: 11px 0;
    border-bottom: 1px solid #3d3d44;
    font-size: 12px;
}

.orders-admin .oa-detail-row:last-child {
    border-bottom: 0;
}

.orders-admin .oa-detail-label {
    color: #a9a9b2;
}

.orders-admin .oa-detail-value {
    min-width: 0;
    color: #f2f2f2;
    font-weight: 650;
    overflow-wrap: anywhere;
}

.orders-admin .oa-detail-form {
    padding: 20px;
}

.orders-admin .oa-field {
    margin-bottom: 16px;
}

.orders-admin .oa-field label {
    display: block;
    margin-bottom: 7px;
    color: #363d48;
    font-size: 11px;
    font-weight: 800;
}

.orders-admin .oa-field select {
    display: block;
    width: 100%;
    min-height: 41px;
    padding: 9px 12px;
    border: 1px solid #3d3d44;
    border-radius: 12px;
    background: #232327;
    color: #f2f2f2;
    font: inherit;
    font-size: 12px;
}

.orders-admin .oa-item {
    display: flex;
    align-items: center;
    gap: 11px;
    min-width: 190px;
}

.orders-admin .oa-cover {
    width: 42px;
    height: 56px;
    flex: 0 0 42px;
    object-fit: cover;
    border-radius: 4px;
    background: #36363c;
}

.orders-admin .oa-cover-placeholder {
    display: grid;
    width: 42px;
    height: 56px;
    flex: 0 0 42px;
    place-items: center;
    border-radius: 4px;
    background: rgba(255,107,96,.14);
    color: #f2f2f2;
    font-size: 18px;
}

.orders-admin .oa-total-box {
    padding: 18px 20px;
    border-top: 1px solid #3d3d44;
    background: #2c2c31;
}

.orders-admin .oa-total-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    padding: 6px 0;
    font-size: 12px;
}

.orders-admin .oa-total-row.grand {
    margin-top: 7px;
    padding-top: 13px;
    border-top: 1px solid #e1e4e9;
    font-size: 15px;
    font-weight: 850;
}

@media(max-width:1100px) {
    .orders-admin .oa-stats {
        grid-template-columns: repeat(2,minmax(0,1fr));
    }

    .orders-admin .oa-detail-grid {
        grid-template-columns: 1fr;
    }
}

@media(max-width:650px) {
    .orders-admin .oa-stats {
        gap: 9px;
    }

    .orders-admin .oa-stat {
        padding: 13px;
    }

    .orders-admin .oa-toolbar {
        align-items: stretch;
    }

    .orders-admin .oa-search {
        width: 100%;
    }

    .orders-admin .oa-search input {
        min-width: 0;
    }

    .orders-admin .oa-detail-block,
    .orders-admin .oa-detail-form {
        padding: 15px;
    }

    .orders-admin .oa-detail-row {
        grid-template-columns: 105px minmax(0,1fr);
    }
}
</style>

<div class="orders-admin">

    <?php if (is_array($flash) && !empty($flash['message'])): ?>
        <div
            class="oa-alert <?= ($flash['type'] ?? '') === 'success' ? 'success' : '' ?>"
            role="status"
        >
            <?= comic_admin_orders_escape($flash['message']) ?>
        </div>
    <?php endif; ?>

    <?php if (!$dbReady): ?>
        <div class="oa-alert" role="alert">
            Không tìm thấy kết nối cơ sở dữ liệu.
            Hãy kiểm tra config/db.php và bootstrap.php.
        </div>
    <?php endif; ?>

    <?php foreach ($errors as $error): ?>
        <div class="oa-alert" role="alert">
            <?= comic_admin_orders_escape($error) ?>
        </div>
    <?php endforeach; ?>

    <?php if ($action === 'view'): ?>

        <?php if (!$dbReady || !$order): ?>

            <section class="oa-panel">
                <div class="oa-empty">
                    Không thể hiển thị chi tiết đơn hàng.

                    <p>
                        <a class="oa-btn secondary" href="orders.php">
                            ← Quay lại danh sách
                        </a>
                    </p>
                </div>
            </section>

        <?php else: ?>

            <?php
            $statusInfo = comic_admin_orders_status_info(
                (string) $order['status']
            );

            $paymentInfo = comic_admin_orders_payment_info(
                (string) $order['payment_status']
            );

            $paymentMethods = [
                'cod' => 'Thanh toán khi nhận hàng (COD)',
                'banking' => 'Chuyển khoản ngân hàng',
            ];

            $orderTimestamp = !empty($order['created_at'])
                ? strtotime((string) $order['created_at'])
                : false;

            $updatedTimestamp = !empty($order['updated_at'])
                ? strtotime((string) $order['updated_at'])
                : false;
            ?>

            <div class="oa-toolbar">
                <div>
                    <h2 style="margin:0;font-size:20px;font-weight:850">
                        <?= comic_admin_orders_escape($order['order_code']) ?>
                    </h2>

                    <p class="oa-muted" style="margin:5px 0 0">
                        Tạo lúc
                        <?= $orderTimestamp
                            ? comic_admin_orders_escape(
                                date('d/m/Y H:i', $orderTimestamp)
                            )
                            : '—' ?>
                    </p>
                </div>

                <a class="oa-btn secondary" href="orders.php">
                    ← Quay lại danh sách
                </a>
            </div>

            <section class="oa-detail-grid">

                <!-- THÔNG TIN KHÁCH HÀNG -->
                <div>

                    <article class="oa-panel">
                        <div class="oa-panel-head">
                            <h2>Thông tin nhận hàng</h2>
                        </div>

                        <div class="oa-detail-block">

                            <div class="oa-detail-row">
                                <div class="oa-detail-label">Khách hàng</div>

                                <div class="oa-detail-value">
                                    <?= comic_admin_orders_escape(
                                        $order['full_name']
                                    ) ?>
                                </div>
                            </div>

                            <div class="oa-detail-row">
                                <div class="oa-detail-label">Email</div>

                                <div class="oa-detail-value">
                                    <a href="mailto:<?= comic_admin_orders_escape($order['email']) ?>">
                                        <?= comic_admin_orders_escape(
                                            $order['email']
                                        ) ?>
                                    </a>
                                </div>
                            </div>

                            <div class="oa-detail-row">
                                <div class="oa-detail-label">Điện thoại</div>

                                <div class="oa-detail-value">
                                    <a href="tel:<?= comic_admin_orders_escape($order['phone']) ?>">
                                        <?= comic_admin_orders_escape(
                                            $order['phone']
                                        ) ?>
                                    </a>
                                </div>
                            </div>

                            <div class="oa-detail-row">
                                <div class="oa-detail-label">Địa chỉ</div>

                                <div class="oa-detail-value">
                                    <?= nl2br(
                                        comic_admin_orders_escape(
                                            $order['address']
                                        )
                                    ) ?>
                                </div>
                            </div>

                            <div class="oa-detail-row">
                                <div class="oa-detail-label">Ghi chú</div>

                                <div class="oa-detail-value">
                                    <?= $order['note'] !== null &&
                                        trim((string) $order['note']) !== ''
                                            ? nl2br(
                                                comic_admin_orders_escape(
                                                    $order['note']
                                                )
                                            )
                                            : 'Không có ghi chú.' ?>
                                </div>
                            </div>

                            <div class="oa-detail-row">
                                <div class="oa-detail-label">Cập nhật lần cuối</div>

                                <div class="oa-detail-value">
                                    <?= $updatedTimestamp
                                        ? comic_admin_orders_escape(
                                            date(
                                                'd/m/Y H:i',
                                                $updatedTimestamp
                                            )
                                        )
                                        : '—' ?>
                                </div>
                            </div>

                        </div>
                    </article>

                    <!-- CÁC SẢN PHẨM TRONG ĐƠN -->
                    <article class="oa-panel">

                        <div class="oa-panel-head">
                            <div>
                                <h2>Sản phẩm trong đơn</h2>

                                <div class="oa-muted" style="margin-top:4px">
                                    <?= number_format(count($orderItems)) ?>
                                    dòng sản phẩm
                                </div>
                            </div>
                        </div>

                        <?php if (!$orderItems): ?>

                            <div class="oa-empty">
                                Đơn hàng không có dòng sản phẩm.
                            </div>

                        <?php else: ?>

                            <div class="oa-table-wrap">

                                <table>
                                    <thead>
                                        <tr>
                                            <th>Truyện</th>
                                            <th>Đơn giá</th>
                                            <th>Số lượng</th>
                                            <th>Thành tiền</th>
                                        </tr>
                                    </thead>

                                    <tbody>

                                        <?php foreach ($orderItems as $item): ?>

                                            <?php
                                            $cover = comic_admin_media_url(
                                                (string) ($item['cover_image'] ?? ''),
                                                (string) ($item['comic_title'] ?? ''),
                                                'cover'
                                            );
                                            ?>

                                            <tr>
                                                <td>
                                                    <div class="oa-item">

                                                        <?php if ($cover !== ''): ?>

                                                            <img
                                                                class="oa-cover"
                                                                src="<?= comic_admin_orders_escape($cover) ?>"
                                                                alt=""
                                                                loading="lazy"
                                                                onerror="this.style.display='none';this.nextElementSibling.style.display='grid';"
                                                            >

                                                            <span
                                                                class="oa-cover-placeholder"
                                                                style="display:none"
                                                                aria-hidden="true"
                                                            >▣</span>

                                                        <?php else: ?>

                                                            <span
                                                                class="oa-cover-placeholder"
                                                                aria-hidden="true"
                                                            >▣</span>

                                                        <?php endif; ?>

                                                        <span>
                                                            <strong>
                                                                <?= comic_admin_orders_escape(
                                                                    $item['comic_title']
                                                                ) ?>
                                                            </strong>

                                                            <?php if (!empty($item['comic_id'])): ?>
                                                                <span class="oa-muted">
                                                                    ID truyện:
                                                                    <?= (int) $item['comic_id'] ?>
                                                                </span>
                                                            <?php endif; ?>
                                                        </span>

                                                    </div>
                                                </td>

                                                <td style="white-space:nowrap">
                                                    <?= comic_admin_orders_escape(
                                                        comic_admin_orders_money(
                                                            $item['price']
                                                        )
                                                    ) ?>
                                                </td>

                                                <td>
                                                    ×<?= number_format(
                                                        (int) $item['quantity']
                                                    ) ?>
                                                </td>

                                                <td class="oa-money">
                                                    <?= comic_admin_orders_escape(
                                                        comic_admin_orders_money(
                                                            $item['total']
                                                        )
                                                    ) ?>
                                                </td>
                                            </tr>

                                        <?php endforeach; ?>

                                    </tbody>
                                </table>

                            </div>

                        <?php endif; ?>

                        <div class="oa-total-box">
                            <div class="oa-total-row">
                                <span>Tổng số lượng</span>

                                <strong>
                                    <?= number_format(
                                        array_sum(
                                            array_map(
                                                static function ($item) {
                                                    return (int) $item['quantity'];
                                                },
                                                $orderItems
                                            )
                                        )
                                    ) ?>
                                    cuốn
                                </strong>
                            </div>

                            <div class="oa-total-row grand">
                                <span>Tổng thanh toán</span>

                                <strong style="color:#f2f2f2">
                                    <?= comic_admin_orders_escape(
                                        comic_admin_orders_money(
                                            $order['total_amount']
                                        )
                                    ) ?>
                                </strong>
                            </div>
                        </div>

                    </article>

                </div>

                <!-- CẬP NHẬT TRẠNG THÁI -->
                <div>

                    <article class="oa-panel">

                        <div class="oa-panel-head">
                            <h2>Trạng thái đơn hàng</h2>
                        </div>

                        <div class="oa-detail-form">

                            <p style="margin:0 0 17px">
                                <span class="oa-badge <?= comic_admin_orders_escape($statusInfo['class']) ?>">
                                    <?= comic_admin_orders_escape($statusInfo['label']) ?>
                                </span>

                                <span class="oa-badge <?= comic_admin_orders_escape($paymentInfo['class']) ?>">
                                    <?= comic_admin_orders_escape($paymentInfo['label']) ?>
                                </span>
                            </p>

                            <form
                                method="post"
                                action="orders.php?action=view&amp;id=<?= (int) $order['id'] ?>"
                                data-confirm="Bạn có chắc muốn lưu các trạng thái mới của đơn hàng?"
                            >

                                <input
                                    type="hidden"
                                    name="csrf_token"
                                    value="<?= comic_admin_orders_escape(
                                        comic_admin_csrf_token()
                                    ) ?>"
                                >

                                <input
                                    type="hidden"
                                    name="action"
                                    value="update_status"
                                >

                                <input
                                    type="hidden"
                                    name="order_id"
                                    value="<?= (int) $order['id'] ?>"
                                >

                                <div class="oa-field">
                                    <label for="order-status">
                                        Trạng thái xử lý
                                    </label>

                                    <select
                                        id="order-status"
                                        name="status"
                                        required
                                        <?= $order['status'] === 'cancelled' ? 'disabled' : '' ?>
                                    >

                                        <?php
                                        $statusLabels = [
                                            'pending' => 'Chờ xác nhận',
                                            'processing' => 'Đang xử lý',
                                            'shipping' => 'Đang giao hàng',
                                            'completed' => 'Hoàn thành',
                                            'cancelled' => 'Đã hủy',
                                        ];
                                        ?>

                                        <?php foreach ($statusLabels as $key => $label): ?>
                                            <option
                                                value="<?= comic_admin_orders_escape($key) ?>"
                                                <?= $order['status'] === $key ? 'selected' : '' ?>
                                            >
                                                <?= comic_admin_orders_escape($label) ?>
                                            </option>
                                        <?php endforeach; ?>

                                    </select>

                                    <?php if ($order['status'] === 'cancelled'): ?>
                                        <span class="oa-muted">
                                            Đơn đã hủy không thể mở lại trực tiếp.
                                        </span>
                                        <input type="hidden" name="status" value="cancelled">
                                    <?php endif; ?>
                                </div>

                                <div class="oa-field">
                                    <label for="payment-status">
                                        Tình trạng thanh toán
                                    </label>

                                    <select
                                        id="payment-status"
                                        name="payment_status"
                                        required
                                    >
                                        <?php
                                        $paymentLabels = [
                                            'pending' => 'Chưa thanh toán',
                                            'completed' => 'Đã thanh toán',
                                            'failed' => 'Thất bại',
                                        ];
                                        ?>

                                        <?php foreach ($paymentLabels as $key => $label): ?>
                                            <option
                                                value="<?= comic_admin_orders_escape($key) ?>"
                                                <?= $order['payment_status'] === $key ? 'selected' : '' ?>
                                            >
                                                <?= comic_admin_orders_escape($label) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <button class="oa-btn" type="submit">
                                    Lưu trạng thái
                                </button>

                            </form>

                        </div>
                    </article>

                    <article class="oa-panel">

                        <div class="oa-panel-head">
                            <h2>Thông tin thanh toán</h2>
                        </div>

                        <div class="oa-detail-block">

                            <div class="oa-detail-row">
                                <div class="oa-detail-label">Phương thức</div>

                                <div class="oa-detail-value">
                                    <?= comic_admin_orders_escape(
                                        $paymentMethods[
                                            (string) $order['payment_method']
                                        ] ?? 'Không xác định'
                                    ) ?>
                                </div>
                            </div>

                            <div class="oa-detail-row">
                                <div class="oa-detail-label">Tình trạng</div>

                                <div class="oa-detail-value">
                                    <?= comic_admin_orders_escape(
                                        $paymentInfo['label']
                                    ) ?>
                                </div>
                            </div>

                            <div class="oa-detail-row">
                                <div class="oa-detail-label">Giá trị đơn</div>

                                <div class="oa-detail-value" style="color:#f2f2f2">
                                    <?= comic_admin_orders_escape(
                                        comic_admin_orders_money(
                                            $order['total_amount']
                                        )
                                    ) ?>
                                </div>
                            </div>

                        </div>

                    </article>

                    <div class="oa-muted" style="line-height:1.7">
                        Lưu ý: cập nhật trạng thái tại đây không tự trừ
                        hoặc hoàn lại tồn kho. Cần đối soát với quy trình
                        checkout trước khi xử lý đơn hủy hoặc hoàn hàng.
                    </div>

                </div>

            </section>

        <?php endif; ?>

    <?php else: ?>

        <!-- THỐNG KÊ -->
        <section class="oa-stats" aria-label="Thống kê đơn hàng">

            <article class="oa-stat">
                <span class="oa-stat-label">Tổng đơn hàng</span>

                <strong class="oa-stat-value">
                    <?= number_format($stats['total']) ?>
                </strong>

                <span class="oa-stat-note">
                    Tất cả đơn trong hệ thống
                </span>
            </article>

            <article class="oa-stat">
                <span class="oa-stat-label">Chờ xác nhận</span>

                <strong
                    class="oa-stat-value"
                    style="color:#d48b18"
                >
                    <?= number_format($stats['pending']) ?>
                </strong>

                <span class="oa-stat-note">
                    Cần kiểm tra đơn mới
                </span>
            </article>

            <article class="oa-stat">
                <span class="oa-stat-label">Đang giao hàng</span>

                <strong
                    class="oa-stat-value"
                    style="color:#2586c7"
                >
                    <?= number_format($stats['shipping']) ?>
                </strong>

                <span class="oa-stat-note">
                    Đơn có trạng thái shipping
                </span>
            </article>

            <article class="oa-stat">
                <span class="oa-stat-label">Doanh thu đã thanh toán</span>

                <strong
                    class="oa-stat-value"
                    style="color:#6fdc9c;font-size:clamp(17px,1.8vw,23px)"
                >
                    <?= comic_admin_orders_escape(
                        comic_admin_orders_money($stats['revenue'])
                    ) ?>
                </strong>

                <span class="oa-stat-note">
                    Không tính đơn đã hủy
                </span>
            </article>

        </section>

        <!-- TÌM KIẾM / LỌC -->
        <div class="oa-toolbar">

            <form class="oa-search" method="get" action="orders.php">

                <input
                    type="search"
                    name="q"
                    value="<?= comic_admin_orders_escape($search) ?>"
                    placeholder="Mã đơn, tên khách, email, điện thoại..."
                    aria-label="Tìm đơn hàng"
                >

                <select name="status" aria-label="Lọc trạng thái đơn">
                    <option value="all">Tất cả trạng thái</option>

                    <option value="pending" <?= $statusFilter === 'pending' ? 'selected' : '' ?>>
                        Chờ xác nhận
                    </option>

                    <option value="processing" <?= $statusFilter === 'processing' ? 'selected' : '' ?>>
                        Đang xử lý
                    </option>

                    <option value="shipping" <?= $statusFilter === 'shipping' ? 'selected' : '' ?>>
                        Đang giao hàng
                    </option>

                    <option value="completed" <?= $statusFilter === 'completed' ? 'selected' : '' ?>>
                        Hoàn thành
                    </option>

                    <option value="cancelled" <?= $statusFilter === 'cancelled' ? 'selected' : '' ?>>
                        Đã hủy
                    </option>
                </select>

                <select name="payment" aria-label="Lọc thanh toán">
                    <option value="all">Mọi thanh toán</option>

                    <option value="pending" <?= $paymentFilter === 'pending' ? 'selected' : '' ?>>
                        Chưa thanh toán
                    </option>

                    <option value="completed" <?= $paymentFilter === 'completed' ? 'selected' : '' ?>>
                        Đã thanh toán
                    </option>

                    <option value="failed" <?= $paymentFilter === 'failed' ? 'selected' : '' ?>>
                        Thanh toán thất bại
                    </option>
                </select>

                <button class="oa-btn secondary" type="submit">
                    Tìm kiếm
                </button>

                <?php if (
                    $search !== '' ||
                    $statusFilter !== 'all' ||
                    $paymentFilter !== 'all'
                ): ?>
                    <a class="oa-btn secondary" href="orders.php">
                        Xóa lọc
                    </a>
                <?php endif; ?>

            </form>

        </div>

        <!-- DANH SÁCH -->
        <section class="oa-panel">

            <div class="oa-panel-head">
                <div>
                    <h2>Danh sách đơn hàng</h2>

                    <div class="oa-muted" style="margin-top:4px">
                        Theo dõi đơn mới nhất và cập nhật tiến độ xử lý.
                    </div>
                </div>

                <span class="oa-muted">
                    <?= number_format($totalOrders) ?> kết quả
                </span>
            </div>

            <?php if (!$dbReady): ?>

                <div class="oa-empty">
                    Cần kết nối cơ sở dữ liệu để hiển thị đơn hàng.
                </div>

            <?php elseif (!$orderRows): ?>

                <div class="oa-empty">
                    <div style="font-size:30px;margin-bottom:9px">
                        ▤
                    </div>

                    Không tìm thấy đơn hàng phù hợp.
                </div>

            <?php else: ?>

                <div class="oa-table-wrap">

                    <table>

                        <thead>
                            <tr>
                                <th>Đơn hàng</th>
                                <th>Ngày tạo</th>
                                <th>Tổng tiền</th>
                                <th>Thanh toán</th>
                                <th>Trạng thái</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach ($orderRows as $row): ?>

                                <?php
                                $rowStatus = comic_admin_orders_status_info(
                                    (string) $row['status']
                                );

                                $rowPayment = comic_admin_orders_payment_info(
                                    (string) $row['payment_status']
                                );

                                $timestamp = !empty($row['created_at'])
                                    ? strtotime((string) $row['created_at'])
                                    : false;

                                $methodLabel = [
                                    'cod' => 'COD',
                                    'banking' => 'Chuyển khoản',
                                ][(string) $row['payment_method']] ?? 'Khác';
                                ?>

                                <tr>

                                    <td>
                                        <span class="oa-code">
                                            <?= comic_admin_orders_escape(
                                                $row['order_code']
                                            ) ?>
                                        </span>

                                        <span class="oa-customer">
                                            <?= comic_admin_orders_escape(
                                                $row['full_name']
                                            ) ?>
                                        </span>

                                        <span class="oa-customer">
                                            <?= comic_admin_orders_escape(
                                                $row['phone']
                                            ) ?>
                                            ·
                                            <?= comic_admin_orders_escape(
                                                $methodLabel
                                            ) ?>
                                        </span>
                                    </td>

                                    <td style="white-space:nowrap">
                                        <?= $timestamp
                                            ? comic_admin_orders_escape(
                                                date(
                                                    'd/m/Y H:i',
                                                    $timestamp
                                                )
                                            )
                                            : '—' ?>
                                    </td>

                                    <td class="oa-money">
                                        <?= comic_admin_orders_escape(
                                            comic_admin_orders_money(
                                                $row['total_amount']
                                            )
                                        ) ?>
                                    </td>

                                    <td>
                                        <span class="oa-badge <?= comic_admin_orders_escape($rowPayment['class']) ?>">
                                            <?= comic_admin_orders_escape(
                                                $rowPayment['label']
                                            ) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <span class="oa-badge <?= comic_admin_orders_escape($rowStatus['class']) ?>">
                                            <?= comic_admin_orders_escape(
                                                $rowStatus['label']
                                            ) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <div class="oa-actions">

                                            <a
                                                class="oa-btn secondary"
                                                href="orders.php?action=view&amp;id=<?= (int) $row['id'] ?>"
                                            >
                                                Chi tiết
                                            </a>

                                        </div>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

                <!-- PHÂN TRANG -->
                <div class="oa-pagination">

                    <span class="oa-muted">
                        Hiển thị
                        <?= number_format(
                            min(
                                $totalOrders,
                                $offset + ($totalOrders > 0 ? 1 : 0)
                            )
                        ) ?>–<?= number_format(
                            min(
                                $totalOrders,
                                $offset + count($orderRows)
                            )
                        ) ?>
                        trong <?= number_format($totalOrders) ?> đơn hàng
                    </span>

                    <?php if ($totalPages > 1): ?>

                        <nav class="oa-pages" aria-label="Phân trang">

                            <?php
                            $queryBase = [];

                            if ($search !== '') {
                                $queryBase['q'] = $search;
                            }

                            if ($statusFilter !== 'all') {
                                $queryBase['status'] = $statusFilter;
                            }

                            if ($paymentFilter !== 'all') {
                                $queryBase['payment'] = $paymentFilter;
                            }

                            if ($page > 1) {
                                $prevUrl = 'orders.php?' .
                                    http_build_query(
                                        array_merge(
                                            $queryBase,
                                            ['page' => $page - 1]
                                        )
                                    );

                                echo '<a href="' .
                                    comic_admin_orders_escape($prevUrl) .
                                    '" aria-label="Trang trước">‹</a>';
                            }

                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);

                            for (
                                $i = $startPage;
                                $i <= $endPage;
                                $i++
                            ) {
                                $pageUrl = 'orders.php?' .
                                    http_build_query(
                                        array_merge(
                                            $queryBase,
                                            ['page' => $i]
                                        )
                                    );

                                if ($i === $page) {
                                    echo '<span class="current" aria-current="page">' .
                                        $i . '</span>';
                                } else {
                                    echo '<a href="' .
                                        comic_admin_orders_escape($pageUrl) .
                                        '">' . $i . '</a>';
                                }
                            }

                            if ($page < $totalPages) {
                                $nextUrl = 'orders.php?' .
                                    http_build_query(
                                        array_merge(
                                            $queryBase,
                                            ['page' => $page + 1]
                                        )
                                    );

                                echo '<a href="' .
                                    comic_admin_orders_escape($nextUrl) .
                                    '" aria-label="Trang sau">›</a>';
                            }
                            ?>

                        </nav>

                    <?php endif; ?>

                </div>

            <?php endif; ?>

        </section>

    <?php endif; ?>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
