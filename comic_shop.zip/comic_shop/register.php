<?php
declare(strict_types=1);

/**
 * Comic Shop - Đăng ký tài khoản
 * Đường dẫn: /register.php
 * CSDL: bảng users trong comic_shop.sql
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* -------------------------------------------------------
   1. NẠP CẤU HÌNH VÀ HÀM DÙNG CHUNG
------------------------------------------------------- */

$dbFile = __DIR__ . '/config/db.php';

if (is_file($dbFile)) {
    $dbReturn = require_once $dbFile;
} else {
    $dbReturn = null;
}

$functionsFile = __DIR__ . '/includes/functions.php';

if (is_file($functionsFile)) {
    require_once $functionsFile;
}

/* Hỗ trợ PDO hoặc MySQLi tùy cấu hình dự án. */
$database = null;

if ($dbReturn instanceof PDO) {
    $database = $dbReturn;
} elseif (
    class_exists('mysqli') &&
    $dbReturn instanceof mysqli
) {
    $database = $dbReturn;
} else {
    foreach (
        ['pdo', 'conn', 'mysqli', 'db', 'connection', 'database']
        as $variableName
    ) {
        if (
            isset($$variableName) &&
            (
                $$variableName instanceof PDO ||
                (
                    class_exists('mysqli') &&
                    $$variableName instanceof mysqli
                )
            )
        ) {
            $database = $$variableName;
            break;
        }
    }
}

/* -------------------------------------------------------
   2. HÀM HỖ TRỢ
------------------------------------------------------- */

if (!function_exists('comic_register_escape')) {
    function comic_register_escape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_register_length')) {
    function comic_register_length(string $value): int
    {
        if (function_exists('mb_strlen')) {
            return mb_strlen($value, 'UTF-8');
        }

        $count = preg_match_all('/./us', $value);

        return $count === false ? strlen($value) : $count;
    }
}

if (!function_exists('comic_register_redirect')) {
    function comic_register_redirect(): void
    {
        header('Location: register.php', true, 303);
        exit;
    }
}

/* -------------------------------------------------------
   3. CSRF TOKEN VÀ THÔNG BÁO
------------------------------------------------------- */

if (
    !isset($_SESSION['comic_register_csrf']) ||
    !is_string($_SESSION['comic_register_csrf'])
) {
    $_SESSION['comic_register_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['comic_register_csrf'];

$errorMessage = '';
$successMessage = '';

$old = [
    'full_name' => '',
    'email' => '',
    'phone' => '',
];

if (isset($_SESSION['comic_register_flash'])) {
    $flash = $_SESSION['comic_register_flash'];

    if (is_array($flash)) {
        $errorMessage = (string) ($flash['error'] ?? '');
        $successMessage = (string) ($flash['success'] ?? '');
    }

    unset($_SESSION['comic_register_flash']);
}

if (isset($_SESSION['comic_register_old'])) {
    $oldData = $_SESSION['comic_register_old'];

    if (is_array($oldData)) {
        foreach (array_keys($old) as $key) {
            if (
                isset($oldData[$key]) &&
                is_string($oldData[$key])
            ) {
                $old[$key] = $oldData[$key];
            }
        }
    }

    unset($_SESSION['comic_register_old']);
}

/* -------------------------------------------------------
   4. XỬ LÝ ĐĂNG KÝ
------------------------------------------------------- */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $fullName = isset($_POST['full_name']) &&
        is_string($_POST['full_name'])
        ? trim($_POST['full_name'])
        : '';

    $email = isset($_POST['email']) &&
        is_string($_POST['email'])
        ? strtolower(trim($_POST['email']))
        : '';

    $phone = isset($_POST['phone']) &&
        is_string($_POST['phone'])
        ? trim($_POST['phone'])
        : '';

    $password = isset($_POST['password']) &&
        is_string($_POST['password'])
        ? $_POST['password']
        : '';

    $confirmPassword = isset($_POST['confirm_password']) &&
        is_string($_POST['confirm_password'])
        ? $_POST['confirm_password']
        : '';

    $_SESSION['comic_register_old'] = [
        'full_name' => $fullName,
        'email' => $email,
        'phone' => $phone,
    ];

    $submittedToken = isset($_POST['csrf_token']) &&
        is_string($_POST['csrf_token'])
        ? $_POST['csrf_token']
        : '';

    $validToken = is_string($csrfToken) &&
        $submittedToken !== '' &&
        hash_equals($csrfToken, $submittedToken);

    $errorMessage = '';

    if (!$validToken) {
        $errorMessage =
            'Phiên đăng ký đã hết hạn. Vui lòng thử lại.';
    } elseif (
        comic_register_length($fullName) < 2 ||
        comic_register_length($fullName) > 120
    ) {
        $errorMessage =
            'Họ tên phải có từ 2 đến 120 ký tự.';
    } elseif (
        strlen($email) > 150 ||
        filter_var($email, FILTER_VALIDATE_EMAIL) === false
    ) {
        $errorMessage =
            'Vui lòng nhập địa chỉ email hợp lệ.';
    } elseif (
        $phone !== '' &&
        (
            strlen($phone) > 20 ||
            !preg_match('/^[0-9+\s().-]{7,20}$/', $phone)
        )
    ) {
        $errorMessage =
            'Số điện thoại không hợp lệ.';
    } elseif (
        strlen($password) < 8 ||
        strlen($password) > 72
    ) {
        $errorMessage =
            'Mật khẩu phải có ít nhất 8 ký tự và tối đa 72 byte.';
    } elseif (!hash_equals($password, $confirmPassword)) {
        $errorMessage =
            'Mật khẩu xác nhận không khớp.';
    } elseif (
        !($database instanceof PDO) &&
        !(
            class_exists('mysqli') &&
            $database instanceof mysqli
        )
    ) {
        $errorMessage =
            'Không kết nối được cơ sở dữ liệu. ' .
            'Vui lòng kiểm tra config/db.php.';
    } else {
        try {
            /*
             * Băm mật khẩu trước khi lưu.
             * Tài khoản đăng ký luôn có role = customer.
             */
            $passwordHash = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            if ($passwordHash === false) {
                throw new RuntimeException(
                    'Không thể mã hóa mật khẩu.'
                );
            }

            if ($database instanceof PDO) {
                $database->setAttribute(
                    PDO::ATTR_ERRMODE,
                    PDO::ERRMODE_EXCEPTION
                );

                $check = $database->prepare(
                    'SELECT id FROM users WHERE email = ? LIMIT 1'
                );

                $check->execute([$email]);

                if ($check->fetch(PDO::FETCH_ASSOC)) {
                    $errorMessage =
                        'Email này đã được đăng ký. ' .
                        'Vui lòng sử dụng email khác hoặc đăng nhập.';
                } else {
                    $insert = $database->prepare(
                        "INSERT INTO users
                            (full_name, email, password, phone, role, is_active)
                         VALUES
                            (?, ?, ?, ?, 'customer', 1)"
                    );

                    $insert->execute([
                        $fullName,
                        $email,
                        $passwordHash,
                        $phone !== '' ? $phone : null,
                    ]);
                }
            } else {
                $check = $database->prepare(
                    'SELECT id FROM users WHERE email = ? LIMIT 1'
                );

                if (!$check) {
                    throw new RuntimeException(
                        'Không thể chuẩn bị truy vấn email.'
                    );
                }

                $check->bind_param('s', $email);
                $check->execute();
                $check->store_result();

                $emailExists = $check->num_rows > 0;
                $check->close();

                if ($emailExists) {
                    $errorMessage =
                        'Email này đã được đăng ký. ' .
                        'Vui lòng sử dụng email khác hoặc đăng nhập.';
                } else {
                    $insert = $database->prepare(
                        "INSERT INTO users
                            (full_name, email, password, phone, role, is_active)
                         VALUES
                            (?, ?, ?, ?, 'customer', 1)"
                    );

                    if (!$insert) {
                        throw new RuntimeException(
                            'Không thể chuẩn bị truy vấn đăng ký.'
                        );
                    }

                    $phoneValue = $phone !== '' ? $phone : null;

                    $insert->bind_param(
                        'ssss',
                        $fullName,
                        $email,
                        $passwordHash,
                        $phoneValue
                    );

                    $insert->execute();
                    $insert->close();
                }
            }

            if ($errorMessage === '') {
                /*
                 * Không tự đăng nhập sau khi đăng ký.
                 * Thông báo thành công sẽ hiển thị trên trang.
                 */
                unset($_SESSION['comic_register_old']);

                $_SESSION['comic_register_flash'] = [
                    'success' =>
                        'Đăng ký thành công! Hãy đăng nhập bằng tài khoản mới.',
                ];

                $_SESSION['comic_register_csrf'] =
                    bin2hex(random_bytes(32));

                comic_register_redirect();
            }
        } catch (Throwable $exception) {
            /*
             * Mã lỗi 1062 / SQLSTATE 23000 thường là email trùng.
             */
            $isDuplicate =
                (string) $exception->getCode() === '23000' ||
                (
                    property_exists($exception, 'errorInfo') &&
                    isset($exception->errorInfo[1]) &&
                    (int) $exception->errorInfo[1] === 1062
                ) ||
                (
                    $exception instanceof mysqli_sql_exception &&
                    (int) $exception->getCode() === 1062
                );

            if ($isDuplicate) {
                $errorMessage =
                    'Email này đã được sử dụng. ' .
                    'Vui lòng thử email khác.';
            } else {
                error_log(
                    '[Comic Shop register] ' .
                    $exception->getMessage()
                );

                $errorMessage =
                    'Không thể tạo tài khoản lúc này. ' .
                    'Vui lòng kiểm tra kết nối cơ sở dữ liệu rồi thử lại.';
            }
        }
    }

    $_SESSION['comic_register_flash'] = [
        'error' => $errorMessage,
    ];

    $_SESSION['comic_register_csrf'] =
        bin2hex(random_bytes(32));

    comic_register_redirect();
}

/* Cập nhật token dùng cho biểu mẫu sau khi chuyển hướng. */
$csrfToken = $_SESSION['comic_register_csrf'];

/* Trang đăng ký không hiện icon tìm kiếm trên thanh header */
$pageTitle = 'Đăng ký | Comic Shop';
$activeMenu = 'register';
$hideHeaderSearch = true;

$headerFile = __DIR__ . '/includes/header.php';
$footerFile = __DIR__ . '/includes/footer.php';

if (is_file($headerFile)) {
    require_once $headerFile;
} else {
    ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Đăng ký | Comic Shop</title>
    </head>
    <body>
    <?php
}
?>

<style>
/* Giao diện đăng ký: cùng bố cục và bảng màu với trang đăng nhập */
body:has(.comic-register),
.scrn-page-wrapper:has(.comic-register){
    background-color:#1c1c1f;
}
/* Trang đăng ký không hiện chân trang */
body:has(.comic-register) footer{display:none!important}

body:has(.comic-register){margin:0}
.scrn-page-wrapper:has(.comic-register){
    display:flex;
    flex-direction:column;
    min-height:100vh;
    min-height:100dvh;
}
.scrn-page-wrapper:has(.comic-register) .scrn-main-content{
    flex:1 1 auto;
    display:flex;
    flex-direction:column;
    padding:0;
}

.comic-register{
    --bg:#1c1c1f;
    --glass:#232327;
    --glass-2:#2c2c31;
    --glass-3:#36363c;
    --stroke:#3d3d44;
    --line:rgba(255,255,255,.38);
    --text:#f2f2f2;
    --muted:#a9a9b2;
    box-sizing:border-box;
    flex:1 1 auto;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:16px 18px;
    background:var(--bg);
    color:var(--text);
    font-family:"Inter","Montserrat",system-ui,-apple-system,"Segoe UI",Arial,sans-serif;
}
.comic-register *{box-sizing:border-box}
.comic-register .reg-layout{
    display:grid;
    grid-template-columns:minmax(0,1fr) minmax(440px,1.05fr);
    width:min(1040px,100%);
    overflow:hidden;
    border:1px solid var(--stroke);
    border-radius:30px;
    background:var(--glass);
}
.comic-register .reg-art{
    position:relative;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
    overflow:hidden;
    padding:30px 34px;
    border-right:1px solid var(--stroke);
    background:
        radial-gradient(ellipse at 90% 0%,rgba(255,255,255,.08),transparent 45%),
        var(--glass-2);
}
.comic-register .reg-art:before{
    position:absolute;
    right:-100px;
    bottom:-120px;
    width:340px;
    height:340px;
    border:1px solid rgba(255,255,255,.10);
    border-radius:50%;
    content:"";
    box-shadow:0 0 0 34px rgba(255,255,255,.025),0 0 0 70px rgba(255,255,255,.02);
}
.comic-register .reg-brand{
    position:relative;
    z-index:1;
    display:flex;
    align-items:center;
    gap:10px;
    color:var(--text);
    font-size:15px;
    font-weight:800;
    letter-spacing:.4px;
    text-decoration:none;
}
.comic-register .reg-brand-mark{
    display:flex;
    width:38px;
    height:38px;
    align-items:center;
    justify-content:center;
    border-radius:12px;
    background:#f2f2f2;
    color:#111111;
    font-size:20px;
    font-weight:800;
}
.comic-register .reg-art-main{
    position:relative;
    z-index:1;
    margin:35px 0;
}
.comic-register .reg-art-eyebrow{
    color:var(--muted);
    font-size:10px;
    font-weight:800;
    letter-spacing:2px;
    text-transform:uppercase;
}
.comic-register .reg-art h2{
    margin:15px 0;
    font-size:clamp(27px,3vw,38px);
    font-weight:800;
    letter-spacing:-.8px;
    line-height:1.2;
}
.comic-register .reg-art h2 span{color:var(--muted)}
.comic-register .reg-art p{
    max-width:330px;
    margin:0;
    color:var(--muted);
    font-size:12px;
    line-height:1.95;
}
.comic-register .reg-art-footer{
    position:relative;
    z-index:1;
    color:var(--muted);
    font-size:10px;
    line-height:1.7;
}
.comic-register .reg-form-side{
    display:flex;
    flex-direction:column;
    justify-content:center;
    padding:24px 32px;
}
.comic-register .reg-heading{margin-bottom:14px}
.comic-register .reg-heading h1{
    display:flex;
    align-items:center;
    gap:10px;
    margin:0;
    font-size:24px;
    font-weight:800;
    letter-spacing:-.5px;
}
.comic-register .reg-heading h1:before{
    content:"";
    width:4px;
    height:.85em;
    border-radius:4px;
    background:var(--text);
}
.comic-register .reg-heading p{
    margin:6px 0 0;
    color:var(--muted);
    font-size:12px;
    line-height:1.6;
}
.comic-register .reg-alert{
    margin-bottom:12px;
    padding:9px 14px;
    border:1px solid var(--stroke);
    border-left:4px solid var(--text);
    border-radius:18px;
    background:var(--bg);
    color:var(--text);
    font-size:11px;
    line-height:1.6;
}
.comic-register .reg-alert a{font-weight:800;text-decoration:underline}
.comic-register .reg-field{margin-bottom:11px;min-width:0}
.comic-register .reg-row{display:grid;grid-template-columns:1fr 1fr;gap:0 12px}
.comic-register .reg-field label{
    display:block;
    margin-bottom:6px;
    color:var(--text);
    font-size:11px;
    font-weight:700;
}
.comic-register .reg-input-wrap{position:relative}
.comic-register .reg-field input{
    width:100%;
    min-height:40px;
    padding:8px 16px;
    border:1px solid var(--stroke);
    border-radius:999px;
    outline:none;
    background:var(--bg);
    color:var(--text);
    font:inherit;
    font-size:12px;
    transition:border-color .15s,box-shadow .15s;
}
.comic-register .reg-field input::placeholder{color:#7c7c85}
.comic-register .reg-field input:-webkit-autofill{
    -webkit-box-shadow:0 0 0 40px var(--bg) inset;
    -webkit-text-fill-color:var(--text);
}
.comic-register .reg-field input:focus{
    border-color:var(--line);
    box-shadow:0 0 0 3px rgba(255,255,255,.07);
}
.comic-register .reg-password-input{padding-right:52px!important}
.comic-register .reg-show-password{
    position:absolute;
    top:50%;
    right:10px;
    padding:6px;
    transform:translateY(-50%);
    border:0;
    background:transparent;
    color:var(--muted);
    font:inherit;
    font-size:10px;
    font-weight:800;
    cursor:pointer;
}
.comic-register .reg-show-password:hover{color:var(--text)}
.comic-register .reg-submit{
    display:flex;
    width:100%;
    height:44px;
    margin-top:6px;
    align-items:center;
    justify-content:center;
    gap:8px;
    border:1.5px solid #f2f2f2;
    border-radius:999px;
    background:#f2f2f2;
    color:#111111;
    font:inherit;
    font-size:12px;
    font-weight:700;
    cursor:pointer;
    transition:background .2s,transform .2s;
}
.comic-register .reg-submit:hover{
    border-color:#ffffff;
    background:#ffffff;
    transform:translateY(-1px);
}
.comic-register .reg-submit:disabled{opacity:.7;cursor:wait;transform:none}
.comic-register .reg-note{
    margin:10px 0 0;
    color:#85858e;
    font-size:10px;
    line-height:1.5;
    text-align:center;
}
.comic-register .reg-bottom{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    flex-wrap:wrap;
    margin-top:14px;
    padding-top:14px;
    border-top:1px solid var(--stroke);
    color:var(--muted);
    font-size:11px;
}
.comic-register .reg-bottom a{
    color:var(--text);
    font-weight:800;
    text-decoration:none;
}
.comic-register .reg-bottom a:hover{text-decoration:underline}
.comic-register .reg-bottom .reg-back{
    display:inline;
    color:var(--muted);
    font-weight:700;
}
.comic-register .reg-bottom .reg-back:hover{color:var(--text)}
@media(max-width:760px){
    .comic-register{padding:24px 14px}
    .comic-register .reg-layout{grid-template-columns:1fr;max-width:465px}
    .comic-register .reg-art{min-height:220px;padding:24px;border-right:0;border-bottom:1px solid var(--stroke)}
    .comic-register .reg-art-main{margin:30px 0 22px}
    .comic-register .reg-art h2{font-size:29px}
    .comic-register .reg-art-footer{display:none}
    .comic-register .reg-form-side{padding:28px 25px}
    .comic-register .reg-row{grid-template-columns:1fr}
}
@media(max-width:390px){
    .comic-register .reg-form-side{padding:27px 18px}
    .comic-register .reg-art{padding:20px}
}
</style>

<main class="comic-register">
    <div class="reg-layout">

        <section class="reg-art">
            <a class="reg-brand" href="index.php">
                <span class="reg-brand-mark">C.</span>
                <span>COMIC SHOP</span>
            </a>

            <div class="reg-art-main">
                <div class="reg-art-eyebrow">Join the story</div>

                <h2>
                    Mở ra<br>
                    câu chuyện <span>của bạn.</span>
                </h2>

                <p>
                    Tạo tài khoản để lưu lại những bộ truyện yêu thích,
                    theo dõi đơn hàng và khám phá thêm nhiều câu chuyện mới.
                </p>
            </div>

            <div class="reg-art-footer">
                COMIC SHOP · THẾ GIỚI TRUYỆN TRANH
            </div>
        </section>

        <section class="reg-form-side" aria-labelledby="register-title">
            <div class="reg-heading">
                <h1 id="register-title">Tạo tài khoản</h1>
                <p>
                    Điền thông tin bên dưới để trở thành thành viên của shop.
                </p>
            </div>

            <?php if ($errorMessage !== ''): ?>
                <div class="reg-alert" role="alert">
                    <?= comic_register_escape($errorMessage) ?>
                </div>
            <?php endif; ?>

            <?php if ($successMessage !== ''): ?>
                <div class="reg-alert" role="status">
                    <?= comic_register_escape($successMessage) ?>
                    <a href="login.php">Đăng nhập ngay.</a>
                </div>
            <?php endif; ?>

            <form
                method="post"
                action="register.php"
                id="comic-register-form"
                autocomplete="on"
            >
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= comic_register_escape($csrfToken) ?>"
                >

                <div class="reg-field">
                    <label for="reg-name">Họ và tên *</label>
                    <input
                        type="text"
                        id="reg-name"
                        name="full_name"
                        value="<?= comic_register_escape($old['full_name']) ?>"
                        minlength="2"
                        maxlength="120"
                        autocomplete="name"
                        placeholder="Nguyễn Văn An"
                        required
                    >
                </div>

                <div class="reg-row">
                <div class="reg-field">
                    <label for="reg-email">Email *</label>
                    <input
                        type="email"
                        id="reg-email"
                        name="email"
                        value="<?= comic_register_escape($old['email']) ?>"
                        maxlength="150"
                        autocomplete="email"
                        placeholder="ban@email.com"
                        required
                    >
                </div>

                <div class="reg-field">
                    <label for="reg-phone">Số điện thoại</label>
                    <input
                        type="tel"
                        id="reg-phone"
                        name="phone"
                        value="<?= comic_register_escape($old['phone']) ?>"
                        maxlength="20"
                        autocomplete="tel"
                        placeholder="09xxxxxxxx"
                    >
                </div>
                </div>

                <div class="reg-row">
                <div class="reg-field">
                    <label for="reg-password">Mật khẩu *</label>
                    <div class="reg-input-wrap">
                        <input
                            class="reg-password-input"
                            type="password"
                            id="reg-password"
                            name="password"
                            minlength="8"
                            maxlength="72"
                            autocomplete="new-password"
                            placeholder="Tối thiểu 8 ký tự"
                            required
                        >
                        <button
                            class="reg-show-password"
                            type="button"
                            data-target="reg-password"
                            aria-label="Hiện mật khẩu"
                        >Hiện</button>
                    </div>
                </div>

                <div class="reg-field">
                    <label for="reg-confirm">Xác nhận mật khẩu *</label>
                    <div class="reg-input-wrap">
                        <input
                            class="reg-password-input"
                            type="password"
                            id="reg-confirm"
                            name="confirm_password"
                            minlength="8"
                            maxlength="72"
                            autocomplete="new-password"
                            placeholder="Nhập lại mật khẩu"
                            required
                        >
                        <button
                            class="reg-show-password"
                            type="button"
                            data-target="reg-confirm"
                            aria-label="Hiện mật khẩu"
                        >Hiện</button>
                    </div>
                </div>
                </div>

                <button
                    class="reg-submit"
                    type="submit"
                    id="reg-submit"
                >
                    Đăng ký tài khoản <span aria-hidden="true">→</span>
                </button>

                <p class="reg-note">
                    Mật khẩu được mã hóa trước khi lưu. Đăng ký đồng nghĩa với việc
                    bạn đồng ý sử dụng dịch vụ của Comic Shop.
                </p>
            </form>

            <div class="reg-bottom">
                <span>
                    Đã có tài khoản?
                    <a href="login.php">Đăng nhập</a>
                </span>
                <a class="reg-back" href="index.php">
                    ← Quay lại cửa hàng
                </a>
            </div>

        </section>

    </div>
</main>

<script>
(function () {
    'use strict';

    document.querySelectorAll('.reg-show-password').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var input = document.getElementById(btn.dataset.target);
            if (!input) { return; }

            var isPassword = input.type === 'password';
            input.type = isPassword ? 'text' : 'password';
            btn.textContent = isPassword ? 'Ẩn' : 'Hiện';
            btn.setAttribute('aria-label',
                isPassword ? 'Ẩn mật khẩu' : 'Hiện mật khẩu');
        });
    });

    var form = document.getElementById('comic-register-form');
    var submit = document.getElementById('reg-submit');

    if (form && submit) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                form.reportValidity();
                return;
            }

            if (submit.dataset.submitting === '1') {
                event.preventDefault();
                return;
            }

            submit.dataset.submitting = '1';
            submit.disabled = true;
            submit.textContent = 'Đang tạo tài khoản...';
        });
    }
})();
</script>

<?php
if (is_file($footerFile)) {
    require_once $footerFile;
} else {
    echo '</body></html>';
}
?>
