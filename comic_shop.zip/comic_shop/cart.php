<?php
declare(strict_types=1);

/**
 * COMIC SHOP
 * File: cart.php
 * Giỏ hàng - thêm, sửa số lượng, xóa sản phẩm.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. KẾT NỐI DATABASE
========================================================= */

$dbConfigReturn = null;
$dbConfigFile = __DIR__ . '/config/db.php';

if (is_file($dbConfigFile)) {
    $dbConfigReturn = require_once $dbConfigFile;
}

$cartDb = null;

$cartDbCandidates = [
    $dbConfigReturn,
    $GLOBALS['comic_shop_db'] ?? null,
    $GLOBALS['pdo'] ?? null,
    $GLOBALS['conn'] ?? null,
    $GLOBALS['mysqli'] ?? null,
    $GLOBALS['db'] ?? null,
    $pdo ?? null,
    $conn ?? null,
    $mysqli ?? null,
    $db ?? null,
];

foreach ($cartDbCandidates as $candidate) {
    if (
        $candidate instanceof PDO ||
        (class_exists('mysqli') && $candidate instanceof mysqli)
    ) {
        $cartDb = $candidate;
        break;
    }
}

$cartDbReady = $cartDb instanceof PDO ||
    (class_exists('mysqli') && $cartDb instanceof mysqli);

/* =========================================================
   2. HÀM DATABASE
========================================================= */

if (!function_exists('comic_cart_escape')) {
    function comic_cart_escape($value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_cart_money')) {
    function comic_cart_money($amount): string
    {
        return number_format((float)$amount, 0, ',', '.') . ' ₫';
    }
}

if (!function_exists('comic_cart_query')) {
    function comic_cart_query(
        $database,
        string $sql,
        array $params = []
    ): array {
        if ($database instanceof PDO) {
            $statement = $database->prepare($sql);
            $statement->execute($params);

            $rows = $statement->columnCount() > 0
                ? $statement->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $affected = $statement->rowCount();
            $lastId = $database->lastInsertId();

            $statement->closeCursor();

            return [
                'rows' => $rows,
                'affected' => $affected,
                'insert_id' => $lastId,
            ];
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            $statement = $database->prepare($sql);

            if (!$statement) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn database.'
                );
            }

            if ($params !== []) {
                $types = '';
                $bindParams = [];

                foreach ($params as $param) {
                    if (is_int($param) || is_bool($param)) {
                        $types .= 'i';
                    } elseif (is_float($param)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }
                }

                $bindParams[] = $types;

                foreach ($params as &$param) {
                    $bindParams[] = &$param;
                }

                unset($param);

                if (!call_user_func_array(
                    [$statement, 'bind_param'],
                    $bindParams
                )) {
                    $statement->close();

                    throw new RuntimeException(
                        'Không thể gắn tham số truy vấn.'
                    );
                }
            }

            if (!$statement->execute()) {
                $error = $statement->error;
                $statement->close();

                throw new RuntimeException(
                    $error ?: 'Truy vấn database thất bại.'
                );
            }

            $rows = [];

            if ($statement->field_count > 0) {
                $result = $statement->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $statement->close();

                    throw new RuntimeException(
                        'Không đọc được kết quả truy vấn.'
                    );
                }
            }

            $affected = $statement->affected_rows;
            $lastId = $statement->insert_id;

            $statement->close();

            return [
                'rows' => $rows,
                'affected' => $affected,
                'insert_id' => $lastId,
            ];
        }

        throw new RuntimeException(
            'Không tìm thấy kết nối PDO hoặc MySQLi.'
        );
    }
}

/* =========================================================
   3. NGƯỜI SỞ HỮU GIỎ HÀNG
========================================================= */

if (!function_exists('comic_cart_current_user_id')) {
    function comic_cart_current_user_id(): int
    {
        $candidates = [
            $_SESSION['user']['id'] ?? null,
            $_SESSION['user']['user_id'] ?? null,
            $_SESSION['user_id'] ?? null,
            $_SESSION['customer_id'] ?? null,
            $_SESSION['customer']['id'] ?? null,
        ];

        foreach ($candidates as $value) {
            if (
                (is_int($value) ||
                    (is_string($value) && ctype_digit($value))) &&
                (int)$value > 0
            ) {
                return (int)$value;
            }
        }

        return 0;
    }
}

if (!function_exists('comic_cart_owner_condition')) {
    function comic_cart_owner_condition(): array
    {
        $userId = comic_cart_current_user_id();
        $sessionId = session_id();

        if ($userId > 0) {
            return [
                '(user_id = ? OR session_id = ?)',
                [$userId, $sessionId],
            ];
        }

        return [
            '(user_id IS NULL AND session_id = ?)',
            [$sessionId],
        ];
    }
}

/* =========================================================
   4. THÔNG BÁO VÀ CSRF
========================================================= */

if (!function_exists('comic_cart_flash')) {
    function comic_cart_flash(
        string $type,
        string $message
    ): void {
        $_SESSION['comic_cart_flash'] = [
            'type' => $type,
            'message' => $message,
        ];
    }
}

if (!function_exists('comic_cart_redirect')) {
    function comic_cart_redirect(): void
    {
        header('Location: cart.php', true, 303);
        exit;
    }
}

if (
    empty($_SESSION['comic_cart_csrf']) ||
    !is_string($_SESSION['comic_cart_csrf'])
) {
    $_SESSION['comic_cart_csrf'] = bin2hex(random_bytes(32));
}

$cartCsrf = $_SESSION['comic_cart_csrf'];

$cartFlash = $_SESSION['comic_cart_flash'] ?? null;
unset($_SESSION['comic_cart_flash']);

$cartErrors = [];

/* =========================================================
   5. XỬ LÝ CÁC THAO TÁC GIỎ HÀNG
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $action = isset($_POST['action']) &&
        is_string($_POST['action'])
        ? $_POST['action']
        : '';

    $postedToken = isset($_POST['csrf_token']) &&
        is_string($_POST['csrf_token'])
        ? $_POST['csrf_token']
        : '';

    /*
     * Form thêm truyện từ comic-detail.php hiện dùng action=add.
     * Các thao tác sửa/xóa yêu cầu CSRF token.
     */
    if (
        $action !== 'add' &&
        !hash_equals($cartCsrf, $postedToken)
    ) {
        comic_cart_flash(
            'error',
            'Phiên làm việc đã hết hạn. Vui lòng thử lại.'
        );

        comic_cart_redirect();
    }

    if (!$cartDbReady) {
        comic_cart_flash(
            'error',
            'Chưa kết nối được database. Hãy kiểm tra config/db.php.'
        );

        comic_cart_redirect();
    }

    try {
        [$ownerSql, $ownerParams] =
            comic_cart_owner_condition();

        if ($action === 'add') {
            $comicId = (int)($_POST['comic_id'] ?? 0);
            $quantity = (int)($_POST['quantity'] ?? 1);

            if ($comicId < 1) {
                comic_cart_flash(
                    'error',
                    'Truyện cần thêm vào giỏ không hợp lệ.'
                );

                comic_cart_redirect();
            }

            $quantity = max(1, min(999, $quantity));

            $comicRows = comic_cart_query(
                $cartDb,
                'SELECT id, title, stock, is_active
                 FROM comics
                 WHERE id = ?
                 LIMIT 1',
                [$comicId]
            )['rows'];

            $comic = $comicRows[0] ?? null;

            if (!$comic || (int)$comic['is_active'] !== 1) {
                comic_cart_flash(
                    'error',
                    'Truyện không tồn tại hoặc hiện không được bán.'
                );

                comic_cart_redirect();
            }

            $stock = (int)$comic['stock'];

            if ($stock < 1) {
                comic_cart_flash(
                    'error',
                    'Truyện này hiện đã hết hàng.'
                );

                comic_cart_redirect();
            }

            [$ownerSql, $ownerParams] =
                comic_cart_owner_condition();

            $existingRows = comic_cart_query(
                $cartDb,
                'SELECT id, quantity
                 FROM cart
                 WHERE comic_id = ?
                   AND ' . $ownerSql . '
                 ORDER BY id ASC
                 LIMIT 1',
                array_merge([$comicId], $ownerParams)
            )['rows'];

            if ($existingRows) {
                $existingId = (int)$existingRows[0]['id'];
                $existingQuantity = (int)$existingRows[0]['quantity'];

                $newQuantity = $existingQuantity + $quantity;

                if ($newQuantity > $stock) {
                    comic_cart_flash(
                        'error',
                        'Chỉ còn ' . $stock .
                        ' cuốn "' . $comic['title'] .
                        '" trong kho. Số lượng trong giỏ chưa được tăng.'
                    );

                    comic_cart_redirect();
                }

                comic_cart_query(
                    $cartDb,
                    'UPDATE cart
                     SET quantity = ?
                     WHERE id = ?
                       AND ' . $ownerSql,
                    array_merge(
                        [$newQuantity, $existingId],
                        $ownerParams
                    )
                );

            } else {
                if ($quantity > $stock) {
                    comic_cart_flash(
                        'error',
                        'Số lượng vượt quá tồn kho hiện có.'
                    );

                    comic_cart_redirect();
                }

                $userId = comic_cart_current_user_id();

                comic_cart_query(
                    $cartDb,
                    'INSERT INTO cart
                        (user_id, session_id, comic_id, quantity)
                     VALUES (?, ?, ?, ?)',
                    [
                        $userId > 0 ? $userId : null,
                        session_id(),
                        $comicId,
                        $quantity,
                    ]
                );
            }

            comic_cart_flash(
                'success',
                'Đã thêm "' . $comic['title'] . '" vào giỏ hàng.'
            );

            comic_cart_redirect();

        } elseif ($action === 'update') {
            $cartId = (int)($_POST['cart_id'] ?? 0);
            $quantity = (int)($_POST['quantity'] ?? 1);

            if ($cartId < 1) {
                comic_cart_flash(
                    'error',
                    'Mục giỏ hàng không hợp lệ.'
                );

                comic_cart_redirect();
            }

            $itemRows = comic_cart_query(
                $cartDb,
                'SELECT cart.id, cart.quantity,
                        comics.title, comics.stock, comics.is_active
                 FROM cart
                 INNER JOIN comics ON comics.id = cart.comic_id
                 WHERE cart.id = ?
                   AND ' . str_replace(
                       ['user_id', 'session_id'],
                       ['cart.user_id', 'cart.session_id'],
                       $ownerSql
                   ) . '
                 LIMIT 1',
                array_merge([$cartId], $ownerParams)
            )['rows'];

            $item = $itemRows[0] ?? null;

            if (!$item) {
                comic_cart_flash(
                    'error',
                    'Không tìm thấy sản phẩm trong giỏ hàng.'
                );

                comic_cart_redirect();
            }

            if (
                (int)$item['is_active'] !== 1 ||
                (int)$item['stock'] < 1
            ) {
                comic_cart_flash(
                    'error',
                    'Sản phẩm đã hết hàng hoặc không còn được bán. Hãy xóa sản phẩm khỏi giỏ.'
                );

                comic_cart_redirect();
            }

            $quantity = max(
                1,
                min((int)$item['stock'], 999, $quantity)
            );

            comic_cart_query(
                $cartDb,
                'UPDATE cart
                 SET quantity = ?
                 WHERE id = ?
                   AND ' . $ownerSql,
                array_merge(
                    [$quantity, $cartId],
                    $ownerParams
                )
            );

            comic_cart_flash(
                'success',
                'Đã cập nhật số lượng sản phẩm.'
            );

            $_SESSION['comic_cart_csrf'] =
                bin2hex(random_bytes(32));

            comic_cart_redirect();

        } elseif ($action === 'remove') {
            $cartId = (int)($_POST['cart_id'] ?? 0);

            if ($cartId < 1) {
                comic_cart_flash(
                    'error',
                    'Mục giỏ hàng không hợp lệ.'
                );

                comic_cart_redirect();
            }

            comic_cart_query(
                $cartDb,
                'DELETE FROM cart
                 WHERE id = ?
                   AND ' . $ownerSql,
                array_merge([$cartId], $ownerParams)
            );

            comic_cart_flash(
                'success',
                'Đã xóa sản phẩm khỏi giỏ hàng.'
            );

            $_SESSION['comic_cart_csrf'] =
                bin2hex(random_bytes(32));

            comic_cart_redirect();

        } elseif ($action === 'clear') {
            comic_cart_query(
                $cartDb,
                'DELETE FROM cart WHERE ' . $ownerSql,
                $ownerParams
            );

            comic_cart_flash(
                'success',
                'Đã xóa toàn bộ sản phẩm trong giỏ hàng.'
            );

            $_SESSION['comic_cart_csrf'] =
                bin2hex(random_bytes(32));

            comic_cart_redirect();

        } else {
            comic_cart_flash(
                'error',
                'Thao tác giỏ hàng không hợp lệ.'
            );

            comic_cart_redirect();
        }

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Cart] ' . $exception->getMessage()
        );

        comic_cart_flash(
            'error',
            'Không thể xử lý giỏ hàng. Vui lòng thử lại.'
        );

        comic_cart_redirect();
    }
}

/* Tìm đường dẫn ảnh bìa thực tế (DB có thể chỉ lưu tên file). */
if (!function_exists('comic_cart_resolve_image')) {
    function comic_cart_resolve_image(string $path): string
    {
        $path = ltrim(str_replace('\\', '/', trim($path)), '/');

        if ($path === '') {
            return '';
        }

        if (preg_match('#^(https?:)?//#i', $path)) {
            return $path;
        }

        if (is_file(__DIR__ . '/' . $path)) {
            return $path;
        }

        $info = pathinfo($path);
        $dir = ($info['dirname'] ?? '.') === '.' ? '' : $info['dirname'] . '/';
        $name = (string)($info['filename'] ?? '');
        $dirs = [$dir];

        if ($dir === '') {
            $dirs[] = 'assets/images/covers/';
        }

        foreach ($dirs as $tryDir) {
            if (is_file(__DIR__ . '/' . $tryDir . ($info['basename'] ?? ''))) {
                return $tryDir . $info['basename'];
            }

            foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
                $try = $tryDir . $name . '.' . $ext;

                if ($name !== '' && is_file(__DIR__ . '/' . $try)) {
                    return $try;
                }
            }
        }

        return '';
    }
}

if (!function_exists('comic_cart_cover')) {
    function comic_cart_cover(array $item): string
    {
        $found = comic_cart_resolve_image((string)($item['cover_image'] ?? ''));

        if ($found === '') {
            $found = comic_cart_resolve_image(
                'assets/images/covers/' . (string)($item['slug'] ?? '')
            );
        }

        return $found;
    }
}

/* =========================================================
   6. ĐỌC SẢN PHẨM TRONG GIỎ
========================================================= */

$cartItems = [];
$cartCount = 0;
$subtotal = 0.0;
$originalTotal = 0.0;
$totalSavings = 0.0;

if ($cartDbReady) {
    try {
        [$ownerSql, $ownerParams] =
            comic_cart_owner_condition();

        $cartItems = comic_cart_query(
            $cartDb,
            'SELECT
                cart.id AS cart_id,
                cart.comic_id,
                cart.quantity,
                comics.title,
                comics.slug,
                comics.price,
                comics.sale_price,
                comics.cover_image,
                comics.stock,
                comics.is_active
             FROM cart
             INNER JOIN comics ON comics.id = cart.comic_id
             WHERE ' . str_replace(
                 ['user_id', 'session_id'],
                 ['cart.user_id', 'cart.session_id'],
                 $ownerSql
             ) . '
             ORDER BY cart.id ASC',
            $ownerParams
        )['rows'];

        foreach ($cartItems as &$item) {
            $price = (float)$item['price'];
            $salePrice = $item['sale_price'] !== null
                ? (float)$item['sale_price']
                : null;

            $hasDiscount = $salePrice !== null &&
                $salePrice > 0 &&
                $salePrice < $price;

            $unitPrice = $hasDiscount ? $salePrice : $price;
            $quantity = (int)$item['quantity'];

            $item['unit_price'] = $unitPrice;
            $item['original_price'] = $price;
            $item['has_discount'] = $hasDiscount;
            $item['line_total'] = $unitPrice * $quantity;
            $item['cover_src'] = comic_cart_cover($item);

            $subtotal += $item['line_total'];
            $originalTotal += $price * $quantity;
            $cartCount += $quantity;
        }

        unset($item);

        $totalSavings = max(0, $originalTotal - $subtotal);

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Cart] ' . $exception->getMessage()
        );

        $cartErrors[] =
            'Không tải được dữ liệu giỏ hàng. Hãy kiểm tra cấu trúc database.';
    }
}

/* =========================================================
   7. GIAO DIỆN
========================================================= */

$pageTitle = 'Giỏ hàng | Comic Shop';
$pageDescription = 'Kiểm tra sản phẩm và số lượng truyện trong giỏ hàng.';
$activeMenu = 'cart';
$hideHeaderSearch = true; // Ẩn nút kính lúp trên thanh trên
$hideFooter = true;       // Ẩn phần chân trang

$headerFile = __DIR__ . '/includes/header.php';
$footerFile = __DIR__ . '/includes/footer.php';

if (is_file($headerFile)) {
    require_once $headerFile;
} else {
    ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= comic_cart_escape($pageTitle) ?></title>
        <meta
            name="description"
            content="<?= comic_cart_escape($pageDescription) ?>"
        >
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
    <?php
}
?>

<style>
.cart-page{
    --cart-red:#f2f2f2;
    --cart-ink:#f2f2f2;
    --cart-muted:#a9a9b2;
    --cart-border:#3d3d44;
    padding:33px 0 55px;
    color:var(--cart-ink);
}
.cart-page *{box-sizing:border-box}
.cart-page .cart-wrap{
    width:calc(100% - 48px);
    margin:0 auto;
}
.cart-page .cart-heading{margin-bottom:24px}
.cart-page .cart-eyebrow{
    color:var(--cart-red);
    font-size:10px;
    font-weight:900;
    letter-spacing:2px;
    text-transform:uppercase;
}
.cart-page .cart-title{
    margin:8px 0;
    font-size:clamp(27px,4vw,36px);
    font-weight:950;
    letter-spacing:-.8px;
}
.cart-page .cart-description{
    margin:0;
    color:var(--cart-muted);
    font-size:13px;
    line-height:1.8;
}
.cart-page .cart-alert{
    margin-bottom:18px;
    padding:13px 15px;
    border:1px solid #3d3d44;
    border-left:4px solid var(--cart-red);
    border-radius:7px;
    background:#2c2c31;
    color:#f2f2f2;
    font-size:12px;
    line-height:1.7;
}
.cart-page .cart-alert.success{
    border-color:#3d3d44;
    border-left-color:#f2f2f2;
    background:#2c2c31;
    color:#f2f2f2;
}
.cart-page .cart-layout{
    display:grid;
    grid-template-columns:minmax(0,1fr) 320px;
    gap:23px;
    align-items:start;
}
.cart-page .cart-panel,
.cart-page .cart-summary{
    overflow:hidden;
    border:1px solid var(--cart-border);
    border-radius:24px;
    background:#232327;
    box-shadow:0 5px 20px rgba(0,0,0,.035);
}
.cart-page .cart-panel-head{
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:12px;
    padding:17px 19px;
    border-bottom:1px solid #3d3d44;
}
.cart-page .cart-panel-head h2{
    margin:0;
    font-size:14px;
    font-weight:900;
}
.cart-page .cart-muted{
    color:var(--cart-muted);
    font-size:11px;
    line-height:1.7;
}
.cart-page .cart-table-wrap{width:100%;overflow-x:auto}
.cart-page .cart-table{
    width:100%;
    min-width:630px;
    border-collapse:collapse;
}
.cart-page .cart-table th{
    padding:12px 14px;
    background:#2c2c31;
    color:#a9a9b2;
    text-align:left;
    font-size:10px;
    font-weight:850;
    text-transform:uppercase;
    letter-spacing:.4px;
    white-space:nowrap;
}
.cart-page .cart-table td{
    padding:17px 14px;
    border-top:1px solid #3d3d44;
    vertical-align:middle;
    font-size:12px;
}
.cart-page .cart-product{
    display:flex;
    align-items:center;
    gap:13px;
    min-width:210px;
}
.cart-page .cart-cover{
    display:block;
    width:73px;
    height:92px;
    flex-shrink:0;
    overflow:hidden;
    border:1px solid #3d3d44;
    border-radius:5px;
    background:#2c2c31;
}
.cart-page .cart-cover img{
    display:block;
    width:100%;
    height:100%;
    object-fit:cover;
}
.cart-page .cart-cover-placeholder{
    display:flex;
    width:100%;
    height:100%;
    align-items:center;
    justify-content:center;
    background:linear-gradient(145deg,#303030,#515151);
    color:#fff;
    font-size:24px;
    font-weight:950;
}
.cart-page .cart-product-name{
    display:block;
    max-width:250px;
    color:#f2f2f2;
    font-size:12px;
    font-weight:900;
    line-height:1.65;
    overflow-wrap:anywhere;
}
.cart-page .cart-product-name:hover{color:var(--cart-red)}
.cart-page .cart-unavailable{
    display:inline-flex;
    margin-top:6px;
    padding:4px 6px;
    border-radius:4px;
    background:#2c2c31;
    color:#f2f2f2;
    font-size:9px;
    font-weight:850;
}
.cart-page .cart-price{
    color:#f2f2f2;
    font-weight:850;
    white-space:nowrap;
}
.cart-page .cart-old-price{
    display:block;
    margin-top:5px;
    color:#a9a9b2;
    font-size:10px;
    font-weight:500;
    text-decoration:line-through;
}
.cart-page .cart-quantity{
    display:flex;
    align-items:center;
    gap:0;
    width:max-content;
    overflow:hidden;
    border:1px solid #3d3d44;
    border-radius:6px;
}
.cart-page .cart-quantity button{
    display:flex;
    width:32px;
    height:34px;
    align-items:center;
    justify-content:center;
    border:0;
    background:#2c2c31;
    color:#a9a9b2;
    font-size:18px;
    cursor:pointer;
}
.cart-page .cart-quantity button:hover:not(:disabled){
    background:#2c2c31;
    color:var(--cart-red);
}
.cart-page .cart-quantity button:disabled{
    opacity:.4;
    cursor:not-allowed;
}
.cart-page .cart-quantity input{
    width:43px;
    height:34px;
    padding:0;
    border:0;
    border-right:1px solid #3d3d44;
    border-left:1px solid #3d3d44;
    outline:none;
    background:#1c1c1f;
    color:#f2f2f2;
    text-align:center;
    font:inherit;
    font-size:12px;
    font-weight:850;
    appearance:textfield;
    -moz-appearance:textfield;
}
.cart-page .cart-quantity input::-webkit-inner-spin-button,
.cart-page .cart-quantity input::-webkit-outer-spin-button{
    margin:0;
    -webkit-appearance:none;
}
.cart-page .cart-line-total{
    color:#f2f2f2;
    font-size:13px;
    font-weight:900;
    white-space:nowrap;
}
.cart-page .cart-remove{
    padding:7px;
    border:0;
    background:transparent;
    color:#a9a9b2;
    font-size:17px;
    cursor:pointer;
}
.cart-page .cart-remove:hover{color:var(--cart-red)}
.cart-page .cart-item-form{margin:0}
.cart-page .cart-bottom{
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
    gap:10px;
    padding:15px 18px;
    border-top:1px solid #3d3d44;
}
.cart-page .cart-btn{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:7px;
    min-height:39px;
    padding:9px 13px;
    border:1px solid transparent;
    border-radius:999px;
    background:var(--cart-red);
    color:#111111;
    font-size:11px;
    font-weight:900;
    text-decoration:none;
    cursor:pointer;
    transition:background .15s;
}
.cart-page .cart-btn:hover{
    background:#d9d9de;
    color:#111111;
}
.cart-page .cart-btn.secondary{
    border-color:#3d3d44;
    background:#232327;
    color:#d6d6db;
}
.cart-page .cart-btn.secondary:hover{
    border-color:var(--cart-red);
    color:var(--cart-red);
}
.cart-page .cart-btn.danger{
    border-color:#3d3d44;
    background:#2c2c31;
    color:#f2f2f2;
}
.cart-page .cart-summary{padding:21px}
.cart-page .cart-summary h2{
    margin:0 0 18px;
    padding-bottom:13px;
    border-bottom:1px solid #3d3d44;
    font-size:15px;
    font-weight:900;
}
.cart-page .cart-summary-row{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    gap:13px;
    margin:14px 0;
    color:#a9a9b2;
    font-size:12px;
}
.cart-page .cart-summary-row strong{
    color:#f2f2f2;
    font-weight:850;
    text-align:right;
}
.cart-page .cart-saving{color:#f2f2f2!important}
.cart-page .cart-summary-total{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    gap:10px;
    margin-top:18px;
    padding-top:17px;
    border-top:1px dashed #3d3d44;
}
.cart-page .cart-summary-total span{
    padding-top:4px;
    color:#d6d6db;
    font-size:12px;
    font-weight:850;
}
.cart-page .cart-summary-total strong{
    color:var(--cart-red);
    font-size:23px;
    font-weight:950;
    line-height:1.3;
    text-align:right;
    overflow-wrap:anywhere;
}
.cart-page .cart-checkout{
    display:flex;
    width:100%;
    min-height:45px;
    align-items:center;
    justify-content:center;
    gap:8px;
    margin-top:20px;
    border:0;
    border-radius:999px;
    background:var(--cart-red);
    color:#111111;
    font-size:12px;
    font-weight:950;
    text-decoration:none;
    cursor:pointer;
}
.cart-page .cart-checkout:hover{
    background:#d9d9de;
    color:#111111;
}
.cart-page .cart-checkout-note{
    margin:13px 0 0;
    color:#a9a9b2;
    font-size:10px;
    line-height:1.8;
    text-align:center;
}
.cart-page .cart-benefits{
    display:grid;
    gap:12px;
    margin-top:15px;
    padding:15px;
    border:1px solid var(--cart-border);
    border-radius:18px;
    background:#232327;
}
.cart-page .cart-benefit{
    display:flex;
    align-items:flex-start;
    gap:9px;
    color:#a9a9b2;
    font-size:11px;
    line-height:1.65;
}
.cart-page .cart-benefit span:first-child{
    color:#f2f2f2;
    font-weight:900;
}
.cart-page .cart-empty{
    padding:55px 20px;
    text-align:center;
}
.cart-page .cart-empty-icon{
    display:flex;
    width:75px;
    height:75px;
    align-items:center;
    justify-content:center;
    margin:0 auto 18px;
    border-radius:50%;
    background:#2c2c31;
    color:var(--cart-red);
    font-size:31px;
}
.cart-page .cart-empty h2{
    margin:0 0 10px;
    font-size:22px;
    font-weight:950;
}
.cart-page .cart-empty p{
    max-width:390px;
    margin:0 auto 20px;
    color:var(--cart-muted);
    font-size:12px;
    line-height:1.9;
}
@media(max-width:970px){
    .cart-page .cart-layout{grid-template-columns:minmax(0,1fr) 285px;gap:15px}
    .cart-page .cart-summary{padding:17px}
}
@media(max-width:760px){
    .cart-page .cart-layout{grid-template-columns:1fr}
    .cart-page .cart-summary{order:2}
}
@media(max-width:480px){
    .cart-page{padding-top:24px}
    .cart-page .cart-wrap{width:calc(100% - 26px)}
    .cart-page .cart-panel-head{align-items:flex-start}
    .cart-page .cart-bottom{align-items:stretch}
    .cart-page .cart-bottom>*{flex:1}
}

/* ===== Đồng bộ bố cục & màu sắc với trang tài khoản / đăng nhập ===== */
body:has(.cart-page),
.scrn-page-wrapper:has(.cart-page){background-color:#1c1c1f}
.scrn-page-wrapper:has(.cart-page){display:flex;flex-direction:column;min-height:100vh;min-height:100dvh}
.scrn-page-wrapper:has(.cart-page) .scrn-main-content{flex:1 1 auto;display:flex;flex-direction:column;padding:0}
.cart-page{flex:1 1 auto;padding:16px 0 28px;background:#1c1c1f;
    font-family:"Inter","Montserrat",system-ui,-apple-system,"Segoe UI",Arial,sans-serif}
.cart-page .cart-wrap{width:min(1100px,calc(100% - 48px))}
.cart-page .cart-heading{margin-bottom:14px}
.cart-page .cart-eyebrow{color:#a9a9b2;font-weight:800}
.cart-page .cart-title{display:flex;align-items:center;gap:10px;margin:6px 0 4px;
    font-size:clamp(22px,3vw,28px);font-weight:800;letter-spacing:-.5px}
.cart-page .cart-title:before{content:"";width:4px;height:.85em;border-radius:4px;background:#f2f2f2}
.cart-page .cart-description{font-size:12px;line-height:1.6}
.cart-page .cart-alert{border-radius:16px}
/* ===== Tinh chỉnh giao diện giỏ hàng ===== */
.cart-page .cart-heading{margin-bottom:18px}
.cart-page .cart-wrap{width:min(1100px,calc(100% - 48px))}
.cart-page .cart-table td{padding:18px 14px}
.cart-page .cart-cover{width:76px;height:108px;border-radius:8px;box-shadow:0 4px 14px rgba(0,0,0,.35)}
.cart-page .cart-product{gap:16px}
.cart-page .cart-product-name{font-size:13px}
.cart-page .cart-muted{display:block;margin-top:4px}
.cart-page .cart-panel-head .cart-muted{display:inline;margin:0}
.cart-page .cart-summary{position:sticky;top:16px}
.cart-page .cart-summary-total{margin-top:6px;border-top:1px solid #3d3d44;border-style:solid none none none}
@media(max-width:760px){.cart-page .cart-summary{position:static}}
/* ===== Phóng to nội dung, vừa một màn hình, danh sách tự cuộn ===== */
.cart-page{padding:14px 0 20px}
.cart-page .cart-heading{margin-bottom:14px}
.cart-page .cart-title{font-size:clamp(26px,3.2vw,34px)}
.cart-page .cart-layout{
    grid-template-columns:minmax(0,1fr) 380px;
    gap:24px;
    align-items:stretch;
    height:calc(100vh - 270px);
    height:calc(100dvh - 270px);
    min-height:400px;
}
.cart-page .cart-layout>.cart-panel{display:flex;flex-direction:column;min-height:0}
.cart-page .cart-panel-head{flex:0 0 auto;padding:18px 22px}
.cart-page .cart-panel-head h2{font-size:17px}
.cart-page .cart-panel-head .cart-muted{font-size:13px}
.cart-page .cart-table-wrap{
    flex:1 1 auto;
    min-height:0;
    overflow-x:auto;
    overflow-y:auto;
    scrollbar-width:thin;
    scrollbar-color:#55555d #232327;
}
.cart-page .cart-table-wrap::-webkit-scrollbar{width:9px;height:9px}
.cart-page .cart-table-wrap::-webkit-scrollbar-track{background:#232327}
.cart-page .cart-table-wrap::-webkit-scrollbar-thumb{background:#55555d;border-radius:8px}
.cart-page .cart-table th{
    position:sticky;
    top:0;
    z-index:2;
    padding:14px 16px;
    font-size:12px;
}
.cart-page .cart-table td{padding:16px;font-size:14px}
.cart-page .cart-cover{width:84px;height:118px}
.cart-page .cart-product{gap:18px}
.cart-page .cart-product-name{font-size:16px;max-width:280px}
.cart-page .cart-muted{font-size:13px}
.cart-page .cart-price,
.cart-page .cart-line-total{font-size:16px}
.cart-page .cart-old-price{font-size:12px}
.cart-page .cart-quantity button{width:38px;height:40px;font-size:20px}
.cart-page .cart-quantity input{width:48px;height:40px;font-size:15px}
.cart-page .cart-remove{font-size:22px;padding:8px}
.cart-page .cart-bottom{flex:0 0 auto;padding:14px 22px}
.cart-page .cart-btn{min-height:44px;padding:10px 18px;font-size:14px}
.cart-page .cart-summary{align-self:start;position:static;padding:26px}
.cart-page .cart-summary h2{font-size:19px;margin-bottom:20px}
.cart-page .cart-summary-row{font-size:15px;margin:16px 0}
.cart-page .cart-summary-total span{font-size:15px}
.cart-page .cart-summary-total strong{font-size:30px}
.cart-page .cart-checkout{min-height:54px;font-size:16px;margin-top:24px}
@media(max-width:970px){
    .cart-page .cart-layout{grid-template-columns:minmax(0,1fr) 300px}
}
@media(max-width:760px){
    .cart-page .cart-layout{grid-template-columns:1fr;height:auto;min-height:0}
    .cart-page .cart-table-wrap{max-height:55vh}
}
/* ===== Vừa một màn hình, không cuộn cả trang; danh sách tự cuộn khi nhiều sản phẩm ===== */
html:has(.cart-page),
body:has(.cart-page){overflow:hidden}
.cart-page{padding:10px 0 14px}
.cart-page .cart-heading{margin-bottom:10px}
.cart-page .cart-title{font-size:clamp(22px,2.6vw,28px);margin:2px 0}
.cart-page .cart-layout{
    height:calc(100vh - 260px);
    height:calc(100dvh - 260px);
    min-height:320px;
    grid-template-columns:minmax(0,1fr) 340px;
    gap:20px;
    align-items:stretch;
}
.cart-page .cart-layout>.cart-panel{display:flex;flex-direction:column;min-height:0}
.cart-page .cart-table-wrap{flex:1 1 auto;min-height:0;overflow-x:hidden;overflow-y:auto}
.cart-page .cart-table{min-width:0;table-layout:fixed}
.cart-page .cart-table th{position:sticky;top:0;z-index:2;padding:11px 14px;font-size:11px;letter-spacing:.6px}
.cart-page .cart-table th:nth-child(2){width:120px}
.cart-page .cart-table th:nth-child(3){width:136px}
.cart-page .cart-table th:nth-child(4){width:120px}
.cart-page .cart-table th:nth-child(5){width:52px}
.cart-page .cart-table td{padding:10px 14px;font-size:13px}
.cart-page .cart-product{min-width:0;gap:12px}
.cart-page .cart-cover{width:56px;height:80px;border-radius:6px}
.cart-page .cart-product-name{max-width:none;font-size:14px;line-height:1.4}
.cart-page .cart-muted{font-size:12px;margin-top:3px}
.cart-page .cart-panel-head{padding:12px 18px}
.cart-page .cart-panel-head h2{font-size:15px}
.cart-page .cart-panel-head .cart-muted{font-size:12px;margin:0}
.cart-page .cart-price{display:block;font-size:14px}
.cart-page .cart-old-price{margin-top:2px;font-size:11px}
.cart-page .cart-line-total{font-size:14px}
.cart-page .cart-quantity button{width:30px;height:34px;font-size:17px}
.cart-page .cart-quantity input{width:40px;height:34px;font-size:13px}
.cart-page .cart-remove{width:30px;height:30px;padding:0;display:inline-flex;align-items:center;justify-content:center;border:1px solid #3d3d44;border-radius:50%;font-size:16px;line-height:1}
.cart-page .cart-bottom{flex:0 0 auto;padding:10px 18px}
.cart-page .cart-btn{min-height:38px;padding:8px 16px;font-size:13px}
.cart-page .cart-summary{align-self:start;position:static;padding:20px}
.cart-page .cart-summary h2{font-size:17px;margin-bottom:12px;padding-bottom:10px}
.cart-page .cart-summary-row{font-size:14px;margin:10px 0}
.cart-page .cart-summary-total strong{font-size:26px}
.cart-page .cart-checkout{min-height:48px;font-size:15px;margin-top:16px}
@media(max-width:970px){
    .cart-page .cart-layout{grid-template-columns:minmax(0,1fr) 290px;gap:14px}
}
@media(max-width:760px){
    html:has(.cart-page),body:has(.cart-page){overflow:auto}
    .cart-page .cart-layout{grid-template-columns:1fr;height:auto;min-height:0}
    .cart-page .cart-table-wrap{max-height:55vh;overflow-x:auto}
    .cart-page .cart-table{min-width:560px}
}
</style>

<main class="cart-page">
    <div class="cart-wrap">

        <header class="cart-heading">
            <h1 class="cart-title">Giỏ hàng của bạn</h1>
        </header>

        <?php if (is_array($cartFlash) && !empty($cartFlash['message']) && ($cartFlash['type'] ?? '') !== 'success'): ?>
            <div
                class="cart-alert <?= ($cartFlash['type'] ?? '') === 'success' ? 'success' : '' ?>"
                role="status"
            >
                <?= comic_cart_escape($cartFlash['message']) ?>
            </div>
        <?php endif; ?>

        <?php if (!$cartDbReady): ?>

            <div class="cart-alert">
                Không tìm thấy kết nối database. Hãy kiểm tra
                <strong>config/db.php</strong> và tên biến kết nối đang sử dụng.
            </div>

        <?php elseif (!empty($cartErrors)): ?>

            <div class="cart-alert">
                <?php foreach ($cartErrors as $error): ?>
                    <div><?= comic_cart_escape($error) ?></div>
                <?php endforeach; ?>
            </div>

        <?php elseif (!$cartItems): ?>

            <section class="cart-panel">
                <div class="cart-empty">
                    <div class="cart-empty-icon" aria-hidden="true">🛒</div>
                    <h2>Giỏ hàng đang trống</h2>
                    <p>
                        Bạn chưa thêm truyện nào vào giỏ. Khám phá bộ sưu tập
                        và chọn những cuốn truyện yêu thích của bạn nhé.
                    </p>
                    <a class="cart-btn" href="comics.php">
                        Khám phá tủ truyện →
                    </a>
                </div>
            </section>

        <?php else: ?>

            <div class="cart-layout">

                <section class="cart-panel">
                    <div class="cart-panel-head">
                        <h2>Sản phẩm trong giỏ</h2>
                        <span class="cart-muted">
                            <?= number_format($cartCount) ?> sản phẩm
                        </span>
                    </div>

                    <div class="cart-table-wrap">
                        <table class="cart-table">
                            <thead>
                                <tr>
                                    <th>Truyện</th>
                                    <th>Đơn giá</th>
                                    <th>Số lượng</th>
                                    <th>Thành tiền</th>
                                    <th></th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php foreach ($cartItems as $item): ?>
                                    <?php
                                    $itemStock = (int)$item['stock'];
                                    $itemQuantity = (int)$item['quantity'];

                                    $isAvailable =
                                        (int)$item['is_active'] === 1 &&
                                        $itemStock > 0;

                                    $quantityMax = max(
                                        1,
                                        min(999, $itemStock)
                                    );
                                    ?>

                                    <tr data-cart-item>
                                        <td>
                                            <div class="cart-product">
                                                <a
                                                    class="cart-cover"
                                                    href="comic-detail.php?slug=<?= rawurlencode((string)$item['slug']) ?>"
                                                    aria-label="<?= comic_cart_escape($item['title']) ?>"
                                                >
                                                    <?php if ($item['cover_src'] !== ''): ?>
                                                        <img
                                                            src="<?= comic_cart_escape($item['cover_src']) ?>"
                                                            alt="<?= comic_cart_escape($item['title']) ?>"
                                                            loading="lazy"
                                                            onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"
                                                        >
                                                        <div class="cart-cover-placeholder" style="display:none">C.</div>
                                                    <?php else: ?>
                                                        <div class="cart-cover-placeholder">C.</div>
                                                    <?php endif; ?>
                                                </a>

                                                <div>
                                                    <a
                                                        class="cart-product-name"
                                                        href="comic-detail.php?slug=<?= rawurlencode((string)$item['slug']) ?>"
                                                    >
                                                        <?= comic_cart_escape($item['title']) ?>
                                                    </a>

                                                    <?php if (!$isAvailable): ?>
                                                        <span class="cart-unavailable">
                                                            Không còn hàng
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="cart-muted">
                                                            Còn <?= number_format($itemStock) ?> cuốn
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>

                                        <td>
                                            <span class="cart-price">
                                                <?= comic_cart_money($item['unit_price']) ?>
                                            </span>

                                            <?php if ($item['has_discount']): ?>
                                                <span class="cart-old-price">
                                                    <?= comic_cart_money($item['original_price']) ?>
                                                </span>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <form
                                                class="cart-item-form"
                                                method="post"
                                                action="cart.php"
                                                data-auto-submit="quantity"
                                            >
                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?= comic_cart_escape($cartCsrf) ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="action"
                                                    value="update"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="cart_id"
                                                    value="<?= (int)$item['cart_id'] ?>"
                                                >

                                                <div class="cart-quantity">
                                                    <button
                                                        type="button"
                                                        class="cart-qty-minus"
                                                        data-qty-action="decrease"
                                                        aria-label="Giảm số lượng"
                                                        <?= !$isAvailable || $itemQuantity <= 1 ? 'disabled' : '' ?>
                                                    >−</button>

                                                    <input
                                                        type="number"
                                                        name="quantity"
                                                        data-cart-quantity
                                                        value="<?= $itemQuantity ?>"
                                                        min="1"
                                                        max="<?= $quantityMax ?>"
                                                        inputmode="numeric"
                                                        aria-label="Số lượng"
                                                        <?= !$isAvailable ? 'disabled' : '' ?>
                                                    >

                                                    <button
                                                        type="button"
                                                        class="cart-qty-plus"
                                                        data-qty-action="increase"
                                                        aria-label="Tăng số lượng"
                                                        <?= !$isAvailable || $itemQuantity >= $quantityMax ? 'disabled' : '' ?>
                                                    >+</button>
                                                </div>
                                            </form>
                                        </td>

                                        <td>
                                            <span class="cart-line-total">
                                                <?= comic_cart_money($item['line_total']) ?>
                                            </span>
                                        </td>

                                        <td>
                                            <form
                                                method="post"
                                                action="cart.php"
                                                class="cart-item-form"
                                                data-cart-remove-form
                                                data-confirm="Bạn có chắc muốn xóa truyện này khỏi giỏ hàng?"
                                            >
                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?= comic_cart_escape($cartCsrf) ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="action"
                                                    value="remove"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="cart_id"
                                                    value="<?= (int)$item['cart_id'] ?>"
                                                >

                                                <button
                                                    type="submit"
                                                    class="cart-remove"
                                                    aria-label="Xóa <?= comic_cart_escape($item['title']) ?>"
                                                    title="Xóa sản phẩm"
                                                >×</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="cart-bottom">
                        <a class="cart-btn secondary" href="comics.php">
                            ← Tiếp tục mua hàng
                        </a>

                        <form
                            method="post"
                            action="cart.php"
                            data-confirm="Bạn có chắc muốn xóa toàn bộ giỏ hàng?"
                            style="margin:0"
                        >
                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= comic_cart_escape($cartCsrf) ?>"
                            >

                            <input
                                type="hidden"
                                name="action"
                                value="clear"
                            >

                            <button class="cart-btn danger" type="submit">
                                Xóa toàn bộ giỏ
                            </button>
                        </form>
                    </div>
                </section>

                <aside>
                    <section class="cart-summary">
                        <h2>Tóm tắt đơn hàng</h2>


                        <?php if ($totalSavings > 0): ?>
                            <div class="cart-summary-row">
                                <span>Tiết kiệm</span>
                                <strong class="cart-saving">
                                    −<?= comic_cart_money($totalSavings) ?>
                                </strong>
                            </div>
                        <?php endif; ?>

                        <div class="cart-summary-row">
                            <span>Phí giao hàng</span>
                            <strong>Tính khi đặt hàng</strong>
                        </div>

                        <div class="cart-summary-total">
                            <span>Tổng cộng</span>
                            <strong><?= comic_cart_money($subtotal) ?></strong>
                        </div>

                        <a
                            class="cart-checkout"
                            href="checkout.php"
                        >
                            Tiến hành đặt hàng →
                        </a>

                    </section>

                </aside>

            </div>

        <?php endif; ?>

    </div>
</main>

<?php
/*
 * Dùng assets/js/cart.js nếu file đó tồn tại.
 * Nếu chưa có file JS, đoạn fallback bên dưới vẫn xử lý nút tăng/giảm.
 */
$cartJsPath = __DIR__ . '/assets/js/cart.js';

if (is_file($cartJsPath)):
?>
    <script src="assets/js/cart.js"></script>
<?php else: ?>
    <script>
    (function () {
        'use strict';

        document.querySelectorAll('[data-cart-quantity]').forEach(function (input) {
            var row = input.closest('[data-cart-item]');
            if (!row) return;

            var minus = row.querySelector('[data-qty-action="decrease"]');
            var plus = row.querySelector('[data-qty-action="increase"]');

            function sync() {
                var min = Math.max(1, parseInt(input.min || '1', 10));
                var max = Math.max(min, parseInt(input.max || '999', 10));
                var value = parseInt(input.value || String(min), 10);

                if (!Number.isFinite(value)) value = min;

                value = Math.max(min, Math.min(max, value));
                input.value = String(value);

                if (minus) minus.disabled = input.disabled || value <= min;
                if (plus) plus.disabled = input.disabled || value >= max;
            }

            function submitUpdate() {
                sync();

                var form = input.closest('form');

                if (form && !input.disabled) {
                    if (typeof form.requestSubmit === 'function') {
                        form.requestSubmit();
                    } else {
                        form.submit();
                    }
                }
            }

            if (minus) {
                minus.addEventListener('click', function () {
                    input.value = String(parseInt(input.value || '1', 10) - 1);
                    submitUpdate();
                });
            }

            if (plus) {
                plus.addEventListener('click', function () {
                    input.value = String(parseInt(input.value || '1', 10) + 1);
                    submitUpdate();
                });
            }

            input.addEventListener('change', submitUpdate);
            input.addEventListener('blur', sync);

            sync();
        });

        document.querySelectorAll('form[data-confirm]').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                var message = form.getAttribute('data-confirm');

                if (message && !window.confirm(message)) {
                    event.preventDefault();
                }
            });
        });
    })();
    </script>
<?php endif; ?>

<script>
(function () {
    'use strict';

    var wrap = document.querySelector('.cart-table-wrap');
    if (!wrap) return;

    var key = 'comic_cart_scroll';

    try {
        var saved = sessionStorage.getItem(key);

        if (saved !== null) {
            wrap.scrollTop = parseInt(saved, 10) || 0;
            sessionStorage.removeItem(key);
        }
    } catch (e) {}

    document.addEventListener('submit', function () {
        try {
            sessionStorage.setItem(key, String(wrap.scrollTop));
        } catch (e) {}
    }, true);
})();
</script>

<?php
if (is_file($footerFile)) {
    require_once $footerFile;
} else {
    echo '</body></html>';
}
?>
