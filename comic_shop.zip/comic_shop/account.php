<?php
declare(strict_types=1);

/**
 * COMIC SHOP
 * File: account.php
 * Trang tài khoản khách hàng.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. NẠP CẤU HÌNH
========================================================= */

$mainConfig = __DIR__ . '/config/main.php';
$dbConfig = __DIR__ . '/config/db.php';

if (is_file($mainConfig)) {
    require_once $mainConfig;
}

if (is_file($dbConfig)) {
    require_once $dbConfig;
}

/* =========================================================
   2. KẾT NỐI DATABASE
========================================================= */

$accountDb = null;

$accountDbCandidates = [
    $GLOBALS['comic_shop_db'] ?? null,
    $GLOBALS['pdo'] ?? null,
    $GLOBALS['conn'] ?? null,
    $GLOBALS['mysqli'] ?? null,
    $GLOBALS['db'] ?? null,
    $pdo ?? null,
    $conn ?? null,
    $mysqli ?? null,
    $db ?? null,
];

foreach ($accountDbCandidates as $candidate) {
    if (
        $candidate instanceof PDO ||
        (class_exists('mysqli') && $candidate instanceof mysqli)
    ) {
        $accountDb = $candidate;
        break;
    }
}

$accountDbReady = $accountDb instanceof PDO ||
    (class_exists('mysqli') && $accountDb instanceof mysqli);

/* =========================================================
   3. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_account_escape')) {
    function comic_account_escape($value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_account_query')) {
    function comic_account_query(
        $db,
        string $sql,
        array $params = []
    ): array {
        if ($db instanceof PDO) {
            $stmt = $db->prepare($sql);
            $stmt->execute($params);

            $rows = $stmt->columnCount() > 0
                ? $stmt->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $stmt->closeCursor();

            return ['rows' => $rows];
        }

        if (class_exists('mysqli') && $db instanceof mysqli) {
            $stmt = $db->prepare($sql);

            if (!$stmt) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn database.'
                );
            }

            if ($params !== []) {
                $types = '';
                $bindValues = [];

                foreach ($params as $value) {
                    if (is_int($value) || is_bool($value)) {
                        $types .= 'i';
                    } elseif (is_float($value)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }
                }

                $bindValues[] = $types;

                foreach ($params as &$value) {
                    $bindValues[] = &$value;
                }

                unset($value);

                if (!call_user_func_array(
                    [$stmt, 'bind_param'],
                    $bindValues
                )) {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không thể gắn tham số truy vấn.'
                    );
                }
            }

            if (!$stmt->execute()) {
                $error = $stmt->error;
                $stmt->close();

                throw new RuntimeException(
                    $error ?: 'Truy vấn database thất bại.'
                );
            }

            $rows = [];

            if ($stmt->field_count > 0) {
                $result = $stmt->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $stmt->close();

                    throw new RuntimeException(
                        'Không đọc được kết quả database.'
                    );
                }
            }

            $stmt->close();

            return ['rows' => $rows];
        }

        throw new RuntimeException(
            'Không tìm thấy kết nối PDO hoặc MySQLi.'
        );
    }
}

if (!function_exists('comic_account_flash')) {
    function comic_account_flash(
        string $type,
        string $message
    ): void {
        $_SESSION['comic_account_flash'] = [
            'type' => $type,
            'message' => $message,
        ];
    }
}

if (!function_exists('comic_account_redirect')) {
    function comic_account_redirect(): void
    {
        header('Location: account.php', true, 303);
        exit;
    }
}

if (!function_exists('comic_account_get_user_id')) {
    function comic_account_get_user_id(): int
    {
        $sessionCandidates = [
            $_SESSION['user']['id'] ?? null,
            $_SESSION['user']['user_id'] ?? null,
            $_SESSION['user_id'] ?? null,
            $_SESSION['customer_id'] ?? null,
            $_SESSION['customer']['id'] ?? null,
        ];

        foreach ($sessionCandidates as $value) {
            if (
                (is_int($value) || (is_string($value) && ctype_digit($value))) &&
                (int)$value > 0
            ) {
                return (int)$value;
            }
        }

        return 0;
    }
}

/* =========================================================
   4. KIỂM TRA ĐĂNG NHẬP
========================================================= */

$accountUserId = comic_account_get_user_id();

if ($accountUserId < 1) {
    header('Location: login.php?redirect=account.php', true, 303);
    exit;
}

if (
    empty($_SESSION['comic_account_csrf']) ||
    !is_string($_SESSION['comic_account_csrf'])
) {
    $_SESSION['comic_account_csrf'] = bin2hex(random_bytes(32));
}

$accountCsrf = $_SESSION['comic_account_csrf'];

$accountFlash = $_SESSION['comic_account_flash'] ?? null;
unset($_SESSION['comic_account_flash']);

$accountErrors = [];
$accountUser = null;
$orderSummary = [
    'total' => 0,
    'completed' => 0,
];
$recentOrders = [];

/* =========================================================
   5. XỬ LÝ CẬP NHẬT HỒ SƠ VÀ ĐỔI MẬT KHẨU
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $postedToken = isset($_POST['csrf_token'])
        && is_string($_POST['csrf_token'])
        ? $_POST['csrf_token']
        : '';

    if (!hash_equals($accountCsrf, $postedToken)) {
        comic_account_flash(
            'error',
            'Phiên làm việc đã hết hạn. Vui lòng thử lại.'
        );

        comic_account_redirect();
    }

    if (!$accountDbReady) {
        comic_account_flash(
            'error',
            'Chưa kết nối được database. Hãy kiểm tra config/db.php.'
        );

        comic_account_redirect();
    }

    $postAction = isset($_POST['action'])
        && is_string($_POST['action'])
        ? $_POST['action']
        : '';

    try {
        $userRows = comic_account_query(
            $accountDb,
            'SELECT id, full_name, email, password, phone, address,
                    role, avatar, is_active
             FROM users
             WHERE id = ?
             LIMIT 1',
            [$accountUserId]
        )['rows'];

        $currentUser = $userRows[0] ?? null;

        if (!$currentUser || (int)$currentUser['is_active'] !== 1) {
            unset(
                $_SESSION['user'],
                $_SESSION['user_id'],
                $_SESSION['customer_id'],
                $_SESSION['customer']
            );

            comic_account_flash(
                'error',
                'Tài khoản không tồn tại hoặc đã bị khóa. Vui lòng đăng nhập lại.'
            );

            header('Location: login.php', true, 303);
            exit;
        }

        if ($postAction === 'update_profile') {
            $fullName = trim((string)($_POST['full_name'] ?? ''));
            $email = trim((string)($_POST['email'] ?? ''));
            $phone = trim((string)($_POST['phone'] ?? ''));
            $address = trim((string)($_POST['address'] ?? ''));

            $nameLength = function_exists('mb_strlen')
                ? mb_strlen($fullName, 'UTF-8')
                : strlen($fullName);

            if ($fullName === '' || $nameLength > 120) {
                $accountErrors[] =
                    'Họ tên là bắt buộc và không được vượt quá 120 ký tự.';
            }

            if (
                $email === '' ||
                strlen($email) > 150 ||
                !filter_var($email, FILTER_VALIDATE_EMAIL)
            ) {
                $accountErrors[] = 'Địa chỉ email không hợp lệ.';
            }

            if (strlen($phone) > 20) {
                $accountErrors[] =
                    'Số điện thoại không được vượt quá 20 ký tự.';
            }

            if (strlen($address) > 255) {
                $accountErrors[] =
                    'Địa chỉ không được vượt quá 255 ký tự.';
            }

            if (!$accountErrors) {
                $duplicate = comic_account_query(
                    $accountDb,
                    'SELECT id
                     FROM users
                     WHERE email = ? AND id <> ?
                     LIMIT 1',
                    [$email, $accountUserId]
                )['rows'];

                if ($duplicate) {
                    $accountErrors[] =
                        'Email này đã được sử dụng bởi tài khoản khác.';
                }
            }

            if (!$accountErrors) {
                comic_account_query(
                    $accountDb,
                    'UPDATE users
                     SET full_name = ?,
                         email = ?,
                         phone = ?,
                         address = ?
                     WHERE id = ?',
                    [
                        $fullName,
                        $email,
                        $phone !== '' ? $phone : null,
                        $address !== '' ? $address : null,
                        $accountUserId,
                    ]
                );

                /*
                 * Đồng bộ các thông tin thường dùng trong session.
                 */
                if (
                    isset($_SESSION['user']) &&
                    is_array($_SESSION['user'])
                ) {
                    $_SESSION['user']['id'] = $accountUserId;
                    $_SESSION['user']['full_name'] = $fullName;
                    $_SESSION['user']['name'] = $fullName;
                    $_SESSION['user']['email'] = $email;
                    $_SESSION['user']['phone'] = $phone;
                    $_SESSION['user']['address'] = $address;
                }

                $_SESSION['comic_account_csrf'] =
                    bin2hex(random_bytes(32));

                comic_account_redirect();
            }

        } elseif ($postAction === 'change_password') {
            $currentPassword = (string)(
                $_POST['current_password'] ?? ''
            );

            $newPassword = (string)(
                $_POST['new_password'] ?? ''
            );

            $confirmPassword = (string)(
                $_POST['confirm_password'] ?? ''
            );

            if ($currentPassword === '') {
                $accountErrors[] =
                    'Vui lòng nhập mật khẩu hiện tại.';
            }

            if (strlen($newPassword) < 8) {
                $accountErrors[] =
                    'Mật khẩu mới phải có ít nhất 8 ký tự.';
            }

            if ($newPassword !== $confirmPassword) {
                $accountErrors[] =
                    'Mật khẩu xác nhận không khớp.';
            }

            if (
                !$accountErrors &&
                !password_verify(
                    $currentPassword,
                    (string)$currentUser['password']
                )
            ) {
                $accountErrors[] =
                    'Mật khẩu hiện tại không chính xác.';
            }

            if (
                !$accountErrors &&
                password_verify(
                    $newPassword,
                    (string)$currentUser['password']
                )
            ) {
                $accountErrors[] =
                    'Mật khẩu mới phải khác mật khẩu hiện tại.';
            }

            if (!$accountErrors) {
                $passwordHash = password_hash(
                    $newPassword,
                    PASSWORD_DEFAULT
                );

                comic_account_query(
                    $accountDb,
                    'UPDATE users
                     SET password = ?
                     WHERE id = ?',
                    [$passwordHash, $accountUserId]
                );

                comic_account_flash(
                    'success',
                    'Đổi mật khẩu thành công.'
                );

                $_SESSION['comic_account_csrf'] =
                    bin2hex(random_bytes(32));

                comic_account_redirect();
            }

        } else {
            comic_account_flash(
                'error',
                'Thao tác không hợp lệ.'
            );

            comic_account_redirect();
        }

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Account] ' . $exception->getMessage()
        );

        $accountErrors[] =
            'Không thể lưu thông tin. Vui lòng thử lại sau.';
    }
}

/* =========================================================
   6. TẢI THÔNG TIN TÀI KHOẢN
========================================================= */

if ($accountDbReady) {
    try {
        $userRows = comic_account_query(
            $accountDb,
            'SELECT id, full_name, email, phone, address,
                    role, avatar, is_active, created_at
             FROM users
             WHERE id = ?
             LIMIT 1',
            [$accountUserId]
        )['rows'];

        $accountUser = $userRows[0] ?? null;

        if (
            !$accountUser ||
            (int)$accountUser['is_active'] !== 1
        ) {
            unset(
                $_SESSION['user'],
                $_SESSION['user_id'],
                $_SESSION['customer_id'],
                $_SESSION['customer']
            );

            header('Location: login.php', true, 303);
            exit;
        }

        if (isset($_SESSION['user']) && is_array($_SESSION['user'])) {
            $_SESSION['user']['id'] = $accountUserId;
            $_SESSION['user']['full_name'] = $accountUser['full_name'];
            $_SESSION['user']['name'] = $accountUser['full_name'];
            $_SESSION['user']['email'] = $accountUser['email'];
        }

        $orderStatsRows = comic_account_query(
            $accountDb,
            "SELECT
                COUNT(*) AS total,
                COALESCE(SUM(
                    CASE WHEN status = 'completed' THEN 1 ELSE 0 END
                ), 0) AS completed
             FROM orders
             WHERE user_id = ?",
            [$accountUserId]
        )['rows'];

        if ($orderStatsRows) {
            $orderSummary['total'] =
                (int)$orderStatsRows[0]['total'];

            $orderSummary['completed'] =
                (int)$orderStatsRows[0]['completed'];
        }

        $recentOrders = comic_account_query(
            $accountDb,
            'SELECT id, order_code, total_amount, status, created_at
             FROM orders
             WHERE user_id = ?
             ORDER BY created_at DESC, id DESC
             LIMIT 5',
            [$accountUserId]
        )['rows'];

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Account] ' . $exception->getMessage()
        );

        $accountErrors[] =
            'Không thể tải dữ liệu tài khoản. Hãy kiểm tra cấu hình database.';
    }
}

/* =========================================================
   7. CHUẨN BỊ GIAO DIỆN
========================================================= */

$pageTitle = 'Tài khoản của tôi';
$pageDescription = 'Quản lý thông tin cá nhân và đơn hàng.';
$activeMenu = 'account';

$statusLabels = [
    'pending' => 'Chờ xử lý',
    'processing' => 'Đang xử lý',
    'shipping' => 'Đang giao',
    'completed' => 'Hoàn tất',
    'cancelled' => 'Đã hủy',
];

$statusClasses = [
    'pending' => 'pending',
    'processing' => 'processing',
    'shipping' => 'shipping',
    'completed' => 'completed',
    'cancelled' => 'cancelled',
];

/* Trang tài khoản không hiện icon tìm kiếm trên thanh header */
$hideHeaderSearch = true;

/* Mục hiển thị mặc định: quay lại tab mật khẩu nếu vừa gửi form đổi mật khẩu */
$accountActiveTab = (
    ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'
    && ($_POST['action'] ?? '') === 'change_password'
) ? 'password' : 'profile';

require_once __DIR__ . '/includes/header.php';
?>

<style>
/* Giao diện tài khoản: bảng màu tối, thẻ kính, nút bo tròn như trang chủ / đăng nhập */
body:has(.account-page),
.scrn-page-wrapper:has(.account-page){background-color:#1c1c1f}
/* Trang tài khoản không hiện chân trang */
body:has(.account-page) footer{display:none!important}
body:has(.account-page){margin:0}
.scrn-page-wrapper:has(.account-page){display:flex;flex-direction:column;min-height:100vh;min-height:100dvh}
.scrn-page-wrapper:has(.account-page) .scrn-main-content{flex:1 1 auto;display:flex;flex-direction:column;padding:0}

.account-page{
    --bg:#1c1c1f;--glass:#232327;--glass-2:#2c2c31;--glass-3:#36363c;
    --stroke:#3d3d44;--line:rgba(255,255,255,.38);--text:#f2f2f2;--muted:#a9a9b2;
    flex:1 1 auto;display:flex;flex-direction:column;justify-content:center;
    padding:16px 0 20px;background:var(--bg);color:var(--text);
    font-family:"Inter","Montserrat",system-ui,-apple-system,"Segoe UI",Arial,sans-serif
}
.account-page *{box-sizing:border-box}
.account-page .account-container{width:min(1100px,calc(100% - 48px));margin:0 auto}

/* Hàng tiêu đề + thống kê */
.account-page .account-heading{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;margin-bottom:14px}
.account-page .account-eyebrow{color:var(--muted);font-size:10px;font-weight:800;letter-spacing:2px;text-transform:uppercase}
.account-page .account-title{display:flex;align-items:center;gap:10px;margin:6px 0 0;font-size:clamp(22px,3vw,28px);font-weight:800;letter-spacing:-.5px}
.account-page .account-title:before{content:"";width:4px;height:.85em;border-radius:4px;background:var(--text)}
.account-page .account-stats{display:flex;gap:10px;flex-wrap:wrap}
.account-page .account-stat{display:flex;align-items:center;gap:10px;padding:7px 18px 7px 8px;border:1px solid var(--stroke);border-radius:999px;background:var(--glass)}
.account-page .account-stat-icon{display:grid;place-items:center;width:32px;height:32px;border-radius:50%;background:var(--glass-3);font-size:14px;font-weight:800}
.account-page .account-stat-label{display:block;color:var(--muted);font-size:10px;font-weight:600;line-height:1.3}
.account-page .account-stat-value{display:block;font-size:15px;font-weight:800;line-height:1.3}

/* Thông báo */
.account-page .account-alert{margin-bottom:12px;padding:9px 14px;border:1px solid var(--stroke);border-left:4px solid var(--text);border-radius:16px;background:var(--glass);color:var(--text);font-size:12px;line-height:1.6}
.account-page .account-alert.success{background:var(--glass-2)}

/* Bố cục chính */
.account-page .account-layout{display:grid;grid-template-columns:230px minmax(0,1fr);gap:16px;align-items:stretch}
.account-page .account-side,.account-page .account-card{overflow:hidden;border:1px solid var(--stroke);border-radius:24px;background:var(--glass)}
.account-page .account-side{display:flex;flex-direction:column}
.account-page .account-user{padding:20px 16px 16px;text-align:center;border-bottom:1px solid var(--stroke)}
.account-page .account-avatar{display:flex;width:64px;height:64px;align-items:center;justify-content:center;margin:0 auto 10px;border:2px solid var(--line);border-radius:50%;background:#f2f2f2;color:#111111;font-size:26px;font-weight:800;overflow:hidden}
.account-page .account-avatar img{width:100%;height:100%;object-fit:cover}
.account-page .account-user-name{font-size:14px;font-weight:800;overflow-wrap:anywhere}
.account-page .account-user-email{margin-top:4px;color:var(--muted);font-size:11px;overflow-wrap:anywhere}

/* Nút chọn mục */
.account-page .account-nav{display:flex;flex-direction:column;gap:6px;padding:12px}
.account-page .account-nav .nav-btn{display:flex;align-items:center;gap:10px;width:100%;padding:11px 16px;border:1px solid transparent;border-radius:999px;background:transparent;color:var(--muted);font:inherit;font-size:12px;font-weight:700;text-align:left;text-decoration:none;cursor:pointer;transition:background .15s,color .15s,border-color .15s}
.account-page .account-nav .nav-btn:hover{background:var(--glass-2);color:var(--text)}
.account-page .account-nav .nav-btn.active{background:var(--glass-3);border-color:var(--line);color:var(--text)}
.account-page .account-nav .nav-btn span{width:16px;text-align:center}
.account-page .account-nav .nav-btn:focus-visible{outline:2px solid #f2f2f2;outline-offset:2px}
.account-page .account-nav .nav-logout:hover{background:var(--glass-2);color:var(--text)}
.account-page .account-nav .nav-sep{height:1px;margin:4px 6px;background:var(--stroke)}

/* Khung nội dung */
/* Các mục xếp chồng cùng một ô lưới: khung luôn cao bằng mục dài nhất nên chuyển mục không bị nhảy */
.account-page .account-main{min-width:0;display:grid;grid-template-columns:minmax(0,1fr)}
.account-page .account-card{grid-area:1/1;display:flex;flex-direction:column}
.account-page .account-card[hidden]{display:flex;visibility:hidden;pointer-events:none}
.account-page .account-card-header{padding:14px 22px;border-bottom:1px solid var(--stroke)}
.account-page .account-card-header h2{display:flex;align-items:center;gap:9px;margin:0;font-size:15px;font-weight:800}
.account-page .account-card-header h2:before{content:"";width:4px;height:14px;border-radius:4px;background:var(--text)}
.account-page .account-card-header p{margin:4px 0 0 13px;color:var(--muted);font-size:11px;line-height:1.6}
.account-page .account-card-body{flex:1 1 auto;padding:16px 22px 18px}
.account-page .account-card-body form{display:flex;flex-direction:column;height:100%}

/* Form */
.account-page .account-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px 14px}
.account-page .account-field{min-width:0}
.account-page .account-field.full{grid-column:1/-1}
.account-page .account-field label{display:block;margin-bottom:6px;color:var(--text);font-size:11px;font-weight:700}
.account-page .account-field input,.account-page .account-field textarea{width:100%;min-height:42px;padding:9px 18px;border:1px solid var(--stroke);border-radius:999px;outline:none;background:var(--bg);color:var(--text);font:inherit;font-size:12.5px;transition:border-color .15s,box-shadow .15s}
.account-page .account-field textarea{min-height:64px;padding:11px 18px;border-radius:20px;resize:none;line-height:1.6}
.account-page .account-field input:focus,.account-page .account-field textarea:focus{border-color:var(--line);box-shadow:0 0 0 3px rgba(255,255,255,.07)}
.account-page .account-field input::placeholder{color:#7c7c85}
.account-page .account-field input[readonly]{background:var(--glass-2);color:var(--muted)}
.account-page .account-field input:-webkit-autofill{-webkit-box-shadow:0 0 0 40px var(--bg) inset;-webkit-text-fill-color:var(--text)}
.account-page .account-form-footer{display:flex;align-items:center;flex-wrap:wrap;gap:10px;margin-top:auto;padding-top:16px}
.account-page .account-btn{display:inline-flex;align-items:center;justify-content:center;height:40px;padding:0 22px;border:1.5px solid #f2f2f2;border-radius:999px;background:#f2f2f2;color:#111111;font:inherit;font-size:12px;font-weight:700;text-decoration:none;cursor:pointer;transition:background .2s,transform .2s}
.account-page .account-btn:hover{background:#ffffff;border-color:#ffffff;color:#111111;transform:translateY(-1px)}
.account-page .account-btn.secondary{border-color:var(--line);background:rgba(255,255,255,.08);color:var(--text)}
.account-page .account-btn.secondary:hover{background:rgba(255,255,255,.18);border-color:var(--line);color:var(--text)}

@media(max-width:850px){
    .account-page{justify-content:flex-start}
    .account-page .account-layout{grid-template-columns:1fr}
    .account-page .account-side{display:grid;grid-template-columns:190px minmax(0,1fr)}
    .account-page .account-user{border-right:1px solid var(--stroke);border-bottom:0}
    .account-page .account-nav{align-self:center}
}
@media(max-width:560px){
    .account-page .account-container{width:calc(100% - 28px)}
    .account-page .account-side{display:block}
    .account-page .account-user{border-right:0;border-bottom:1px solid var(--stroke)}
    .account-page .account-form-grid{grid-template-columns:1fr}
    .account-page .account-field.full{grid-column:auto}
    .account-page .account-card-body{padding:14px 16px}
    .account-page .account-card-header{padding:13px 16px}
}
</style>

<main class="account-page">
    <div class="account-container">

        <header class="account-heading">
            <div class="account-heading-text">
                <div class="account-eyebrow">Comic Shop · Thành viên</div>
                <h1 class="account-title">Tài khoản của tôi</h1>
            </div>

            <?php if ($accountUser): ?>
                <div class="account-stats" aria-label="Tổng quan đơn hàng">
                    <div class="account-stat">
                        <span class="account-stat-icon">▤</span>
                        <div>
                            <span class="account-stat-label">Tổng đơn hàng</span>
                            <strong class="account-stat-value"><?= number_format($orderSummary['total']) ?></strong>
                        </div>
                    </div>
                    <div class="account-stat">
                        <span class="account-stat-icon">✓</span>
                        <div>
                            <span class="account-stat-label">Đơn hoàn tất</span>
                            <strong class="account-stat-value"><?= number_format($orderSummary['completed']) ?></strong>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </header>

        <?php if (is_array($accountFlash) && !empty($accountFlash['message'])): ?>
            <div class="account-alert <?= ($accountFlash['type'] ?? '') === 'success' ? 'success' : '' ?>" role="status">
                <?= comic_account_escape($accountFlash['message']) ?>
            </div>
        <?php endif; ?>

        <?php if ($accountErrors): ?>
            <div class="account-alert" role="alert">
                <strong>Không thể hoàn tất thao tác:</strong>
                <ul style="margin:7px 0 0;padding-left:20px">
                    <?php foreach ($accountErrors as $error): ?>
                        <li><?= comic_account_escape($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (!$accountDbReady): ?>
            <div class="account-alert">
                Không tìm thấy kết nối database. Hãy kiểm tra
                <strong>config/db.php</strong> để xác nhận tên biến kết nối.
            </div>
        <?php elseif (!$accountUser): ?>
            <div class="account-alert">
                Không tải được hồ sơ tài khoản. Vui lòng thử lại sau.
            </div>
        <?php else: ?>


            <div class="account-layout">

                <aside class="account-side">
                    <div class="account-user">
                        <div class="account-avatar">
                            <?php if (!empty($accountUser['avatar'])): ?>
                                <img
                                    src="<?= comic_account_escape($accountUser['avatar']) ?>"
                                    alt="Ảnh đại diện"
                                    onerror="this.style.display='none'"
                                >
                            <?php else: ?>
                                <?= comic_account_escape(
                                    function_exists('mb_substr')
                                        ? mb_strtoupper(
                                            mb_substr(
                                                (string)$accountUser['full_name'],
                                                0,
                                                1,
                                                'UTF-8'
                                            ),
                                            'UTF-8'
                                        )
                                        : strtoupper(substr(
                                            (string)$accountUser['full_name'],
                                            0,
                                            1
                                        ))
                                ) ?>
                            <?php endif; ?>
                        </div>

                        <div class="account-user-name">
                            <?= comic_account_escape($accountUser['full_name']) ?>
                        </div>

                        <div class="account-user-email">
                            <?= comic_account_escape($accountUser['email']) ?>
                        </div>
                    </div>

                    <nav class="account-nav" aria-label="Tài khoản" role="tablist">
                        <button type="button" class="nav-btn<?= $accountActiveTab === 'profile' ? ' active' : '' ?>" role="tab" data-tab="profile" aria-selected="<?= $accountActiveTab === 'profile' ? 'true' : 'false' ?>" aria-controls="profile">
                            <span>♙</span> Thông tin cá nhân
                        </button>
                        <button type="button" class="nav-btn<?= $accountActiveTab === 'password' ? ' active' : '' ?>" role="tab" data-tab="password" aria-selected="<?= $accountActiveTab === 'password' ? 'true' : 'false' ?>" aria-controls="password">
                            <span>♢</span> Đổi mật khẩu
                        </button>
                        <a class="nav-btn nav-logout" href="logout.php">
                            <span>⏻</span> Đăng xuất
                        </a>
                        <div class="nav-sep"></div>
                        <a class="nav-btn" href="comics.php">
                            <span>⌕</span> Tiếp tục mua truyện
                        </a>
                    </nav>
                </aside>

                <div class="account-main">

                    <section class="account-card" id="profile" role="tabpanel" data-panel="profile"<?= $accountActiveTab === 'profile' ? '' : ' hidden' ?>>
                        <div class="account-card-header">
                            <h2>Thông tin cá nhân</h2>
                            <p>Cập nhật thông tin liên hệ dùng cho tài khoản và đơn hàng.</p>
                        </div>

                        <div class="account-card-body">
                            <form method="post" action="account.php">
                                <input
                                    type="hidden"
                                    name="csrf_token"
                                    value="<?= comic_account_escape($accountCsrf) ?>"
                                >
                                <input
                                    type="hidden"
                                    name="action"
                                    value="update_profile"
                                >

                                <div class="account-form-grid">
                                    <div class="account-field">
                                        <label for="full-name">Họ và tên *</label>
                                        <input
                                            id="full-name"
                                            type="text"
                                            name="full_name"
                                            maxlength="120"
                                            required
                                            value="<?= comic_account_escape(
                                                $_POST['action'] ?? '' === 'update_profile'
                                                    ? ($_POST['full_name'] ?? $accountUser['full_name'])
                                                    : $accountUser['full_name']
                                            ) ?>"
                                            autocomplete="name"
                                        >
                                    </div>

                                    <div class="account-field">
                                        <label for="email">Địa chỉ email *</label>
                                        <input
                                            id="email"
                                            type="email"
                                            name="email"
                                            maxlength="150"
                                            required
                                            value="<?= comic_account_escape(
                                                ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'
                                                && ($_POST['action'] ?? '') === 'update_profile'
                                                    ? ($_POST['email'] ?? $accountUser['email'])
                                                    : $accountUser['email']
                                            ) ?>"
                                            autocomplete="email"
                                        >
                                    </div>

                                    <div class="account-field">
                                        <label for="phone">Số điện thoại</label>
                                        <input
                                            id="phone"
                                            type="tel"
                                            name="phone"
                                            maxlength="20"
                                            value="<?= comic_account_escape(
                                                ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'
                                                && ($_POST['action'] ?? '') === 'update_profile'
                                                    ? ($_POST['phone'] ?? '')
                                                    : $accountUser['phone']
                                            ) ?>"
                                            autocomplete="tel"
                                        >
                                    </div>

                                    <div class="account-field">
                                        <label for="role">Loại tài khoản</label>
                                        <input
                                            id="role"
                                            type="text"
                                            readonly
                                            value="<?php
                                                $roleLabels = [
                                                    'customer' => 'Khách hàng',
                                                    'staff' => 'Nhân viên',
                                                    'admin' => 'Quản trị viên',
                                                ];
                                                echo comic_account_escape(
                                                    $roleLabels[$accountUser['role']]
                                                    ?? $accountUser['role']
                                                );
                                            ?>"
                                        >
                                    </div>

                                    <div class="account-field full">
                                        <label for="address">Địa chỉ nhận hàng</label>
                                        <textarea
                                            id="address"
                                            name="address"
                                            maxlength="255"
                            rows="2"
                                            autocomplete="street-address"
                                        ><?= comic_account_escape(
                                            ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'
                                            && ($_POST['action'] ?? '') === 'update_profile'
                                                ? ($_POST['address'] ?? '')
                                                : $accountUser['address']
                                        ) ?></textarea>
                                    </div>
                                </div>

                                <div class="account-form-footer">
                                    <button class="account-btn" type="submit">
                                        Lưu thông tin
                                    </button>
                                    <a class="account-btn secondary" href="account.php">
                                        Hủy thay đổi
                                    </a>
                                </div>
                            </form>
                        </div>
                    </section>

                    <section class="account-card" id="password" role="tabpanel" data-panel="password"<?= $accountActiveTab === 'password' ? '' : ' hidden' ?>>
                        <div class="account-card-header">
                            <h2>Bảo mật tài khoản</h2>
                            <p>Sử dụng mật khẩu riêng và khó đoán để bảo vệ tài khoản.</p>
                        </div>

                        <div class="account-card-body">
                            <form method="post" action="account.php">
                                <input
                                    type="hidden"
                                    name="csrf_token"
                                    value="<?= comic_account_escape($accountCsrf) ?>"
                                >
                                <input
                                    type="hidden"
                                    name="action"
                                    value="change_password"
                                >

                                <div class="account-form-grid">
                                    <div class="account-field full">
                                        <label for="current-password">Mật khẩu hiện tại *</label>
                                        <input
                                            id="current-password"
                                            type="password"
                                            name="current_password"
                                            required
                                            autocomplete="current-password"
                                        >
                                    </div>

                                    <div class="account-field">
                                        <label for="new-password">Mật khẩu mới *</label>
                                        <input
                                            id="new-password"
                                            type="password"
                                            name="new_password"
                                            placeholder="Tối thiểu 8 ký tự"
                                            minlength="8"
                                            required
                                            autocomplete="new-password"
                                        >
                                    </div>

                                    <div class="account-field">
                                        <label for="confirm-password">Xác nhận mật khẩu mới *</label>
                                        <input
                                            id="confirm-password"
                                            type="password"
                                            name="confirm_password"
                                            minlength="8"
                                            required
                                            autocomplete="new-password"
                                        >
                                    </div>
                                </div>

                                <div class="account-form-footer">
                                    <button class="account-btn" type="submit">
                                        Đổi mật khẩu
                                    </button>
                                </div>
                            </form>
                        </div>
                    </section>


                </div>
            </div>

        <?php endif; ?>

    </div>
</main>

<script>
(function () {
    'use strict';

    /* Chuyển mục bằng nút bên trái */
    var tabButtons = document.querySelectorAll('.account-nav [data-tab]');
    var panels = document.querySelectorAll('.account-page [data-panel]');

    function showTab(name) {
        var found = false;

        panels.forEach(function (panel) {
            var match = panel.getAttribute('data-panel') === name;
            panel.hidden = !match;
            if (match) { found = true; }
        });

        if (!found) { return; }

        tabButtons.forEach(function (btn) {
            var active = btn.getAttribute('data-tab') === name;
            btn.classList.toggle('active', active);
            btn.setAttribute('aria-selected', active ? 'true' : 'false');
        });
    }

    tabButtons.forEach(function (btn) {
        btn.addEventListener('click', function () {
            showTab(btn.getAttribute('data-tab'));
        });
    });

    if (window.location.hash === '#password') { showTab('password'); }

    var newPassword = document.getElementById('new-password');
    var confirmPassword = document.getElementById('confirm-password');

    if (newPassword && confirmPassword) {
        confirmPassword.addEventListener('input', function () {
            if (
                confirmPassword.value !== '' &&
                confirmPassword.value !== newPassword.value
            ) {
                confirmPassword.setCustomValidity(
                    'Mật khẩu xác nhận không khớp.'
                );
            } else {
                confirmPassword.setCustomValidity('');
            }
        });

        newPassword.addEventListener('input', function () {
            if (confirmPassword.value === newPassword.value) {
                confirmPassword.setCustomValidity('');
            }
        });
    }
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
