<?php
/*
 * COMIC SHOP
 * File: logout.php
 * Đăng xuất khách hàng.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. LƯU THÔNG TIN TRƯỚC KHI ĐĂNG XUẤT
========================================================= */

$userId = 0;

$userIdCandidates = [
    $_SESSION['user']['id'] ?? null,
    $_SESSION['user']['user_id'] ?? null,
    $_SESSION['user_id'] ?? null,
    $_SESSION['customer_id'] ?? null,
    $_SESSION['customer']['id'] ?? null,
];

foreach ($userIdCandidates as $candidate) {
    if (
        (is_int($candidate) ||
            (is_string($candidate) && ctype_digit($candidate))) &&
        (int)$candidate > 0
    ) {
        $userId = (int)$candidate;
        break;
    }
}

$oldSessionId = session_id();

/* =========================================================
   2. NẠP KẾT NỐI DATABASE
========================================================= */

$logoutDb = null;
$dbConfigFile = __DIR__ . '/config/db.php';

if (is_file($dbConfigFile)) {
    $configResult = require_once $dbConfigFile;

    if (
        $configResult instanceof PDO ||
        (class_exists('mysqli') && $configResult instanceof mysqli)
    ) {
        $logoutDb = $configResult;
    }
}

$dbCandidates = [
    $GLOBALS['comic_shop_db'] ?? null,
    $GLOBALS['pdo'] ?? null,
    $GLOBALS['conn'] ?? null,
    $GLOBALS['mysqli'] ?? null,
    $GLOBALS['db'] ?? null,
    $pdo ?? null,
    $conn ?? null,
    $mysqli ?? null,
    $db ?? null,
];

foreach ($dbCandidates as $candidate) {
    if (
        $candidate instanceof PDO ||
        (class_exists('mysqli') && $candidate instanceof mysqli)
    ) {
        $logoutDb = $candidate;
        break;
    }
}

/* =========================================================
   3. TẠO SESSION ID MỚI
========================================================= */

$sessionRegenerated = false;

if (session_status() === PHP_SESSION_ACTIVE) {
    $sessionRegenerated = session_regenerate_id(true);
}

$newSessionId = session_id();

/* =========================================================
   4. GIỮ GIỎ HÀNG CỦA KHÁCH KHI ĐĂNG XUẤT
========================================================= */

/*
 * Bảng cart có các cột:
 * user_id, session_id, comic_id, quantity.
 *
 * Chuyển các mặt hàng của tài khoản thành giỏ hàng khách
 * gắn với session mới, thay vì xóa sản phẩm.
 */

if (
    $userId > 0 &&
    $sessionRegenerated &&
    (
        $logoutDb instanceof PDO ||
        (
            class_exists('mysqli') &&
            $logoutDb instanceof mysqli
        )
    )
) {
    try {
        $sql = 'UPDATE cart
                SET user_id = NULL,
                    session_id = ?
                WHERE user_id = ?
                   OR (
                        user_id IS NULL
                        AND session_id = ?
                   )';

        if ($logoutDb instanceof PDO) {
            $statement = $logoutDb->prepare($sql);

            $statement->execute([
                $newSessionId,
                $userId,
                $oldSessionId,
            ]);

            $statement->closeCursor();

        } elseif ($logoutDb instanceof mysqli) {
            $statement = $logoutDb->prepare($sql);

            if ($statement) {
                $statement->bind_param(
                    'sis',
                    $newSessionId,
                    $userId,
                    $oldSessionId
                );

                $statement->execute();
                $statement->close();
            }
        }

    } catch (Throwable $exception) {
        /*
         * Đăng xuất vẫn phải tiếp tục nếu database gặp lỗi.
         * Không ghi thông tin cá nhân vào thông báo cho người dùng.
         */
        error_log(
            '[Comic Shop Logout] Không thể chuyển giỏ hàng: ' .
            $exception->getMessage()
        );
    }
}

/* =========================================================
   5. XÓA THÔNG TIN ĐĂNG NHẬP KHÁCH HÀNG
========================================================= */

unset(
    $_SESSION['user'],
    $_SESSION['user_id'],
    $_SESSION['customer_id'],
    $_SESSION['customer'],
    $_SESSION['comic_account_csrf'],
    $_SESSION['comic_checkout_csrf'],
    $_SESSION['comic_login_csrf']
);

/*
 * Giữ các dữ liệu session không liên quan đến đăng nhập,
 * ví dụ thông tin giỏ hàng tạm nếu các trang khác sử dụng.
 */

/* =========================================================
   6. CHUYỂN VỀ TRANG CHỦ
========================================================= */

header('Location: index.php', true, 303);
exit;
?>
