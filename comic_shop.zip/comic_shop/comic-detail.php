<?php
declare(strict_types=1);

/**
 * COMIC SHOP
 * File: comic-detail.php
 * Trang chi tiết truyện.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. KẾT NỐI DATABASE
========================================================= */

$dbConfigFile = __DIR__ . '/config/db.php';
$dbConfigReturn = null;

if (is_file($dbConfigFile)) {
    $dbConfigReturn = require_once $dbConfigFile;
}

$detailDb = null;

$detailCandidates = [
    $dbConfigReturn,
    $GLOBALS['comic_shop_db'] ?? null,
    $GLOBALS['pdo'] ?? null,
    $GLOBALS['conn'] ?? null,
    $GLOBALS['mysqli'] ?? null,
    $GLOBALS['db'] ?? null,
    $pdo ?? null,
    $conn ?? null,
    $mysqli ?? null,
    $db ?? null,
];

foreach ($detailCandidates as $candidate) {
    if (
        $candidate instanceof PDO ||
        (class_exists('mysqli') && $candidate instanceof mysqli)
    ) {
        $detailDb = $candidate;
        break;
    }
}

$detailDbReady = $detailDb instanceof PDO ||
    (class_exists('mysqli') && $detailDb instanceof mysqli);

/* =========================================================
   2. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_detail_escape')) {
    function comic_detail_escape($value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_detail_money')) {
    function comic_detail_money($amount): string
    {
        return number_format((float)$amount, 0, ',', '.') . ' ₫';
    }
}

if (!function_exists('comic_detail_query')) {
    function comic_detail_query(
        $database,
        string $sql,
        array $params = []
    ): array {
        if ($database instanceof PDO) {
            $database->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );

            $statement = $database->prepare($sql);
            $statement->execute($params);

            $rows = $statement->columnCount() > 0
                ? $statement->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $affected = $statement->rowCount();

            $statement->closeCursor();

            return [
                'rows' => $rows,
                'affected' => $affected,
            ];
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            $statement = $database->prepare($sql);

            if (!$statement) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn database.'
                );
            }

            if ($params !== []) {
                $types = '';
                $bindParams = [];

                foreach ($params as $param) {
                    if (is_int($param) || is_bool($param)) {
                        $types .= 'i';
                    } elseif (is_float($param)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }
                }

                $bindParams[] = $types;

                foreach ($params as &$param) {
                    $bindParams[] = &$param;
                }

                unset($param);

                if (!call_user_func_array(
                    [$statement, 'bind_param'],
                    $bindParams
                )) {
                    $statement->close();

                    throw new RuntimeException(
                        'Không thể gắn tham số truy vấn.'
                    );
                }
            }

            if (!$statement->execute()) {
                $error = $statement->error;
                $statement->close();

                throw new RuntimeException(
                    $error ?: 'Truy vấn database thất bại.'
                );
            }

            $rows = [];

            if ($statement->field_count > 0) {
                $result = $statement->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $statement->close();

                    throw new RuntimeException(
                        'Không đọc được kết quả truy vấn.'
                    );
                }
            }

            $affected = $statement->affected_rows;
            $statement->close();

            return [
                'rows' => $rows,
                'affected' => $affected,
            ];
        }

        throw new RuntimeException(
            'Không tìm thấy kết nối PDO hoặc MySQLi.'
        );
    }
}

if (!function_exists('comic_detail_resolve_image')) {
    /* Tìm file ảnh thật trên đĩa; thử cả các đuôi jpg/jpeg/png/webp. */
    function comic_detail_resolve_image(string $path): string
    {
        $path = ltrim(str_replace('\\', '/', trim($path)), '/');

        if ($path === '') {
            return '';
        }

        if (preg_match('#^(https?:)?//#i', $path)) {
            return $path;
        }

        if (is_file(__DIR__ . '/' . $path)) {
            return $path;
        }

        $info = pathinfo($path);
        $dir = ($info['dirname'] ?? '.') === '.' ? '' : $info['dirname'] . '/';
        $name = (string)($info['filename'] ?? '');

        /* Chỉ ghi tên file trong DB -> tìm trong assets/images/covers */
        $dirs = [$dir];
        if ($dir === '') {
            $dirs[] = 'assets/images/covers/';
        }

        foreach ($dirs as $tryDir) {
            if (is_file(__DIR__ . '/' . $tryDir . ($info['basename'] ?? ''))) {
                return $tryDir . $info['basename'];
            }

            foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
                $try = $tryDir . $name . '.' . $ext;

                if ($name !== '' && is_file(__DIR__ . '/' . $try)) {
                    return $try;
                }
            }
        }

        return '';
    }
}

if (!function_exists('comic_detail_cover')) {
    /* Ảnh bìa: cover_image -> assets/images/covers/<slug> -> '' */
    function comic_detail_cover(array $comic): string
    {
        $found = comic_detail_resolve_image((string)($comic['cover_image'] ?? ''));

        if ($found === '') {
            $found = comic_detail_resolve_image(
                'assets/images/covers/' . (string)($comic['slug'] ?? '')
            );
        }

        return $found;
    }
}

if (!function_exists('comic_detail_placeholder')) {
    /* Ảnh thay thế dạng SVG (cùng kiểu với trang chủ) khi chưa có ảnh bìa. */
    function comic_detail_placeholder(string $title, int $seed): string
    {
        $palette = ['#3b3b44', '#44404a', '#394248', '#473f3f', '#3f4638'];
        $color = $palette[abs($seed) % count($palette)];

        $words = preg_split('/\s+/u', trim($title)) ?: [];
        $lines = [];
        $line = '';

        foreach ($words as $word) {
            $try = $line === '' ? $word : $line . ' ' . $word;

            if (mb_strlen($try, 'UTF-8') > 14 && $line !== '') {
                $lines[] = $line;
                $line = $word;
            } else {
                $line = $try;
            }
        }

        if ($line !== '') {
            $lines[] = $line;
        }

        $lines = array_slice($lines, 0, 4);

        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600">'
            . '<rect width="400" height="600" fill="' . $color . '"/>'
            . '<rect y="360" width="400" height="150" fill="#141414" opacity=".9"/>'
            . '<rect y="360" width="400" height="5" fill="#f2f2f2"/>'
            . '<text x="200" y="230" fill="#f2f2f2" font-family="Arial,sans-serif" '
            . 'font-weight="800" font-size="120" text-anchor="middle">C.</text>';

        foreach ($lines as $i => $text) {
            $svg .= '<text x="200" y="' . (410 + $i * 26) . '" fill="#fff" '
                . 'font-family="Arial,sans-serif" font-weight="700" font-size="20" '
                . 'text-anchor="middle">'
                . htmlspecialchars(mb_strtoupper($text, 'UTF-8'), ENT_QUOTES, 'UTF-8')
                . '</text>';
        }

        return 'data:image/svg+xml;charset=utf-8,' . rawurlencode($svg . '</svg>');
    }
}

if (!function_exists('comic_detail_image_src')) {
    function comic_detail_image_src(array $comic): string
    {
        $cover = comic_detail_cover($comic);

        return $cover !== ''
            ? $cover
            : comic_detail_placeholder(
                (string)($comic['title'] ?? 'Comic'),
                (int)($comic['id'] ?? 0)
            );
    }
}

if (!function_exists('comic_detail_user_id')) {
    function comic_detail_user_id(): int
    {
        $candidates = [
            $_SESSION['user']['id'] ?? null,
            $_SESSION['user']['user_id'] ?? null,
            $_SESSION['user_id'] ?? null,
            $_SESSION['customer_id'] ?? null,
            $_SESSION['customer']['id'] ?? null,
        ];

        foreach ($candidates as $value) {
            if (
                (is_int($value) ||
                    (is_string($value) && ctype_digit($value))) &&
                (int)$value > 0
            ) {
                return (int)$value;
            }
        }

        return 0;
    }
}

/* =========================================================
   3. LẤY KHÓA TRUYỆN
========================================================= */

$comicKey = trim((string)(
    $_GET['slug'] ?? $_GET['id'] ?? ''
));

$comic = null;
$galleryImages = [];
$reviews = [];
$reviewStarCounts = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];

$reviewFilter = isset($_GET['rating']) ? (int)$_GET['rating'] : 0;

if ($reviewFilter < 1 || $reviewFilter > 5) {
    $reviewFilter = 0;
}

$detailError = '';

if (
    empty($_SESSION['comic_detail_csrf']) ||
    !is_string($_SESSION['comic_detail_csrf'])
) {
    $_SESSION['comic_detail_csrf'] = bin2hex(random_bytes(32));
}

$detailCsrf = $_SESSION['comic_detail_csrf'];

/* =========================================================
   4. TẢI THÔNG TIN TRUYỆN
========================================================= */

if ($detailDbReady && $comicKey !== '') {
    try {
        $detailSelect = '
            SELECT
                c.*,
                cat.name AS category_name,
                cat.slug AS category_slug,
                a.name AS author_name,
                a.slug AS author_slug,
                a.bio AS author_bio,
                p.name AS publisher_name,
                p.slug AS publisher_slug,
                s.title AS series_title,
                s.slug AS series_slug,
                s.status AS series_status
            FROM comics c
            INNER JOIN categories cat
                ON cat.id = c.category_id
            LEFT JOIN authors a
                ON a.id = c.author_id
            LEFT JOIN publishers p
                ON p.id = c.publisher_id
            LEFT JOIN series s
                ON s.id = c.series_id
            WHERE ';

        if (ctype_digit($comicKey)) {
            $comicRows = comic_detail_query(
                $detailDb,
                $detailSelect . 'c.id = ? AND c.is_active = 1 LIMIT 1',
                [(int)$comicKey]
            )['rows'];
        } else {
            $comicRows = comic_detail_query(
                $detailDb,
                $detailSelect . 'c.slug = ? AND c.is_active = 1 LIMIT 1',
                [$comicKey]
            )['rows'];
        }

        $comic = $comicRows[0] ?? null;

        if ($comic) {
            $galleryImages = comic_detail_query(
                $detailDb,
                'SELECT id, image, sort_order
                 FROM comic_images
                 WHERE comic_id = ?
                 ORDER BY sort_order ASC, id ASC',
                [(int)$comic['id']]
            )['rows'];

            $reviewRows = comic_detail_query(
                $detailDb,
                'SELECT
                    r.id,
                    r.rating,
                    r.comment,
                    r.created_at,
                    u.full_name AS reviewer_name
                 FROM reviews r
                 INNER JOIN users u ON u.id = r.user_id
                 WHERE r.comic_id = ?' .
                 ($reviewFilter > 0 ? ' AND r.rating = ?' : '') . '
                 ORDER BY r.created_at DESC, r.id DESC
                 LIMIT 50',
                $reviewFilter > 0
                    ? [(int)$comic['id'], $reviewFilter]
                    : [(int)$comic['id']]
            )['rows'];

            $starCountRows = comic_detail_query(
                $detailDb,
                'SELECT rating, COUNT(*) AS total
                 FROM reviews
                 WHERE comic_id = ?
                 GROUP BY rating',
                [(int)$comic['id']]
            )['rows'];

            foreach ($starCountRows as $starCountRow) {
                $starKey = (int)$starCountRow['rating'];

                if (isset($reviewStarCounts[$starKey])) {
                    $reviewStarCounts[$starKey] = (int)$starCountRow['total'];
                }
            }

            $reviews = $reviewRows;

            /*
             * Lấy thống kê trực tiếp từ bảng reviews để bảo đảm
             * điểm hiển thị phản ánh các đánh giá đang tồn tại.
             */
            $ratingRows = comic_detail_query(
                $detailDb,
                'SELECT
                    COALESCE(ROUND(AVG(rating), 1), 0) AS avg_rating,
                    COUNT(*) AS review_count
                 FROM reviews
                 WHERE comic_id = ?',
                [(int)$comic['id']]
            )['rows'];

            $comic['display_rating'] = (float)(
                $ratingRows[0]['avg_rating'] ?? $comic['rating_avg']
            );

            $comic['display_review_count'] = (int)(
                $ratingRows[0]['review_count'] ?? $comic['review_count']
            );

        } else {
            $detailError =
                'Truyện không tồn tại, đã ngừng bán hoặc đường dẫn không hợp lệ.';
        }

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Detail] ' . $exception->getMessage()
        );

        $detailError =
            'Không thể tải chi tiết truyện. Vui lòng thử lại sau.';
    }

} elseif (!$detailDbReady) {
    $detailError =
        'Chưa kết nối được database. Hãy kiểm tra config/db.php.';

} else {
    $detailError =
        'Vui lòng chọn truyện cần xem.';
}

/* =========================================================
   6. GIÁ BÁN, THÔNG TIN VÀ GIAO DIỆN
========================================================= */

$pageTitle = $comic
    ? (string)$comic['title'] . ' | Comic Shop'
    : 'Chi tiết truyện | Comic Shop';

$pageDescription = $comic
    ? (string)($comic['description'] ?? $comic['title'])
    : 'Chi tiết truyện tại Comic Shop.';

$activeMenu = 'comics';

/* Ẩn icon kính lúp trên thanh header */
$hideHeaderSearch = true;

$regularPrice = $comic ? (float)$comic['price'] : 0.0;

$salePrice = $comic && $comic['sale_price'] !== null
    ? (float)$comic['sale_price']
    : null;

$hasSale = $comic &&
    $salePrice !== null &&
    $salePrice > 0 &&
    $salePrice < $regularPrice;

$currentPrice = $hasSale
    ? (float)$salePrice
    : $regularPrice;

$discountPercent = ($hasSale && $regularPrice > 0)
    ? (int)round((1 - $currentPrice / $regularPrice) * 100)
    : 0;

$coverTypeLabels = [
    'paperback' => 'Bìa mềm',
    'hardcover' => 'Bìa cứng',
    'boxset' => 'Hộp bộ truyện',
];

$ageLabels = [
    'all' => 'Mọi lứa tuổi',
    '13+' => '13+',
    '16+' => '16+',
    '18+' => '18+',
];

$seriesStatusLabels = [
    'ongoing' => 'Đang phát hành',
    'completed' => 'Đã hoàn thành',
    'hiatus' => 'Tạm ngưng',
];

$headerFile = __DIR__ . '/includes/header.php';
$footerFile = __DIR__ . '/includes/footer.php';

if (is_file($headerFile)) {
    require_once $headerFile;
} else {
    ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= comic_detail_escape($pageTitle) ?></title>
        <meta
            name="description"
            content="<?= comic_detail_escape($pageDescription) ?>"
        >
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
    <?php
}
?>

<style>
.comic-detail-page{
    --cd-red:#f2f2f2;
    --cd-ink:#f2f2f2;
    --cd-muted:#a9a9b2;
    --cd-border:#3d3d44;
    padding:0 0 55px;
    min-height:100vh;
    background:#1c1c1f;
    color:var(--cd-ink);
    font-family:"Inter","Montserrat",system-ui,-apple-system,"Segoe UI",Arial,sans-serif;
}
.comic-detail-page *{box-sizing:border-box}
body:has(.comic-detail-page){background:#1c1c1f}
body:has(.comic-detail-page) footer{display:none!important}
.comic-detail-page a{color:inherit;text-decoration:none}
.comic-detail-page .cd-wrap{
    width:calc(100% - 48px);
    margin-inline:auto;
    padding-top:6px;
}
.comic-detail-page .cd-breadcrumb{
    display:flex;
    align-items:center;
    flex-wrap:wrap;
    gap:9px;
    padding:12px 0;
    color:#a9a9b2;
    font-size:11px;
}
.comic-detail-page .cd-breadcrumb a:hover{color:var(--cd-red)}
.comic-detail-page .cd-alert{
    margin-bottom:18px;
    padding:13px 15px;
    border:1px solid #3d3d44;
    border-left:4px solid var(--cd-red);
    10px;
    background:#2c2c31;
    color:#f2f2f2;
    font-size:12px;
    line-height:1.7;
}
.comic-detail-page .cd-alert.success{
    border-color:#3d3d44;
    border-left-color:#f2f2f2;
    background:#2c2c31;
    color:#f2f2f2;
}
.comic-detail-page .cd-product{
    display:grid;
    grid-template-columns:minmax(220px,calc((100vh - 230px) * .75)) minmax(0,1fr);
    gap:32px;
    align-items:stretch;
    padding-bottom:24px;
}
.comic-detail-page .cd-gallery{
    min-width:0;
    display:flex;
    flex-direction:column;
}
.comic-detail-page .cd-main-image{
    position:relative;
    aspect-ratio:3/4;
    flex:1 1 auto;
    display:flex;
    align-items:center;
    justify-content:center;
    width:100%;
    min-height:0;
    overflow:hidden;
    border:1px solid var(--cd-border);
    border-radius:24px;
    background:
        #232327;
}
.comic-detail-page .cd-main-image img{
    position:absolute;
    inset:0;
    display:block;
    width:100%;
    height:100%;
    object-fit:cover;
    transition:opacity .15s;
}
.comic-detail-page .cd-badges{
    position:absolute;
    top:14px;
    left:14px;
    display:flex;
    flex-wrap:wrap;
    gap:7px;
}
.comic-detail-page .cd-badge{
    display:inline-flex;
    align-items:center;
    padding:6px 9px;
    border-radius:4px;
    background:var(--cd-red);
    color:#111111;
    font-size:10px;
    font-weight:900;
}
.comic-detail-page .cd-badge.dark{background:#55555e;color:#f2f2f2}
.comic-detail-page .cd-gallery-thumbs{
    display:flex;
    flex-wrap:wrap;
    gap:7px;
    margin-top:8px;
}
.comic-detail-page .cd-thumb{
    display:flex;
    width:48px;
    height:56px;
    align-items:center;
    justify-content:center;
    overflow:hidden;
    padding:0;
    border:1px solid #3d3d44;
    border-radius:10px;
    background:#2c2c31;
    cursor:pointer;
    transition:border-color .15s;
}
.comic-detail-page .cd-thumb.active,
.comic-detail-page .cd-thumb:hover{border:2px solid var(--cd-red)}
.comic-detail-page .cd-thumb img{
    display:block;
    width:100%;
    height:100%;
    object-fit:cover;
}
.comic-detail-page .cd-info{min-width:0}
.comic-detail-page .cd-category{
    display:inline-flex;
    margin-bottom:8px;
    padding:5px 9px;
    border-radius:4px;
    background:#2c2c31;
    color:#f2f2f2;
    font-size:10px;
    font-weight:900;
    letter-spacing:.5px;
    text-transform:uppercase;
}
.comic-detail-page .cd-title{
    margin:0 0 8px;
    color:#f2f2f2;
    font-size:clamp(22px,2.4vw,30px);
    font-weight:950;
    letter-spacing:-.8px;
    line-height:1.22;
    overflow-wrap:anywhere;
}
.comic-detail-page .cd-rating{
    display:flex;
    align-items:center;
    flex-wrap:wrap;
    gap:9px;
    margin-bottom:12px;
    color:#a9a9b2;
    font-size:11px;
}
.comic-detail-page .cd-stars{
    color:#f2f2f2;
    font-size:17px;
    letter-spacing:1px;
    white-space:nowrap;
}
.comic-detail-page .cd-dot{
    width:4px;
    height:4px;
    border-radius:50%;
    background:#6a6a73;
}
.comic-detail-page .cd-price-box{
    padding:12px 16px;
    border:1px solid #3d3d44;
    border-radius:18px;
    background:#232327;
}
.comic-detail-page .cd-price-row{
    display:flex;
    align-items:center;
    flex-wrap:wrap;
    gap:11px;
}
.comic-detail-page .cd-price{
    color:var(--cd-red);
    font-size:26px;
    font-weight:950;
    letter-spacing:-.6px;
}
.comic-detail-page .cd-old-price{
    color:#a9a9b2;
    font-size:14px;
    text-decoration:line-through;
}
.comic-detail-page .cd-save{
    display:inline-flex;
    padding:5px 7px;
    border-radius:4px;
    background:#2c2c31;
    color:#f2f2f2;
    font-size:10px;
    font-weight:900;
}
.comic-detail-page .cd-stock{
    display:flex;
    align-items:center;
    flex-wrap:wrap;
    gap:7px;
    margin-top:6px;
    color:#a9a9b2;
    font-size:11px;
}
.comic-detail-page .cd-stock-dot{
    width:7px;
    height:7px;
    border-radius:50%;
    background:#f2f2f2;
}
.comic-detail-page .cd-stock.out .cd-stock-dot{background:var(--cd-red)}
.comic-detail-page .cd-description{
    margin:12px 0;
    color:#a9a9b2;
    font-size:13px;
    line-height:1.7;
    white-space:pre-line;
    overflow-wrap:anywhere;
}
.comic-detail-page .cd-purchase{
    display:flex;
    align-items:center;
    flex-wrap:wrap;
    gap:10px;
    margin-bottom:12px;
}
.comic-detail-page .cd-quantity{
    display:flex;
    align-items:center;
    overflow:hidden;
    border:1px solid #3d3d44;
    border-radius:999px;
}
.comic-detail-page .cd-quantity button{
    width:37px;
    height:38px;
    border:0;
    background:#2c2c31;
    color:#f2f2f2;
    font-size:19px;
    cursor:pointer;
}
.comic-detail-page .cd-quantity button:hover{color:var(--cd-red)}
.comic-detail-page .cd-quantity input{
    width:44px;
    height:38px;
    border:0;
    border-right:1px solid #3d3d44;
    border-left:1px solid #3d3d44;
    outline:none;
    background:#2c2c31;
    color:#f2f2f2;
    text-align:center;
    font:inherit;
    font-size:12px;
    font-weight:900;
    appearance:textfield;
    -moz-appearance:textfield;
}
.comic-detail-page .cd-quantity input::-webkit-inner-spin-button,
.comic-detail-page .cd-quantity input::-webkit-outer-spin-button{
    margin:0;
    -webkit-appearance:none;
}
.comic-detail-page .cd-btn{
    display:inline-flex;
    min-height:38px;
    align-items:center;
    justify-content:center;
    gap:8px;
    padding:8px 16px;
    border:1px solid transparent;
    border-radius:999px;
    background:#f2f2f2;
    color:#111111;
    font-size:12px;
    font-weight:800;
    text-decoration:none;
    cursor:pointer;
    transition:background .2s,transform .2s;
}
.comic-detail-page .cd-btn:hover{background:#ffffff;color:#111111;transform:translateY(-1px)}
.comic-detail-page .cd-btn.secondary{
    border-color:rgba(255,255,255,.38);
    background:transparent;
    color:#f2f2f2;
}
.comic-detail-page .cd-btn.secondary:hover{
    border-color:#f2f2f2;
    background:rgba(255,255,255,.12);
    color:#f2f2f2;
}
.comic-detail-page .cd-btn:disabled{
    opacity:.5;
    cursor:not-allowed;
}
.comic-detail-page .cd-specs{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:0 20px;
    padding-top:6px;
    border-top:1px solid var(--cd-border);
}
.comic-detail-page .cd-spec{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    gap:10px;
    padding:6px 0;
    border-bottom:1px solid #2c2c31;
    font-size:11px;
    line-height:1.4;
}
.comic-detail-page .cd-spec-label{color:#a9a9b2}
.comic-detail-page .cd-spec-value{
    color:#f2f2f2;
    font-weight:800;
    text-align:right;
    overflow-wrap:anywhere;
}
.comic-detail-page .cd-section{
    margin-top:37px;
    padding-top:25px;
    border-top:1px solid var(--cd-border);
}
.comic-detail-page .cd-section-head{
    display:flex;
    justify-content:space-between;
    align-items:flex-end;
    flex-wrap:wrap;
    gap:12px;
    margin-bottom:21px;
}
.comic-detail-page .cd-section-head h2{
    margin:0;
    color:#f2f2f2;
    font-size:23px;
    font-weight:950;
    letter-spacing:-.4px;
}
.comic-detail-page .cd-section-sub{
    margin-top:6px;
    color:#a9a9b2;
    font-size:11px;
    line-height:1.7;
}
.comic-detail-page .cd-content-text{
    color:#c9c9d0;
    font-size:13px;
    line-height:2;
    white-space:pre-line;
    overflow-wrap:anywhere;
}
.comic-detail-page .cd-reviews{
    display:grid;
    grid-template-columns:230px minmax(0,1fr);
    gap:24px;
    align-items:start;
}
.comic-detail-page .cd-rating-summary{
    padding:22px;
    border:1px solid var(--cd-border);
    border-radius:18px;
    background:#2c2c31;
    text-align:center;
}
.comic-detail-page .cd-big-rating{
    margin:7px 0;
    color:#f2f2f2;
    font-size:40px;
    font-weight:950;
}
.comic-detail-page .cd-rating-summary .cd-stars{font-size:20px}
.comic-detail-page .cd-rating-count{
    margin-top:7px;
    color:#a9a9b2;
    font-size:11px;
}
.comic-detail-page .cd-review-list{min-width:0}
.comic-detail-page .cd-review-scroll{max-height:210px;overflow-y:auto;padding-right:10px;scrollbar-width:thin;scrollbar-color:#55555e transparent}
.comic-detail-page .cd-review-scroll::-webkit-scrollbar{width:8px}
.comic-detail-page .cd-review-scroll::-webkit-scrollbar-thumb{background:#55555e;border-radius:10px}
.comic-detail-page .cd-review-scroll::-webkit-scrollbar-track{background:transparent}
.comic-detail-page .cd-review-filter{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px}
.comic-detail-page .cd-review-filter a{display:inline-flex;align-items:center;min-height:32px;padding:6px 14px;border:1px solid #3d3d44;border-radius:999px;background:#2c2c31;color:#a9a9b2;font-size:11px;font-weight:700;transition:background .2s,color .2s,border-color .2s}
.comic-detail-page .cd-review-filter a:hover{border-color:#6b6b74;color:#f2f2f2}
.comic-detail-page .cd-review-filter a.active{border-color:#f2f2f2;background:#f2f2f2;color:#111111}
.comic-detail-page .cd-review{
    padding:17px 0;
    border-bottom:1px solid #3d3d44;
}
.comic-detail-page .cd-review:first-child{padding-top:0}
.comic-detail-page .cd-review-head{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    flex-wrap:wrap;
    gap:8px;
}
.comic-detail-page .cd-reviewer{
    color:#f2f2f2;
    font-size:12px;
    font-weight:900;
}
.comic-detail-page .cd-review-date{
    margin-top:4px;
    color:#a9a9b2;
    font-size:10px;
}
.comic-detail-page .cd-review-stars{
    color:#f2f2f2;
    font-size:14px;
    letter-spacing:.5px;
}
.comic-detail-page .cd-review-comment{
    margin-top:11px;
    color:#c9c9d0;
    font-size:12px;
    line-height:1.8;
    white-space:pre-line;
    overflow-wrap:anywhere;
}
.comic-detail-page .cd-review-form{
    margin-top:22px;
    padding:20px;
    border:1px solid var(--cd-border);
    border-radius:18px;
    background:#2c2c31;
}
.comic-detail-page .cd-review-form h3{
    margin:0 0 6px;
    font-size:15px;
    font-weight:900;
}
.comic-detail-page .cd-form-help{
    margin:0 0 17px;
    color:#a9a9b2;
    font-size:11px;
    line-height:1.7;
}
.comic-detail-page .cd-field{margin-bottom:15px}
.comic-detail-page .cd-field label{
    display:block;
    margin-bottom:7px;
    color:#d6d6db;
    font-size:11px;
    font-weight:850;
}
.comic-detail-page .cd-field select,
.comic-detail-page .cd-field textarea{
    box-sizing:border-box;
    width:100%;
    padding:10px 12px;
    border:1px solid #3d3d44;
    border-radius:6px;
    outline:none;
    background:#2c2c31;
    color:#f2f2f2;
    font:inherit;
    font-size:12px;
}
.comic-detail-page .cd-field textarea{
    min-height:100px;
    resize:vertical;
    line-height:1.7;
}
.comic-detail-page .cd-field select:focus,
.comic-detail-page .cd-field textarea:focus{
    border-color:var(--cd-red);
    box-shadow:0 0 0 3px rgba(255,255,255,.12);
}
.comic-detail-page .cd-related-grid{
    display:grid;
    grid-template-columns:repeat(4,minmax(0,1fr));
    gap:17px;
}
.comic-detail-page .cd-related-card{
    overflow:hidden;
    border:1px solid #3d3d44;
    border-radius:18px;
    background:#232327;
    transition:transform .2s,box-shadow .2s;
}
.comic-detail-page .cd-related-card:hover{
    transform:translateY(-3px);
    box-shadow:0 14px 30px rgba(0,0,0,.45);
}
.comic-detail-page .cd-related-cover{
    position:relative;
    display:flex;
    align-items:center;
    justify-content:center;
    aspect-ratio:3/4;
    overflow:hidden;
    background:#2c2c31;
}
.comic-detail-page .cd-related-cover img{
    display:block;
    width:100%;
    height:100%;
    object-fit:cover;
    transition:transform .25s;
}
.comic-detail-page .cd-related-card:hover .cd-related-cover img{
    transform:scale(1.04);
}
.comic-detail-page .cd-related-body{padding:13px}
.comic-detail-page .cd-related-name{
    display:-webkit-box;
    min-height:39px;
    overflow:hidden;
    color:#f2f2f2;
    font-size:12px;
    font-weight:900;
    line-height:1.6;
    -webkit-box-orient:vertical;
    -webkit-line-clamp:2;
}
.comic-detail-page .cd-related-card:hover .cd-related-name{color:var(--cd-red)}
.comic-detail-page .cd-related-price{
    margin-top:9px;
    color:var(--cd-red);
    font-size:14px;
    font-weight:950;
}
.comic-detail-page .cd-related-old{
    margin-left:5px;
    color:#a9a9b2;
    font-size:10px;
    font-weight:500;
    text-decoration:line-through;
}
.comic-detail-page .cd-empty{
    padding:48px 22px;
    border:1px solid var(--cd-border);
    border-radius:24px;
    background:#2c2c31;
    text-align:center;
}
.comic-detail-page .cd-empty h1{
    margin:0 0 10px;
    font-size:23px;
    font-weight:950;
}
.comic-detail-page .cd-empty p{
    margin:0 auto 20px;
    color:#a9a9b2;
    font-size:12px;
    line-height:1.8;
}
@media(max-width:850px){
    .comic-detail-page .cd-product{
        grid-template-columns:minmax(240px,340px) minmax(0,1fr);
        gap:25px;
    }
    .comic-detail-page .cd-reviews{grid-template-columns:190px minmax(0,1fr)}
    .comic-detail-page .cd-related-grid{grid-template-columns:repeat(3,minmax(0,1fr))}
}
@media(max-width:650px){
    .comic-detail-page .cd-product{grid-template-columns:1fr;gap:25px}
    .comic-detail-page .cd-gallery{max-width:460px;margin-inline:auto;width:100%}
    .comic-detail-page .cd-main-image{min-height:300px;max-height:480px}
    .comic-detail-page .cd-main-image img{max-height:480px}
        .comic-detail-page .cd-reviews{grid-template-columns:1fr}
    .comic-detail-page .cd-rating-summary{max-width:none}
    .comic-detail-page .cd-related-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media(max-width:390px){
    .comic-detail-page .cd-wrap{width:calc(100% - 26px)}
    .comic-detail-page .cd-specs{grid-template-columns:1fr}
    .comic-detail-page .cd-purchase{align-items:stretch}
    .comic-detail-page .cd-btn{flex:1}
}
</style>

<main class="comic-detail-page">
    <div class="cd-wrap">

        <nav class="cd-breadcrumb" aria-label="Breadcrumb">
            <a href="index.php">Trang chủ</a>
            <span>/</span>
            <a href="comics.php">Truyện tranh</a>

            <?php if ($comic): ?>
                <span>/</span>
                <a href="comics.php?category=<?= rawurlencode((string)$comic['category_slug']) ?>">
                    <?= comic_detail_escape($comic['category_name']) ?>
                </a>
                <span>/</span>
                <span><?= comic_detail_escape($comic['title']) ?></span>
            <?php endif; ?>
        </nav>

        <?php if (!$comic): ?>

            <section class="cd-empty">
                <h1>Không tìm thấy truyện</h1>
                <p><?= comic_detail_escape($detailError) ?></p>
                <a class="cd-btn" href="comics.php">← Quay lại cửa hàng</a>
            </section>

        <?php else: ?>

            <?php
            $stock = (int)$comic['stock'];

            $available = (
                (int)$comic['is_active'] === 1 &&
                $stock > 0
            );

            $mainCover = comic_detail_image_src($comic);

            $coverType = $coverTypeLabels[$comic['cover_type']]
                ?? $comic['cover_type'];

            $ageRating = $ageLabels[$comic['age_rating']]
                ?? $comic['age_rating'];

            $ratingAverage = (float)$comic['display_rating'];
            $reviewCount = (int)$comic['display_review_count'];

            $detailUrl = 'comic-detail.php?slug=' .
                rawurlencode((string)$comic['slug']);

            $releaseDate = !empty($comic['release_date'])
                ? strtotime((string)$comic['release_date'])
                : false;
            ?>

            <section class="cd-product">

                <div class="cd-gallery">
                    <div class="cd-main-image">
                        <img
                            id="cd-main-cover"
                            src="<?= comic_detail_escape($mainCover) ?>"
                            alt="<?= comic_detail_escape($comic['title']) ?>"
                            fetchpriority="high"
                            data-fallback="<?= comic_detail_escape(comic_detail_placeholder((string)$comic['title'], (int)$comic['id'])) ?>"
                            onerror="if(this.dataset.fallback&&this.src!==this.dataset.fallback){this.src=this.dataset.fallback}"
                        >

                        <div class="cd-badges">
                            <?php if ((int)$comic['is_new'] === 1): ?>
                                <span class="cd-badge">MỚI</span>
                            <?php endif; ?>

                            <?php if ($hasSale): ?>
                                <span class="cd-badge dark">
                                    -<?= $discountPercent ?>%
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php
                    $galleryList = [];
                    foreach ($galleryImages as $galleryImage) {
                        $resolved = comic_detail_resolve_image((string)$galleryImage['image']);
                        if ($resolved !== '' && $resolved !== $mainCover) {
                            $galleryList[] = $resolved;
                        }
                    }
                    ?>
                    <?php if ($galleryList): ?>
                        <div class="cd-gallery-thumbs" aria-label="Ảnh sản phẩm">
                            <button type="button" class="cd-thumb active"
                                    data-image="<?= comic_detail_escape($mainCover) ?>"
                                    aria-label="Xem ảnh bìa">
                                <img src="<?= comic_detail_escape($mainCover) ?>" alt="Ảnh bìa">
                            </button>

                            <?php foreach ($galleryList as $galleryUrl): ?>
                                <button type="button" class="cd-thumb"
                                        data-image="<?= comic_detail_escape($galleryUrl) ?>"
                                        aria-label="Xem ảnh sản phẩm">
                                    <img src="<?= comic_detail_escape($galleryUrl) ?>"
                                         alt="Ảnh truyện" loading="lazy"
                                         onerror="this.closest('.cd-thumb').style.display='none'">
                                </button>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="cd-info">
                    <a
                        class="cd-category"
                        href="comics.php?category=<?= rawurlencode((string)$comic['category_slug']) ?>"
                    >
                        <?= comic_detail_escape($comic['category_name']) ?>
                    </a>

                    <h1 class="cd-title">
                        <?= comic_detail_escape($comic['title']) ?>
                    </h1>

                    <div class="cd-rating">
                        <span class="cd-stars" aria-label="Điểm đánh giá">
                            <?php
                            $roundedRating = (int)round($ratingAverage);
                            echo str_repeat('★', max(0, min(5, $roundedRating)));
                            echo str_repeat('☆', 5 - max(0, min(5, $roundedRating)));
                            ?>
                        </span>

                        <span>
                            <?= number_format($ratingAverage, 1) ?>/5
                        </span>

                        <span class="cd-dot"></span>

                        <a href="#reviews">
                            <?= number_format($reviewCount) ?> đánh giá
                        </a>

                        <span class="cd-dot"></span>

                        <span>
                            <?= number_format((int)$comic['sold_count']) ?> lượt bán
                        </span>
                    </div>

                    <div class="cd-price-box">
                        <div class="cd-price-row">
                            <span class="cd-price">
                                <?= comic_detail_money($currentPrice) ?>
                            </span>

                            <?php if ($hasSale): ?>
                                <span class="cd-old-price">
                                    <?= comic_detail_money($regularPrice) ?>
                                </span>

                                <span class="cd-save">
                                    Tiết kiệm <?= $discountPercent ?>%
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="cd-stock <?= $available ? '' : 'out' ?>">
                            <span class="cd-stock-dot"></span>

                            <?php if ($available): ?>
                                <span>Còn hàng · <?= number_format($stock) ?> cuốn</span>
                            <?php else: ?>
                                <span>Hiện đã hết hàng hoặc ngừng bán</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if (!empty($comic['description'])): ?>
                        <div class="cd-description">
                            <?= comic_detail_escape($comic['description']) ?>
                        </div>
                    <?php endif; ?>

                    <form
                        class="cd-purchase"
                        method="post"
                        action="cart.php"
                        id="cd-add-cart"
                    >
                        <input type="hidden" name="action" value="add">

                        <input
                            type="hidden"
                            name="comic_id"
                            value="<?= (int)$comic['id'] ?>"
                        >

                        <div class="cd-quantity">
                            <button
                                type="button"
                                id="cd-quantity-minus"
                                aria-label="Giảm số lượng"
                                <?= !$available ? 'disabled' : '' ?>
                            >−</button>

                            <input
                                type="number"
                                name="quantity"
                                id="cd-quantity"
                                min="1"
                                max="<?= max(1, min(999, $stock)) ?>"
                                value="1"
                                aria-label="Số lượng truyện"
                                <?= !$available ? 'disabled' : '' ?>
                            >

                            <button
                                type="button"
                                id="cd-quantity-plus"
                                aria-label="Tăng số lượng"
                                <?= !$available ? 'disabled' : '' ?>
                            >+</button>
                        </div>

                        <button
                            type="submit"
                            class="cd-btn"
                            <?= !$available ? 'disabled' : '' ?>
                        >
                            + Thêm vào giỏ hàng
                        </button>

                        <a class="cd-btn secondary" href="cart.php">
                            Xem giỏ hàng
                        </a>
                    </form>

                    <div class="cd-specs">
                        <div class="cd-spec">
                            <span class="cd-spec-label">Tác giả</span>
                            <span class="cd-spec-value">
                                <?= comic_detail_escape(
                                    $comic['author_name'] ?: 'Đang cập nhật'
                                ) ?>
                            </span>
                        </div>

                        <div class="cd-spec">
                            <span class="cd-spec-label">Nhà xuất bản</span>
                            <span class="cd-spec-value">
                                <?= comic_detail_escape(
                                    $comic['publisher_name'] ?: 'Đang cập nhật'
                                ) ?>
                            </span>
                        </div>

                        <div class="cd-spec">
                            <span class="cd-spec-label">Bộ truyện</span>
                            <span class="cd-spec-value">
                                <?php if (!empty($comic['series_title'])): ?>
                                    <a
                                        href="comics.php?series=<?= rawurlencode((string)$comic['series_slug']) ?>"
                                        style="color:#f2f2f2"
                                    >
                                        <?= comic_detail_escape($comic['series_title']) ?>
                                    </a>
                                <?php else: ?>
                                    Độc lập
                                <?php endif; ?>
                            </span>
                        </div>

                        <div class="cd-spec">
                            <span class="cd-spec-label">Tập số</span>
                            <span class="cd-spec-value">
                                <?= $comic['volume_number'] !== null
                                    ? (int)$comic['volume_number']
                                    : 'Không áp dụng' ?>
                            </span>
                        </div>

                        <div class="cd-spec">
                            <span class="cd-spec-label">Hình thức</span>
                            <span class="cd-spec-value">
                                <?= comic_detail_escape($coverType) ?>
                            </span>
                        </div>

                        <div class="cd-spec">
                            <span class="cd-spec-label">Độ tuổi</span>
                            <span class="cd-spec-value">
                                <?= comic_detail_escape($ageRating) ?>
                            </span>
                        </div>

                        <div class="cd-spec">
                            <span class="cd-spec-label">Số trang</span>
                            <span class="cd-spec-value">
                                <?= $comic['pages'] !== null
                                    ? number_format((int)$comic['pages'])
                                    : 'Đang cập nhật' ?>
                            </span>
                        </div>

                        <div class="cd-spec">
                            <span class="cd-spec-label">Ngôn ngữ</span>
                            <span class="cd-spec-value">
                                <?= comic_detail_escape($comic['language']) ?>
                            </span>
                        </div>

                        <div class="cd-spec">
                            <span class="cd-spec-label">ISBN</span>
                            <span class="cd-spec-value">
                                <?= comic_detail_escape(
                                    $comic['isbn'] ?: 'Đang cập nhật'
                                ) ?>
                            </span>
                        </div>

                        <div class="cd-spec">
                            <span class="cd-spec-label">Ngày phát hành</span>
                            <span class="cd-spec-value">
                                <?= $releaseDate
                                    ? comic_detail_escape(date('d/m/Y', $releaseDate))
                                    : 'Đang cập nhật' ?>
                            </span>
                        </div>
                    </div>

                </div>

            </section>

            <?php if (!empty($comic['content'])): ?>
                <section class="cd-section" id="description">
                    <div class="cd-section-head">
                        <div>
                            <h2>Giới thiệu nội dung</h2>
                            <div class="cd-section-sub">
                                Thông tin chi tiết về cuốn truyện
                            </div>
                        </div>
                    </div>

                    <div class="cd-content-text">
                        <?= comic_detail_escape($comic['content']) ?>
                    </div>
                </section>
            <?php endif; ?>

            <section class="cd-section" id="reviews">
                <div class="cd-section-head">
                    <div>
                        <h2>Đánh giá từ khách hàng</h2>
                        <div class="cd-section-sub">
                            Nhận xét của độc giả đã để lại đánh giá cho cuốn truyện này.
                        </div>
                    </div>
                </div>

                <div class="cd-reviews">
                    <div class="cd-rating-summary">
                        <div class="cd-rating-count">Điểm trung bình</div>

                        <div class="cd-big-rating">
                            <?= number_format($ratingAverage, 1) ?>
                        </div>

                        <div class="cd-stars">
                            <?php
                            $summaryStars = (int)round($ratingAverage);
                            echo str_repeat('★', max(0, min(5, $summaryStars)));
                            echo str_repeat('☆', 5 - max(0, min(5, $summaryStars)));
                            ?>
                        </div>

                        <div class="cd-rating-count">
                            <?= number_format($reviewCount) ?> đánh giá
                        </div>
                    </div>

                    <div class="cd-review-list">
                        <div class="cd-review-filter" aria-label="Lọc đánh giá theo số sao">
                            <a
                                href="<?= comic_detail_escape($detailUrl) ?>#reviews"
                                class="<?= $reviewFilter === 0 ? 'active' : '' ?>"
                            >
                                Tất cả (<?= number_format($reviewCount) ?>)
                            </a>

                            <?php for ($filterStar = 5; $filterStar >= 1; $filterStar--): ?>
                                <a
                                    href="<?= comic_detail_escape($detailUrl) ?>&amp;rating=<?= $filterStar ?>#reviews"
                                    class="<?= $reviewFilter === $filterStar ? 'active' : '' ?>"
                                >
                                    <?= $filterStar ?> ★ (<?= number_format($reviewStarCounts[$filterStar]) ?>)
                                </a>
                            <?php endfor; ?>
                        </div>

                        <div class="cd-review-scroll">
                        <?php if (!$reviews): ?>

                            <div style="padding:20px;border:1px solid #3d3d44;border-radius:18px;background:#232327;color:#a9a9b2;font-size:12px;line-height:1.8">
                                <?= $reviewFilter > 0
                                    ? 'Chưa có đánh giá ' . $reviewFilter . ' sao nào cho truyện này.'
                                    : 'Chưa có đánh giá nào cho truyện này.' ?>
                            </div>

                        <?php else: ?>

                            <?php foreach ($reviews as $review): ?>
                                <?php
                                $reviewStars = max(
                                    1,
                                    min(5, (int)$review['rating'])
                                );

                                $reviewTimestamp = strtotime(
                                    (string)$review['created_at']
                                );
                                ?>

                                <article class="cd-review">
                                    <div class="cd-review-head">
                                        <div>
                                            <div class="cd-reviewer">
                                                <?= comic_detail_escape(
                                                    $review['reviewer_name']
                                                ) ?>
                                            </div>

                                            <div class="cd-review-date">
                                                <?= $reviewTimestamp
                                                    ? comic_detail_escape(
                                                        date('d/m/Y H:i', $reviewTimestamp)
                                                    )
                                                    : '' ?>
                                            </div>
                                        </div>

                                        <div
                                            class="cd-review-stars"
                                            aria-label="<?= $reviewStars ?> trên 5 sao"
                                        >
                                            <?= str_repeat('★', $reviewStars) .
                                                str_repeat('☆', 5 - $reviewStars) ?>
                                        </div>
                                    </div>

                                    <?php if (trim((string)$review['comment']) !== ''): ?>
                                        <div class="cd-review-comment">
                                            <?= comic_detail_escape($review['comment']) ?>
                                        </div>
                                    <?php endif; ?>
                                </article>
                            <?php endforeach; ?>

                        <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="cd-review-form">
                    <h3>Muốn đánh giá cuốn truyện này?</h3>

                    <p class="cd-form-help">
                        Bạn chỉ có thể đánh giá sau khi đơn hàng chứa truyện
                        này đã hoàn tất. Vào mục Đơn hàng của tôi để gửi đánh giá.
                    </p>

                    <a
                        class="cd-btn"
                        href="<?= comic_detail_user_id() > 0
                            ? 'my-orders.php?status=completed'
                            : 'login.php?redirect=' . rawurlencode('my-orders.php?status=completed') ?>"
                    >
                        <?= comic_detail_user_id() > 0
                            ? 'Đến đơn hàng đã hoàn tất'
                            : 'Đăng nhập' ?>
                    </a>
                </div>
            </section>

        <?php endif; ?>

    </div>
</main>

<script>
(function () {
    'use strict';

    /* Thay ảnh chính khi người dùng chọn ảnh thu nhỏ. */
    var mainImage = document.getElementById('cd-main-cover');

    document.querySelectorAll('.cd-thumb[data-image]').forEach(function (button) {
        button.addEventListener('click', function () {
            var imageUrl = button.getAttribute('data-image');

            if (!mainImage || !imageUrl) {
                return;
            }

            mainImage.src = imageUrl;

            document.querySelectorAll('.cd-thumb').forEach(function (thumb) {
                thumb.classList.remove('active');
            });

            button.classList.add('active');
        });
    });

    /* Nút tăng giảm số lượng. */
    var quantityInput = document.getElementById('cd-quantity');
    var minusButton = document.getElementById('cd-quantity-minus');
    var plusButton = document.getElementById('cd-quantity-plus');

    function syncQuantityButtons() {
        if (!quantityInput) {
            return;
        }

        var min = Math.max(1, parseInt(quantityInput.min || '1', 10));
        var max = Math.max(min, parseInt(quantityInput.max || '1', 10));
        var value = parseInt(quantityInput.value || '1', 10);

        if (!Number.isFinite(value)) {
            value = min;
        }

        value = Math.min(max, Math.max(min, value));
        quantityInput.value = String(value);

        if (minusButton) {
            minusButton.disabled = value <= min;
        }

        if (plusButton) {
            plusButton.disabled = value >= max;
        }
    }

    if (quantityInput) {
        quantityInput.addEventListener('change', syncQuantityButtons);
        quantityInput.addEventListener('input', syncQuantityButtons);
        syncQuantityButtons();
    }

    if (minusButton && quantityInput) {
        minusButton.addEventListener('click', function () {
            quantityInput.value = String(
                parseInt(quantityInput.value || '1', 10) - 1
            );

            syncQuantityButtons();
        });
    }

    if (plusButton && quantityInput) {
        plusButton.addEventListener('click', function () {
            quantityInput.value = String(
                parseInt(quantityInput.value || '1', 10) + 1
            );

            syncQuantityButtons();
        });
    }
})();
</script>

<?php
if (is_file($footerFile)) {
    require_once $footerFile;
} else {
    echo '</body></html>';
}
?>
