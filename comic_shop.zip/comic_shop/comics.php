<?php
/*
 * COMIC SHOP
 * File: comics.php
 * Trang danh sách truyện đã được gộp vào trang chủ (index.php#catalog).
 * File này chỉ chuyển hướng, giữ nguyên các tham số lọc
 * (category, filter, q, sort, page...) để mọi liên kết cũ vẫn hoạt động.
 */

$query = (string)($_SERVER['QUERY_STRING'] ?? '');

header(
    'Location: index.php' . ($query !== '' ? '?' . $query : '') . '#catalog',
    true,
    302
);
exit;
