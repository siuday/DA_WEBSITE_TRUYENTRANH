<?php
declare(strict_types=1);

/**
 * COMIC SHOP
 * File: checkout.php
 * Thanh toán và tạo đơn hàng.
 *
 * Sử dụng các bảng có sẵn:
 * cart, comics, orders, order_items, users.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. KẾT NỐI DATABASE
========================================================= */

$dbConfigFile = __DIR__ . '/config/db.php';
$dbConfigReturn = null;

if (is_file($dbConfigFile)) {
    $dbConfigReturn = require_once $dbConfigFile;
}

$checkoutDb = null;

$checkoutCandidates = [
    $dbConfigReturn,
    $GLOBALS['comic_shop_db'] ?? null,
    $GLOBALS['pdo'] ?? null,
    $GLOBALS['conn'] ?? null,
    $GLOBALS['mysqli'] ?? null,
    $GLOBALS['db'] ?? null,
    $pdo ?? null,
    $conn ?? null,
    $mysqli ?? null,
    $db ?? null,
];

foreach ($checkoutCandidates as $candidate) {
    if (
        $candidate instanceof PDO ||
        (class_exists('mysqli') && $candidate instanceof mysqli)
    ) {
        $checkoutDb = $candidate;
        break;
    }
}

$checkoutDbReady = $checkoutDb instanceof PDO ||
    (class_exists('mysqli') && $checkoutDb instanceof mysqli);

/* =========================================================
   2. HÀM HỖ TRỢ DATABASE
========================================================= */

if (!function_exists('comic_checkout_escape')) {
    function comic_checkout_escape($value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_checkout_money')) {
    function comic_checkout_money($amount): string
    {
        return number_format((float)$amount, 0, ',', '.') . ' ₫';
    }
}

/*
 * Phí giao hàng: mặc định 30.000 đ,
 * miễn phí khi giá trị hàng lớn hơn 500.000 đ.
 */
if (!defined('COMIC_SHIPPING_FEE')) {
    define('COMIC_SHIPPING_FEE', 30000);
}

if (!defined('COMIC_FREE_SHIP_THRESHOLD')) {
    define('COMIC_FREE_SHIP_THRESHOLD', 500000);
}

if (!function_exists('comic_checkout_shipping')) {
    function comic_checkout_shipping($subtotal): float
    {
        $subtotal = (float)$subtotal;

        if ($subtotal <= 0 || $subtotal > COMIC_FREE_SHIP_THRESHOLD) {
            return 0.0;
        }

        return (float)COMIC_SHIPPING_FEE;
    }
}

if (!function_exists('comic_checkout_query')) {
    function comic_checkout_query(
        $database,
        string $sql,
        array $params = []
    ): array {
        if ($database instanceof PDO) {
            $database->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );

            $statement = $database->prepare($sql);
            $statement->execute($params);

            $rows = $statement->columnCount() > 0
                ? $statement->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $affected = $statement->rowCount();
            $insertId = $database->lastInsertId();

            $statement->closeCursor();

            return [
                'rows' => $rows,
                'affected' => $affected,
                'insert_id' => $insertId,
            ];
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            $statement = $database->prepare($sql);

            if (!$statement) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn database.'
                );
            }

            if ($params !== []) {
                $types = '';
                $bindParams = [];

                foreach ($params as $param) {
                    if (is_int($param) || is_bool($param)) {
                        $types .= 'i';
                    } elseif (is_float($param)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }
                }

                $bindParams[] = $types;

                foreach ($params as &$param) {
                    $bindParams[] = &$param;
                }

                unset($param);

                if (!call_user_func_array(
                    [$statement, 'bind_param'],
                    $bindParams
                )) {
                    $statement->close();

                    throw new RuntimeException(
                        'Không thể gắn tham số truy vấn.'
                    );
                }
            }

            if (!$statement->execute()) {
                $error = $statement->error;
                $statement->close();

                throw new RuntimeException(
                    $error ?: 'Truy vấn database thất bại.'
                );
            }

            $rows = [];

            if ($statement->field_count > 0) {
                $result = $statement->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $statement->close();

                    throw new RuntimeException(
                        'Không đọc được kết quả truy vấn.'
                    );
                }
            }

            $affected = $statement->affected_rows;
            $insertId = $statement->insert_id;

            $statement->close();

            return [
                'rows' => $rows,
                'affected' => $affected,
                'insert_id' => $insertId,
            ];
        }

        throw new RuntimeException(
            'Không tìm thấy kết nối PDO hoặc MySQLi.'
        );
    }
}

if (!function_exists('comic_checkout_begin')) {
    function comic_checkout_begin($database): void
    {
        if ($database instanceof PDO) {
            $database->beginTransaction();
            return;
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            $database->begin_transaction();
            return;
        }

        throw new RuntimeException(
            'Không thể bắt đầu giao dịch database.'
        );
    }
}

if (!function_exists('comic_checkout_commit')) {
    function comic_checkout_commit($database): void
    {
        if ($database instanceof PDO) {
            $database->commit();
            return;
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            if (!$database->commit()) {
                throw new RuntimeException(
                    'Không thể hoàn tất giao dịch database.'
                );
            }

            return;
        }
    }
}

if (!function_exists('comic_checkout_rollback')) {
    function comic_checkout_rollback($database): void
    {
        if ($database instanceof PDO) {
            if ($database->inTransaction()) {
                $database->rollBack();
            }
            return;
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            $database->rollback();
        }
    }
}

/* =========================================================
   3. LẤY THÔNG TIN NGƯỜI DÙNG
========================================================= */

if (!function_exists('comic_checkout_user_id')) {
    function comic_checkout_user_id(): int
    {
        $candidates = [
            $_SESSION['user']['id'] ?? null,
            $_SESSION['user']['user_id'] ?? null,
            $_SESSION['user_id'] ?? null,
            $_SESSION['customer_id'] ?? null,
            $_SESSION['customer']['id'] ?? null,
        ];

        foreach ($candidates as $value) {
            if (
                (is_int($value) ||
                    (is_string($value) && ctype_digit($value))) &&
                (int)$value > 0
            ) {
                return (int)$value;
            }
        }

        return 0;
    }
}

if (!function_exists('comic_checkout_owner')) {
    function comic_checkout_owner(): array
    {
        $userId = comic_checkout_user_id();
        $sessionId = session_id();

        if ($userId > 0) {
            return [
                '(cart.user_id = ? OR cart.session_id = ?)',
                [$userId, $sessionId],
            ];
        }

        return [
            '(cart.user_id IS NULL AND cart.session_id = ?)',
            [$sessionId],
        ];
    }
}

/* =========================================================
   4. CSRF VÀ THÔNG BÁO
========================================================= */

if (!function_exists('comic_checkout_flash')) {
    function comic_checkout_flash(
        string $type,
        string $message
    ): void {
        $_SESSION['comic_checkout_flash'] = [
            'type' => $type,
            'message' => $message,
        ];
    }
}

if (!function_exists('comic_checkout_redirect')) {
    function comic_checkout_redirect(string $url = 'checkout.php'): void
    {
        header('Location: ' . $url, true, 303);
        exit;
    }
}

if (
    empty($_SESSION['comic_checkout_csrf']) ||
    !is_string($_SESSION['comic_checkout_csrf'])
) {
    $_SESSION['comic_checkout_csrf'] = bin2hex(random_bytes(32));
}

$checkoutCsrf = $_SESSION['comic_checkout_csrf'];

$checkoutFlash = $_SESSION['comic_checkout_flash'] ?? null;
unset($_SESSION['comic_checkout_flash']);

$checkoutSuccess = $_SESSION['comic_checkout_success'] ?? null;
unset($_SESSION['comic_checkout_success']);

$checkoutErrors = [];

$formData = [
    'full_name' => '',
    'email' => '',
    'phone' => '',
    'address' => '',
    'note' => '',
    'payment_method' => 'cod',
];

$currentUserId = comic_checkout_user_id();
$currentUser = null;

/* =========================================================
   5. ĐIỀN SẴN THÔNG TIN KHÁCH HÀNG ĐĂNG NHẬP
========================================================= */

if ($checkoutDbReady && $currentUserId > 0) {
    try {
        $userRows = comic_checkout_query(
            $checkoutDb,
            'SELECT id, full_name, email, phone, address, is_active
             FROM users
             WHERE id = ?
             LIMIT 1',
            [$currentUserId]
        )['rows'];

        $currentUser = $userRows[0] ?? null;

        if (
            $currentUser &&
            (int)$currentUser['is_active'] !== 1
        ) {
            $currentUser = null;
        }

        if ($currentUser) {
            $formData = [
                'full_name' => (string)$currentUser['full_name'],
                'email' => (string)$currentUser['email'],
                'phone' => (string)($currentUser['phone'] ?? ''),
                'address' => (string)($currentUser['address'] ?? ''),
                'note' => '',
                'payment_method' => 'cod',
            ];
        }
    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Checkout] ' . $exception->getMessage()
        );
    }
}

/* =========================================================
   6. XỬ LÝ ĐẶT HÀNG
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $action = isset($_POST['action']) &&
        is_string($_POST['action'])
        ? $_POST['action']
        : '';

    $postedToken = isset($_POST['csrf_token']) &&
        is_string($_POST['csrf_token'])
        ? $_POST['csrf_token']
        : '';

    if (
        $action !== 'place_order' ||
        !hash_equals($checkoutCsrf, $postedToken)
    ) {
        comic_checkout_flash(
            'error',
            'Phiên làm việc đã hết hạn hoặc biểu mẫu không hợp lệ.'
        );

        comic_checkout_redirect();
    }

    if (!$checkoutDbReady) {
        comic_checkout_flash(
            'error',
            'Chưa kết nối được database. Hãy kiểm tra config/db.php.'
        );

        comic_checkout_redirect();
    }

    $formData = [
        'full_name' => trim((string)($_POST['full_name'] ?? '')),
        'email' => trim((string)($_POST['email'] ?? '')),
        'phone' => trim((string)($_POST['phone'] ?? '')),
        'address' => trim((string)($_POST['address'] ?? '')),
        'note' => trim((string)($_POST['note'] ?? '')),
        'payment_method' => trim(
            (string)($_POST['payment_method'] ?? 'cod')
        ),
    ];

    $fullName = $formData['full_name'];
    $email = $formData['email'];
    $phone = $formData['phone'];
    $address = $formData['address'];
    $note = $formData['note'];
    $paymentMethod = $formData['payment_method'];

    $fullNameLength = function_exists('mb_strlen')
        ? mb_strlen($fullName, 'UTF-8')
        : strlen($fullName);

    if ($fullName === '' || $fullNameLength > 120) {
        $checkoutErrors[] =
            'Họ tên là bắt buộc và không vượt quá 120 ký tự.';
    }

    if (
        $email === '' ||
        strlen($email) > 150 ||
        !filter_var($email, FILTER_VALIDATE_EMAIL)
    ) {
        $checkoutErrors[] = 'Địa chỉ email không hợp lệ.';
    }

    if ($phone === '' || strlen($phone) > 20) {
        $checkoutErrors[] =
            'Số điện thoại là bắt buộc và không vượt quá 20 ký tự.';
    }

    if ($address === '' || strlen($address) > 255) {
        $checkoutErrors[] =
            'Địa chỉ nhận hàng là bắt buộc và không vượt quá 255 ký tự.';
    }

    if (strlen($note) > 5000) {
        $checkoutErrors[] =
            'Ghi chú không được vượt quá 5.000 ký tự.';
    }

    if (!in_array($paymentMethod, ['cod', 'banking'], true)) {
        $checkoutErrors[] =
            'Phương thức thanh toán không hợp lệ.';
    }

    /*
     * Kiểm tra tài khoản đăng nhập vẫn hợp lệ.
     */
    if ($currentUserId > 0 && !$currentUser) {
        $checkoutErrors[] =
            'Không xác minh được tài khoản. Vui lòng đăng nhập lại.';
    }

    $transactionStarted = false;

    try {
        if (!$checkoutErrors) {
            comic_checkout_begin($checkoutDb);
            $transactionStarted = true;

            /*
             * Khóa các dòng giỏ hàng/truyện trong giao dịch.
             * Giá và tồn kho luôn lấy từ database, không tin dữ liệu client.
             */
            [$ownerSql, $ownerParams] = comic_checkout_owner();

            $cartRows = comic_checkout_query(
                $checkoutDb,
                'SELECT
                    cart.id AS cart_id,
                    cart.comic_id,
                    cart.quantity,
                    comics.title,
                    comics.price,
                    comics.sale_price,
                    comics.stock,
                    comics.is_active
                 FROM cart
                 INNER JOIN comics ON comics.id = cart.comic_id
                 WHERE ' . $ownerSql . '
                 ORDER BY cart.id ASC
                 FOR UPDATE',
                $ownerParams
            )['rows'];

            if (!$cartRows) {
                $checkoutErrors[] =
                    'Giỏ hàng đang trống. Hãy chọn truyện trước khi đặt hàng.';
            }

            /*
             * Gộp sản phẩm trùng mã truyện nếu giỏ có nhiều dòng.
             */
            $groupedItems = [];

            foreach ($cartRows as $row) {
                $comicId = (int)$row['comic_id'];

                if (!isset($groupedItems[$comicId])) {
                    $groupedItems[$comicId] = [
                        'comic_id' => $comicId,
                        'title' => (string)$row['title'],
                        'price' => (float)$row['price'],
                        'sale_price' => $row['sale_price'] !== null
                            ? (float)$row['sale_price']
                            : null,
                        'stock' => (int)$row['stock'],
                        'is_active' => (int)$row['is_active'],
                        'quantity' => 0,
                    ];
                }

                $groupedItems[$comicId]['quantity'] +=
                    (int)$row['quantity'];
            }

            /*
             * Kiểm tra tồn kho sau khi đã gộp số lượng.
             */
            foreach ($groupedItems as $item) {
                if ((int)$item['is_active'] !== 1) {
                    $checkoutErrors[] =
                        'Truyện "' . $item['title'] .
                        '" hiện không còn được bán.';

                    continue;
                }

                if ((int)$item['stock'] < 1) {
                    $checkoutErrors[] =
                        'Truyện "' . $item['title'] . '" đã hết hàng.';

                    continue;
                }

                if ((int)$item['quantity'] > (int)$item['stock']) {
                    $checkoutErrors[] =
                        'Truyện "' . $item['title'] .
                        '" chỉ còn ' . (int)$item['stock'] .
                        ' cuốn trong kho; vui lòng điều chỉnh số lượng.';
                }
            }

            $orderTotal = 0.0;
            $pricedItems = [];

            if (!$checkoutErrors) {
                foreach ($groupedItems as $item) {
                    $originalPrice = (float)$item['price'];
                    $salePrice = $item['sale_price'];

                    $unitPrice = (
                        $salePrice !== null &&
                        $salePrice > 0 &&
                        $salePrice < $originalPrice
                    )
                        ? $salePrice
                        : $originalPrice;

                    $quantity = (int)$item['quantity'];
                    $lineTotal = round($unitPrice * $quantity, 2);

                    $item['unit_price'] = $unitPrice;
                    $item['line_total'] = $lineTotal;

                    $pricedItems[] = $item;
                    $orderTotal += $lineTotal;
                }

                $orderSubtotal = round($orderTotal, 2);
                $orderShipping = comic_checkout_shipping($orderSubtotal);
                $orderTotal = round($orderSubtotal + $orderShipping, 2);
            }

            if ($checkoutErrors) {
                comic_checkout_rollback($checkoutDb);
                $transactionStarted = false;

            } else {
                /*
                 * Mã đơn duy nhất, tránh phụ thuộc ID tự tăng.
                 */
                $orderCode = 'CS-' .
                    date('Ymd') . '-' .
                    strtoupper(bin2hex(random_bytes(4)));

                $userIdForOrder = $currentUserId > 0
                    ? $currentUserId
                    : null;

                $orderInsert = comic_checkout_query(
                    $checkoutDb,
                    'INSERT INTO orders
                        (
                            order_code,
                            user_id,
                            full_name,
                            email,
                            phone,
                            address,
                            note,
                            total_amount,
                            payment_method,
                            payment_status,
                            status
                        )
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [
                        $orderCode,
                        $userIdForOrder,
                        $fullName,
                        $email,
                        $phone,
                        $address,
                        $note !== '' ? $note : null,
                        $orderTotal,
                        $paymentMethod,
                        'pending',
                        'pending',
                    ]
                );

                /*
                 * Lấy ID đơn hàng ngay từ kết quả INSERT.
                 * (Trước đây ép kiểu sai: (int)$checkoutDb instanceof PDO
                 * luôn ra false nên $orderId = 0 và đơn bị hủy.)
                 */
                $orderId = (int)($orderInsert['insert_id'] ?? 0);

                if ($orderId < 1) {
                    throw new RuntimeException(
                        'Không lấy được ID đơn hàng vừa tạo.'
                    );
                }

                /*
                 * Lưu chi tiết đơn hàng và giảm tồn kho.
                 */
                foreach ($pricedItems as $item) {
                    comic_checkout_query(
                        $checkoutDb,
                        'INSERT INTO order_items
                            (
                                order_id,
                                comic_id,
                                comic_title,
                                price,
                                quantity,
                                total
                            )
                         VALUES (?, ?, ?, ?, ?, ?)',
                        [
                            $orderId,
                            (int)$item['comic_id'],
                            (string)$item['title'],
                            (float)$item['unit_price'],
                            (int)$item['quantity'],
                            (float)$item['line_total'],
                        ]
                    );

                    $stockUpdate = comic_checkout_query(
                        $checkoutDb,
                        'UPDATE comics
                         SET stock = stock - ?,
                             sold_count = sold_count + ?
                         WHERE id = ?
                           AND stock >= ?
                           AND is_active = 1',
                        [
                            (int)$item['quantity'],
                            (int)$item['quantity'],
                            (int)$item['comic_id'],
                            (int)$item['quantity'],
                        ]
                    );

                    if ((int)$stockUpdate['affected'] !== 1) {
                        throw new RuntimeException(
                            'Tồn kho đã thay đổi trong lúc đặt hàng.'
                        );
                    }
                }

                /*
                 * Chỉ xóa giỏ hàng sau khi đơn hàng và chi tiết
                 * đã được lưu thành công trong cùng giao dịch.
                 */
                [$ownerSql, $ownerParams] = comic_checkout_owner();

                comic_checkout_query(
                    $checkoutDb,
                    'DELETE FROM cart WHERE ' . $ownerSql,
                    $ownerParams
                );

                comic_checkout_commit($checkoutDb);
                $transactionStarted = false;

                $_SESSION['comic_checkout_success'] = [
                    'order_code' => $orderCode,
                    'total_amount' => $orderTotal,
                    'payment_method' => $paymentMethod,
                ];

                $_SESSION['comic_checkout_csrf'] =
                    bin2hex(random_bytes(32));

                comic_checkout_redirect('checkout.php?success=1');
            }
        }

    } catch (Throwable $exception) {
        if ($transactionStarted) {
            try {
                comic_checkout_rollback($checkoutDb);
            } catch (Throwable $rollbackException) {
                error_log(
                    '[Comic Shop Checkout Rollback] ' .
                    $rollbackException->getMessage()
                );
            }

            $transactionStarted = false;
        }

        error_log(
            '[Comic Shop Checkout] ' . $exception->getMessage()
        );

        $checkoutErrors[] =
            'Đặt hàng chưa thành công. Hệ thống đã hủy giao dịch để tránh lưu đơn dở dang. Vui lòng thử lại.';

        $checkoutHost = strtolower((string)($_SERVER['SERVER_NAME'] ?? ''));

        if (in_array($checkoutHost, ['localhost', '127.0.0.1', '::1'], true)) {
            $checkoutErrors[] =
                'Chi tiết lỗi (chỉ hiện trên localhost): ' .
                $exception->getMessage();
        }
    }
}

/* Tìm đường dẫn ảnh bìa thực tế (DB có thể chỉ lưu tên file). */
if (!function_exists('comic_checkout_resolve_image')) {
    function comic_checkout_resolve_image(string $path): string
    {
        $path = ltrim(str_replace('\\', '/', trim($path)), '/');

        if ($path === '') {
            return '';
        }

        if (preg_match('#^(https?:)?//#i', $path)) {
            return $path;
        }

        if (is_file(__DIR__ . '/' . $path)) {
            return $path;
        }

        $info = pathinfo($path);
        $dir = ($info['dirname'] ?? '.') === '.' ? '' : $info['dirname'] . '/';
        $name = (string)($info['filename'] ?? '');
        $dirs = [$dir];

        if ($dir === '') {
            $dirs[] = 'assets/images/covers/';
        }

        foreach ($dirs as $tryDir) {
            if (is_file(__DIR__ . '/' . $tryDir . ($info['basename'] ?? ''))) {
                return $tryDir . $info['basename'];
            }

            foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
                $try = $tryDir . $name . '.' . $ext;

                if ($name !== '' && is_file(__DIR__ . '/' . $try)) {
                    return $try;
                }
            }
        }

        return '';
    }
}

if (!function_exists('comic_checkout_cover')) {
    function comic_checkout_cover(array $item): string
    {
        $found = comic_checkout_resolve_image((string)($item['cover_image'] ?? ''));

        if ($found === '') {
            $found = comic_checkout_resolve_image(
                'assets/images/covers/' . (string)($item['slug'] ?? '')
            );
        }

        return $found;
    }
}

/* =========================================================
   7. TẢI LẠI GIỎ HÀNG ĐỂ HIỂN THỊ
========================================================= */

$checkoutItems = [];
$checkoutSubtotal = 0.0;
$checkoutQuantity = 0;
$checkoutShipping = 0.0;
$checkoutGrandTotal = 0.0;

if (
    $checkoutDbReady &&
    !is_array($checkoutSuccess)
) {
    try {
        [$ownerSql, $ownerParams] = comic_checkout_owner();

        $checkoutItems = comic_checkout_query(
            $checkoutDb,
            'SELECT
                cart.id AS cart_id,
                cart.comic_id,
                cart.quantity,
                comics.title,
                comics.slug,
                comics.price,
                comics.sale_price,
                comics.cover_image,
                comics.stock,
                comics.is_active
             FROM cart
             INNER JOIN comics ON comics.id = cart.comic_id
             WHERE ' . $ownerSql . '
             ORDER BY cart.id ASC',
            $ownerParams
        )['rows'];

        foreach ($checkoutItems as &$item) {
            $regularPrice = (float)$item['price'];

            $salePrice = $item['sale_price'] !== null
                ? (float)$item['sale_price']
                : null;

            $unitPrice = (
                $salePrice !== null &&
                $salePrice > 0 &&
                $salePrice < $regularPrice
            )
                ? $salePrice
                : $regularPrice;

            $itemQuantity = (int)$item['quantity'];

            $item['unit_price'] = $unitPrice;
            $item['line_total'] = $unitPrice * $itemQuantity;
            $item['cover_src'] = comic_checkout_cover($item);

            $checkoutSubtotal += $item['line_total'];
            $checkoutQuantity += $itemQuantity;
        }

        unset($item);

        $checkoutShipping = comic_checkout_shipping($checkoutSubtotal);
        $checkoutGrandTotal = $checkoutSubtotal + $checkoutShipping;

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop Checkout] ' . $exception->getMessage()
        );

        $checkoutErrors[] =
            'Không tải được tóm tắt giỏ hàng. Vui lòng quay lại giỏ hàng.';
    }
}

/* =========================================================
   8. CHUẨN BỊ GIAO DIỆN
========================================================= */

$pageTitle = 'Thanh toán | Comic Shop';
$pageDescription =
    'Xác nhận thông tin giao hàng và đặt mua truyện tại Comic Shop.';

$activeMenu = 'cart';
$hideHeaderSearch = true; // Ẩn nút kính lúp
$hideFooter = true;       // Ẩn phần chân trang

$headerFile = __DIR__ . '/includes/header.php';
$footerFile = __DIR__ . '/includes/footer.php';

if (is_file($headerFile)) {
    require_once $headerFile;
} else {
    ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= comic_checkout_escape($pageTitle) ?></title>
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
    <?php
}
?>

<style>
.checkout-page{
    --co-ink:#f2f2f2;
    --co-muted:#a9a9b2;
    --co-border:#3d3d44;
    flex:1 1 auto;
    padding:8px 0 16px;
    background:#1c1c1f;
    color:var(--co-ink);
    font-family:"Inter","Montserrat",system-ui,-apple-system,"Segoe UI",Arial,sans-serif;
}
.checkout-page *{box-sizing:border-box}
.checkout-page .co-wrap{width:min(1100px,calc(100% - 48px));margin:0 auto}
.checkout-page .co-heading{margin-bottom:8px}
.checkout-page .co-title{
    display:flex;align-items:center;gap:10px;
    margin:6px 0 4px;
    font-size:clamp(26px,3.2vw,34px);
    font-weight:800;letter-spacing:-.5px;
}
.checkout-page .co-title:before{content:"";width:4px;height:.85em;border-radius:4px;background:#f2f2f2}
.checkout-page .co-alert{
    margin-bottom:16px;padding:14px 18px;
    border:1px solid var(--co-border);border-left:4px solid #f2f2f2;
    border-radius:16px;background:#2c2c31;color:#f2f2f2;
    font-size:14px;line-height:1.6;
}
.checkout-page .co-alert.error{
    border-color:#5a3338;border-left-color:#ff6b6b;background:#2b2225;
}
.checkout-page .co-alert strong{display:block;margin-bottom:4px;font-size:15px;font-weight:800}
.checkout-page .co-alert.error strong{color:#ff8f8f}
.checkout-page .co-alert p{margin:0;color:#e4e4e8}
.checkout-page .co-alert ul{margin:6px 0 0;padding-left:20px;color:#e4e4e8}
.checkout-page .co-alert li+li{margin-top:4px}
.checkout-page .co-layout{
    display:grid;
    grid-template-columns:minmax(0,1fr) 380px;
    gap:24px;
    align-items:start;
}
.checkout-page .co-main{
    display:flex;flex-direction:column;gap:16px;
    min-width:0;
}
.checkout-page .co-panel,
.checkout-page .co-summary{
    border:1px solid var(--co-border);
    border-radius:24px;
    background:#232327;
}
.checkout-page .co-panel{flex:0 0 auto}
.checkout-page .co-panel-head{padding:16px 22px;border-bottom:1px solid var(--co-border)}
.checkout-page .co-panel-head h2{margin:0;font-size:17px;font-weight:800}
.checkout-page .co-panel-body{padding:18px 22px}
.checkout-page .co-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px 16px}
.checkout-page .co-field{min-width:0}
.checkout-page .co-field.full{grid-column:1/-1}
.checkout-page .co-field label{
    display:block;margin-bottom:6px;
    color:var(--co-muted);font-size:13px;font-weight:700;
}
.checkout-page .co-field input,
.checkout-page .co-field textarea{
    width:100%;min-height:44px;padding:10px 14px;
    border:1px solid var(--co-border);border-radius:12px;outline:none;
    background:#1c1c1f;color:var(--co-ink);
    font:inherit;font-size:14px;
}
.checkout-page .co-field textarea{min-height:76px;height:76px;resize:none;line-height:1.5}
.checkout-page .co-field input::placeholder,
.checkout-page .co-field textarea::placeholder{color:#6f6f78}
.checkout-page .co-field input:focus,
.checkout-page .co-field textarea:focus{border-color:#f2f2f2;box-shadow:0 0 0 3px rgba(242,242,242,.1)}
.checkout-page .co-payment-options{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.checkout-page .co-payment-option{
    display:flex;align-items:center;gap:12px;
    padding:14px 16px;
    border:1px solid var(--co-border);border-radius:14px;
    background:#1c1c1f;cursor:pointer;
    transition:border-color .15s,background .15s;
}
.checkout-page .co-payment-option:has(input:checked){border-color:#f2f2f2;background:#2c2c31}
.checkout-page .co-payment-option input{width:18px;height:18px;margin:0;accent-color:#f2f2f2;flex-shrink:0}
.checkout-page .co-payment-title{display:block;color:#f2f2f2;font-size:14px;font-weight:800;line-height:1.4}
.checkout-page .co-btn{
    display:inline-flex;min-height:44px;align-items:center;justify-content:center;gap:7px;
    padding:10px 18px;border:1px solid var(--co-border);border-radius:999px;
    background:#232327;color:#d6d6db;
    font-size:14px;font-weight:800;text-decoration:none;cursor:pointer;
}
.checkout-page .co-btn:hover{border-color:#f2f2f2;color:#f2f2f2}
.checkout-page .co-btn:not(.secondary){background:#f2f2f2;color:#111;border-color:transparent}
.checkout-page .co-btn:not(.secondary):hover{background:#d9d9de;color:#111}
.checkout-page .co-actions{display:flex;flex-wrap:wrap;gap:9px;margin-top:20px}

/* Cột phải: đơn hàng */
.checkout-page .co-summary{
    display:flex;flex-direction:column;padding:22px 24px;
    position:sticky;top:16px;
}
.checkout-page .co-summary h2{
    flex:0 0 auto;margin:0 0 12px;padding-bottom:12px;
    border-bottom:1px solid var(--co-border);
    font-size:19px;font-weight:800;
}
.checkout-page .co-items{
    flex:0 1 auto;max-height:min(300px,38vh);overflow-y:auto;padding-right:6px;
    scrollbar-width:thin;scrollbar-color:#55555d #232327;
}
.checkout-page .co-items::-webkit-scrollbar,
.checkout-page .co-main::-webkit-scrollbar{width:8px}
.checkout-page .co-items::-webkit-scrollbar-thumb,
.checkout-page .co-main::-webkit-scrollbar-thumb{background:#55555d;border-radius:8px}
.checkout-page .co-item{
    display:grid;grid-template-columns:60px minmax(0,1fr);gap:14px;
    padding:10px 0;
}
.checkout-page .co-item+.co-item{border-top:1px solid #2f2f35}
.checkout-page .co-cover{
    display:block;width:60px;height:84px;overflow:hidden;
    border:1px solid var(--co-border);border-radius:8px;background:#2c2c31;
}
.checkout-page .co-cover img{display:block;width:100%;height:100%;object-fit:cover}
.checkout-page .co-cover-ph{
    display:flex;width:100%;height:100%;align-items:center;justify-content:center;
    background:linear-gradient(145deg,#303030,#515151);color:#fff;font-size:20px;font-weight:900;
}
.checkout-page .co-product-title{
    display:block;color:#f2f2f2;font-size:14px;font-weight:800;line-height:1.45;text-decoration:none;
}
.checkout-page .co-item-meta{margin-top:4px;color:var(--co-muted);font-size:13px}
.checkout-page .co-item-total{margin-top:4px;color:#f2f2f2;font-size:15px;font-weight:800}
.checkout-page .co-summary-row{
    flex:0 0 auto;display:flex;justify-content:space-between;gap:12px;
    margin:12px 0 0;color:var(--co-muted);font-size:14px;
}
.checkout-page .co-summary-row strong{color:#f2f2f2;font-weight:800}
.checkout-page .co-summary-total{
    flex:0 0 auto;display:flex;justify-content:space-between;align-items:center;gap:10px;
    margin-top:12px;padding-top:14px;border-top:1px solid var(--co-border);
}
.checkout-page .co-summary-total span{color:#d6d6db;font-size:14px;font-weight:800}
.checkout-page .co-summary-total strong{color:#f2f2f2;font-size:28px;font-weight:900}
.checkout-page .co-submit{
    flex:0 0 auto;display:flex;width:100%;min-height:52px;align-items:center;justify-content:center;
    margin-top:16px;border:0;border-radius:999px;
    background:#f2f2f2;color:#111;font:inherit;font-size:16px;font-weight:900;cursor:pointer;
}
.checkout-page .co-submit:hover{background:#d9d9de}
.checkout-page .co-submit:disabled{opacity:.6;cursor:wait}
.checkout-page .co-back{
    flex:0 0 auto;display:block;margin-top:12px;text-align:center;
    color:var(--co-muted);font-size:13px;font-weight:700;text-decoration:none;
}
.checkout-page .co-back:hover{color:#f2f2f2}

/* Trạng thái rỗng / thành công */
.checkout-page .co-empty{padding:47px 21px;text-align:center}
.checkout-page .co-empty-icon{margin-bottom:14px;font-size:38px}
.checkout-page .co-empty h2{margin:0 0 10px;font-size:23px;font-weight:900}
.checkout-page .co-empty p{max-width:420px;margin:0 auto 20px;color:var(--co-muted);font-size:14px;line-height:1.8}
.checkout-page .co-success{
    max-width:560px;margin:0 auto;padding:20px 24px;
    border:1px solid var(--co-border);border-radius:24px;background:#232327;text-align:center;
}
.checkout-page .co-success-icon{
    display:flex;width:48px;height:48px;align-items:center;justify-content:center;
    margin:0 auto 10px;border-radius:50%;background:#2c2c31;color:#f2f2f2;font-size:24px;font-weight:900;
}
.checkout-page .co-success h2{margin:0 0 6px;font-size:22px;font-weight:900}
.checkout-page .co-success p{margin:0 0 4px;color:var(--co-muted);font-size:13px;line-height:1.55}
.checkout-page .co-order-code{
    display:inline-block;margin:6px 0 8px;padding:7px 16px;
    border:1px dashed #55555d;border-radius:10px;background:#1c1c1f;
    color:#f2f2f2;font-size:15px;font-weight:900;letter-spacing:1px;
}
.checkout-page .co-success-total{margin:2px 0 8px;color:#f2f2f2;font-size:24px;font-weight:900}
.checkout-page .co-success-actions{display:flex;justify-content:center;flex-wrap:wrap;gap:9px;margin-top:12px}

@media(max-width:970px){
    .checkout-page .co-layout{grid-template-columns:minmax(0,1fr) 320px;gap:16px}
}
@media(max-width:800px){
    .checkout-page .co-layout{grid-template-columns:1fr}
    .checkout-page .co-summary{position:static}
    .checkout-page .co-items{max-height:40vh}
    .checkout-page .co-payment-options{grid-template-columns:1fr}
}
@media(max-width:510px){
    .checkout-page .co-wrap{width:calc(100% - 26px)}
    .checkout-page .co-grid{grid-template-columns:1fr}
    .checkout-page .co-field.full{grid-column:auto}
}

/* Đồng bộ nền & bố cục với giỏ hàng / tài khoản */
body:has(.checkout-page),
.scrn-page-wrapper:has(.checkout-page){background-color:#1c1c1f}
.scrn-page-wrapper:has(.checkout-page){display:flex;flex-direction:column;min-height:100vh;min-height:100dvh}
.scrn-page-wrapper:has(.checkout-page) .scrn-main-content{flex:1 1 auto;display:flex;flex-direction:column;padding:0}

/* ===== Bố cục gọn, vừa một màn hình (không cuộn trang) ===== */
.checkout-page{padding:0 0 12px}
.checkout-page .co-title{margin:4px 0 8px;font-size:clamp(22px,2.6vw,28px)}
.checkout-page .co-heading{margin-bottom:4px}
.checkout-page .co-layout{gap:20px;align-items:stretch}
.checkout-page .co-main{gap:12px}
.checkout-page .co-panel,
.checkout-page .co-summary{border-radius:20px}
.checkout-page .co-panel-head{padding:11px 20px}
.checkout-page .co-panel-head h2{font-size:16px}
.checkout-page .co-panel-body{padding:14px 20px}
.checkout-page .co-grid{grid-template-columns:repeat(6,minmax(0,1fr));gap:10px 14px}
.checkout-page .co-field.span2{grid-column:span 2}
.checkout-page .co-field.span3{grid-column:span 3}
.checkout-page .co-field label{margin-bottom:4px;font-size:12px}
.checkout-page .co-field input,
.checkout-page .co-field textarea{min-height:40px;padding:8px 12px;font-size:13px}
.checkout-page .co-field textarea{min-height:64px;height:64px}
.checkout-page .co-payment-option{padding:11px 14px}
.checkout-page .co-payment-title{font-size:13px}

.checkout-page .co-summary{position:static;padding:16px 20px}
.checkout-page .co-summary h2{margin:0 0 6px;padding-bottom:10px;font-size:17px}
.checkout-page .co-items{max-height:196px;overflow-y:auto;padding-right:6px}
.checkout-page .co-item{grid-template-columns:48px minmax(0,1fr);gap:12px;padding:8px 0;min-height:98px;align-items:center}
.checkout-page .co-cover{width:48px;height:68px}
.checkout-page .co-product-title{font-size:13px;line-height:1.35}
.checkout-page .co-item-meta{margin-top:2px;font-size:12px}
.checkout-page .co-item-total{margin-top:2px;font-size:14px}
.checkout-page .co-summary-row{margin:8px 0 0;font-size:13px}
.checkout-page .co-summary-row .co-free{color:#7ee2a0}
.checkout-page .co-ship-hint{
    margin-top:6px;padding:7px 10px;border-radius:10px;
    background:#2c2c31;color:var(--co-muted);font-size:12px;line-height:1.45;
}
.checkout-page .co-summary-total{margin-top:10px;padding-top:10px}
.checkout-page .co-summary-total strong{font-size:24px}
.checkout-page .co-submit{min-height:46px;margin-top:12px;font-size:15px}
.checkout-page .co-back{margin-top:8px}

/* Màn hình desktop: khóa cuộn trang, mọi thứ nằm gọn trong khung nhìn */
@media (min-width:801px) and (min-height:700px){
    html:has(.checkout-page),
    body:has(.checkout-page){overflow:hidden}
    .scrn-page-wrapper:has(.checkout-page){height:100vh;height:100dvh;overflow:hidden}
}
@media(max-width:800px){
    .checkout-page .co-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
    .checkout-page .co-field.span2,
    .checkout-page .co-field.span3{grid-column:span 1}
    .checkout-page .co-field:nth-child(3){grid-column:1/-1}
    .checkout-page .co-items{max-height:196px}
}
@media(max-width:510px){
    .checkout-page .co-grid{grid-template-columns:1fr}
    .checkout-page .co-field.span2,
    .checkout-page .co-field.span3,
    .checkout-page .co-field:nth-child(3){grid-column:auto}
}
</style>

<main class="checkout-page">
    <div class="co-wrap">

        <header class="co-heading">
            <h1 class="co-title">Thanh toán</h1>
        </header>

        <?php if (is_array($checkoutFlash) && !empty($checkoutFlash['message']) && ($checkoutFlash['type'] ?? '') !== 'success'): ?>
            <div
                class="co-alert <?= ($checkoutFlash['type'] ?? '') === 'error' ? 'error' : '' ?>"
                role="alert"
            >
                <?= comic_checkout_escape($checkoutFlash['message']) ?>
            </div>
        <?php endif; ?>

        <?php if ($checkoutErrors): ?>
            <div class="co-alert error" role="alert">
                <strong>Chưa thể đặt hàng</strong>
                <?php if (count($checkoutErrors) === 1): ?>
                    <p><?= comic_checkout_escape(reset($checkoutErrors)) ?></p>
                <?php else: ?>
                    <ul>
                        <?php foreach ($checkoutErrors as $error): ?>
                            <li><?= comic_checkout_escape($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if (!$checkoutDbReady): ?>

            <section class="co-panel">
                <div class="co-empty">
                    <div class="co-empty-icon">!</div>
                    <h2>Chưa kết nối được database</h2>
                    <p>
                        Vui lòng kiểm tra file config/db.php và biến kết nối
                        đang được sử dụng trong dự án.
                    </p>
                    <a class="co-btn secondary" href="cart.php">
                        ← Quay lại giỏ hàng
                    </a>
                </div>
            </section>

        <?php elseif (is_array($checkoutSuccess)): ?>

            <section class="co-success">
                <div class="co-success-icon">✓</div>

                <h2>Đặt hàng thành công!</h2>

                <p>
                    Cảm ơn bạn đã mua sắm tại Comic Shop.
                    Đơn hàng đã được lưu vào hệ thống.
                </p>

                <div class="co-order-code">
                    <?= comic_checkout_escape($checkoutSuccess['order_code'] ?? '') ?>
                </div>

                <p style="margin-bottom:0">Tổng tiền đơn hàng</p>

                <div class="co-success-total">
                    <?= comic_checkout_money(
                        $checkoutSuccess['total_amount'] ?? 0
                    ) ?>
                </div>

                <?php if (($checkoutSuccess['payment_method'] ?? 'cod') === 'cod'): ?>
                    <p>
                        Phương thức thanh toán: <strong>Thanh toán khi nhận hàng (COD)</strong>.
                    </p>
                <?php else: ?>
                    <p>
                        Phương thức thanh toán: <strong>Chuyển khoản ngân hàng</strong>.
                        Cửa hàng cần xác nhận thanh toán trước khi hoàn tất đơn.
                        Trang này chưa tích hợp cổng thanh toán trực tuyến.
                    </p>
                <?php endif; ?>

                <div class="co-success-actions">
                    <a class="co-btn" href="comics.php">
                        Tiếp tục mua truyện →
                    </a>

                    <a class="co-btn secondary" href="index.php">
                        Về trang chủ
                    </a>
                </div>
            </section>

        <?php elseif (!$checkoutItems): ?>

            <section class="co-panel">
                <div class="co-empty">
                    <div class="co-empty-icon">🛒</div>
                    <h2>Giỏ hàng đang trống</h2>
                    <p>
                        Bạn cần thêm ít nhất một sản phẩm vào giỏ hàng
                        trước khi tiến hành đặt hàng.
                    </p>
                    <a class="co-btn" href="comics.php">
                        Khám phá truyện →
                    </a>
                </div>
            </section>

        <?php else: ?>

            <form method="post" action="checkout.php" id="checkout-form">
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= comic_checkout_escape($checkoutCsrf) ?>"
                >

                <input type="hidden" name="action" value="place_order">

                <div class="co-layout">

                    <div class="co-main">

                        <section class="co-panel">
                            <div class="co-panel-head">
                                <h2>Thông tin nhận hàng</h2>
                            </div>

                            <div class="co-panel-body">
                                <div class="co-grid">

                                    <div class="co-field span2">
                                        <label for="full-name">Họ và tên *</label>
                                        <input
                                            id="full-name"
                                            type="text"
                                            name="full_name"
                                            maxlength="120"
                                            required
                                            autocomplete="name"
                                            value="<?= comic_checkout_escape($formData['full_name']) ?>"
                                            placeholder="Họ tên người nhận"
                                        >
                                    </div>

                                    <div class="co-field span2">
                                        <label for="phone">Số điện thoại *</label>
                                        <input
                                            id="phone"
                                            type="tel"
                                            name="phone"
                                            maxlength="20"
                                            required
                                            autocomplete="tel"
                                            value="<?= comic_checkout_escape($formData['phone']) ?>"
                                            placeholder="Số điện thoại liên hệ"
                                        >
                                    </div>

                                    <div class="co-field span2">
                                        <label for="email">Email *</label>
                                        <input
                                            id="email"
                                            type="email"
                                            name="email"
                                            maxlength="150"
                                            required
                                            autocomplete="email"
                                            value="<?= comic_checkout_escape($formData['email']) ?>"
                                            placeholder="email@example.com"
                                        >
                                    </div>

                                    <div class="co-field span3">
                                        <label for="address">Địa chỉ giao hàng *</label>
                                        <textarea
                                            id="address"
                                            name="address"
                                            maxlength="255"
                                            required
                                            autocomplete="street-address"
                                            placeholder="Số nhà, đường, phường/xã, quận/huyện, tỉnh/thành"
                                        ><?= comic_checkout_escape($formData['address']) ?></textarea>
                                    </div>

                                    <div class="co-field span3">
                                        <label for="note">Ghi chú đơn hàng</label>
                                        <textarea
                                            id="note"
                                            name="note"
                                            maxlength="5000"
                                            placeholder="Ghi chú giao hàng (nếu có)"
                                        ><?= comic_checkout_escape($formData['note']) ?></textarea>
                                    </div>

                                </div>
                            </div>
                        </section>

                        <section class="co-panel">
                            <div class="co-panel-head">
                                <h2>Phương thức thanh toán</h2>
                            </div>

                            <div class="co-panel-body">
                                <div class="co-payment-options">

                                    <label class="co-payment-option">
                                        <input
                                            type="radio"
                                            name="payment_method"
                                            value="cod"
                                            <?= $formData['payment_method'] === 'cod' ? 'checked' : '' ?>
                                        >
                                        <span class="co-payment-title">
                                            Thanh toán khi nhận hàng (COD)
                                        </span>
                                    </label>

                                    <label class="co-payment-option">
                                        <input
                                            type="radio"
                                            name="payment_method"
                                            value="banking"
                                            <?= $formData['payment_method'] === 'banking' ? 'checked' : '' ?>
                                        >
                                        <span class="co-payment-title">
                                            Chuyển khoản ngân hàng
                                        </span>
                                    </label>

                                </div>
                            </div>
                        </section>

                    </div>

                    <aside class="co-summary">
                        <h2>Đơn hàng của bạn</h2>

                        <div class="co-items">
                            <?php foreach ($checkoutItems as $item): ?>
                                <div class="co-item">
                                    <a
                                        class="co-cover"
                                        href="comic-detail.php?slug=<?= rawurlencode((string)$item['slug']) ?>"
                                    >
                                        <?php if ($item['cover_src'] !== ''): ?>
                                            <img
                                                src="<?= comic_checkout_escape($item['cover_src']) ?>"
                                                alt="<?= comic_checkout_escape($item['title']) ?>"
                                                loading="lazy"
                                                onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"
                                            >
                                            <span class="co-cover-ph" style="display:none">C.</span>
                                        <?php else: ?>
                                            <span class="co-cover-ph">C.</span>
                                        <?php endif; ?>
                                    </a>

                                    <div>
                                        <a
                                            class="co-product-title"
                                            href="comic-detail.php?slug=<?= rawurlencode((string)$item['slug']) ?>"
                                        >
                                            <?= comic_checkout_escape($item['title']) ?>
                                        </a>

                                        <div class="co-item-meta">
                                            SL: <?= number_format((int)$item['quantity']) ?>
                                            × <?= comic_checkout_money($item['unit_price']) ?>
                                        </div>

                                        <div class="co-item-total">
                                            <?= comic_checkout_money($item['line_total']) ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="co-summary-row">
                            <span>Tạm tính</span>
                            <strong><?= comic_checkout_money($checkoutSubtotal) ?></strong>
                        </div>

                        <div class="co-summary-row">
                            <span>Phí giao hàng</span>
                            <?php if ($checkoutShipping > 0): ?>
                                <strong><?= comic_checkout_money($checkoutShipping) ?></strong>
                            <?php else: ?>
                                <strong class="co-free">Miễn phí</strong>
                            <?php endif; ?>
                        </div>

                        <?php if ($checkoutShipping > 0): ?>
                            <div class="co-ship-hint">
                                Mua thêm
                                <?= comic_checkout_money(COMIC_FREE_SHIP_THRESHOLD - $checkoutSubtotal + 1) ?>
                                để được miễn phí giao hàng
                                (đơn trên <?= comic_checkout_money(COMIC_FREE_SHIP_THRESHOLD) ?>).
                            </div>
                        <?php endif; ?>

                        <div class="co-summary-total">
                            <span>Tổng cộng (<?= number_format($checkoutQuantity) ?> cuốn)</span>
                            <strong><?= comic_checkout_money($checkoutGrandTotal) ?></strong>
                        </div>

                        <button
                            type="submit"
                            class="co-submit"
                            id="place-order-button"
                        >
                            Xác nhận đặt hàng →
                        </button>

                        <a class="co-back" href="cart.php">← Quay lại giỏ hàng</a>
                    </aside>

                </div>
            </form>

        <?php endif; ?>

    </div>
</main>

<script>
(function () {
    'use strict';

    var form = document.getElementById('checkout-form');
    var submitButton = document.getElementById('place-order-button');

    if (form && submitButton) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                form.reportValidity();
                return;
            }

            if (submitButton.dataset.submitting === '1') {
                event.preventDefault();
                return;
            }

            submitButton.dataset.submitting = '1';
            submitButton.disabled = true;
            submitButton.textContent = 'Đang xử lý đơn hàng...';
        });
    }
})();
</script>

<?php
if (is_file($footerFile)) {
    require_once $footerFile;
} else {
    echo '</body></html>';
}
?>
