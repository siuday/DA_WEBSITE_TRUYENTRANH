<?php
/*
 * COMIC SHOP
 * File: login.php
 * Trang đăng nhập khách hàng.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. KẾT NỐI DATABASE
========================================================= */

if (is_file(__DIR__ . '/config/main.php')) {
    require_once __DIR__ . '/config/main.php';
}

$dbConfigReturn = null;

if (is_file(__DIR__ . '/config/db.php')) {
    $dbConfigReturn = require_once __DIR__ . '/config/db.php';
}

$loginDb = null;

$loginCandidates = [
    $dbConfigReturn,
    $GLOBALS['comic_shop_db'] ?? null,
    $GLOBALS['pdo'] ?? null,
    $GLOBALS['conn'] ?? null,
    $GLOBALS['mysqli'] ?? null,
    $GLOBALS['db'] ?? null,
    $pdo ?? null,
    $conn ?? null,
    $mysqli ?? null,
    $db ?? null,
];

foreach ($loginCandidates as $candidate) {
    if (
        $candidate instanceof PDO ||
        (class_exists('mysqli') && $candidate instanceof mysqli)
    ) {
        $loginDb = $candidate;
        break;
    }
}

$loginDbReady = $loginDb instanceof PDO ||
    (class_exists('mysqli') && $loginDb instanceof mysqli);

/* =========================================================
   2. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_login_escape')) {
    function comic_login_escape($value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_login_find_user')) {
    function comic_login_find_user($database, string $email): ?array
    {
        $sql = 'SELECT
                    id,
                    full_name,
                    email,
                    password,
                    phone,
                    address,
                    role,
                    avatar,
                    is_active
                FROM users
                WHERE email = ?
                LIMIT 1';

        if ($database instanceof PDO) {
            $database->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );

            $statement = $database->prepare($sql);
            $statement->execute([$email]);

            $user = $statement->fetch(PDO::FETCH_ASSOC);

            $statement->closeCursor();

            return $user ?: null;
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            $statement = $database->prepare($sql);

            if (!$statement) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn đăng nhập.'
                );
            }

            $statement->bind_param('s', $email);

            if (!$statement->execute()) {
                $error = $statement->error;
                $statement->close();

                throw new RuntimeException(
                    $error ?: 'Không thể truy vấn tài khoản.'
                );
            }

            $result = $statement->get_result();

            $user = $result
                ? $result->fetch_assoc()
                : null;

            if ($result) {
                $result->free();
            }

            $statement->close();

            return $user ?: null;
        }

        throw new RuntimeException(
            'Không tìm thấy kết nối database.'
        );
    }
}

/* =========================================================
   3. CSRF VÀ THÔNG BÁO
========================================================= */

if (
    empty($_SESSION['comic_login_csrf']) ||
    !is_string($_SESSION['comic_login_csrf'])
) {
    $_SESSION['comic_login_csrf'] = bin2hex(random_bytes(32));
}

$loginCsrf = $_SESSION['comic_login_csrf'];

$loginError = '';
$emailValue = '';

/*
 * Chỉ cho phép chuyển đến các trang nội bộ được xác định trước,
 * tránh lỗi chuyển hướng ra website bên ngoài.
 */
$allowedRedirects = [
    'account.php',
    'cart.php',
    'checkout.php',
    'my-orders.php',
];

$requestedRedirect = isset($_GET['redirect']) &&
    is_string($_GET['redirect'])
    ? $_GET['redirect']
    : '';

$redirectTarget = in_array(
    $requestedRedirect,
    $allowedRedirects,
    true
)
    ? $requestedRedirect
    : 'account.php';

/* =========================================================
   4. KIỂM TRA PHIÊN ĐĂNG NHẬP
========================================================= */

if (
    isset($_SESSION['user']) &&
    is_array($_SESSION['user']) &&
    !empty($_SESSION['user']['id'])
) {
    header(
        'Location: ' . $redirectTarget,
        true,
        303
    );
    exit;
}

/* =========================================================
   5. XỬ LÝ ĐĂNG NHẬP
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $emailValue = trim((string)(
        $_POST['email'] ?? ''
    ));

    $password = (string)(
        $_POST['password'] ?? ''
    );

    $postedRedirect = isset($_POST['redirect'])
        && is_string($_POST['redirect'])
        ? $_POST['redirect']
        : '';

    if (in_array(
        $postedRedirect,
        $allowedRedirects,
        true
    )) {
        $redirectTarget = $postedRedirect;
    }

    $postedToken = isset($_POST['csrf_token'])
        && is_string($_POST['csrf_token'])
        ? $_POST['csrf_token']
        : '';

    if (!hash_equals($loginCsrf, $postedToken)) {
        $loginError =
            'Phiên đăng nhập đã hết hạn. Hãy tải lại trang và thử lại.';

    } elseif (
        $emailValue === '' ||
        strlen($emailValue) > 150 ||
        !filter_var($emailValue, FILTER_VALIDATE_EMAIL)
    ) {
        $loginError = 'Vui lòng nhập địa chỉ email hợp lệ.';

    } elseif ($password === '' || strlen($password) > 4096) {
        $loginError = 'Vui lòng nhập mật khẩu hợp lệ.';

    } elseif (!$loginDbReady) {
        $loginError =
            'Không kết nối được database. Hãy kiểm tra config/db.php.';

    } else {
        try {
            $user = comic_login_find_user(
                $loginDb,
                $emailValue
            );

            /*
             * Không phân biệt email không tồn tại với mật khẩu sai
             * để tránh tiết lộ thông tin tài khoản.
             */
            if (
                !$user ||
                !password_verify(
                    $password,
                    (string)$user['password']
                )
            ) {
                $loginError =
                    'Email hoặc mật khẩu không chính xác.';

            } elseif ((int)$user['is_active'] !== 1) {
                $loginError =
                    'Tài khoản đã bị khóa hoặc chưa được kích hoạt.';

            } elseif (
                !in_array(
                    (string)$user['role'],
                    ['customer', 'staff', 'admin'],
                    true
                )
            ) {
                $loginError =
                    'Tài khoản không có quyền đăng nhập hợp lệ.';

            } else {
                /*
                 * Trang login.php dành cho khu vực khách hàng.
                 * Nhân viên và quản trị viên dùng trang đăng nhập
                 * riêng tại admin/login.php.
                 */
                if ($user['role'] !== 'customer') {
                    $loginError =
                        'Tài khoản nhân viên hoặc quản trị viên cần đăng nhập tại khu vực quản trị.';
                } else {
                    /*
                     * Đổi session ID để hạn chế session fixation.
                     */
                    session_regenerate_id(true);

                    /*
                     * Đồng bộ session với account.php, cart.php
                     * và checkout.php.
                     */
                    $_SESSION['user'] = [
                        'id' => (int)$user['id'],
                        'full_name' => (string)$user['full_name'],
                        'name' => (string)$user['full_name'],
                        'email' => (string)$user['email'],
                        'phone' => (string)($user['phone'] ?? ''),
                        'address' => (string)($user['address'] ?? ''),
                        'role' => (string)$user['role'],
                        'avatar' => (string)($user['avatar'] ?? ''),
                    ];

                    $_SESSION['user_id'] = (int)$user['id'];
                    $_SESSION['customer_id'] = (int)$user['id'];

                    /*
                     * Xóa CSRF cũ, tạo token mới sau đăng nhập.
                     */
                    unset(
                        $_SESSION['comic_login_csrf']
                    );

                    /*
                     * Cập nhật hash nếu thuật toán mật khẩu
                     * mặc định của PHP đã thay đổi.
                     */
                    if (
                        password_needs_rehash(
                            (string)$user['password'],
                            PASSWORD_DEFAULT
                        )
                    ) {
                        $newHash = password_hash(
                            $password,
                            PASSWORD_DEFAULT
                        );

                        if ($loginDb instanceof PDO) {
                            $statement = $loginDb->prepare(
                                'UPDATE users SET password = ? WHERE id = ?'
                            );

                            $statement->execute([
                                $newHash,
                                (int)$user['id'],
                            ]);

                            $statement->closeCursor();

                        } elseif (
                            class_exists('mysqli') &&
                            $loginDb instanceof mysqli
                        ) {
                            $statement = $loginDb->prepare(
                                'UPDATE users SET password = ? WHERE id = ?'
                            );

                            if ($statement) {
                                $userIdForHash = (int)$user['id'];

                                $statement->bind_param(
                                    'si',
                                    $newHash,
                                    $userIdForHash
                                );

                                $statement->execute();
                                $statement->close();
                            }
                        }
                    }

                    header(
                        'Location: ' . $redirectTarget,
                        true,
                        303
                    );
                    exit;
                }
            }

        } catch (Throwable $exception) {
            error_log(
                '[Comic Shop Login] ' . $exception->getMessage()
            );

            $loginError =
                'Đã xảy ra lỗi khi đăng nhập. Vui lòng thử lại sau.';
        }
    }
}

/* =========================================================
   6. CHUẨN BỊ GIAO DIỆN
========================================================= */

$pageTitle = 'Đăng nhập | Comic Shop';

$pageDescription =
    'Đăng nhập tài khoản Comic Shop để quản lý thông tin và theo dõi đơn hàng.';

$activeMenu = 'login';

/* Trang đăng nhập không hiện icon tìm kiếm trên thanh header */
$hideHeaderSearch = true;

$headerFile = __DIR__ . '/includes/header.php';
$footerFile = __DIR__ . '/includes/footer.php';

if (is_file($headerFile)) {
    require_once $headerFile;
} else {
    ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= comic_login_escape($pageTitle) ?></title>
        <meta
            name="description"
            content="<?= comic_login_escape($pageDescription) ?>"
        >
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
    <?php
}
?>

<style>
/* Giao diện đăng nhập: cùng bảng màu đen nhạt, thẻ kính, viền xám và nút bo tròn như trang chủ */
body:has(.comic-login),
.scrn-page-wrapper:has(.comic-login){
    background-color:#1c1c1f;
}
/* Trang đăng nhập không hiện chân trang */
body:has(.comic-login) footer{display:none!important}

/* Vừa khít màn hình: khung đăng nhập tự co giãn vào phần còn lại dưới header, không bị cuộn lên xuống */
body:has(.comic-login){margin:0}
.scrn-page-wrapper:has(.comic-login){
    display:flex;
    flex-direction:column;
    min-height:100vh;
    min-height:100dvh;
}
.scrn-page-wrapper:has(.comic-login) .scrn-main-content{
    flex:1 1 auto;
    display:flex;
    flex-direction:column;
    padding:0;
}

.comic-login{
    --bg:#1c1c1f;
    --glass:#232327;
    --glass-2:#2c2c31;
    --glass-3:#36363c;
    --stroke:#3d3d44;
    --line:rgba(255,255,255,.38);
    --text:#f2f2f2;
    --muted:#a9a9b2;
    box-sizing:border-box;
    flex:1 1 auto;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:24px 18px;
    background:var(--bg);
    color:var(--text);
}
.comic-login *{box-sizing:border-box}
.comic-login .login-layout{
    display:grid;
    grid-template-columns:minmax(0,1fr) minmax(350px,.9fr);
    width:min(960px,100%);
    min-height:550px;
    overflow:hidden;
    border:1px solid var(--stroke);
    border-radius:30px;
    background:var(--glass);
}
.comic-login .login-art{
    position:relative;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
    overflow:hidden;
    padding:36px;
    border-right:1px solid var(--stroke);
    background:
        radial-gradient(ellipse at 90% 0%,rgba(255,255,255,.08),transparent 45%),
        var(--glass-2);
    color:var(--text);
}
.comic-login .login-art:before{
    position:absolute;
    right:-100px;
    bottom:-120px;
    width:340px;
    height:340px;
    border:1px solid rgba(255,255,255,.10);
    border-radius:50%;
    content:"";
    box-shadow:0 0 0 34px rgba(255,255,255,.025),0 0 0 70px rgba(255,255,255,.02);
}
.comic-login .login-brand{
    position:relative;
    z-index:1;
    display:flex;
    align-items:center;
    gap:10px;
    color:var(--text);
    font-size:15px;
    font-weight:800;
    letter-spacing:.4px;
    text-decoration:none;
}
.comic-login .login-brand-mark{
    display:flex;
    width:38px;
    height:38px;
    align-items:center;
    justify-content:center;
    border-radius:12px;
    background:#f2f2f2;
    color:#111111;
    font-size:20px;
    font-weight:800;
}
.comic-login .login-art-main{
    position:relative;
    z-index:1;
    margin:35px 0;
}
.comic-login .login-art-eyebrow{
    color:var(--muted);
    font-size:10px;
    font-weight:800;
    letter-spacing:2px;
    text-transform:uppercase;
}
.comic-login .login-art h2{
    margin:15px 0;
    font-size:clamp(27px,3vw,38px);
    font-weight:800;
    letter-spacing:-.8px;
    line-height:1.2;
}
.comic-login .login-art h2 span{color:var(--muted)}
.comic-login .login-art p{
    max-width:330px;
    margin:0;
    color:var(--muted);
    font-size:12px;
    line-height:1.95;
}
.comic-login .login-art-footer{
    position:relative;
    z-index:1;
    color:var(--muted);
    font-size:10px;
    line-height:1.7;
}
.comic-login .login-form-side{
    display:flex;
    flex-direction:column;
    justify-content:center;
    padding:40px 36px;
}
.comic-login .login-heading{margin-bottom:24px}
.comic-login .login-heading h1{
    display:flex;
    align-items:center;
    gap:10px;
    margin:0;
    font-size:26px;
    font-weight:800;
    letter-spacing:-.5px;
}
.comic-login .login-heading h1:before{
    content:"";
    width:4px;
    height:.85em;
    border-radius:4px;
    background:var(--text);
}
.comic-login .login-heading p{
    margin:8px 0 0;
    color:var(--muted);
    font-size:12px;
    line-height:1.8;
}
.comic-login .login-error{
    margin-bottom:17px;
    padding:12px 16px;
    border:1px solid var(--stroke);
    border-left:4px solid var(--text);
    border-radius:18px;
    background:var(--bg);
    color:var(--text);
    font-size:11px;
    line-height:1.8;
}
.comic-login .login-field{margin-bottom:17px}
.comic-login .login-field label{
    display:block;
    margin-bottom:8px;
    color:var(--text);
    font-size:11px;
    font-weight:700;
}
.comic-login .login-input-wrap{position:relative}
.comic-login .login-field input{
    box-sizing:border-box;
    width:100%;
    min-height:46px;
    padding:11px 18px;
    border:1px solid var(--stroke);
    border-radius:999px;
    outline:none;
    background:var(--bg);
    color:var(--text);
    font:inherit;
    font-size:12px;
    transition:border-color .15s,box-shadow .15s;
}
.comic-login .login-field input::placeholder{color:#7c7c85}
.comic-login .login-field input:-webkit-autofill{
    -webkit-box-shadow:0 0 0 40px var(--bg) inset;
    -webkit-text-fill-color:var(--text);
}
.comic-login .login-field input:focus{
    border-color:var(--line);
    box-shadow:0 0 0 3px rgba(255,255,255,.07);
}
.comic-login .login-password-input{padding-right:70px!important}
.comic-login .login-show-password{
    position:absolute;
    top:50%;
    right:12px;
    padding:6px;
    transform:translateY(-50%);
    border:0;
    background:transparent;
    color:var(--muted);
    font:inherit;
    font-size:10px;
    font-weight:800;
    cursor:pointer;
}
.comic-login .login-show-password:hover{color:var(--text)}
.comic-login .login-options{
    display:flex;
    justify-content:flex-end;
    align-items:center;
    margin-top:-4px;
    margin-bottom:20px;
}
.comic-login .login-options a{
    color:var(--muted);
    font-size:11px;
    font-weight:700;
    text-decoration:none;
}
.comic-login .login-options a:hover{color:var(--text);text-decoration:underline}
.comic-login .login-submit{
    display:flex;
    width:100%;
    height:46px;
    align-items:center;
    justify-content:center;
    gap:8px;
    border:1.5px solid #f2f2f2;
    border-radius:999px;
    background:#f2f2f2;
    color:#111111;
    font:inherit;
    font-size:12px;
    font-weight:700;
    cursor:pointer;
    transition:background .2s,transform .2s;
}
.comic-login .login-submit:hover{
    border-color:#ffffff;
    background:#ffffff;
    transform:translateY(-1px);
}
.comic-login .login-submit:disabled{opacity:.7;cursor:wait;transform:none}
.comic-login .login-register{
    margin-top:21px;
    color:var(--muted);
    font-size:11px;
    line-height:1.8;
    text-align:center;
}
.comic-login .login-register a{
    color:var(--text);
    font-weight:800;
    text-decoration:none;
}
.comic-login .login-register a:hover{text-decoration:underline}
.comic-login .login-divider{
    display:flex;
    align-items:center;
    gap:12px;
    margin:23px 0 17px;
    color:var(--muted);
    font-size:9px;
}
.comic-login .login-divider:before,
.comic-login .login-divider:after{
    height:1px;
    flex:1;
    background:var(--stroke);
    content:"";
}
.comic-login .login-back{
    display:flex;
    justify-content:center;
    color:var(--muted);
    font-size:11px;
    font-weight:700;
    text-decoration:none;
}
.comic-login .login-back:hover{color:var(--text)}
@media(max-width:760px){
    .comic-login{padding:24px 14px}
    .comic-login .login-layout{grid-template-columns:1fr;max-width:465px}
    .comic-login .login-art{min-height:220px;padding:24px;border-right:0;border-bottom:1px solid var(--stroke)}
    .comic-login .login-art-main{margin:30px 0 22px}
    .comic-login .login-art h2{font-size:29px}
    .comic-login .login-art-footer{display:none}
    .comic-login .login-form-side{padding:30px 25px}
}
@media(max-width:390px){
    .comic-login .login-form-side{padding:27px 18px}
    .comic-login .login-art{padding:20px}
}
</style>

<main class="comic-login">
    <div class="login-layout">

        <section class="login-art">
            <a class="login-brand" href="index.php">
                <span class="login-brand-mark">C.</span>
                <span>COMIC SHOP</span>
            </a>

            <div class="login-art-main">
                <div class="login-art-eyebrow">
                    Chào mừng trở lại
                </div>

                <h2>
                    Mỗi trang sách,<br>
                    một <span>cuộc phiêu lưu.</span>
                </h2>

                <p>
                    Đăng nhập để quản lý tài khoản, theo dõi đơn hàng
                    và tiếp tục khám phá những bộ truyện yêu thích.
                </p>
            </div>

            <div class="login-art-footer">
                COMIC SHOP · THẾ GIỚI TRUYỆN TRANH
            </div>
        </section>

        <section class="login-form-side">
            <div class="login-heading">
                <h1>Đăng nhập</h1>
                <p>
                    Nhập thông tin tài khoản của bạn để tiếp tục.
                </p>
            </div>

            <?php if ($loginError !== ''): ?>
                <div class="login-error" role="alert">
                    <?= comic_login_escape($loginError) ?>
                </div>
            <?php endif; ?>

            <form
                method="post"
                action="login.php"
                id="comic-login-form"
            >
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= comic_login_escape($loginCsrf) ?>"
                >

                <input
                    type="hidden"
                    name="redirect"
                    value="<?= comic_login_escape($redirectTarget) ?>"
                >

                <div class="login-field">
                    <label for="login-email">Địa chỉ email</label>

                    <input
                        type="email"
                        id="login-email"
                        name="email"
                        required
                        maxlength="150"
                        autocomplete="username"
                        value="<?= comic_login_escape($emailValue) ?>"
                        placeholder="Nhập email của bạn"
                    >
                </div>

                <div class="login-field">
                    <label for="login-password">Mật khẩu</label>

                    <div class="login-input-wrap">
                        <input
                            class="login-password-input"
                            type="password"
                            id="login-password"
                            name="password"
                            required
                            autocomplete="current-password"
                            placeholder="Nhập mật khẩu"
                        >

                        <button
                            class="login-show-password"
                            type="button"
                            id="login-toggle-password"
                            aria-label="Hiện mật khẩu"
                        >
                            Hiện
                        </button>
                    </div>
                </div>

                <div class="login-options">
                    <a href="forgot-password.php">
                        Quên mật khẩu?
                    </a>
                </div>

                <button
                    class="login-submit"
                    type="submit"
                    id="login-submit"
                >
                    Đăng nhập <span aria-hidden="true">→</span>
                </button>
            </form>

            <div class="login-register">
                Chưa có tài khoản?
                <a href="register.php">Đăng ký ngay</a>
            </div>

            <div class="login-divider">HOẶC</div>

            <a class="login-back" href="index.php">
                ← Quay lại cửa hàng
            </a>
        </section>

    </div>
</main>

<script>
(function () {
    'use strict';

    var passwordInput = document.getElementById('login-password');
    var toggleButton = document.getElementById('login-toggle-password');
    var loginForm = document.getElementById('comic-login-form');
    var submitButton = document.getElementById('login-submit');

    if (passwordInput && toggleButton) {
        toggleButton.addEventListener('click', function () {
            var isPassword = passwordInput.type === 'password';

            passwordInput.type = isPassword ? 'text' : 'password';
            toggleButton.textContent = isPassword ? 'Ẩn' : 'Hiện';

            toggleButton.setAttribute(
                'aria-label',
                isPassword ? 'Ẩn mật khẩu' : 'Hiện mật khẩu'
            );
        });
    }

    if (loginForm && submitButton) {
        loginForm.addEventListener('submit', function (event) {
            if (!loginForm.checkValidity()) {
                event.preventDefault();
                loginForm.reportValidity();
                return;
            }

            if (submitButton.dataset.submitting === '1') {
                event.preventDefault();
                return;
            }

            submitButton.dataset.submitting = '1';
            submitButton.disabled = true;
            submitButton.textContent = 'Đang đăng nhập...';
        });
    }
})();
</script>

<?php
if (is_file($footerFile)) {
    require_once $footerFile;
} else {
    echo '</body></html>';
}
?>
