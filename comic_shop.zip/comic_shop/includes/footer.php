<?php
// includes/footer.php
// Trang nào đặt $hideFooter = true trước khi nạp header thì ẩn chân trang
$hideFooter = $hideFooter ?? false;
?>
    </main><!-- /.scrn-main-content -->

    <?php if (!$hideFooter): ?>
    <!-- Footer gọn: thương hiệu | liên kết | đăng ký bản tin -->
    <footer class="scrn-footer">
        <div class="scrn-container">
            <div class="scrn-footer-grid">
                <!-- Thương hiệu -->
                <div class="scrn-footer-brand">
                    <a href="index.php" class="scrn-logo scrn-logo--dark">
                        C<span class="scrn-logo-box"></span>MIC
                    </a>
                    <p class="scrn-footer-address">
                        12 Lê Lợi, Quận 1, TP. Hồ Chí Minh, Việt Nam, 700000
                    </p>
                    <p class="scrn-footer-address">TEL: +84 (0)28 3822 9956</p>
                </div>

                <!-- Liên kết -->
                <nav class="scrn-footer-links" aria-label="Liên kết chân trang">
                    <a href="comics.php">Truyện tranh</a>
                    <a href="comics.php?category=truyen-viet">Truyện Việt</a>
                    <a href="comics.php?filter=new">Mới phát hành</a>
                    <a href="comics.php?filter=discount">Khuyến mãi</a>
                    <a href="blog.php">Góc Review</a>
                    <a href="cart.php">Giỏ hàng</a>
                    <a href="account.php">Tài khoản</a>
                    <a href="my-orders.php">Đơn hàng</a>
                    <a href="contact.php">Liên hệ</a>
                    <a href="forgot-password.php">Trợ giúp</a>
                </nav>

                <!-- Đăng ký bản tin -->
                <div class="scrn-footer-newsletter">
                    <h3 class="scrn-footer-heading">NEWSLETTER</h3>
                    <p class="scrn-footer-desc">
                        Cập nhật lịch phát hành manga mới nhất và ưu đãi độc quyền hàng tháng từ Comic Shop...
                    </p>
                    <form class="scrn-newsletter-form" id="scrnNewsletterForm" onsubmit="event.preventDefault(); window.scrnShowToast && window.scrnShowToast('Cảm ơn bạn đã đăng ký nhận bản tin Comic Shop!', 'success'); this.reset();">
                        <input type="email" name="email" placeholder="Email" required>
                        <button type="submit" class="scrn-btn-subscribe">SUBSCRIBE</button>
                    </form>
                </div>
            </div>

            <div class="scrn-footer-bottom">
                <span>Copyright © <?= date('Y') ?> Comic Shop</span>
                <div class="scrn-footer-socials">
                    <a href="https://facebook.com" target="_blank" rel="noopener" aria-label="Facebook"><i class="fa-brands fa-square-facebook"></i></a>
                    <a href="https://tiktok.com" target="_blank" rel="noopener" aria-label="TikTok"><i class="fa-brands fa-tiktok"></i></a>
                    <a href="https://instagram.com" target="_blank" rel="noopener" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </footer>
    <?php endif; ?>
</div><!-- /.scrn-page-wrapper -->

<!-- JavaScript dùng chung -->
<script src="assets/js/main.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/main.js') ?>"></script>
<script src="assets/js/cart.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/cart.js') ?>"></script>
<?php if (!empty($extraJs) && is_array($extraJs)): ?>
    <?php foreach ($extraJs as $jsFile): ?>
        <script src="<?= e($jsFile) ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>
</body>
</html>