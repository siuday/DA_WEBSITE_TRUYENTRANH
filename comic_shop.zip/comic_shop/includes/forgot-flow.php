                comic_shop_forgot_flow_execute(
                    $database,
                    'UPDATE password_otps SET attempts = ? WHERE id = ?',
                    [$nextAttempts, $otpId]
                );
            }

            return ['success' => false, 'message' => 'Mã xác thực không đúng hoặc đã hết hạn.'];
        }

        return ['success' => true, 'message' => 'Mã xác thực hợp lệ.', 'user_id' => (int)$record['user']['id']];
    }
}

if (!function_exists('comic_shop_forgot_flow_verify_code')) {
    /** @return array{success: bool, message: string} */
    function comic_shop_forgot_flow_verify_code($database, string $email, string $code): array
    {
        if (!comic_shop_forgot_flow_db_is_supported($database)) {
            return ['success' => false, 'message' => 'Kết nối cơ sở dữ liệu chưa sẵn sàng.'];
        }

        try {
            comic_shop_forgot_flow_begin($database);
            $result = comic_shop_forgot_flow_check_code_locked($database, $email, trim($code));
            comic_shop_forgot_flow_commit($database);
            unset($result['user_id']);
            return $result;
        } catch (Throwable $exception) {
            comic_shop_forgot_flow_rollback($database);
            error_log('[ComicShop forgot-flow] Lỗi kiểm tra OTP: ' . $exception->getMessage());
            return ['success' => false, 'message' => 'Chưa thể kiểm tra mã lúc này. Vui lòng thử lại.'];
        }
    }
}

if (!function_exists('comic_shop_forgot_flow_reset_password')) {
    /**
     * Kiểm tra OTP và đổi mật khẩu trong cùng một giao dịch.
     * Mật khẩu phải dài 8-72 byte để tránh bị cắt khi thuật toán mặc định là bcrypt.
     * @return array{success: bool, message: string}
     */
    function comic_shop_forgot_flow_reset_password(
        $database,
        string $email,
        string $code,
        string $newPassword,
        string $confirmPassword
    ): array {
        if (!comic_shop_forgot_flow_db_is_supported($database)) {
            return ['success' => false, 'message' => 'Kết nối cơ sở dữ liệu chưa sẵn sàng.'];
        }

        if (strlen($newPassword) < 8 || strlen($newPassword) > 72) {
            return ['success' => false, 'message' => 'Mật khẩu mới phải dài ít nhất 8 ký tự và tối đa 72 byte.'];
        }

        if (!hash_equals($newPassword, $confirmPassword)) {
            return ['success' => false, 'message' => 'Mật khẩu xác nhận không khớp.'];
        }

        try {
            comic_shop_forgot_flow_begin($database);
            $check = comic_shop_forgot_flow_check_code_locked($database, $email, trim($code));

            if (empty($check['success']) || empty($check['user_id'])) {
                comic_shop_forgot_flow_commit($database);
                return ['success' => false, 'message' => (string)$check['message']];
            }

            $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
            if ($passwordHash === false) {
                throw new RuntimeException('Không thể băm mật khẩu mới.');
            }

            $updated = comic_shop_forgot_flow_execute(
                $database,
                'UPDATE users SET password = ? WHERE id = ? AND is_active = 1',
                [$passwordHash, (int)$check['user_id']]
            );

            if ($updated !== 1) {
                throw new RuntimeException('Không thể cập nhật mật khẩu tài khoản.');
            }

            comic_shop_forgot_flow_execute(
                $database,
                'DELETE FROM password_otps WHERE user_id = ?',
                [(int)$check['user_id']]
            );

            comic_shop_forgot_flow_commit($database);

            if (session_status() === PHP_SESSION_ACTIVE) {
                unset($_SESSION['user_id'], $_SESSION['user'], $_SESSION['user_name']);
                session_regenerate_id(true);
            }

            return ['success' => true, 'message' => 'Đặt lại mật khẩu thành công. Bạn có thể đăng nhập bằng mật khẩu mới.'];
        } catch (Throwable $exception) {
            comic_shop_forgot_flow_rollback($database);
            error_log('[ComicShop forgot-flow] Lỗi đặt lại mật khẩu: ' . $exception->getMessage());
            return ['success' => false, 'message' => 'Chưa thể đặt lại mật khẩu lúc này. Vui lòng thử lại sau.'];
        }
    }
}