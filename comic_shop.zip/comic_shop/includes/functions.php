<?php
// includes/functions.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';

/**
 * Lấy đối tượng kết nối PDO (tương thích với mọi cách viết trong config/db.php)
 */
function db(): PDO
{
    static $pdoInstance = null;
    if ($pdoInstance instanceof PDO) {
        return $pdoInstance;
    }

    global $pdo,$conn;
    if (isset($pdo) &&$pdo instanceof PDO) {
        $pdoInstance =$pdo;
        return $pdoInstance;
    }
    if (isset($conn) &&$conn instanceof PDO) {
        $pdoInstance =$conn;
        return $pdoInstance;
    }

    // Dự phòng nếu config/db.php dùng mysqli hoặc chưa khởi tạo PDO
    $host = defined('DB_HOST') ? DB_HOST : '127.0.0.1';
    $name = defined('DB_NAME') ? DB_NAME : 'comic_shop';
    $user = defined('DB_USER') ? DB_USER : 'root';
    $pass = defined('DB_PASS') ? DB_PASS : '';

    $dsn = "mysql:host={$host};dbname={$name};charset=utf8mb4";
    $pdoInstance = new PDO($dsn, $user,$pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);

    return $pdoInstance;
}

/**
 * Escape HTML chống XSS
 */
function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

/**
 * Định dạng giá tiền VNĐ
 */
function formatPrice($amount): string
{
    return number_format((float)$amount, 0, ',', '.') . ' đ';
}

/**
 * Tính giá thực tế của truyện (ưu tiên sale_price nếu có giảm giá)
 */
function getEffectivePrice($comic): float
{
    if (!empty($comic['sale_price']) && (float)$comic['sale_price'] > 0 && (float)$comic['sale_price'] < (float)$comic['price']) {
        return (float)$comic['sale_price'];
    }
    return (float)($comic['price'] ?? 0);
}

/**
 * Tạo slug tiếng Việt chuẩn SEO
 */
function createSlug($str): string
{
    $str = (string)$str;
    $str = mb_strtolower(trim($str), 'UTF-8');$unicode = [
        'a' => 'á|à|ả|ã|ạ|ă|ắ|ặ|ằ|ẳ|ẵ|â|ấ|ầ|ẩ|ẫ|ậ',
        'd' => 'đ',
        'e' => 'é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ',
        'i' => 'í|ì|ỉ|ĩ|ị',
        'o' => 'ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ',
        'u' => 'ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự',
        'y' => 'ý|ỳ|ỷ|ỹ|ỵ',
    ];
    foreach ($unicode as $nonUnicode =>$uni) {
        $str = preg_replace("/($uni)/i", $nonUnicode,$str);
    }
    $str = preg_replace('/[^a-z0-9\s-]/', '',$str);
    $str = preg_replace('/[\s-]+/', '-',$str);
    return trim($str, '-');
}

/**
 * Trả về đường dẫn ảnh bìa hoặc ảnh giữ chỗ SVG nếu chưa có file ảnh thật
 */
function coverImageUrl($path, $title = 'Comic'): string
{
    $path  = $path === null ? '' : (string)$path;
    $title = (string)$title;
    if (!empty($path)) {
        $fullPath = __DIR__ . '/../' . ltrim($path, '/');
        if (file_exists($fullPath)) {
            return ltrim($path, '/');
        }
    }
    // Tạo SVG placeholder mang phong cách poster SCRN
    $encodedTitle = rawurlencode(mb_substr($title, 0, 28));
    return "data:image/svg+xml;utf8," . rawurlencode(
        '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="600" viewBox="0 0 400 600">'
        . '<rect width="100%" height="100%" fill="#1f232a"/>'
        . '<rect x="16" y="16" width="368" height="568" fill="none" stroke="#e84c3d" stroke-width="2" opacity="0.6"/>'
        . '<text x="50%" y="45%" dominant-baseline="middle" text-anchor="middle" fill="#e84c3d" font-family="sans-serif" font-size="22" font-weight="bold">SCRN COMIC</text>'
        . '<text x="50%" y="54%" dominant-baseline="middle" text-anchor="middle" fill="#ffffff" font-family="sans-serif" font-size="16">' . htmlspecialchars(mb_substr($title, 0, 26), ENT_QUOTES) . '</text>'
        . '</svg>'
    );
}

/**
 * Hiển thị dải sao đánh giá (★) theo phong cách SCRN
 */
function renderStars($rating, $max = 5): string
{
    $rating = (float)$rating;
    $max    = (int)$max;
    $filled = (int)round($rating);
    if ($filled === 0 && $rating == 0) {$filled = 5; // Mặc định hiển thị 5 sao thẩm mỹ nếu truyện chưa có lượt vote
    }
    $html = '<span class="scrn-stars" aria-label="Rating ' . $rating . ' of ' .$max . '">';
    for ($i = 1; $i <= $max; $i++) {
        $class = ($i <= $filled) ? 'star-filled' : 'star-empty';$html .= '<span class="star ' . $class . '">★</span>';
    }
    $html .= '</span>';
    return $html;
}

/**
 * Nhãn độ tuổi (Age Rating) giống thanh thông số PG của mẫu
 */
function formatAgeRating($age): string
{
    $age = $age === null ? null : (string)$age;
    $map = [
        'all' => 'PG (Mọi lứa tuổi)',
        '13+' => '13+',
        '16+' => '16+',
        '18+' => '18+',
    ];
    return $map[$age ?? 'all'] ?? 'PG';
}

/**
 * Nhãn loại bìa
 */
function formatCoverType($type): string
{
    $type = $type === null ? null : (string)$type;
    $map = [
        'paperback' => 'Bìa mềm',
        'hardcover' => 'Bìa cứng',
        'boxset'    => 'Boxset',
    ];
    return $map[$type ?? 'paperback'] ?? 'Bìa mềm';
}

/**
 * Flash message (thông báo nhanh giữa các trang)
 */
function setFlash($type, $message): void
{
    $type    = (string)$type;
    $message = (string)$message;
    $_SESSION['flash_message'] = [
        'type'    => $type,
        'message' => $message,
    ];
}

function getFlash(): ?array
{
    if (!empty($_SESSION['flash_message'])) {
        $flash =$_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        return $flash;
    }
    return null;
}

/**
 * Quản lý đăng nhập & phân quyền người dùng
 */
function currentUser(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }
    static $cachedUser = null;
    if ($cachedUser !== null) {
        return $cachedUser;
    }
    $stmt = db()->prepare("SELECT id, full_name, email, phone, address, role, avatar, is_active FROM users WHERE id = ? AND is_active = 1 LIMIT 1");
    $stmt->execute([(int)$_SESSION['user_id']]);
    $user =$stmt->fetch();
    if (!$user) {
        unset($_SESSION['user_id'],$_SESSION['user_role']);
        return null;
    }
    $cachedUser =$user;
    return $cachedUser;
}

function isLoggedIn(): bool
{
    return currentUser() !== null;
}

function isAdmin(): bool
{
    $user = currentUser();
    return $user &&$user['role'] === 'admin';
}

function isStaffOrAdmin(): bool
{
    $user = currentUser();
    return $user && in_array($user['role'], ['admin', 'staff'], true);
}

function requireLogin(string $redirect = 'login.php'): void
{
    if (!isLoggedIn()) {
        setFlash('warning', 'Vui lòng đăng nhập để tiếp tục.');
        header('Location: ' . $redirect);
        exit;
    }
}

/**
 * Session ID riêng cho giỏ hàng khách vãng lai (bảng `cart`)
 */
function getCartSessionId(): string
{
    if (empty($_SESSION['cart_session_id'])) {$_SESSION['cart_session_id'] = session_id() ?: bin2hex(random_bytes(16));
    }
    return $_SESSION['cart_session_id'];
}

/**
 * Đồng bộ giỏ hàng từ session sang user_id sau khi đăng nhập
 */
function mergeSessionCartToUser($userId): void
{
    $userId = (int)$userId;
    $sessionId = getCartSessionId();$pdo = db();

    $stmt =$pdo->prepare("SELECT comic_id, quantity FROM cart WHERE session_id = ? AND user_id IS NULL");
    $stmt->execute([$sessionId]);
    $guestItems =$stmt->fetchAll();

    foreach ($guestItems as$item) {
        $check =$pdo->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND comic_id = ?");
        $check->execute([$userId,$item['comic_id']]);
        $existing =$check->fetch();

        if ($existing) {$newQty = (int)$existing['quantity'] + (int)$item['quantity'];
            $upd =$pdo->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
            $upd->execute([$newQty,$existing['id']]);
        } else {
            $ins =$pdo->prepare("INSERT INTO cart (user_id, session_id, comic_id, quantity) VALUES (?, NULL, ?, ?)");
            $ins->execute([$userId, $item['comic_id'],$item['quantity']]);
        }
    }

    $del =$pdo->prepare("DELETE FROM cart WHERE session_id = ? AND user_id IS NULL");
    $del->execute([$sessionId]);
}

/**
 * Thêm sản phẩm vào bảng `cart`
 */
function addToCart($comicId, $quantity = 1): array
{
    $comicId  = (int)$comicId;
    $quantity = (int)$quantity;
    $quantity = max(1, $quantity);$pdo = db();

    $stmt =$pdo->prepare("SELECT id, title, stock, is_active FROM comics WHERE id = ? AND is_active = 1 LIMIT 1");
    $stmt->execute([$comicId]);
    $comic =$stmt->fetch();

    if (!$comic) {
        return ['success' => false, 'message' => 'Truyện không tồn tại hoặc đã ngừng kinh doanh.'];
    }
    if ((int)$comic['stock'] <= 0) {
        return ['success' => false, 'message' => 'Truyện này hiện đã hết hàng.'];
    }

    $user = currentUser();
    if ($user) {
        $check =$pdo->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND comic_id = ?");
        $check->execute([$user['id'],$comicId]);
        $row =$check->fetch();

        if ($row) {
            $newQty = min((int)$comic['stock'], (int)$row['quantity'] +$quantity);
            $upd =$pdo->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
            $upd->execute([$newQty,$row['id']]);
        } else {
            $newQty = min((int)$comic['stock'],$quantity);
            $ins =$pdo->prepare("INSERT INTO cart (user_id, comic_id, quantity) VALUES (?, ?, ?)");
            $ins->execute([$user['id'], $comicId,$newQty]);
        }
    } else {
        $sessionId = getCartSessionId();
        $check =$pdo->prepare("SELECT id, quantity FROM cart WHERE session_id = ? AND user_id IS NULL AND comic_id = ?");
        $check->execute([$sessionId,$comicId]);
        $row =$check->fetch();

        if ($row) {
            $newQty = min((int)$comic['stock'], (int)$row['quantity'] +$quantity);
            $upd =$pdo->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
            $upd->execute([$newQty,$row['id']]);
        } else {
            $newQty = min((int)$comic['stock'],$quantity);
            $ins =$pdo->prepare("INSERT INTO cart (session_id, comic_id, quantity) VALUES (?, ?, ?)");
            $ins->execute([$sessionId, $comicId,$newQty]);
        }
    }

    return [
        'success'    => true,
        'message'    => 'Đã thêm "' . $comic['title'] . '" vào giỏ hàng!',
        'cart_count' => getCartCount(),
    ];
}

/**
 * Lấy danh sách sản phẩm trong giỏ hàng
 */
function getCartItems(): array
{
    $pdo = db();$user = currentUser();

    $sql = "SELECT c.id AS cart_id, c.quantity,
                   m.id AS comic_id, m.title, m.slug, m.price, m.sale_price,
                   m.cover_image, m.stock, m.volume_number, m.cover_type,
                   a.name AS author_name, cat.name AS category_name
            FROM cart c
            JOIN comics m ON c.comic_id = m.id
            LEFT JOIN authors a ON m.author_id = a.id
            LEFT JOIN categories cat ON m.category_id = cat.id
            WHERE m.is_active = 1 AND ";

    if ($user) {$sql .= "c.user_id = ? ORDER BY c.updated_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$user['id']]);
    } else {
        $sql .= "c.session_id = ? AND c.user_id IS NULL ORDER BY c.updated_at DESC";
        $stmt =$pdo->prepare($sql);$stmt->execute([getCartSessionId()]);
    }

    $items =$stmt->fetchAll();
    foreach ($items as &$item) {$item['effective_price'] = getEffectivePrice($item);$item['subtotal']        = $item['effective_price'] * (int)$item['quantity'];
    }
    return $items;
}

/**
 * Đếm tổng số lượng truyện trong giỏ hàng
 */
function getCartCount(): int
{
    $pdo = db();$user = currentUser();

    if ($user) {
        $stmt =$pdo->prepare("SELECT COALESCE(SUM(quantity), 0) FROM cart WHERE user_id = ?");
        $stmt->execute([$user['id']]);
    } else {
        $stmt =$pdo->prepare("SELECT COALESCE(SUM(quantity), 0) FROM cart WHERE session_id = ? AND user_id IS NULL");
        $stmt->execute([getCartSessionId()]);
    }
    return (int)$stmt->fetchColumn();
}

/**
 * Tính tổng tiền giỏ hàng
 */
function getCartTotal(?array $items = null): float
{
    if ($items === null) {$items = getCartItems();
    }
    $total = 0;
    foreach ($items as$item) {
        $total += (float)$item['subtotal'];
    }
    return $total;
}

/**
 * Lấy danh sách toàn bộ thể loại (dùng cho menu & bộ lọc)
 */
function getCategories(): array
{
    $stmt = db()->query("SELECT id, name, slug, description, image FROM categories ORDER BY id ASC");
    return $stmt->fetchAll();
}