<?php
// includes/header.php
require_once __DIR__ . '/functions.php';

$pageTitle     = $pageTitle ?? 'Comic Shop — Thế Giới Truyện Tranh';
$hasHeroBanner = $hasHeroBanner ?? false;
$currentUser   = currentUser();
$cartCount     = getCartCount();
$categories    = getCategories();
$flash         = getFlash();
$currentPage   = basename($_SERVER['PHP_SELF'] ?? 'index.php');
// Trang nào đặt $hideHeaderSearch = true trước khi nạp header thì ẩn nút kính lúp ở thanh trên
$hideHeaderSearch = $hideHeaderSearch ?? false;
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?></title>
    <!-- Google Fonts: Montserrat (Tiêu đề/UI) & Merriweather (Trích dẫn nghiêng giống mẫu SCRN) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,400;1,300;1,400&family=Montserrat:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Font Awesome 6 Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="assets/css/style.css?v=<?= (int)@filemtime(__DIR__ . '/../assets/css/style.css') ?>">
</head>
<body class="<?= $hasHeroBanner ? 'has-hero-banner' : 'no-hero-banner' ?>">

<!-- Hộp tìm kiếm nhanh (Search Modal Overlay) -->
<div class="scrn-search-overlay" id="scrnSearchOverlay" aria-hidden="true">
    <button type="button" class="scrn-search-close" id="scrnSearchClose" aria-label="Đóng tìm kiếm">
        <i class="fa-solid fa-xmark"></i>
    </button>
    <div class="scrn-search-box">
        <form action="comics.php" method="GET" class="scrn-search-form">
            <input type="text" name="q" placeholder="Nhập tên bộ truyện, tác giả, ISBN..." autocomplete="off" id="scrnSearchInput">
            <button type="submit" aria-label="Tìm kiếm">
                <i class="fa-solid fa-magnifying-glass"></i>
            </button>
        </form>
        <p class="scrn-search-hint">Gợi ý: One Piece, Conan, Doraemon, Attack on Titan, Kimetsu no Yaiba...</p>
    </div>
</div>

<!-- Khung giao diện chính (Mô phỏng khung trang SCRN) -->
<div class="scrn-page-wrapper">
    <!-- Thanh Header chuẩn SCRN -->
    <header class="scrn-topbar <?= $hasHeroBanner ? 'scrn-topbar--overlay' : 'scrn-topbar--solid' ?>">
        <div class="scrn-container scrn-topbar-inner">
            <!-- Icon điều hướng bên trái: Trang chủ / Liên hệ -->
            <div class="scrn-topbar-left">
                <nav class="scrn-topbar-actions scrn-nav-icons" aria-label="Điều hướng chính">
                    <a href="index.php" class="scrn-icon-btn<?= $currentPage === 'index.php' ? ' active' : '' ?>" title="Trang chủ" aria-label="Trang chủ">
                        <i class="fa-solid fa-house"></i>
                    </a>
                    <a href="contact.php" class="scrn-icon-btn<?= $currentPage === 'contact.php' ? ' active' : '' ?>" title="Liên hệ" aria-label="Liên hệ">
                        <i class="fa-solid fa-envelope"></i>
                    </a>
                </nav>
            </div>

            <!-- Logo C■MIC ở chính giữa -->
            <div class="scrn-topbar-center">
                <a href="index.php" class="scrn-logo" title="Comic Shop">
                    C<span class="scrn-logo-box"></span>MIC
                </a>
            </div>

            <!-- Social + Search + Giỏ hàng + Tài khoản bên phải -->
            <div class="scrn-topbar-right">
                <div class="scrn-topbar-actions">
                    <?php if (!$hideHeaderSearch): ?>
                    <button type="button" class="scrn-icon-btn" id="scrnSearchBtn" aria-label="Tìm kiếm">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                    <?php endif; ?>

                    <a href="cart.php" class="scrn-icon-btn scrn-cart-btn<?= $currentUser ? '' : ' scrn-cart-btn--guest' ?>" title="Giỏ hàng">
                        <i class="fa-solid fa-bag-shopping"></i>
                        <span class="scrn-cart-badge" id="cart-badge"><?= (int)$cartCount ?></span>
                    </a>

                    <!-- Đơn hàng đã đặt: khách chưa đăng nhập sẽ được chuyển tới trang đăng nhập -->
                    <a href="<?= $currentUser ? 'my-orders.php' : 'login.php?redirect=my-orders.php' ?>" class="scrn-icon-btn<?= $currentPage === 'my-orders.php' ? ' active' : '' ?>" title="Đơn hàng đã đặt" aria-label="Đơn hàng đã đặt">
                        <i class="fa-solid fa-receipt"></i>
                    </a>

                    <?php if ($currentUser): ?>
                        <a href="account.php" class="scrn-user-pill" title="Tài khoản: <?= e($currentUser['full_name']) ?>" aria-label="Tài khoản">
                            <i class="fa-regular fa-user"></i>
                        </a>
                    <?php else: ?>
                        <a href="login.php" class="scrn-user-pill" title="Đăng nhập" aria-label="Đăng nhập">
                            <i class="fa-regular fa-user"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <?php if ($flash): ?>
        <div class="scrn-flash scrn-flash--<?= e($flash['type']) ?>" id="scrnFlashAlert">
            <div class="scrn-container scrn-flash-inner">
                <span><?= e($flash['message']) ?></span>
                <button type="button" class="scrn-flash-close" onclick="this.parentElement.parentElement.remove()">×</button>
            </div>
        </div>
    <?php endif; ?>

    <!-- Vùng thông báo Toast khi thêm giỏ hàng bằng AJAX -->
    <div id="scrnToastContainer" class="scrn-toast-container"></div>

    <main class="scrn-main-content">
