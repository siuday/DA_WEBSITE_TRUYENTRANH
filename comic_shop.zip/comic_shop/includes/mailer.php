     * @return array{success: bool, message: string}
     */
    function comic_shop_send_email(
        string $to,
        string $subject,
        string $htmlBody,
        string $textBody = ''
    ): array {
        $to = trim($to);
        if ($to === '' || filter_var($to, FILTER_VALIDATE_EMAIL) === false) {
            return ['success' => false, 'message' => 'Địa chỉ email người nhận không hợp lệ.'];
        }

        $config = comic_shop_mailer_config();
        if ($config['host'] === '') {
            error_log('[ComicShop mailer] SMTP chưa được cấu hình.');
            return [
                'success' => false,
                'message' => 'Email chưa được cấu hình. Hãy thiết lập SMTP trong config/main.php.',
            ];
        }

        if ($config['from_address'] === '' || filter_var($config['from_address'], FILTER_VALIDATE_EMAIL) === false) {
            error_log('[ComicShop mailer] Địa chỉ gửi email không hợp lệ hoặc chưa được cấu hình.');
            return ['success' => false, 'message' => 'Địa chỉ email gửi chưa được cấu hình hợp lệ.'];
        }

        $libraryDirectory = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'PHPMailer';
        $exceptionFile = $libraryDirectory . DIRECTORY_SEPARATOR . 'Exception.php';
        $mailerFile = $libraryDirectory . DIRECTORY_SEPARATOR . 'PHPMailer.php';
        $smtpFile = $libraryDirectory . DIRECTORY_SEPARATOR . 'SMTP.php';

        foreach ([$exceptionFile, $mailerFile, $smtpFile] as $requiredFile) {
            if (!is_file($requiredFile)) {
                error_log('[ComicShop mailer] Thiếu thư viện PHPMailer: ' . $requiredFile);
                return ['success' => false, 'message' => 'Không tìm thấy thư viện gửi email PHPMailer.'];
            }
        }

        require_once $exceptionFile;
        require_once $mailerFile;
        require_once $smtpFile;

        if (!class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
            error_log('[ComicShop mailer] Không thể nạp lớp PHPMailer.');
            return ['success' => false, 'message' => 'Không thể khởi tạo thư viện gửi email.'];
        }

        try {
            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
            $mail->isSMTP();
            $mail->Host = (string) $config['host'];
            $mail->Port = (int) $config['port'];
            $mail->SMTPAuth = (bool) $config['smtp_auth'];
            $mail->Timeout = (int) $config['timeout'];
            $mail->CharSet = 'UTF-8';
            $mail->Encoding = 'base64';
            $mail->SMTPDebug = 0;

            if ($mail->SMTPAuth) {
                $mail->Username = (string) $config['username'];
                $mail->Password = (string) $config['password'];
            }

            $encryption = (string) $config['encryption'];
            if ($encryption === 'ssl' || $encryption === 'smtps') {
                $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
            } elseif ($encryption === 'tls' || $encryption === 'starttls') {
                $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            } elseif ($encryption === '' || $encryption === 'none') {
                $mail->SMTPSecure = '';
                $mail->SMTPAutoTLS = false;
            } else {
                return ['success' => false, 'message' => 'Kiểu mã hóa SMTP không hợp lệ (dùng tls, ssl hoặc none).'];
            }

            $mail->setFrom((string) $config['from_address'], (string) $config['from_name']);
            $mail->addAddress($to);

            if ($config['reply_to'] !== '' && filter_var($config['reply_to'], FILTER_VALIDATE_EMAIL)) {
                $mail->addReplyTo((string) $config['reply_to']);
            }

            $mail->Subject = $subject;
            $mail->isHTML(true);
            $mail->Body = $htmlBody;
            $mail->AltBody = $textBody !== ''
                ? $textBody
                : trim(html_entity_decode(strip_tags(str_replace(
                    ['<br>', '<br/>', '<br />', '</p>', '</div>'],
                    "\n",
                    $htmlBody
                )), ENT_QUOTES | ENT_HTML5, 'UTF-8'));

            $mail->send();
            return ['success' => true, 'message' => 'Email đã được gửi.'];
        } catch (\Throwable $exception) {
            error_log('[ComicShop mailer] Gửi email thất bại: ' . $exception->getMessage());
            return [
                'success' => false,
                'message' => 'Gửi email thất bại. Hãy kiểm tra cấu hình SMTP và nhật ký PHP.',
            ];
        }
    }
}
