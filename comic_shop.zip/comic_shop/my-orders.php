<?php
/*
 * COMIC SHOP
 * File: my-orders.php
 * Lịch sử và chi tiết đơn hàng của khách hàng.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. KẾT NỐI DATABASE
========================================================= */

$dbConfigFile = __DIR__ . '/config/db.php';
$dbConfigReturn = null;

if (is_file($dbConfigFile)) {
    $dbConfigReturn = require_once $dbConfigFile;
}

$orderDb = null;

$orderDbCandidates = [
    $dbConfigReturn,
    $GLOBALS['comic_shop_db'] ?? null,
    $GLOBALS['pdo'] ?? null,
    $GLOBALS['conn'] ?? null,
    $GLOBALS['mysqli'] ?? null,
    $GLOBALS['db'] ?? null,
    $pdo ?? null,
    $conn ?? null,
    $mysqli ?? null,
    $db ?? null,
];

foreach ($orderDbCandidates as $candidate) {
    if (
        $candidate instanceof PDO ||
        (class_exists('mysqli') && $candidate instanceof mysqli)
    ) {
        $orderDb = $candidate;
        break;
    }
}

$orderDbReady = $orderDb instanceof PDO ||
    (class_exists('mysqli') && $orderDb instanceof mysqli);

/* =========================================================
   2. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_my_orders_escape')) {
    function comic_my_orders_escape($value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_my_orders_money')) {
    function comic_my_orders_money($value): string
    {
        return number_format((float)$value, 0, ',', '.') . ' ₫';
    }
}

/* Tìm đường dẫn ảnh bìa thực tế (DB có thể chỉ lưu tên file). */
if (!function_exists('comic_my_orders_resolve_image')) {
    function comic_my_orders_resolve_image(string $path): string
    {
        $path = ltrim(str_replace('\\', '/', trim($path)), '/');

        if ($path === '') {
            return '';
        }

        if (preg_match('#^(https?:)?//#i', $path)) {
            return $path;
        }

        if (is_file(__DIR__ . '/' . $path)) {
            return $path;
        }

        $info = pathinfo($path);
        $dir = ($info['dirname'] ?? '.') === '.' ? '' : $info['dirname'] . '/';
        $name = (string)($info['filename'] ?? '');
        $dirs = [$dir];

        if ($dir === '') {
            $dirs[] = 'assets/images/covers/';
        }

        foreach ($dirs as $tryDir) {
            if (is_file(__DIR__ . '/' . $tryDir . ($info['basename'] ?? ''))) {
                return $tryDir . $info['basename'];
            }

            foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
                $try = $tryDir . $name . '.' . $ext;

                if ($name !== '' && is_file(__DIR__ . '/' . $try)) {
                    return $try;
                }
            }
        }

        return '';
    }
}

if (!function_exists('comic_my_orders_query')) {
    function comic_my_orders_query(
        $database,
        string $sql,
        array $params = []
    ): array {
        if ($database instanceof PDO) {
            $database->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );

            $statement = $database->prepare($sql);
            $statement->execute($params);

            $rows = $statement->columnCount() > 0
                ? $statement->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $statement->closeCursor();

            return $rows;
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            $statement = $database->prepare($sql);

            if (!$statement) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn database.'
                );
            }

            if ($params !== []) {
                $types = '';
                $bindParams = [];

                foreach ($params as $param) {
                    if (is_int($param) || is_bool($param)) {
                        $types .= 'i';
                    } elseif (is_float($param)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }
                }

                $bindParams[] = $types;

                foreach ($params as &$param) {
                    $bindParams[] = &$param;
                }

                unset($param);

                if (!call_user_func_array(
                    [$statement, 'bind_param'],
                    $bindParams
                )) {
                    $statement->close();

                    throw new RuntimeException(
                        'Không thể gắn tham số truy vấn.'
                    );
                }
            }

            if (!$statement->execute()) {
                $error = $statement->error;
                $statement->close();

                throw new RuntimeException(
                    $error ?: 'Truy vấn database thất bại.'
                );
            }

            $rows = [];

            if ($statement->field_count > 0) {
                $result = $statement->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $statement->close();

                    throw new RuntimeException(
                        'Không đọc được kết quả truy vấn.'
                    );
                }
            }

            $statement->close();

            return $rows;
        }

        throw new RuntimeException(
            'Không tìm thấy kết nối PDO hoặc MySQLi.'
        );
    }
}

if (!function_exists('comic_my_orders_user_id')) {
    function comic_my_orders_user_id(): int
    {
        $candidates = [
            $_SESSION['user']['id'] ?? null,
            $_SESSION['user']['user_id'] ?? null,
            $_SESSION['user_id'] ?? null,
            $_SESSION['customer_id'] ?? null,
            $_SESSION['customer']['id'] ?? null,
        ];

        foreach ($candidates as $value) {
            if (
                (is_int($value) ||
                    (is_string($value) && ctype_digit($value))) &&
                (int)$value > 0
            ) {
                return (int)$value;
            }
        }

        return 0;
    }
}

/* =========================================================
   3. KIỂM TRA ĐĂNG NHẬP
========================================================= */

$currentUserId = comic_my_orders_user_id();

if ($currentUserId < 1) {
    header(
        'Location: login.php?redirect=my-orders.php',
        true,
        303
    );
    exit;
}

/* =========================================================
   4. BỘ LỌC VÀ BIẾN TRANG
========================================================= */

$allowedStatuses = [
    'pending',
    'processing',
    'shipping',
    'completed',
    'cancelled',
];

$statusFilter = isset($_GET['status']) &&
    is_string($_GET['status'])
    ? $_GET['status']
    : '';

if (
    $statusFilter !== '' &&
    !in_array($statusFilter, $allowedStatuses, true)
) {
    $statusFilter = '';
}

$selectedOrderId = max(
    0,
    (int)($_GET['order_id'] ?? 0)
);

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 10;

$totalOrders = 0;
$totalPages = 1;
$orders = [];
$orderThumbs = [];
$statusCounts = array_fill_keys($allowedStatuses, 0);

$orderDetails = null;
$orderItems = [];
$myReviews = [];

$orderError = '';

$summary = [
    'total_orders' => 0,
    'completed_orders' => 0,
    'pending_orders' => 0,
    'total_spent' => 0,
];

/* =========================================================
   4B. XỬ LÝ GỬI ĐÁNH GIÁ (CHỈ CHO ĐƠN ĐÃ HOÀN TẤT)
========================================================= */

if (empty($_SESSION['comic_my_orders_csrf'])) {
    $_SESSION['comic_my_orders_csrf'] = bin2hex(random_bytes(32));
}

$ordersCsrf = (string)$_SESSION['comic_my_orders_csrf'];

$reviewFlash = $_SESSION['comic_my_orders_flash'] ?? null;
unset($_SESSION['comic_my_orders_flash']);

$reviewErrors = [];

$reviewInput = [
    'comic_id' => 0,
    'rating' => 5,
    'comment' => '',
];

if (
    ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' &&
    ($_POST['action'] ?? '') === 'submit_review'
) {
    $postedToken = isset($_POST['csrf_token']) &&
        is_string($_POST['csrf_token'])
        ? $_POST['csrf_token']
        : '';

    $postedOrderId = max(0, (int)($_POST['order_id'] ?? 0));
    $postedComicId = max(0, (int)($_POST['comic_id'] ?? 0));
    $postedRating = (int)($_POST['rating'] ?? 0);
    $postedComment = trim((string)($_POST['comment'] ?? ''));

    $reviewInput = [
        'comic_id' => $postedComicId,
        'rating' => $postedRating >= 1 && $postedRating <= 5
            ? $postedRating
            : 5,
        'comment' => $postedComment,
    ];

    /* Giữ nguyên trang chi tiết đơn khi có lỗi */
    $selectedOrderId = $postedOrderId;

    $commentLength = function_exists('mb_strlen')
        ? mb_strlen($postedComment, 'UTF-8')
        : strlen($postedComment);

    if (!hash_equals($ordersCsrf, $postedToken)) {
        $reviewErrors[] =
            'Phiên làm việc đã hết hạn. Vui lòng tải lại trang và thử lại.';

    } elseif (!$orderDbReady) {
        $reviewErrors[] = 'Chưa kết nối được database.';

    } elseif ($postedOrderId < 1 || $postedComicId < 1) {
        $reviewErrors[] = 'Không xác định được truyện cần đánh giá.';

    } elseif ($postedRating < 1 || $postedRating > 5) {
        $reviewErrors[] =
            'Điểm đánh giá phải nằm trong khoảng 1 đến 5 sao.';

    } elseif ($commentLength > 5000) {
        $reviewErrors[] = 'Bình luận không được vượt quá 5.000 ký tự.';

    } else {
        try {
            /*
             * Chỉ cho đánh giá khi truyện nằm trong đơn hàng
             * của chính tài khoản này và đơn đã hoàn tất.
             */
            $eligibleRows = comic_my_orders_query(
                $orderDb,
                "SELECT oi.comic_id
                 FROM order_items oi
                 INNER JOIN orders o ON o.id = oi.order_id
                 WHERE o.id = ?
                   AND o.user_id = ?
                   AND o.status = 'completed'
                   AND oi.comic_id = ?
                 LIMIT 1",
                [$postedOrderId, $currentUserId, $postedComicId]
            );

            if (!$eligibleRows) {
                $reviewErrors[] =
                    'Bạn chỉ có thể đánh giá truyện thuộc đơn hàng đã hoàn tất của mình.';
            } else {
                $activeUserRows = comic_my_orders_query(
                    $orderDb,
                    'SELECT id FROM users
                     WHERE id = ? AND is_active = 1
                     LIMIT 1',
                    [$currentUserId]
                );

                $existingRows = comic_my_orders_query(
                    $orderDb,
                    'SELECT id FROM reviews
                     WHERE comic_id = ? AND user_id = ?
                     LIMIT 1',
                    [$postedComicId, $currentUserId]
                );

                if (!$activeUserRows) {
                    $reviewErrors[] =
                        'Tài khoản không tồn tại hoặc đã bị khóa.';
                } elseif ($existingRows) {
                    $reviewErrors[] =
                        'Bạn đã đánh giá truyện này rồi.';
                }
            }

            if (!$reviewErrors) {
                comic_my_orders_query(
                    $orderDb,
                    'INSERT INTO reviews
                        (comic_id, user_id, rating, comment)
                     VALUES (?, ?, ?, ?)',
                    [
                        $postedComicId,
                        $currentUserId,
                        $postedRating,
                        $postedComment !== '' ? $postedComment : null,
                    ]
                );

                comic_my_orders_query(
                    $orderDb,
                    'UPDATE comics
                     SET
                        rating_avg = (
                            SELECT COALESCE(ROUND(AVG(r.rating), 1), 0)
                            FROM reviews r
                            WHERE r.comic_id = ?
                        ),
                        review_count = (
                            SELECT COUNT(*)
                            FROM reviews r
                            WHERE r.comic_id = ?
                        )
                     WHERE id = ?',
                    [$postedComicId, $postedComicId, $postedComicId]
                );

                $_SESSION['comic_my_orders_flash'] =
                    'Cảm ơn bạn đã gửi đánh giá cho truyện!';

                $_SESSION['comic_my_orders_csrf'] =
                    bin2hex(random_bytes(32));

                header(
                    'Location: my-orders.php?order_id=' .
                    $postedOrderId . '#review-' . $postedComicId,
                    true,
                    303
                );
                exit;
            }

        } catch (Throwable $exception) {
            error_log(
                '[Comic Shop My Orders Review] ' .
                $exception->getMessage()
            );

            $reviewErrors[] =
                'Không thể lưu đánh giá. Vui lòng thử lại.';
        }
    }
}

/* =========================================================
   4C. SỬA THÔNG TIN NHẬN HÀNG (CHỈ ĐƠN CHỜ XỬ LÝ)
========================================================= */

$editOrderId = max(0, (int)($_GET['edit_order'] ?? 0));
$editOrder = null;
$editNotice = '';
$editErrors = [];
$editInput = null;

$statusQuery = $statusFilter !== ''
    ? '&status=' . rawurlencode($statusFilter)
    : '';

if (!function_exists('comic_my_orders_len')) {
    function comic_my_orders_len(string $value): int
    {
        return function_exists('mb_strlen')
            ? mb_strlen($value, 'UTF-8')
            : strlen($value);
    }
}

if (
    ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' &&
    ($_POST['action'] ?? '') === 'update_order'
) {
    $postedToken = isset($_POST['csrf_token']) &&
        is_string($_POST['csrf_token'])
        ? $_POST['csrf_token']
        : '';

    $editOrderId = max(0, (int)($_POST['order_id'] ?? 0));

    $editInput = [
        'full_name' => trim((string)($_POST['full_name'] ?? '')),
        'phone' => trim((string)($_POST['phone'] ?? '')),
        'email' => trim((string)($_POST['email'] ?? '')),
        'address' => trim((string)($_POST['address'] ?? '')),
        'note' => trim((string)($_POST['note'] ?? '')),
    ];

    if (!hash_equals($ordersCsrf, $postedToken)) {
        $editErrors[] =
            'Phiên làm việc đã hết hạn. Vui lòng tải lại trang và thử lại.';
    }

    if (!$orderDbReady) {
        $editErrors[] = 'Chưa kết nối được database.';
    }

    if ($editOrderId < 1) {
        $editErrors[] = 'Không xác định được đơn hàng cần sửa.';
    }

    $nameLength = comic_my_orders_len($editInput['full_name']);

    if ($nameLength < 2 || $nameLength > 100) {
        $editErrors[] = 'Họ tên phải từ 2 đến 100 ký tự.';
    }

    if (!preg_match('/^[0-9+\s().-]{8,20}$/', $editInput['phone'])) {
        $editErrors[] = 'Số điện thoại không hợp lệ.';
    }

    if (
        $editInput['email'] === '' ||
        comic_my_orders_len($editInput['email']) > 150 ||
        !filter_var($editInput['email'], FILTER_VALIDATE_EMAIL)
    ) {
        $editErrors[] = 'Email không hợp lệ.';
    }

    $addressLength = comic_my_orders_len($editInput['address']);

    if ($addressLength < 5 || $addressLength > 500) {
        $editErrors[] = 'Địa chỉ giao hàng phải từ 5 đến 500 ký tự.';
    }

    if (comic_my_orders_len($editInput['note']) > 1000) {
        $editErrors[] = 'Ghi chú không được vượt quá 1.000 ký tự.';
    }

    if (!$editErrors) {
        try {
            /* Chỉ sửa đơn của chính tài khoản này và còn chờ xử lý */
            $editableRows = comic_my_orders_query(
                $orderDb,
                "SELECT id FROM orders
                 WHERE id = ? AND user_id = ? AND status = 'pending'
                 LIMIT 1",
                [$editOrderId, $currentUserId]
            );

            if (!$editableRows) {
                $editErrors[] =
                    'Chỉ có thể sửa thông tin của đơn hàng đang chờ xử lý.';
            } else {
                comic_my_orders_query(
                    $orderDb,
                    "UPDATE orders
                     SET full_name = ?,
                         phone = ?,
                         email = ?,
                         address = ?,
                         note = ?
                     WHERE id = ?
                       AND user_id = ?
                       AND status = 'pending'",
                    [
                        $editInput['full_name'],
                        $editInput['phone'],
                        $editInput['email'],
                        $editInput['address'],
                        $editInput['note'] !== '' ? $editInput['note'] : null,
                        $editOrderId,
                        $currentUserId,
                    ]
                );

                $_SESSION['comic_my_orders_csrf'] =
                    bin2hex(random_bytes(32));

                header(
                    'Location: my-orders.php' .
                    ($statusFilter !== ''
                        ? '?status=' . rawurlencode($statusFilter)
                        : ''),
                    true,
                    303
                );
                exit;
            }

        } catch (Throwable $exception) {
            error_log(
                '[Comic Shop My Orders Edit] ' .
                $exception->getMessage()
            );

            $editErrors[] =
                'Không thể lưu thay đổi. Vui lòng thử lại.';
        }
    }
}

/* =========================================================
   5. TẢI DỮ LIỆU ĐƠN HÀNG
========================================================= */

if ($orderDbReady) {
    try {
        /*
         * Tóm tắt các đơn hàng của riêng khách hàng đang đăng nhập.
         */
        $summaryRows = comic_my_orders_query(
            $orderDb,
            "SELECT
                COUNT(*) AS total_orders,
                COALESCE(SUM(
                    CASE WHEN status = 'completed'
                         THEN 1 ELSE 0 END
                ), 0) AS completed_orders,
                COALESCE(SUM(
                    CASE WHEN status IN ('pending', 'processing', 'shipping')
                         THEN 1 ELSE 0 END
                ), 0) AS pending_orders,
                COALESCE(SUM(
                    CASE WHEN status <> 'cancelled'
                         THEN total_amount ELSE 0 END
                ), 0) AS total_spent
             FROM orders
             WHERE user_id = ?",
            [$currentUserId]
        );

        if ($summaryRows) {
            $summary = [
                'total_orders' => (int)$summaryRows[0]['total_orders'],
                'completed_orders' => (int)$summaryRows[0]['completed_orders'],
                'pending_orders' => (int)$summaryRows[0]['pending_orders'],
                'total_spent' => (float)$summaryRows[0]['total_spent'],
            ];
        }

        /*
         * Đếm số đơn theo từng trạng thái cho các nút lọc.
         */
        $statusCountRows = comic_my_orders_query(
            $orderDb,
            'SELECT status, COUNT(*) AS total
             FROM orders
             WHERE user_id = ?
             GROUP BY status',
            [$currentUserId]
        );

        foreach ($statusCountRows as $statusCountRow) {
            $countKey = (string)$statusCountRow['status'];

            if (isset($statusCounts[$countKey])) {
                $statusCounts[$countKey] = (int)$statusCountRow['total'];
            }
        }

        /*
         * Lọc trạng thái và đếm số đơn.
         */
        $where = ['user_id = ?'];
        $params = [$currentUserId];

        if ($statusFilter !== '') {
            $where[] = 'status = ?';
            $params[] = $statusFilter;
        }

        $whereSql = ' WHERE ' . implode(' AND ', $where);

        $countRows = comic_my_orders_query(
            $orderDb,
            'SELECT COUNT(*) AS total
             FROM orders' . $whereSql,
            $params
        );

        $totalOrders = (int)($countRows[0]['total'] ?? 0);

        $totalPages = max(
            1,
            (int)ceil($totalOrders / $perPage)
        );

        $page = min($page, $totalPages);
        $offset = ($page - 1) * $perPage;

        $listParams = $params;
        $listParams[] = $perPage;
        $listParams[] = $offset;

        $orders = comic_my_orders_query(
            $orderDb,
            'SELECT
                id,
                order_code,
                total_amount,
                payment_method,
                payment_status,
                status,
                created_at,
                updated_at
             FROM orders' . $whereSql . '
             ORDER BY created_at DESC, id DESC
             LIMIT ? OFFSET ?',
            $listParams
        );

        /*
         * Lấy ảnh bìa của sản phẩm đầu tiên trong mỗi đơn
         * và tổng số dòng sản phẩm để hiện huy hiệu "+N".
         */
        if ($orders) {
            $listOrderIds = array_map(
                static function ($row) {
                    return (int)$row['id'];
                },
                $orders
            );

            $thumbRows = comic_my_orders_query(
                $orderDb,
                'SELECT
                    oi.order_id,
                    oi.comic_title,
                    c.slug,
                    c.cover_image
                 FROM order_items oi
                 LEFT JOIN comics c ON c.id = oi.comic_id
                 WHERE oi.order_id IN (' .
                    implode(',', array_fill(0, count($listOrderIds), '?')) .
                 ')
                 ORDER BY oi.id ASC',
                $listOrderIds
            );

            foreach ($thumbRows as $thumbRow) {
                $thumbOrderId = (int)$thumbRow['order_id'];

                if (!isset($orderThumbs[$thumbOrderId])) {
                    $thumbSrc = comic_my_orders_resolve_image(
                        (string)($thumbRow['cover_image'] ?? '')
                    );

                    if ($thumbSrc === '' && !empty($thumbRow['slug'])) {
                        $thumbSrc = comic_my_orders_resolve_image(
                            'assets/images/covers/' . (string)$thumbRow['slug']
                        );
                    }

                    $orderThumbs[$thumbOrderId] = [
                        'src' => $thumbSrc,
                        'title' => (string)($thumbRow['comic_title'] ?? ''),
                        'count' => 0,
                    ];
                }

                $orderThumbs[$thumbOrderId]['count']++;
            }
        }

        /*
         * Chỉ tải chi tiết khi đơn thuộc về tài khoản hiện tại.
         * Không cho phép khách xem đơn của tài khoản khác bằng cách
         * sửa order_id trên URL.
         */
        if ($editOrderId > 0) {
            $editRows = comic_my_orders_query(
                $orderDb,
                'SELECT
                    id,
                    order_code,
                    full_name,
                    email,
                    phone,
                    address,
                    note,
                    status
                 FROM orders
                 WHERE id = ?
                   AND user_id = ?
                 LIMIT 1',
                [$editOrderId, $currentUserId]
            );

            $editOrder = $editRows[0] ?? null;

            if (!$editOrder) {
                $editNotice =
                    'Đơn hàng không tồn tại hoặc không thuộc tài khoản của bạn.';
            } elseif (($editOrder['status'] ?? '') !== 'pending') {
                $editNotice =
                    'Chỉ có thể sửa thông tin khi đơn hàng đang ở trạng thái Chờ xử lý.';
                $editOrder = null;
            }
        }

        if ($selectedOrderId > 0) {
            $detailRows = comic_my_orders_query(
                $orderDb,
                'SELECT
                    id,
                    order_code,
                    full_name,
                    email,
                    phone,
                    address,
                    note,
                    total_amount,
                    payment_method,
                    payment_status,
                    status,
                    created_at,
                    updated_at
                 FROM orders
                 WHERE id = ?
                   AND user_id = ?
                 LIMIT 1',
                [$selectedOrderId, $currentUserId]
            );

            $orderDetails = $detailRows[0] ?? null;

            if ($orderDetails) {
                $orderItems = comic_my_orders_query(
                    $orderDb,
                    'SELECT
                        oi.id,
                        oi.comic_id,
                        oi.comic_title,
                        oi.price,
                        oi.quantity,
                        oi.total,
                        c.slug,
                        c.cover_image
                     FROM order_items oi
                     LEFT JOIN comics c ON c.id = oi.comic_id
                     WHERE oi.order_id = ?
                     ORDER BY oi.id ASC',
                    [(int)$orderDetails['id']]
                );

                /*
                 * Với đơn đã hoàn tất: lấy các đánh giá mà tài khoản
                 * này đã gửi cho những truyện trong đơn.
                 */
                if (($orderDetails['status'] ?? '') === 'completed') {
                    $reviewComicIds = [];

                    foreach ($orderItems as $orderItem) {
                        $itemComicId = (int)($orderItem['comic_id'] ?? 0);

                        if ($itemComicId > 0) {
                            $reviewComicIds[$itemComicId] = $itemComicId;
                        }
                    }

                    if ($reviewComicIds) {
                        $reviewComicIds = array_values($reviewComicIds);

                        $reviewRows = comic_my_orders_query(
                            $orderDb,
                            'SELECT comic_id, rating, comment, created_at
                             FROM reviews
                             WHERE user_id = ?
                               AND comic_id IN (' .
                                implode(
                                    ',',
                                    array_fill(0, count($reviewComicIds), '?')
                                ) . ')',
                            array_merge([$currentUserId], $reviewComicIds)
                        );

                        foreach ($reviewRows as $reviewRow) {
                            $myReviews[(int)$reviewRow['comic_id']] = $reviewRow;
                        }
                    }
                }
            }
        }

    } catch (Throwable $exception) {
        error_log(
            '[Comic Shop My Orders] ' . $exception->getMessage()
        );

        $orderError =
            'Không tải được lịch sử đơn hàng. Hãy kiểm tra kết nối database.';
    }
} else {
    $orderError =
        'Chưa kết nối được database. Hãy kiểm tra config/db.php.';
}

/* =========================================================
   6. CHUẨN BỊ GIAO DIỆN
========================================================= */

$statusLabels = [
    'pending' => 'Chờ xử lý',
    'processing' => 'Đang xử lý',
    'shipping' => 'Đang giao hàng',
    'completed' => 'Hoàn tất',
    'cancelled' => 'Đã hủy',
];

$statusClasses = [
    'pending' => 'pending',
    'processing' => 'processing',
    'shipping' => 'shipping',
    'completed' => 'completed',
    'cancelled' => 'cancelled',
];

$paymentMethodLabels = [
    'cod' => 'Thanh toán khi nhận hàng',
    'banking' => 'Chuyển khoản ngân hàng',
];

$paymentStatusLabels = [
    'pending' => 'Chờ thanh toán',
    'completed' => 'Đã thanh toán',
    'failed' => 'Thanh toán thất bại',
];

$pageTitle = 'Đơn hàng của tôi | Comic Shop';
$pageDescription = 'Xem lịch sử đơn hàng và chi tiết các đơn mua tại Comic Shop.';
$activeMenu = 'orders';

/* Trang đơn hàng không hiện icon tìm kiếm trên thanh header */
$hideHeaderSearch = true;

$headerFile = __DIR__ . '/includes/header.php';
$footerFile = __DIR__ . '/includes/footer.php';

if (is_file($headerFile)) {
    require_once $headerFile;
} else {
    ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= comic_my_orders_escape($pageTitle) ?></title>
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
    <?php
}
?>

<style>
/* Giao diện đơn hàng: cùng bảng màu tối, thẻ kính, viền xám và nút bo tròn như trang chủ / đăng nhập */
body:has(.my-orders-page),
.scrn-page-wrapper:has(.my-orders-page){background-color:#1c1c1f}
/* Trang đơn hàng không hiện chân trang */
body:has(.my-orders-page) footer{display:none!important}
body:has(.my-orders-page){margin:0}
.scrn-page-wrapper:has(.my-orders-page){display:flex;flex-direction:column;min-height:100vh;min-height:100dvh}
.scrn-page-wrapper:has(.my-orders-page) .scrn-main-content{flex:1 1 auto;display:flex;flex-direction:column;padding:0}

.my-orders-page{
    --bg:#1c1c1f;--glass:#232327;--glass-2:#2c2c31;--glass-3:#36363c;
    --stroke:#3d3d44;--line:rgba(255,255,255,.38);--text:#f2f2f2;--muted:#a9a9b2;
    flex:1 1 auto;padding:30px 0 44px;background:var(--bg);color:var(--text);
    font-family:"Inter","Montserrat",system-ui,-apple-system,"Segoe UI",Arial,sans-serif
}
.my-orders-page *{box-sizing:border-box}
.my-orders-page a{color:inherit;text-decoration:none}
.my-orders-page .mo-wrap{width:min(1180px,calc(100% - 48px));margin:0 auto}

.my-orders-page .mo-heading{margin-bottom:22px}
.my-orders-page .mo-eyebrow{color:var(--muted);font-size:10px;font-weight:800;letter-spacing:2px;text-transform:uppercase}
.my-orders-page .mo-title{display:flex;align-items:center;gap:10px;margin:8px 0 6px;font-size:clamp(24px,3.5vw,32px);font-weight:800;letter-spacing:-.5px}
.my-orders-page .mo-title:before{content:"";width:4px;height:.85em;border-radius:4px;background:var(--text)}
.my-orders-page .mo-description{margin:0;color:var(--muted);font-size:12.5px;line-height:1.7}
.my-orders-page .mo-alert{margin-bottom:16px;padding:12px 16px;border:1px solid var(--stroke);border-left:4px solid var(--text);border-radius:18px;background:var(--glass);color:var(--text);font-size:12px;line-height:1.7}

/* Thống kê */
.my-orders-page .mo-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-bottom:20px}
.my-orders-page .mo-stat{padding:16px 18px;border:1px solid var(--stroke);border-radius:24px;background:var(--glass)}
.my-orders-page .mo-stat-label{display:block;color:var(--muted);font-size:11px;font-weight:600}
.my-orders-page .mo-stat-value{display:block;margin-top:8px;font-size:23px;font-weight:800;color:var(--text);overflow-wrap:anywhere}

/* Khung nội dung */
.my-orders-page .mo-layout{display:grid;grid-template-columns:minmax(0,1fr);gap:18px}
.my-orders-page .mo-panel{min-width:0;overflow:hidden;border:1px solid var(--stroke);border-radius:24px;background:var(--glass)}
.my-orders-page .mo-panel-head{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;padding:16px 22px;border-bottom:1px solid var(--stroke)}
.my-orders-page .mo-panel-head h2{display:flex;align-items:center;gap:9px;margin:0;font-size:15px;font-weight:800}
.my-orders-page .mo-panel-head h2:before{content:"";width:4px;height:14px;border-radius:4px;background:var(--text)}
.my-orders-page .mo-muted{color:var(--muted);font-size:11px;line-height:1.8}

/* Bộ lọc dạng chip */
.my-orders-page .mo-filter{display:flex;flex-wrap:wrap;gap:8px}
.my-orders-page .mo-filter a{display:inline-flex;min-height:32px;align-items:center;justify-content:center;padding:6px 14px;border:1px solid var(--stroke);border-radius:999px;background:var(--glass-2);color:var(--muted);font-size:11px;font-weight:700;transition:background .2s,color .2s,border-color .2s}
.my-orders-page .mo-filter a:hover,.my-orders-page .mo-filter a.active{border-color:var(--line);background:var(--glass-3);color:var(--text)}

/* Bảng */
.my-orders-page .mo-table-wrap{width:100%;overflow-x:auto}
.my-orders-page .mo-table{width:100%;min-width:710px;border-collapse:collapse}
.my-orders-page .mo-table th,.my-orders-page .mo-items th{padding:12px 16px;background:var(--glass-2);color:var(--muted);text-align:left;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.5px;white-space:nowrap}
.my-orders-page .mo-table td{padding:14px 16px;border-top:1px solid var(--stroke);vertical-align:middle;font-size:12px;color:var(--text)}
.my-orders-page .mo-table tbody tr{transition:background .15s}
.my-orders-page .mo-table tbody tr:hover{background:var(--glass-2)}
.my-orders-page .mo-code{display:block;color:var(--text);font-size:12px;font-weight:800}
.my-orders-page .mo-date{display:block;margin-top:5px;color:var(--muted);font-size:10px}
.my-orders-page .mo-payment-status{display:block;margin-top:5px;color:var(--muted);font-size:10px;line-height:1.5}

/* Trạng thái */
.my-orders-page .mo-status{display:inline-flex;padding:5px 12px;border-radius:999px;font-size:10px;font-weight:800;white-space:nowrap}
.my-orders-page .mo-status.pending{background:var(--glass-3);color:#f2f2f2}
.my-orders-page .mo-status.processing{background:#46464e;color:#f2f2f2}
.my-orders-page .mo-status.shipping{background:#5a5a63;color:#ffffff}
.my-orders-page .mo-status.completed{background:#f2f2f2;color:#111111}
.my-orders-page .mo-status.cancelled{background:transparent;color:var(--muted);box-shadow:inset 0 0 0 1px #4d4d55}

/* Nút */
.my-orders-page .mo-btn{display:inline-flex;height:36px;align-items:center;justify-content:center;gap:6px;padding:0 18px;border:1.5px solid #f2f2f2;border-radius:999px;background:#f2f2f2;color:#111111;font-size:11px;font-weight:700;white-space:nowrap;cursor:pointer;transition:background .2s,transform .2s}
.my-orders-page .mo-btn:hover{background:#ffffff;border-color:#ffffff;color:#111111;transform:translateY(-1px)}
.my-orders-page .mo-btn.secondary{border-color:var(--line);background:rgba(255,255,255,.08);color:var(--text)}
.my-orders-page .mo-btn.secondary:hover{background:rgba(255,255,255,.18);border-color:var(--line);color:var(--text)}

/* Trống */
.my-orders-page .mo-empty{padding:48px 20px;text-align:center}
.my-orders-page .mo-empty-icon{display:grid;place-items:center;width:60px;height:60px;margin:0 auto 14px;border:1.5px solid var(--line);border-radius:50%;background:rgba(255,255,255,.08);color:var(--text);font-size:24px}
.my-orders-page .mo-empty h3{margin:0 0 9px;font-size:18px;font-weight:800}
.my-orders-page .mo-empty p{margin:0 auto 18px;max-width:420px;color:var(--muted);font-size:12px;line-height:1.8}

/* Phân trang */
.my-orders-page .mo-pagination{display:flex;justify-content:center;align-items:center;flex-wrap:wrap;gap:8px;padding:16px;border-top:1px solid var(--stroke)}
.my-orders-page .mo-page{display:inline-flex;min-width:34px;height:34px;align-items:center;justify-content:center;padding:0 10px;border:1px solid var(--stroke);border-radius:999px;background:var(--glass-2);color:var(--text);font-size:11px;font-weight:700;transition:background .2s,color .2s}
.my-orders-page .mo-page:hover,.my-orders-page .mo-page.current{border-color:#f2f2f2;background:#f2f2f2;color:#111111}

/* Chi tiết đơn */
.my-orders-page .mo-detail-body{padding:20px 22px}
.my-orders-page .mo-detail-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-bottom:22px}
.my-orders-page .mo-detail-item{padding:13px 16px;border:1px solid var(--stroke);border-radius:18px;background:var(--glass-2)}
.my-orders-page .mo-detail-label{display:block;color:var(--muted);font-size:10px;font-weight:700}
.my-orders-page .mo-detail-value{display:block;margin-top:6px;color:var(--text);font-size:12px;font-weight:700;line-height:1.7;overflow-wrap:anywhere}
.my-orders-page .mo-items-title{display:flex;align-items:center;gap:9px;margin:0 0 12px;font-size:13px;font-weight:800}
.my-orders-page .mo-items-title:before{content:"";width:4px;height:13px;border-radius:4px;background:var(--text)}
.my-orders-page .mo-items{width:100%;border-collapse:collapse;overflow:hidden;border-radius:14px}
.my-orders-page .mo-items th{padding:10px 12px}
.my-orders-page .mo-items td{padding:12px;border-top:1px solid var(--stroke);font-size:11px;line-height:1.7;color:var(--text)}
.my-orders-page .mo-items a:hover{text-decoration:underline}
.my-orders-page .mo-items-total{color:var(--text);font-weight:800;white-space:nowrap}
.my-orders-page .mo-detail-footer{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-top:19px;padding-top:17px;border-top:1px solid var(--stroke)}
.my-orders-page .mo-total-label{color:var(--muted);font-size:12px;font-weight:700}
.my-orders-page .mo-total-value{display:block;margin-top:4px;color:var(--text);font-size:23px;font-weight:800}

/* ===== Gọn lại để vừa một màn hình, hạn chế phải kéo trang ===== */
.my-orders-page{padding:16px 0 20px}
.my-orders-page .mo-wrap{width:min(1100px,calc(100% - 48px))}
.my-orders-page .mo-heading{margin-bottom:12px}
.my-orders-page .mo-title{margin:6px 0 4px;font-size:clamp(22px,3vw,28px)}
.my-orders-page .mo-description{font-size:12px;line-height:1.5}
.my-orders-page .mo-alert{margin-bottom:12px;padding:9px 14px;border-radius:16px}
.my-orders-page .mo-stats{gap:10px;margin-bottom:12px}
.my-orders-page .mo-stat{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 16px;border-radius:999px}
.my-orders-page .mo-stat-label{font-size:10px;line-height:1.3}
.my-orders-page .mo-stat-value{margin-top:0;font-size:16px;line-height:1.3;text-align:right}
.my-orders-page .mo-layout{gap:12px}
.my-orders-page .mo-panel{border-radius:24px}
.my-orders-page .mo-panel-head{padding:11px 20px;gap:8px}
.my-orders-page .mo-filter{gap:6px}
.my-orders-page .mo-filter a{min-height:28px;padding:4px 12px;font-size:10.5px}
.my-orders-page .mo-empty{padding:26px 20px}
.my-orders-page .mo-empty-icon{width:46px;height:46px;margin-bottom:10px;font-size:19px}
.my-orders-page .mo-empty h3{margin-bottom:6px;font-size:16px}
.my-orders-page .mo-empty p{margin-bottom:14px;line-height:1.6}
.my-orders-page .mo-table th{padding:9px 14px}
.my-orders-page .mo-table td{padding:9px 14px}
.my-orders-page .mo-pagination{padding:10px}
.my-orders-page .mo-detail-body{padding:14px 20px}
.my-orders-page .mo-detail-grid{grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-bottom:14px}
.my-orders-page .mo-detail-item{padding:9px 14px;border-radius:16px}
.my-orders-page .mo-detail-footer{margin-top:12px;padding-top:12px}
.my-orders-page .mo-total-value{font-size:20px}
@media(max-width:850px){.my-orders-page .mo-detail-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:580px){.my-orders-page .mo-stat{border-radius:18px}.my-orders-page .mo-detail-grid{grid-template-columns:1fr}}

/* ===== Nội dung to hơn + khung đơn hàng tự cuộn bên trong ===== */
/* Khóa chiều cao trang bằng màn hình; chỉ vùng danh sách đơn hàng có thanh cuộn */
.scrn-page-wrapper:has(.my-orders-page){height:100vh;height:100dvh;min-height:0;overflow:hidden}
.scrn-page-wrapper:has(.my-orders-page) .scrn-main-content{min-height:0}
.my-orders-page{display:flex;flex-direction:column;min-height:0;overflow:hidden;padding:22px 0 22px}
.my-orders-page .mo-wrap{width:min(1240px,calc(100% - 64px));flex:1 1 auto;min-height:0;display:flex;flex-direction:column}
.my-orders-page .mo-heading{flex:none;margin-bottom:16px}
.my-orders-page .mo-eyebrow{font-size:11px}
.my-orders-page .mo-title{margin:8px 0 6px;font-size:clamp(26px,3.2vw,36px)}
.my-orders-page .mo-description{font-size:14px}
.my-orders-page .mo-alert{flex:none;font-size:13px}
.my-orders-page .mo-stats{flex:none;gap:14px;margin-bottom:16px}
.my-orders-page .mo-stat{padding:14px 22px}
.my-orders-page .mo-stat-label{font-size:12px}
.my-orders-page .mo-stat-value{font-size:22px!important}
.my-orders-page .mo-layout{flex:1 1 auto;min-height:0;display:flex;flex-direction:column;gap:14px}
.my-orders-page .mo-panel{flex:1 1 0;min-height:0;display:flex;flex-direction:column}
.my-orders-page .mo-panel-head{flex:none;padding:16px 26px}
.my-orders-page .mo-panel-head h2{font-size:18px}
.my-orders-page .mo-panel-head h2:before{height:17px}
.my-orders-page .mo-muted{font-size:13px}
.my-orders-page .mo-filter a{min-height:38px;padding:7px 18px;font-size:13px}
.my-orders-page .mo-btn{height:44px;padding:0 24px;font-size:13px}
/* Vùng cuộn của danh sách đơn */
.my-orders-page .mo-table-wrap{flex:1 1 auto;min-height:0;overflow:auto;scrollbar-width:thin;scrollbar-color:#55555e transparent}
.my-orders-page .mo-table-wrap::-webkit-scrollbar{width:10px;height:10px}
.my-orders-page .mo-table-wrap::-webkit-scrollbar-thumb{background:#55555e;border-radius:10px;border:2px solid #232327}
.my-orders-page .mo-table-wrap::-webkit-scrollbar-track{background:transparent}
.my-orders-page .mo-table th{position:sticky;top:0;z-index:1;padding:13px 20px;font-size:11px}
.my-orders-page .mo-table td{padding:16px 20px;font-size:14px}
.my-orders-page .mo-code{font-size:14px}
.my-orders-page .mo-date,.my-orders-page .mo-payment-status{font-size:12px}
.my-orders-page .mo-status{padding:6px 14px;font-size:12px}
.my-orders-page .mo-pagination{flex:none;padding:12px}
.my-orders-page .mo-page{min-width:38px;height:38px;font-size:13px}
/* Trạng thái trống */
.my-orders-page .mo-empty{flex:1 1 auto;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px}
.my-orders-page .mo-empty-icon{width:68px;height:68px;margin-bottom:14px;font-size:26px}
.my-orders-page .mo-empty h3{font-size:22px;margin-bottom:8px}
.my-orders-page .mo-empty p{font-size:14px;margin-bottom:18px;max-width:480px}
/* Chi tiết đơn: phần thân tự cuộn */
.my-orders-page .mo-detail-body{flex:1 1 auto;min-height:0;overflow-y:auto;padding:20px 26px;scrollbar-width:thin;scrollbar-color:#55555e transparent}
.my-orders-page .mo-detail-label{font-size:12px}
.my-orders-page .mo-detail-value{font-size:14px}
.my-orders-page .mo-detail-item{padding:12px 16px}
.my-orders-page .mo-items-title{font-size:15px}
.my-orders-page .mo-items th{font-size:11px}
.my-orders-page .mo-items td{font-size:13px}
.my-orders-page .mo-total-value{font-size:24px}
/* Hàng nút dưới cùng luôn hiện */
.my-orders-page .mo-layout>div:last-child{flex:none}
/* Màn hình nhỏ: trả lại cuộn cả trang như bình thường */
@media(max-width:720px),(max-height:560px){
    .scrn-page-wrapper:has(.my-orders-page){height:auto;min-height:100dvh;overflow:visible}
    .my-orders-page{overflow:visible}
    .my-orders-page .mo-wrap{width:calc(100% - 28px);display:block}
    .my-orders-page .mo-layout,.my-orders-page .mo-panel{display:block}
    .my-orders-page .mo-table-wrap{overflow-x:auto}
    .my-orders-page .mo-detail-body{overflow:visible}
    .my-orders-page .mo-empty{display:block}
}

/* ===== Trạng thái trống: thu nhỏ để không bị cắt, tự cuộn nếu khung quá thấp ===== */
.my-orders-page .mo-empty{justify-content:flex-start;overflow-y:auto;padding:14px 20px;scrollbar-width:thin;scrollbar-color:#55555e transparent}
.my-orders-page .mo-empty>:first-child{margin-top:auto}
.my-orders-page .mo-empty>:last-child{margin-bottom:auto}
.my-orders-page .mo-empty-icon{flex:none;width:46px;height:46px;margin-bottom:8px;font-size:19px}
.my-orders-page .mo-empty h3{margin-bottom:5px;font-size:16px}
.my-orders-page .mo-empty p{margin-bottom:12px;max-width:420px;font-size:12.5px;line-height:1.5}
.my-orders-page .mo-empty .mo-btn{flex:none;height:36px;padding:0 20px;font-size:12px}

@media(max-width:850px){.my-orders-page .mo-stats{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:580px){
    .my-orders-page{padding-top:22px}
    .my-orders-page .mo-wrap{width:calc(100% - 28px)}
    .my-orders-page .mo-stats{gap:8px}
    .my-orders-page .mo-stat{padding:13px 14px}
    .my-orders-page .mo-stat-value{font-size:20px}
    .my-orders-page .mo-detail-grid{grid-template-columns:1fr}
    .my-orders-page .mo-panel-head{align-items:flex-start;padding:15px 16px}
    .my-orders-page .mo-detail-body{padding:16px}
}
/* ===== Ảnh sản phẩm đặt đầu mã đơn hàng ===== */
.my-orders-page .mo-order-cell{display:flex;align-items:center;gap:14px}
.my-orders-page .mo-thumb{position:relative;flex:none;width:46px;height:64px;border:1px solid var(--stroke);border-radius:6px;background:var(--glass-2);box-shadow:0 4px 12px rgba(0,0,0,.35)}
.my-orders-page .mo-thumb img{display:block;width:100%;height:100%;object-fit:cover;border-radius:5px}
.my-orders-page .mo-thumb-ph{display:flex;width:100%;height:100%;align-items:center;justify-content:center;border-radius:5px;background:linear-gradient(145deg,#303030,#515151);color:#fff;font-size:16px;font-weight:800}
.my-orders-page .mo-thumb-more{position:absolute;right:-8px;bottom:-8px;min-width:22px;height:22px;display:grid;place-items:center;padding:0 6px;border:2px solid var(--glass);border-radius:999px;background:#f2f2f2;color:#111;font-size:10px;font-weight:800;line-height:1}
.my-orders-page .mo-order-cell .mo-code{display:block}
/* ===== Số lượng đơn trên nút lọc ===== */
.my-orders-page .mo-filter a{gap:8px}
.my-orders-page .mo-count{display:inline-grid;place-items:center;min-width:22px;height:22px;padding:0 7px;border-radius:999px;background:rgba(255,255,255,.1);color:var(--text);font-size:11px;font-weight:800;line-height:1}
.my-orders-page .mo-filter a.active .mo-count,.my-orders-page .mo-filter a:hover .mo-count{background:#f2f2f2;color:#111}
/* ===== Form sửa thông tin đơn hàng ===== */
.my-orders-page .mo-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 14px;margin-bottom:6px}
.my-orders-page .mo-field-wide{grid-column:1/-1}
.my-orders-page .mo-field input{width:100%;padding:10px 14px;border:1px solid var(--stroke);border-radius:14px;background:var(--glass);color:var(--text);font:inherit;font-size:13px}
.my-orders-page .mo-field input:focus,.my-orders-page .mo-field textarea:focus{outline:none;border-color:var(--line)}
.my-orders-page .mo-btn.is-disabled{opacity:.4;cursor:not-allowed;pointer-events:auto}
.my-orders-page .mo-btn.is-disabled:hover{transform:none;background:rgba(255,255,255,.08)}
.my-orders-page .mo-actions{display:flex;align-items:center;gap:8px;flex-wrap:nowrap}
.my-orders-page .mo-item-cell{display:flex;align-items:center;gap:14px}
.my-orders-page .mo-item-thumb{width:52px;height:72px}
@media(max-width:580px){.my-orders-page .mo-form-grid{grid-template-columns:1fr}}
/* ===== Đánh giá sản phẩm trong đơn đã hoàn tất ===== */
.my-orders-page .mo-review{margin-bottom:12px;padding:14px 16px;border:1px solid var(--stroke);border-radius:18px;background:var(--glass-2)}
.my-orders-page .mo-review-title{margin-bottom:10px;font-size:13px;font-weight:800;color:var(--text)}
.my-orders-page .mo-review-stars{color:var(--text);font-size:16px;letter-spacing:2px}
.my-orders-page .mo-review-done{margin-left:10px;color:var(--muted);font-size:11px;letter-spacing:0;font-weight:700}
.my-orders-page .mo-review-comment{margin-top:8px;color:var(--text);font-size:12.5px;line-height:1.7;overflow-wrap:anywhere}
.my-orders-page .mo-field{margin-bottom:12px}
.my-orders-page .mo-field label{display:block;margin-bottom:6px;color:var(--text);font-size:12px;font-weight:700}
.my-orders-page .mo-field select,.my-orders-page .mo-field textarea{width:100%;padding:10px 14px;border:1px solid var(--stroke);border-radius:14px;background:var(--glass);color:var(--text);font:inherit;font-size:13px}
.my-orders-page .mo-field textarea{min-height:90px;resize:vertical}
/* ===== Gộp tiêu đề + thống kê trên một hàng, nhường chỗ cho lịch sử đơn hàng ===== */
.my-orders-page .mo-top{flex:none;display:flex;align-items:center;justify-content:space-between;gap:16px 24px;margin-bottom:12px}
.my-orders-page .mo-top .mo-heading{margin:0;min-width:0}
.my-orders-page .mo-top .mo-eyebrow{font-size:10px}
.my-orders-page .mo-top .mo-title{margin:4px 0 0;font-size:clamp(22px,2.4vw,28px)}
.my-orders-page .mo-top .mo-description{display:none}
.my-orders-page .mo-top .mo-stats{display:flex;flex-wrap:nowrap;justify-content:flex-end;gap:8px;margin:0}
.my-orders-page .mo-top .mo-stat{display:flex;align-items:center;gap:8px;padding:6px 14px;border-radius:999px;white-space:nowrap}
.my-orders-page .mo-top .mo-stat-label{font-size:11px;line-height:1.2}
.my-orders-page .mo-top .mo-stat-value{margin:0;font-size:15px!important;line-height:1.2}
@media(max-width:1180px){
    .my-orders-page .mo-top{flex-direction:column;align-items:stretch}
    .my-orders-page .mo-top .mo-stats{flex-wrap:wrap;justify-content:flex-start}
}
@media(max-width:580px){
    .my-orders-page .mo-top .mo-stats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr))}
    .my-orders-page .mo-top .mo-stat{justify-content:space-between;white-space:normal}
}
</style>

<main class="my-orders-page">
    <div class="mo-wrap">

        <div class="mo-top">
        <header class="mo-heading">
            <div class="mo-eyebrow">Comic Shop · Tài khoản</div>
            <h1 class="mo-title">Đơn hàng của tôi</h1>
            <p class="mo-description">
                Theo dõi trạng thái và xem chi tiết các đơn hàng bạn đã đặt.
            </p>
        </header>
        <section class="mo-stats" aria-label="Tổng quan đơn hàng">
            <div class="mo-stat">
                <span class="mo-stat-label">Tổng số đơn</span>
                <strong class="mo-stat-value">
                    <?= number_format($summary['total_orders']) ?>
                </strong>
            </div>

            <div class="mo-stat">
                <span class="mo-stat-label">Đang xử lý / giao</span>
                <strong class="mo-stat-value">
                    <?= number_format($summary['pending_orders']) ?>
                </strong>
            </div>

            <div class="mo-stat">
                <span class="mo-stat-label">Đơn hoàn tất</span>
                <strong class="mo-stat-value">
                    <?= number_format($summary['completed_orders']) ?>
                </strong>
            </div>

            <div class="mo-stat">
                <span class="mo-stat-label" title="Tổng giá trị đơn không bị hủy">Tổng giá trị</span>
                <strong class="mo-stat-value">
                    <?= comic_my_orders_money($summary['total_spent']) ?>
                </strong>
            </div>
        </section>
        </div>

        <?php if ($orderError !== ''): ?>
            <div class="mo-alert" role="alert">
                <?= comic_my_orders_escape($orderError) ?>
            </div>
        <?php endif; ?>

        <?php if (is_string($reviewFlash) && $reviewFlash !== ''): ?>
            <div class="mo-alert" role="status">
                <?= comic_my_orders_escape($reviewFlash) ?>
            </div>
        <?php endif; ?>

        <?php if ($editErrors): ?>
            <div class="mo-alert" role="alert">
                <strong>Không thể lưu thay đổi:</strong>
                <ul style="margin:7px 0 0;padding-left:19px">
                    <?php foreach ($editErrors as $editError): ?>
                        <li><?= comic_my_orders_escape($editError) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if ($reviewErrors): ?>
            <div class="mo-alert" role="alert">
                <strong>Không thể gửi đánh giá:</strong>
                <ul style="margin:7px 0 0;padding-left:19px">
                    <?php foreach ($reviewErrors as $reviewError): ?>
                        <li><?= comic_my_orders_escape($reviewError) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>


        <div class="mo-layout">

            <?php if ($editOrderId > 0): ?>

                <?php if ($editOrder): ?>
                    <?php
                    $editValues = $editInput ?? [
                        'full_name' => (string)$editOrder['full_name'],
                        'phone' => (string)$editOrder['phone'],
                        'email' => (string)$editOrder['email'],
                        'address' => (string)$editOrder['address'],
                        'note' => (string)($editOrder['note'] ?? ''),
                    ];
                    ?>
                    <section class="mo-panel" id="order-edit">
                        <div class="mo-panel-head">
                            <div>
                                <h2>Sửa thông tin đơn hàng</h2>
                                <span class="mo-muted">
                                    Mã đơn:
                                    <?= comic_my_orders_escape($editOrder['order_code']) ?>
                                </span>
                            </div>

                            <a
                                class="mo-btn secondary"
                                href="my-orders.php<?= $statusFilter !== '' ? '?status=' . rawurlencode($statusFilter) : '' ?>"
                            >
                                ← Quay lại danh sách
                            </a>
                        </div>

                        <div class="mo-detail-body">
                            <form
                                method="post"
                                action="my-orders.php?edit_order=<?= (int)$editOrder['id'] ?><?= $statusQuery ?>"
                            >
                                <input type="hidden" name="action" value="update_order">
                                <input type="hidden" name="csrf_token"
                                       value="<?= comic_my_orders_escape($ordersCsrf) ?>">
                                <input type="hidden" name="order_id"
                                       value="<?= (int)$editOrder['id'] ?>">

                                <div class="mo-form-grid">
                                    <div class="mo-field">
                                        <label for="mo-edit-name">Người nhận</label>
                                        <input id="mo-edit-name" type="text" name="full_name"
                                               maxlength="100" required
                                               value="<?= comic_my_orders_escape($editValues['full_name']) ?>">
                                    </div>

                                    <div class="mo-field">
                                        <label for="mo-edit-phone">Số điện thoại</label>
                                        <input id="mo-edit-phone" type="tel" name="phone"
                                               maxlength="20" required
                                               value="<?= comic_my_orders_escape($editValues['phone']) ?>">
                                    </div>

                                    <div class="mo-field mo-field-wide">
                                        <label for="mo-edit-email">Email</label>
                                        <input id="mo-edit-email" type="email" name="email"
                                               maxlength="150" required
                                               value="<?= comic_my_orders_escape($editValues['email']) ?>">
                                    </div>

                                    <div class="mo-field mo-field-wide">
                                        <label for="mo-edit-address">Địa chỉ giao hàng</label>
                                        <input id="mo-edit-address" type="text" name="address"
                                               maxlength="500" required
                                               value="<?= comic_my_orders_escape($editValues['address']) ?>">
                                    </div>

                                    <div class="mo-field mo-field-wide">
                                        <label for="mo-edit-note">Ghi chú đơn hàng</label>
                                        <textarea id="mo-edit-note" name="note" maxlength="1000"
                                                  placeholder="Ví dụ: giao giờ hành chính..."><?= comic_my_orders_escape($editValues['note']) ?></textarea>
                                    </div>
                                </div>

                                <div style="display:flex;flex-wrap:wrap;gap:10px">
                                    <button type="submit" class="mo-btn">Lưu thay đổi</button>
                                    <a
                                        class="mo-btn secondary"
                                        href="my-orders.php<?= $statusFilter !== '' ? '?status=' . rawurlencode($statusFilter) : '' ?>"
                                    >
                                        Hủy
                                    </a>
                                </div>
                            </form>
                        </div>
                    </section>

                <?php else: ?>

                    <section class="mo-panel">
                        <div class="mo-empty">
                            <div class="mo-empty-icon">!</div>
                            <h3>Không thể sửa đơn hàng</h3>
                            <p><?= comic_my_orders_escape($editNotice) ?></p>
                            <a class="mo-btn" href="my-orders.php">
                                Quay lại đơn hàng của tôi
                            </a>
                        </div>
                    </section>

                <?php endif; ?>

            <?php elseif ($selectedOrderId > 0 && $orderDetails): ?>
                <section class="mo-panel" id="order-detail">
                    <div class="mo-panel-head">
                        <div>
                            <h2>Chi tiết đơn hàng</h2>
                            <span class="mo-muted">
                                Mã đơn:
                                <?= comic_my_orders_escape($orderDetails['order_code']) ?>
                            </span>
                        </div>

                        <a
                            class="mo-btn secondary"
                            href="my-orders.php<?= $statusFilter !== '' ? '?status=' . rawurlencode($statusFilter) : '' ?>"
                        >
                            ← Quay lại danh sách
                        </a>
                    </div>

                    <div class="mo-detail-body">

                        <h3 class="mo-items-title">Sản phẩm đã đặt</h3>

                        <?php if (!$orderItems): ?>

                            <div class="mo-muted">
                                Không có chi tiết sản phẩm trong đơn hàng này.
                            </div>

                        <?php else: ?>

                            <div style="overflow-x:auto">
                                <table class="mo-items">
                                    <thead>
                                        <tr>
                                            <th>Tên truyện</th>
                                            <th>Đơn giá</th>
                                            <th>Số lượng</th>
                                            <th>Thành tiền</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php foreach ($orderItems as $item): ?>
                                            <?php
                                            $itemSrc = comic_my_orders_resolve_image(
                                                (string)($item['cover_image'] ?? '')
                                            );

                                            if ($itemSrc === '' && !empty($item['slug'])) {
                                                $itemSrc = comic_my_orders_resolve_image(
                                                    'assets/images/covers/' . (string)$item['slug']
                                                );
                                            }
                                            ?>
                                            <tr>
                                                <td>
                                                    <div class="mo-item-cell">
                                                        <div class="mo-thumb mo-item-thumb">
                                                            <?php if ($itemSrc !== ''): ?>
                                                                <img
                                                                    src="<?= comic_my_orders_escape($itemSrc) ?>"
                                                                    alt="<?= comic_my_orders_escape($item['comic_title']) ?>"
                                                                    loading="lazy"
                                                                    onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"
                                                                >
                                                                <span class="mo-thumb-ph" style="display:none">C.</span>
                                                            <?php else: ?>
                                                                <span class="mo-thumb-ph">C.</span>
                                                            <?php endif; ?>
                                                        </div>

                                                        <?php if (!empty($item['comic_id'])): ?>
                                                            <a
                                                                href="comic-detail.php?id=<?= (int)$item['comic_id'] ?>"
                                                                style="font-weight:800"
                                                            >
                                                                <?= comic_my_orders_escape($item['comic_title']) ?>
                                                            </a>
                                                        <?php else: ?>
                                                            <span style="font-weight:800">
                                                                <?= comic_my_orders_escape($item['comic_title']) ?>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>

                                                <td>
                                                    <?= comic_my_orders_money($item['price']) ?>
                                                </td>

                                                <td>
                                                    <?= number_format((int)$item['quantity']) ?>
                                                </td>

                                                <td class="mo-items-total">
                                                    <?= comic_my_orders_money($item['total']) ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                        <?php endif; ?>

                        <?php if (
                            $orderDetails['status'] === 'completed' &&
                            $orderItems
                        ): ?>
                            <h3 class="mo-items-title" style="margin-top:24px">
                                Đánh giá sản phẩm
                            </h3>

                            <?php $reviewShown = []; ?>

                            <?php foreach ($orderItems as $item): ?>
                                <?php
                                $reviewComicId = (int)($item['comic_id'] ?? 0);

                                if (
                                    $reviewComicId < 1 ||
                                    isset($reviewShown[$reviewComicId])
                                ) {
                                    continue;
                                }

                                $reviewShown[$reviewComicId] = true;
                                $doneReview = $myReviews[$reviewComicId] ?? null;
                                $useInput = $reviewInput['comic_id'] === $reviewComicId;
                                $formRating = $useInput ? $reviewInput['rating'] : 5;
                                $formComment = $useInput ? $reviewInput['comment'] : '';
                                ?>

                                <div class="mo-review" id="review-<?= $reviewComicId ?>">
                                    <div class="mo-review-title">
                                        <?= comic_my_orders_escape($item['comic_title']) ?>
                                    </div>

                                    <?php if ($doneReview): ?>
                                        <?php
                                        $doneStars = max(0, min(5, (int)$doneReview['rating']));
                                        ?>
                                        <div class="mo-review-stars"
                                             aria-label="<?= $doneStars ?> trên 5 sao">
                                            <?= str_repeat('★', $doneStars) .
                                                str_repeat('☆', 5 - $doneStars) ?>
                                            <span class="mo-review-done">Bạn đã đánh giá</span>
                                        </div>

                                        <?php if (trim((string)$doneReview['comment']) !== ''): ?>
                                            <div class="mo-review-comment">
                                                <?= nl2br(comic_my_orders_escape($doneReview['comment'])) ?>
                                            </div>
                                        <?php endif; ?>

                                    <?php else: ?>
                                        <form method="post"
                                              action="my-orders.php?order_id=<?= (int)$orderDetails['id'] ?>#review-<?= $reviewComicId ?>">
                                            <input type="hidden" name="action" value="submit_review">
                                            <input type="hidden" name="csrf_token"
                                                   value="<?= comic_my_orders_escape($ordersCsrf) ?>">
                                            <input type="hidden" name="order_id"
                                                   value="<?= (int)$orderDetails['id'] ?>">
                                            <input type="hidden" name="comic_id"
                                                   value="<?= $reviewComicId ?>">

                                            <div class="mo-field">
                                                <label for="mo-rating-<?= $reviewComicId ?>">Số sao đánh giá</label>
                                                <select id="mo-rating-<?= $reviewComicId ?>"
                                                        name="rating" required>
                                                    <?php for ($star = 5; $star >= 1; $star--): ?>
                                                        <option value="<?= $star ?>"
                                                            <?= $formRating === $star ? 'selected' : '' ?>>
                                                            <?= $star ?> sao
                                                        </option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>

                                            <div class="mo-field">
                                                <label for="mo-comment-<?= $reviewComicId ?>">Bình luận</label>
                                                <textarea id="mo-comment-<?= $reviewComicId ?>"
                                                          name="comment" maxlength="5000"
                                                          placeholder="Chia sẻ cảm nhận của bạn..."><?= comic_my_orders_escape($formComment) ?></textarea>
                                            </div>

                                            <button type="submit" class="mo-btn">Gửi đánh giá</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>

                        <div class="mo-detail-footer">
                            <div>
                                <span class="mo-total-label">Tổng đơn hàng</span>
                                <strong class="mo-total-value">
                                    <?= comic_my_orders_money($orderDetails['total_amount']) ?>
                                </strong>
                            </div>
                        </div>

                    </div>
                </section>

            <?php elseif ($selectedOrderId > 0): ?>

                <section class="mo-panel">
                    <div class="mo-empty">
                        <div class="mo-empty-icon">!</div>
                        <h3>Không tìm thấy đơn hàng</h3>
                        <p>
                            Đơn hàng không tồn tại hoặc không thuộc tài khoản của bạn.
                        </p>
                        <a class="mo-btn" href="my-orders.php">
                            Quay lại đơn hàng của tôi
                        </a>
                    </div>
                </section>

            <?php else: ?>

                <section class="mo-panel">
                    <div class="mo-panel-head">
                        <div>
                            <h2>Lịch sử đơn hàng</h2>
                            <div class="mo-muted">
                                <?= number_format($totalOrders) ?> đơn hàng phù hợp
                            </div>
                        </div>

                        <div class="mo-filter">
                            <a
                                href="my-orders.php"
                                class="<?= $statusFilter === '' ? 'active' : '' ?>"
                            >
                                Tất cả
                                <span class="mo-count"><?= number_format($summary['total_orders']) ?></span>
                            </a>

                            <?php foreach ($statusLabels as $status => $label): ?>
                                <a
                                    href="my-orders.php?status=<?= rawurlencode($status) ?>"
                                    class="<?= $statusFilter === $status ? 'active' : '' ?>"
                                >
                                    <?= comic_my_orders_escape($label) ?>
                                    <span class="mo-count"><?= number_format($statusCounts[$status] ?? 0) ?></span>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <?php if (!$orderDbReady): ?>

                        <div class="mo-empty">
                            <div class="mo-empty-icon">!</div>
                            <h3>Chưa kết nối được database</h3>
                            <p>
                                Hãy kiểm tra file config/db.php và cấu hình kết nối.
                            </p>
                        </div>

                    <?php elseif (!$orders): ?>

                        <div class="mo-empty">
                            <div class="mo-empty-icon">▤</div>
                            <h3>Chưa có đơn hàng</h3>
                            <p>
                                Bạn chưa có đơn hàng nào trong trạng thái đã chọn.
                                Khám phá cửa hàng để tìm những bộ truyện yêu thích.
                            </p>
                            <a class="mo-btn" href="comics.php">
                                Khám phá truyện →
                            </a>
                        </div>

                    <?php else: ?>

                        <div class="mo-table-wrap">
                            <table class="mo-table">
                                <thead>
                                    <tr>
                                        <th>Mã đơn hàng</th>
                                        <th>Ngày đặt</th>
                                        <th>Thanh toán</th>
                                        <th>Tổng tiền</th>
                                        <th>Trạng thái</th>
                                        <th></th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php foreach ($orders as $order): ?>
                                        <?php
                                        $orderStatus = (string)$order['status'];
                                        $orderTime = strtotime((string)$order['created_at']);
                                        ?>

                                        <?php
                                        $thumb = $orderThumbs[(int)$order['id']] ?? null;
                                        ?>

                                        <tr>
                                            <td>
                                                <div class="mo-order-cell">
                                                    <div class="mo-thumb"
                                                         title="<?= comic_my_orders_escape($thumb['title'] ?? '') ?>">
                                                        <?php if ($thumb && $thumb['src'] !== ''): ?>
                                                            <img
                                                                src="<?= comic_my_orders_escape($thumb['src']) ?>"
                                                                alt="<?= comic_my_orders_escape($thumb['title']) ?>"
                                                                loading="lazy"
                                                                onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"
                                                            >
                                                            <span class="mo-thumb-ph" style="display:none">C.</span>
                                                        <?php else: ?>
                                                            <span class="mo-thumb-ph">C.</span>
                                                        <?php endif; ?>

                                                        <?php if ($thumb && $thumb['count'] > 1): ?>
                                                            <span class="mo-thumb-more">
                                                                +<?= (int)$thumb['count'] - 1 ?>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>

                                                    <span class="mo-code">
                                                        <?= comic_my_orders_escape($order['order_code']) ?>
                                                    </span>
                                                </div>
                                            </td>

                                            <td>
                                                <?= $orderTime
                                                    ? comic_my_orders_escape(date('d/m/Y', $orderTime))
                                                    : '' ?>

                                                <span class="mo-date">
                                                    <?= $orderTime
                                                        ? comic_my_orders_escape(date('H:i', $orderTime))
                                                        : '' ?>
                                                </span>
                                            </td>

                                            <td>
                                                <?= comic_my_orders_escape(
                                                    $paymentMethodLabels[$order['payment_method']]
                                                        ?? $order['payment_method']
                                                ) ?>

                                                <span class="mo-payment-status">
                                                    <?= comic_my_orders_escape(
                                                        $paymentStatusLabels[$order['payment_status']]
                                                            ?? $order['payment_status']
                                                    ) ?>
                                                </span>
                                            </td>

                                            <td>
                                                <strong>
                                                    <?= comic_my_orders_money($order['total_amount']) ?>
                                                </strong>
                                            </td>

                                            <td>
                                                <span class="mo-status <?= comic_my_orders_escape(
                                                    $statusClasses[$orderStatus] ?? ''
                                                ) ?>">
                                                    <?= comic_my_orders_escape(
                                                        $statusLabels[$orderStatus]
                                                            ?? $orderStatus
                                                    ) ?>
                                                </span>
                                            </td>

                                            <td>
                                                <div class="mo-actions">
                                                    <a
                                                        class="mo-btn secondary"
                                                        href="my-orders.php?order_id=<?= (int)$order['id'] ?><?= $statusQuery ?>"
                                                    >
                                                        Chi tiết
                                                    </a>

                                                    <?php if ($orderStatus === 'pending'): ?>
                                                        <a
                                                            class="mo-btn secondary"
                                                            href="my-orders.php?edit_order=<?= (int)$order['id'] ?><?= $statusQuery ?>"
                                                        >
                                                            Sửa thông tin
                                                        </a>
                                                    <?php else: ?>
                                                        <span
                                                            class="mo-btn secondary is-disabled"
                                                            aria-disabled="true"
                                                            title="Chỉ sửa được khi đơn đang chờ xử lý"
                                                        >
                                                            Sửa thông tin
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <?php if ($totalPages > 1): ?>
                            <nav class="mo-pagination" aria-label="Phân trang đơn hàng">
                                <?php if ($page > 1): ?>
                                    <a
                                        class="mo-page"
                                        href="my-orders.php?<?= http_build_query(array_filter([
                                            'status' => $statusFilter,
                                            'page' => $page - 1,
                                        ], static function ($value) {
                                            return $value !== '';
                                        })) ?>"
                                        aria-label="Trang trước"
                                    >
                                        ‹
                                    </a>
                                <?php endif; ?>

                                <?php
                                $startPage = max(1, $page - 2);
                                $endPage = min($totalPages, $page + 2);

                                for (
                                    $pageNumber = $startPage;
                                    $pageNumber <= $endPage;
                                    $pageNumber++
                                ):
                                ?>
                                    <a
                                        class="mo-page <?= $pageNumber === $page ? 'current' : '' ?>"
                                        href="my-orders.php?<?= http_build_query(array_filter([
                                            'status' => $statusFilter,
                                            'page' => $pageNumber,
                                        ], static function ($value) {
                                            return $value !== '';
                                        })) ?>"
                                        <?= $pageNumber === $page ? 'aria-current="page"' : '' ?>
                                    >
                                        <?= $pageNumber ?>
                                    </a>
                                <?php endfor; ?>

                                <?php if ($page < $totalPages): ?>
                                    <a
                                        class="mo-page"
                                        href="my-orders.php?<?= http_build_query(array_filter([
                                            'status' => $statusFilter,
                                            'page' => $page + 1,
                                        ], static function ($value) {
                                            return $value !== '';
                                        })) ?>"
                                        aria-label="Trang tiếp"
                                    >
                                        ›
                                    </a>
                                <?php endif; ?>
                            </nav>
                        <?php endif; ?>

                    <?php endif; ?>
                </section>

            <?php endif; ?>

            <div style="display:flex;flex-wrap:wrap;gap:10px">
                <a class="mo-btn secondary" href="account.php">
                    ← Tài khoản của tôi
                </a>

                <a class="mo-btn" href="comics.php">
                    Tiếp tục mua truyện →
                </a>
            </div>

        </div>
    </div>
</main>

<?php
if (is_file($footerFile)) {
    require_once $footerFile;
} else {
    echo '</body></html>';
}
?>
