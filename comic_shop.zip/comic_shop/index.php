<?php
/*
 * COMIC SHOP
 * File: index.php
 * Trang chủ + cửa hàng truyện (đã gộp trang comics.php vào mục #catalog).
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. KẾT NỐI DATABASE
========================================================= */

$dbConfigFile = __DIR__ . '/config/db.php';
$dbConfigReturn = null;

if (is_file($dbConfigFile)) {
    $dbConfigReturn = require_once $dbConfigFile;
}

$homeDb = null;

$homeDbCandidates = [
    $dbConfigReturn,
    $GLOBALS['comic_shop_db'] ?? null,
    $GLOBALS['pdo'] ?? null,
    $GLOBALS['conn'] ?? null,
    $GLOBALS['mysqli'] ?? null,
    $GLOBALS['db'] ?? null,
    $pdo ?? null,
    $conn ?? null,
    $mysqli ?? null,
    $db ?? null,
];

foreach ($homeDbCandidates as $candidate) {
    if (
        $candidate instanceof PDO ||
        (class_exists('mysqli') && $candidate instanceof mysqli)
    ) {
        $homeDb = $candidate;
        break;
    }
}

$homeDbReady = $homeDb instanceof PDO ||
    (class_exists('mysqli') && $homeDb instanceof mysqli);

/* =========================================================
   2. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_home_escape')) {
    function comic_home_escape($value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_home_money')) {
    function comic_home_money($amount): string
    {
        return number_format((float)$amount, 0, ',', '.') . ' ₫';
    }
}

if (!function_exists('comic_home_excerpt')) {
    function comic_home_excerpt(string $text, int $limit = 110): string
    {
        $text = trim(
            preg_replace('/\s+/u', ' ', strip_tags($text)) ?? ''
        );

        if (function_exists('mb_strlen')) {
            if (mb_strlen($text, 'UTF-8') > $limit) {
                return mb_substr($text, 0, $limit, 'UTF-8') . '…';
            }

            return $text;
        }

        return strlen($text) > $limit
            ? substr($text, 0, $limit) . '…'
            : $text;
    }
}

if (!function_exists('comic_home_query')) {
    function comic_home_query($database, string $sql, array $params = []): array
    {
        if ($database instanceof PDO) {
            $statement = $database->prepare($sql);
            $statement->execute($params);

            $rows = $statement->columnCount() > 0
                ? $statement->fetchAll(PDO::FETCH_ASSOC)
                : [];

            $statement->closeCursor();

            return $rows;
        }

        if (class_exists('mysqli') && $database instanceof mysqli) {
            $statement = $database->prepare($sql);

            if (!$statement) {
                throw new RuntimeException('Không thể chuẩn bị truy vấn database.');
            }

            if ($params !== []) {
                $types = '';
                $bindParams = [];

                foreach ($params as $param) {
                    if (is_int($param) || is_bool($param)) {
                        $types .= 'i';
                    } elseif (is_float($param)) {
                        $types .= 'd';
                    } else {
                        $types .= 's';
                    }
                }

                $bindParams[] = $types;

                foreach ($params as &$param) {
                    $bindParams[] = &$param;
                }

                unset($param);

                if (!call_user_func_array([$statement, 'bind_param'], $bindParams)) {
                    $statement->close();
                    throw new RuntimeException('Không thể gắn tham số truy vấn.');
                }
            }

            if (!$statement->execute()) {
                $error = $statement->error;
                $statement->close();
                throw new RuntimeException($error ?: 'Truy vấn database thất bại.');
            }

            $rows = [];

            if ($statement->field_count > 0) {
                $result = $statement->get_result();

                if ($result instanceof mysqli_result) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $result->free();
                } else {
                    $statement->close();
                    throw new RuntimeException('Không đọc được kết quả truy vấn.');
                }
            }

            $statement->close();

            return $rows;
        }

        throw new RuntimeException('Không tìm thấy kết nối PDO hoặc MySQLi.');
    }
}

/* Tạo URL của mục cửa hàng (luôn quay về #catalog trên trang chủ) */
if (!function_exists('comic_home_catalog_url')) {
    function comic_home_catalog_url(array $params): string
    {
        return 'index.php' .
            ($params ? '?' . http_build_query($params) : '') .
            '#catalog';
    }
}

/* =========================================================
   3. KHỞI TẠO DỮ LIỆU
========================================================= */

$featuredComics = [];
$newComics = [];
$discountComics = [];
$popularComics = [];
$categories = [];

$homeStats = ['comics' => 0, 'categories' => 0, 'authors' => 0];
$homeError = '';

$comicCols = 'id, title, slug, price, sale_price, cover_image,
    description, rating_avg, review_count, stock,
    sold_count, is_featured, is_new, is_discount,
    (SELECT cat.name FROM categories cat WHERE cat.id = comics.category_id) AS category_name';

/* Truyện bị ẩn khỏi trang chủ (vẫn còn trong cửa hàng). */
$hiddenSql = " AND slug NOT IN ('mua-he-o-lang', 'lop-hoc-cuoi-hanh-lang')";

/* =========================================================
   4. LẤY TRUYỆN VÀ DANH MỤC
========================================================= */

if ($homeDbReady) {
    try {
        $featuredComics = comic_home_query(
            $homeDb,
            "SELECT $comicCols FROM comics
             WHERE is_active = 1 AND is_featured = 1 $hiddenSql
             ORDER BY sold_count DESC, id DESC
             LIMIT 4"
        );

        if (!$featuredComics) {
            $featuredComics = comic_home_query(
                $homeDb,
                "SELECT $comicCols FROM comics
                 WHERE is_active = 1 $hiddenSql
                 ORDER BY sold_count DESC, rating_avg DESC, id DESC
                 LIMIT 4"
            );
        }

        $newComics = comic_home_query(
            $homeDb,
            "SELECT $comicCols FROM comics
             WHERE is_active = 1 $hiddenSql
             ORDER BY is_new DESC, release_date DESC, created_at DESC, id DESC
             LIMIT 10"
        );

        $discountComics = comic_home_query(
            $homeDb,
            "SELECT $comicCols FROM comics
             WHERE is_active = 1 $hiddenSql
               AND sale_price IS NOT NULL
               AND sale_price > 0
               AND sale_price < price
             ORDER BY is_discount DESC, (price - sale_price) DESC, id DESC
             LIMIT 10"
        );

        $popularComics = comic_home_query(
            $homeDb,
            "SELECT $comicCols FROM comics
             WHERE is_active = 1 $hiddenSql
             ORDER BY sold_count DESC, rating_avg DESC, id DESC
             LIMIT 8"
        );

        $categories = comic_home_query(
            $homeDb,
            'SELECT cat.id, cat.name, cat.slug, cat.image,
                    COUNT(c.id) AS comic_count
             FROM categories cat
             LEFT JOIN comics c
                ON c.category_id = cat.id AND c.is_active = 1
             GROUP BY cat.id, cat.name, cat.slug, cat.image
             ORDER BY comic_count DESC, cat.name ASC
             LIMIT 8'
        );

        $statsRows = comic_home_query(
            $homeDb,
            'SELECT
                (SELECT COUNT(*) FROM comics WHERE is_active = 1) AS total_comics,
                (SELECT COUNT(*) FROM categories) AS total_categories,
                (SELECT COUNT(*) FROM authors) AS total_authors'
        );

        if ($statsRows) {
            $homeStats = [
                'comics' => (int)$statsRows[0]['total_comics'],
                'categories' => (int)$statsRows[0]['total_categories'],
                'authors' => (int)$statsRows[0]['total_authors'],
            ];
        }
    } catch (Throwable $exception) {
        error_log('[Comic Shop Home] ' . $exception->getMessage());
        $homeError = 'Không thể tải một số dữ liệu truyện. Hãy kiểm tra database.';
    }

} else {
    $homeError = 'Chưa tìm thấy kết nối database. Hãy kiểm tra config/db.php.';
}

/* =========================================================
   4B. MỤC CỬA HÀNG "TẤT CẢ TRUYỆN" (gộp từ comics.php)
========================================================= */

$catSearch = isset($_GET['q']) && is_string($_GET['q'])
    ? trim($_GET['q'])
    : '';

$catCategory = isset($_GET['category']) && is_string($_GET['category'])
    ? trim($_GET['category'])
    : '';

$catAuthor = isset($_GET['author']) && is_string($_GET['author'])
    ? trim($_GET['author'])
    : '';

$catAge = isset($_GET['age_rating']) && is_string($_GET['age_rating'])
    ? $_GET['age_rating']
    : '';

if (!in_array($catAge, ['all', '13+', '16+', '18+'], true)) {
    $catAge = '';
}

$catSort = isset($_GET['sort']) && is_string($_GET['sort'])
    ? $_GET['sort']
    : 'featured';

if (!in_array(
    $catSort,
    ['featured', 'newest', 'popular', 'rating', 'price_asc', 'price_desc', 'discount'],
    true
)) {
    $catSort = 'featured';
}

$catQuick = isset($_GET['filter']) && is_string($_GET['filter'])
    ? trim($_GET['filter'])
    : '';

if (!in_array($catQuick, ['featured', 'new', 'discount'], true)) {
    $catQuick = '';
}

if ($catQuick !== '' && !isset($_GET['sort'])) {
    $catSort = [
        'featured' => 'featured',
        'new'      => 'newest',
        'discount' => 'discount',
    ][$catQuick];
}

$catMinRaw = isset($_GET['min_price']) && is_string($_GET['min_price'])
    ? trim($_GET['min_price'])
    : '';

$catMaxRaw = isset($_GET['max_price']) && is_string($_GET['max_price'])
    ? trim($_GET['max_price'])
    : '';

$catMin = $catMinRaw !== '' && is_numeric($catMinRaw) && (float)$catMinRaw >= 0
    ? (float)$catMinRaw
    : null;

$catMax = $catMaxRaw !== '' && is_numeric($catMaxRaw) && (float)$catMaxRaw >= 0
    ? (float)$catMaxRaw
    : null;

if ($catMin !== null && $catMax !== null && $catMin > $catMax) {
    $swapPrice = $catMin;
    $catMin = $catMax;
    $catMax = $swapPrice;
}

$catRating = isset($_GET['min_rating']) && is_string($_GET['min_rating'])
    && ctype_digit($_GET['min_rating'])
    && (int)$_GET['min_rating'] >= 1 && (int)$_GET['min_rating'] <= 5
    ? (int)$_GET['min_rating']
    : 0;

$catStarCounts = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];

$catPage = max(1, (int)($_GET['page'] ?? 1));
$catPerPage = 8; // 4 cột x 2 dòng, nhiều hơn thì chuyển trang

$catalogComics = [];
$catalogCategories = [];
$catalogAuthors = [];
$catalogTotal = 0;
$catalogPages = 1;
$catBeyond = false; // true khi đang ở trang sau trang cuối (không còn truyện)
$catalogError = '';

$catSortSql = [
    'featured' => 'c.is_featured DESC, c.sold_count DESC, c.id DESC',
    'newest' => 'c.release_date DESC, c.created_at DESC, c.id DESC',
    'popular' => 'c.sold_count DESC, c.rating_avg DESC, c.id DESC',
    'rating' => 'c.rating_avg DESC, c.review_count DESC, c.id DESC',
    'price_asc' =>
        'CASE WHEN c.sale_price IS NOT NULL AND c.sale_price > 0
               AND c.sale_price < c.price
              THEN c.sale_price ELSE c.price END ASC, c.id DESC',
    'price_desc' =>
        'CASE WHEN c.sale_price IS NOT NULL AND c.sale_price > 0
               AND c.sale_price < c.price
              THEN c.sale_price ELSE c.price END DESC, c.id DESC',
    'discount' =>
        '(c.price - CASE WHEN c.sale_price IS NOT NULL AND c.sale_price > 0
                         AND c.sale_price < c.price
                         THEN c.sale_price ELSE c.price END) DESC,
         c.sold_count DESC, c.id DESC',
];

if ($homeDbReady) {
    try {
        $catalogCategories = comic_home_query(
            $homeDb,
            'SELECT cat.id, cat.name, cat.slug, COUNT(c.id) AS comic_count
             FROM categories cat
             LEFT JOIN comics c
                ON c.category_id = cat.id AND c.is_active = 1
             GROUP BY cat.id, cat.name, cat.slug
             ORDER BY cat.name ASC'
        );

        try {
            $starRows = comic_home_query(
                $homeDb,
                'SELECT
                    SUM(rating_avg >= 1) AS s1, SUM(rating_avg >= 2) AS s2,
                    SUM(rating_avg > 0 AND rating_avg < 5) AS s3, SUM(rating_avg >= 4) AS s4,
                    SUM(rating_avg >= 5) AS s5
                 FROM comics WHERE is_active = 1'
            );
            foreach ([1, 2, 3, 4, 5] as $n) {
                $catStarCounts[$n] = (int)($starRows[0]['s' . $n] ?? 0);
            }
        } catch (Throwable $e) {
        }

        $catalogAuthors = comic_home_query(
            $homeDb,
            'SELECT DISTINCT a.id, a.name, a.slug
             FROM authors a
             INNER JOIN comics c ON c.author_id = a.id
             WHERE c.is_active = 1
             ORDER BY a.name ASC'
        );

        $catWhere = ['c.is_active = 1', "c.slug NOT IN ('mua-he-o-lang', 'lop-hoc-cuoi-hanh-lang')"];
        $catBind = [];

        if ($catSearch !== '') {
            $catWhere[] = '(c.title LIKE ? OR c.description LIKE ?
                OR c.isbn LIKE ? OR a.name LIKE ? OR cat.name LIKE ?)';

            $catLike = '%' . $catSearch . '%';
            array_push($catBind, $catLike, $catLike, $catLike, $catLike, $catLike);
        }

        if ($catCategory !== '') {
            if (ctype_digit($catCategory)) {
                $catWhere[] = 'cat.id = ?';
                $catBind[] = (int)$catCategory;
            } else {
                $catWhere[] = 'cat.slug = ?';
                $catBind[] = $catCategory;
            }
        }

        if ($catAuthor !== '') {
            if (ctype_digit($catAuthor)) {
                $catWhere[] = 'a.id = ?';
                $catBind[] = (int)$catAuthor;
            } else {
                $catWhere[] = 'a.slug = ?';
                $catBind[] = $catAuthor;
            }
        }

        if ($catAge !== '') {
            $catWhere[] = 'c.age_rating = ?';
            $catBind[] = $catAge;
        }

        if ($catQuick === 'featured') {
            $catWhere[] = 'c.is_featured = 1';
        } elseif ($catQuick === 'new') {
            $catWhere[] = 'c.is_new = 1';
        } elseif ($catQuick === 'discount') {
            $catWhere[] = '(c.sale_price IS NOT NULL AND c.sale_price > 0
                            AND c.sale_price < c.price)';
        }

        $catPriceSql = 'CASE WHEN c.sale_price IS NOT NULL AND c.sale_price > 0
                             AND c.sale_price < c.price
                        THEN c.sale_price ELSE c.price END';

        if ($catMin !== null) {
            $catWhere[] = '(' . $catPriceSql . ') >= ?';
            $catBind[] = $catMin;
        }

        if ($catMax !== null) {
            $catWhere[] = '(' . $catPriceSql . ') <= ?';
            $catBind[] = $catMax;
        }

        if ($catRating > 0) {
            if ($catRating >= 5) {
                $catWhere[] = 'c.rating_avg >= 5';          /* 5 sao */
            } elseif ($catRating === 4) {
                $catWhere[] = 'c.rating_avg >= 4';          /* từ 4 đến 5 sao */
            } else {
                $catWhere[] = '(c.rating_avg > 0 AND c.rating_avg < 5)'; /* 4 sao trở xuống */
            }
        }

        $catWhereSql = ' WHERE ' . implode(' AND ', $catWhere);

        $catCountRows = comic_home_query(
            $homeDb,
            'SELECT COUNT(*) AS total
             FROM comics c
             INNER JOIN categories cat ON cat.id = c.category_id
             LEFT JOIN authors a ON a.id = c.author_id' . $catWhereSql,
            $catBind
        );

        $catalogTotal = (int)($catCountRows[0]['total'] ?? 0);
        $catalogPages = max(1, (int)ceil($catalogTotal / $catPerPage));
        /* Cho phép tới đúng 1 trang trống sau trang cuối để hiện thông báo, không đi xa hơn */
        $catPage = min($catPage, $catalogPages + 1);
        $catBeyond = $catalogTotal > 0 && $catPage > $catalogPages;
        $catOffset = ($catPage - 1) * $catPerPage;

        $catListBind = $catBind;
        $catListBind[] = $catPerPage;
        $catListBind[] = $catOffset;

        $catalogComics = comic_home_query(
            $homeDb,
            'SELECT
                c.id, c.category_id, c.author_id, c.title, c.slug,
                c.price, c.sale_price, c.cover_image, c.description,
                c.age_rating, c.stock, c.sold_count, c.rating_avg,
                c.review_count, c.is_featured, c.is_new, c.is_discount,
                c.release_date,
                cat.name AS category_name, cat.slug AS category_slug,
                a.name AS author_name
             FROM comics c
             INNER JOIN categories cat ON cat.id = c.category_id
             LEFT JOIN authors a ON a.id = c.author_id' .
             $catWhereSql . '
             ORDER BY ' . $catSortSql[$catSort] . '
             LIMIT ? OFFSET ?',
            $catListBind
        );

    } catch (Throwable $exception) {
        error_log('[Comic Shop Catalog] ' . $exception->getMessage());
        $catalogError =
            'Không thể tải danh sách truyện. Hãy kiểm tra kết nối database và thử lại.';
    }
}

/* Tham số giữ lại khi chuyển trang / đổi bộ lọc */
$catQuery = [];

if ($catSearch !== '') $catQuery['q'] = $catSearch;
if ($catCategory !== '') $catQuery['category'] = $catCategory;
if ($catAuthor !== '') $catQuery['author'] = $catAuthor;
if ($catAge !== '') $catQuery['age_rating'] = $catAge;
if ($catMin !== null) $catQuery['min_price'] = $catMin;
if ($catMax !== null) $catQuery['max_price'] = $catMax;
if ($catRating > 0) $catQuery['min_rating'] = $catRating;
if ($catQuick !== '') $catQuery['filter'] = $catQuick;
if ($catSort !== 'featured') $catQuery['sort'] = $catSort;

/* =========================================================
   5. HÀM HIỂN THỊ
========================================================= */

if (!function_exists('comic_home_placeholder')) {
    function comic_home_placeholder(string $title, int $seed, int $w = 400, int $h = 600): string
    {
        $palettes = [
            ['#3a3a3a', '#111111', '#c9c5a8'],
            ['#3a3a3a', '#111111', '#c9c5a8'],
            ['#3a3a3a', '#111111', '#c9c5a8'],
            ['#3a3a3a', '#111111', '#c9c5a8'],
            ['#3a3a3a', '#111111', '#c9c5a8'],
            ['#3a3a3a', '#111111', '#c9c5a8'],
        ];
        [$c1, $c2, $accent] = $palettes[abs($seed) % 6];

        $maxChars = $w > $h ? 26 : 13;
        $fontSize = $w > $h ? 38 : 27;
        $words = preg_split('/\s+/u', trim($title)) ?: [];
        $lines = [];
        $current = '';

        foreach ($words as $word) {
            $try = $current === '' ? $word : $current . ' ' . $word;

            if (mb_strlen($try, 'UTF-8') <= $maxChars) {
                $current = $try;
            } else {
                if ($current !== '') {
                    $lines[] = $current;
                }
                $current = $word;
            }
        }

        if ($current !== '') {
            $lines[] = $current;
        }

        $lines = array_slice($lines, 0, 3);
        $bandH = (int)round($h * 0.27);
        $bandY = $h - $bandH;
        $lineGap = $fontSize + 6;
        $startY = $bandY + ($bandH - count($lines) * $lineGap) / 2 + $fontSize * 0.85;

        $esc = static fn(string $t): string =>
            htmlspecialchars($t, ENT_XML1 | ENT_QUOTES, 'UTF-8');

        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $w . ' ' . $h . '">'
            . '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">'
            . '<stop offset="0" stop-color="' . $c1 . '"/>'
            . '<stop offset="1" stop-color="' . $c2 . '"/></linearGradient>'
            . '<pattern id="p" width="12" height="12" patternUnits="userSpaceOnUse" patternTransform="rotate(30)">'
            . '<circle cx="6" cy="6" r="2.4" fill="#000" opacity=".18"/></pattern></defs>'
            . '<rect width="' . $w . '" height="' . $h . '" fill="url(#g)"/>'
            . '<circle cx="' . ($w / 2) . '" cy="' . ($bandY * 0.5) . '" r="' . ($bandY * 0.3) . '" fill="' . $accent . '"/>'
            . '<circle cx="' . ($w / 2) . '" cy="' . ($bandY * 0.5) . '" r="' . ($bandY * 0.38) . '" fill="none" stroke="#fff" stroke-width="3" opacity=".5"/>'
            . '<rect width="' . $w . '" height="' . $h . '" fill="url(#p)"/>'
            . '<rect y="' . $bandY . '" width="' . $w . '" height="' . $bandH . '" fill="#141414" opacity=".9"/>'
            . '<rect y="' . $bandY . '" width="' . $w . '" height="5" fill="' . $accent . '"/>';

        foreach ($lines as $i => $line) {
            $svg .= '<text x="' . ($w / 2) . '" y="' . round($startY + $i * $lineGap)
                . '" fill="#fff" font-family="Montserrat,Arial,sans-serif" font-weight="800" font-size="'
                . $fontSize . '" text-anchor="middle">'
                . $esc(mb_strtoupper($line, 'UTF-8')) . '</text>';
        }

        $svg .= '</svg>';

        return 'data:image/svg+xml;charset=utf-8,' . rawurlencode($svg);
    }
}

if (!function_exists('comic_home_resolve')) {
    function comic_home_resolve(string $path): string
    {
        $path = ltrim(trim($path), '/');

        if ($path === '') {
            return '';
        }

        if (is_file(__DIR__ . '/' . $path)) {
            return $path;
        }

        $info = pathinfo($path);
        $dir = ($info['dirname'] ?? '.') === '.' ? '' : $info['dirname'] . '/';

        foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
            $try = $dir . ($info['filename'] ?? '') . '.' . $ext;

            if (is_file(__DIR__ . '/' . $try)) {
                return $try;
            }
        }

        return '';
    }
}

if (!function_exists('comic_home_find')) {
    function comic_home_find(string $dir, string $slug): string
    {
        $slug = trim($slug);

        if ($slug === '') {
            return '';
        }

        foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
            $relative = trim($dir, '/') . '/' . $slug . '.' . $ext;

            if (is_file(__DIR__ . '/' . $relative)) {
                return $relative;
            }
        }

        return '';
    }
}

if (!function_exists('comic_home_image')) {
    function comic_home_image($path, string $title, int $seed, int $w = 400, int $h = 600): string
    {
        $path = trim((string)($path ?? ''));

        if ($path !== '') {
            if (preg_match('#^(https?:)?//#i', $path)) {
                return $path;
            }

            $found = comic_home_resolve($path);

            if ($found !== '') {
                return $found;
            }
        }

        return comic_home_placeholder($title, $seed, $w, $h);
    }
}

if (!function_exists('comic_home_cover')) {
    function comic_home_cover(array $comic): string
    {
        $path = comic_home_resolve((string)($comic['cover_image'] ?? ''));

        if ($path === '') {
            $path = comic_home_find('assets/images/covers', (string)($comic['slug'] ?? ''));
        }

        return comic_home_image(
            $path,
            (string)($comic['title'] ?? 'Comic'),
            (int)($comic['id'] ?? 0)
        );
    }
}

if (!function_exists('comic_home_stars')) {
    function comic_home_stars($rating): string
    {
        $filled = (int)round(max(0, min(5, (float)$rating)));
        $html = '<span class="gl-stars" aria-label="'
            . number_format((float)$rating, 1) . ' trên 5 sao">';

        for ($i = 1; $i <= 5; $i++) {
            $html .= $i <= $filled
                ? '<i class="on">★</i>'
                : '<i>★</i>';
        }

        return $html . '</span>';
    }
}

if (!function_exists('comic_home_url')) {
    function comic_home_url(array $comic): string
    {
        return 'comic-detail.php?slug=' . rawurlencode((string)$comic['slug']);
    }
}

if (!function_exists('comic_home_prices')) {
    function comic_home_prices(array $comic): array
    {
        $regular = (float)($comic['price'] ?? 0);
        $sale = isset($comic['sale_price']) ? (float)$comic['sale_price'] : 0;
        $hasSale = $sale > 0 && $sale < $regular;

        return [
            'current' => $hasSale ? $sale : $regular,
            'regular' => $regular,
            'hasSale' => $hasSale,
            'percent' => ($hasSale && $regular > 0)
                ? (int)round((1 - $sale / $regular) * 100)
                : 0,
        ];
    }
}

/* Thẻ truyện dạng lưới (kính mờ) */
if (!function_exists('comic_home_render_card')) {
    function comic_home_render_card(array $comic): void
    {
        $price = comic_home_prices($comic);
        $url = comic_home_url($comic);
        $stock = (int)($comic['stock'] ?? 0);
        ?>
        <article class="gl-card">
            <a class="gl-card-thumb" href="<?= comic_home_escape($url) ?>">
                <img src="<?= comic_home_escape(comic_home_cover($comic)) ?>"
                     alt="<?= comic_home_escape($comic['title']) ?>" loading="lazy">

                <?php if ($price['hasSale']): ?>
                    <span class="gl-tag">-<?= $price['percent'] ?>%</span>
                <?php elseif ((int)($comic['is_new'] ?? 0) === 1): ?>
                    <span class="gl-tag">Mới</span>
                <?php endif; ?>

            </a>
            <div class="gl-card-body">
                <?php if (!empty($comic['category_name'])): ?>
                    <span class="cp-card-category"><?= comic_home_escape($comic['category_name']) ?></span>
                <?php endif; ?>

                <a class="cp-card-title" href="<?= comic_home_escape($url) ?>">
                    <?= comic_home_escape($comic['title']) ?>
                </a>

                <div class="cp-card-rating">
                    <span class="star">★</span>
                    <span><?= number_format((float)($comic['rating_avg'] ?? 0), 1) ?></span>
                    <span class="count">(<?= number_format((int)($comic['review_count'] ?? 0)) ?>)</span>
                </div>

                <div class="cp-card-price">
                    <strong><?= comic_home_money($price['current']) ?></strong>
                    <?php if ($price['hasSale']): ?>
                        <del><?= comic_home_money($price['regular']) ?></del>
                    <?php endif; ?>
                </div>

                <div class="cp-card-bottom">
                    <span class="cp-stock <?= $stock > 0 ? '' : 'out' ?>">
                        <?= $stock > 0 ? 'Còn hàng' : 'Hết hàng' ?>
                    </span>

                    <a
                        class="cp-view"
                        href="<?= comic_home_escape($url) ?>"
                        aria-label="Xem chi tiết <?= comic_home_escape($comic['title']) ?>"
                        title="Xem chi tiết"
                    >→</a>
                </div>
            </div>
        </article>
        <?php
    }
}

/* Thẻ "Có thể bạn thích": ảnh phủ kín, chữ nằm dưới, nút play tròn */
if (!function_exists('comic_home_render_tile')) {
    function comic_home_render_tile(array $comic): void
    {
        $price = comic_home_prices($comic);
        $url = comic_home_url($comic);
        ?>
        <a class="gl-tile" href="<?= comic_home_escape($url) ?>">
            <img src="<?= comic_home_escape(comic_home_cover($comic)) ?>"
                 alt="" loading="lazy">
            <?php if ($price['hasSale']): ?>
                <span class="gl-tile-tag">-<?= $price['percent'] ?>%</span>
            <?php endif; ?>
            <span class="gl-tile-info">
                <strong><?= comic_home_escape($comic['title']) ?></strong>
                <em><?= comic_home_escape(comic_home_excerpt((string)($comic['description'] ?? ''), 48)) ?: comic_home_money($price['current']) ?></em>
            </span>
        </a>
        <?php
    }
}

/* Dòng truyện nhỏ cho cột bên trái */
if (!function_exists('comic_home_render_row')) {
    function comic_home_render_row(array $comic, string $sub = ''): void
    {
        $price = comic_home_prices($comic);
        ?>
        <a class="gl-row" href="<?= comic_home_escape(comic_home_url($comic)) ?>">
            <img src="<?= comic_home_escape(comic_home_cover($comic)) ?>" alt="" loading="lazy">
            <span class="gl-row-text">
                <strong><?= comic_home_escape($comic['title']) ?></strong>
                <small><?= comic_home_escape($sub !== '' ? $sub : comic_home_money($price['current'])) ?></small>
            </span>
        </a>
        <?php
    }
}

/* =========================================================
   6. THÔNG TIN TRANG
========================================================= */

$pageTitle = [
    'featured' => 'Truyện nổi bật | Comic Shop',
    'new'      => 'Truyện mới phát hành | Comic Shop',
    'discount' => 'Truyện đang giảm giá | Comic Shop',
][$catQuick] ?? 'Comic Shop | Thế giới truyện tranh';

$pageDescription =
    'Khám phá manga, truyện tranh và nhiều bộ truyện hấp dẫn tại Comic Shop.';

$activeMenu = 'home';

/* Giao diện mới có khung riêng, không cần menu đè lên banner */
$hasHeroBanner = true;

/* header.php ghi đè $categories, nên giữ bản có số lượng truyện */
$homeCategories = $categories;

$heroImage = comic_home_find('assets/images/hero', 'hero-bg') ?: '';
$promoImage = comic_home_find('assets/images/banners', 'promo');

/* Slide nổi bật */
$slideSource = $featuredComics ?: ($popularComics ?: $newComics);
$slides = [];

foreach (array_slice($slideSource, 0, 4) as $comic) {
    $p = comic_home_prices($comic);
    $slides[] = [
        'title' => (string)$comic['title'],
        'desc' => comic_home_excerpt((string)($comic['description'] ?? ''), 170),
        'url' => comic_home_url($comic),
        'image' => comic_home_cover($comic),
        'price' => comic_home_money($p['current']),
        'old' => $p['hasSale'] ? comic_home_money($p['regular']) : '',
        'percent' => $p['percent'],
        'rating' => number_format((float)($comic['rating_avg'] ?? 0), 1),
        'sold' => number_format((int)($comic['sold_count'] ?? 0)),
        'stock' => (int)($comic['stock'] ?? 0) > 0,
    ];
}

$firstSlide = $slides[0] ?? null;

/* Gợi ý: ưu tiên truyện phổ biến, bỏ truyện đang làm slide đầu */
$suggestComics = $popularComics ?: $newComics;

/* Tên người dùng (nếu đã đăng nhập) */
$userName = '';
foreach (['user_name', 'username', 'full_name', 'name'] as $key) {
    if (!empty($_SESSION[$key]) && is_string($_SESSION[$key])) {
        $userName = $_SESSION[$key];
        break;
    }
}
if ($userName === '' && !empty($_SESSION['user']) && is_array($_SESSION['user'])) {
    $userName = (string)($_SESSION['user']['full_name']
        ?? $_SESSION['user']['name']
        ?? $_SESSION['user']['username']
        ?? '');
}

/* Trang chủ đã có thanh tìm kiếm riêng nên ẩn nút kính lúp trên header */
$hideHeaderSearch = true;

$headerFile = __DIR__ . '/includes/header.php';
$footerFile = __DIR__ . '/includes/footer.php';
$hasHeader = is_file($headerFile);
$hasFooter = is_file($footerFile);

if ($hasHeader) {
    require_once $headerFile;
} else {
    ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= comic_home_escape($pageTitle) ?></title>
        <meta name="description" content="<?= comic_home_escape($pageDescription) ?>">
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
    <?php
}
?>

<style>
/* =====================================================
   GIAO DIỆN KÍNH MỜ - TRANG CHỦ (bảng màu lạnh, gọn)
===================================================== */
.gl-page {
  --bg: #1c1c1f;           /* nền đen nhạt phủ toàn trang */
  --glass: #232327;
  --glass-2: #2c2c31;
  --glass-3: #36363c;
  --stroke: #3d3d44;
  --line: rgba(255,255,255,.38);   /* viền nút / chip */
  --text: #f2f2f2;
  --muted: #a9a9b2;
  --ink: #111111;          /* chữ nằm trên nền sáng (accent) */
  --accent: #f2f2f2;
  --accent-2: #bdbdc4;
  --radius-xl: 30px;
  --radius-lg: 24px;
  --radius-md: 18px;
  position: relative;
  isolation: isolate;
  min-height: 100vh;
  width: 100%; padding: 0 24px 20px;
  color: var(--text);
  font-family: "Inter", "Montserrat", system-ui, -apple-system, "Segoe UI", Arial, sans-serif;
  background: var(--bg);
}
.gl-page *, .gl-page *::before, .gl-page *::after { box-sizing: border-box; }
.gl-page a { color: inherit; text-decoration: none; }
.gl-page img { display: block; max-width: 100%; }
.gl-page h1, .gl-page h2, .gl-page h3, .gl-page p { margin: 0; }

/* Nền mờ phía sau (ảnh hero nếu có) */
.gl-bg { position: absolute; inset: 0; z-index: -1; overflow: hidden; pointer-events: none; }
.gl-bg::before {
  content: ""; position: absolute; inset: -60px;
  background: var(--bg-image, none) center / cover no-repeat;
  filter: grayscale(1) blur(40px);
  opacity: .05;
}
.gl-bg::after {
  content: ""; position: absolute; inset: 0;
  background: linear-gradient(180deg, rgba(28,28,31,.6), #1c1c1f);
}

/* Khung chính */
.gl-shell {
  position: relative;
  max-width: none; width: 100%; margin: 0;
  padding: 20px;
  border-radius: var(--radius-xl);
  background: var(--glass);
  border: 1px solid var(--stroke);
  box-shadow: none;
}

/* Lưới chính */
.gl-main { display: block; }
.gl-panel {
  padding: 14px;
  border-radius: var(--radius-lg);
  background: var(--glass);
  border: 1px solid var(--stroke);
}
/* Nút play tròn */
.gl-play {
  width: 30px; height: 30px; flex-shrink: 0;
  display: inline-grid; place-items: center;
  border-radius: 50%;
  background: rgba(255,255,255,.2);
  border: 1px solid rgba(255,255,255,.35);
  color: #fff; font-size: 9px; padding-left: 2px;
  -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px);
  transition: background .2s, color .2s, transform .2s;
}
.gl-play--sm { width: 26px; height: 26px; font-size: 8px; }
.gl-play--lg { width: 38px; height: 38px; font-size: 11px; background: #f2f2f2; color: #111111; border-color: #f2f2f2; }
a:hover .gl-play { background: var(--accent); border-color: var(--accent); color: var(--ink); transform: scale(1.08); }

/* Hero nổi bật */
.gl-stage { display: flex; flex-direction: column; gap: 22px; min-width: 0; }
.gl-hero {
  position: relative; min-height: 340px;
  border-radius: var(--radius-lg); overflow: hidden;
  background: var(--bg); border: 1px solid var(--stroke);
}
.gl-hero-bg {
  position: absolute; inset: -30px;
  background-size: cover; background-position: center;
  filter: grayscale(1) blur(28px) brightness(.7);
  transition: opacity .5s ease;
}
.gl-hero::before {
  content: ""; position: absolute; inset: 0; z-index: 1;
  background: linear-gradient(90deg, #1c1c1f 0%, rgba(28,28,31,.82) 55%, rgba(28,28,31,.1) 100%);
}
.gl-hero-poster {
  position: absolute; z-index: 2; right: 7%; top: 50%; transform: translateY(-50%);
  width: 190px; aspect-ratio: 2 / 3;
  border-radius: 18px; overflow: hidden;
  box-shadow: 0 24px 56px rgba(0,0,0,.55);
  border: 1px solid var(--line);
  transition: opacity .35s ease;
}
.gl-hero-poster img { width: 100%; height: 100%; object-fit: cover; }
.gl-hero-body {
  position: relative; z-index: 3;
  display: flex; flex-direction: column; justify-content: flex-end;
  min-height: 340px; max-width: 60%;
  padding: 26px 28px;
  transition: opacity .35s ease;
}
.gl-hero.is-swap .gl-hero-body, .gl-hero.is-swap .gl-hero-poster { opacity: 0; }
.gl-badge {
  position: absolute; z-index: 3; top: 18px; left: 20px;
  padding: 6px 14px; border-radius: 999px;
  background: rgba(255,255,255,.08); border: 1px solid var(--line);
  font-size: 11px; font-weight: 700; color: var(--text);
}
.gl-chips { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; }
.gl-chip {
  padding: 5px 12px; border-radius: 999px;
  background: rgba(255,255,255,.08); border: 1px solid var(--line);
  font-size: 10px; font-weight: 600;
}
.gl-chip--sale { background: var(--accent); border-color: var(--accent); color: var(--ink); font-weight: 800; }
.gl-hero-title {
  font-size: 30px; line-height: 1.12; font-weight: 800; letter-spacing: -.3px;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}
.gl-hero-desc {
  margin-top: 10px; max-width: 440px; font-size: 12.5px; line-height: 1.65; color: var(--muted);
  display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;
}
.gl-hero-meta { margin-top: 12px; font-size: 12px; color: var(--muted); }
.gl-hero-meta b { color: #ffffff; font-size: 17px; margin-right: 8px; }
.gl-hero-meta s { margin-right: 8px; opacity: .65; }
.gl-hero-actions { display: flex; align-items: center; gap: 10px; margin-top: 18px; flex-wrap: wrap; }

.gl-btn {
  display: inline-flex; align-items: center; justify-content: center; gap: 8px;
  height: 42px; padding: 0 22px; border-radius: 999px;
  border: 1.5px solid var(--line); background: rgba(255,255,255,.08);
  color: var(--text); font: inherit; font-size: 13px; font-weight: 700; cursor: pointer;
  transition: background .2s, color .2s, transform .2s;
}
.gl-btn:hover { background: rgba(255,255,255,.18); transform: translateY(-1px); }
.gl-page .gl-btn--solid, .gl-page .gl-btn--solid:visited { background: #f2f2f2; color: #111111; border-color: #f2f2f2; }
.gl-page .gl-btn--solid:hover { background: #ffffff; border-color: #ffffff; color: #111111; }
.gl-btn--icon { width: 42px; padding: 0; }

.gl-arrows { position: absolute; z-index: 4; right: 20px; bottom: 20px; display: flex; gap: 8px; }
.gl-arrow {
  width: 36px; height: 36px; display: grid; place-items: center;
  border-radius: 50%; background: rgba(255,255,255,.08); border: 1.5px solid var(--line);
  color: var(--text); font-size: 18px; cursor: pointer;
  transition: background .2s, color .2s;
}
.gl-page .gl-arrow:hover { background: #f2f2f2; color: #111111; }


/* ---------- Banner đầu trang: cuốn truyện nổi lên trên nền của chính nó ---------- */
.gl-hero--top {
  margin: 0 -24px 60px;
  min-height: 640px;
  overflow: visible;           /* cho cuốn truyện nhô ra ngoài mép banner */
  border: 0; border-radius: 0;
  background: var(--bg);
}
/* nền: ảnh bìa phóng to, mờ nhẹ, cắt đúng khung banner */
.gl-hero--top .gl-hero-bg {
  inset: -24px;
  background-position: center 18%;
  filter: grayscale(1) contrast(1.05) brightness(.7);
  clip-path: inset(24px);
}
.gl-hero--top::before {
  background:
    linear-gradient(90deg, #1c1c1f 0%, rgba(28,28,31,.86) 45%, rgba(28,28,31,.05) 100%),
    linear-gradient(0deg, rgba(28,28,31,.7) 0%, transparent 30%);
}
.gl-hero--top .gl-badge { top: 130px; left: 56px; }
.gl-hero--top .gl-hero-body {
  min-height: 640px; max-width: 54%;
  padding: 170px 56px 90px;
}
.gl-hero--top .gl-hero-title { font-size: 44px; }
.gl-hero--top .gl-hero-desc { max-width: 520px; font-size: 14px; }

/* cuốn truyện 3D, trôi nhẹ, nhô ra khỏi mép dưới banner */
.gl-hero--top .gl-hero-poster {
  width: 270px; right: 11%; top: auto; bottom: 48px;
  border-radius: 6px 12px 12px 6px; border: 0;
  transform: perspective(1400px) rotateY(-15deg) rotateZ(1.5deg);
  transform-origin: 30% 60%;
  box-shadow:
    0 50px 90px rgba(0,0,0,.6),
    0 16px 30px rgba(0,0,0,.4),
    8px 0 0 -2px #3a3a40,
    11px 3px 0 -5px #55555c;
  animation: glFloat 6s ease-in-out infinite;
}
.gl-hero--top .gl-hero-poster::after {
  content: ""; position: absolute; inset: 0; pointer-events: none;
  background:
    linear-gradient(90deg, rgba(0,0,0,.32) 0%, rgba(255,255,255,.2) 2.5%, rgba(0,0,0,0) 8%),
    linear-gradient(115deg, rgba(255,255,255,.16) 0%, transparent 38%);
}
.gl-hero--top .gl-hero-poster:hover { animation-play-state: paused; }
@keyframes glFloat {
  0%, 100% { transform: perspective(1400px) rotateY(-15deg) rotateZ(1.5deg) translateY(0); }
  50%      { transform: perspective(1400px) rotateY(-15deg) rotateZ(1.5deg) translateY(-14px); }
}
.gl-hero--top .gl-arrows { right: 56px; bottom: 28px; }
@media (max-width: 1050px) {
  .gl-hero--top .gl-hero-poster { width: 210px; right: 5%; }
  .gl-hero--top .gl-hero-body { max-width: 60%; }
}
@media (max-width: 720px) {
  .gl-hero--top { margin: 0 -12px 40px; min-height: 680px; }
  .gl-hero--top .gl-hero-body { min-height: 680px; max-width: 100%; padding: 390px 22px 70px; }
  .gl-hero--top .gl-hero-title { font-size: 28px; }
  .gl-hero--top .gl-hero-poster {
    width: 170px; right: 50%; top: 110px; bottom: auto; margin-right: -85px;
    animation: none; transform: perspective(1200px) rotateY(-12deg);
  }
  .gl-hero--top .gl-badge { display: none; }
  .gl-hero--top .gl-arrows { right: 18px; top: 110px; bottom: auto; }
}
@media (prefers-reduced-motion: reduce) { .gl-hero--top .gl-hero-poster { animation: none; } }

/* Tiêu đề mục */
.gl-sec-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; }
.gl-sec-head h2 {
  display: flex; align-items: center; gap: 10px;
  font-size: 18px; font-weight: 800; letter-spacing: -.2px;
}
.gl-sec-head h2::before { content: ""; width: 4px; height: 18px; border-radius: 4px; background: var(--accent); }
.gl-more {
  padding: 6px 14px; border-radius: 999px;
  background: var(--glass-2); border: 1px solid var(--stroke);
  font-size: 11px; font-weight: 700; transition: background .2s, color .2s;
}
.gl-page .gl-more:hover { background: #f2f2f2; color: #111111; border-color: #f2f2f2; }

/* Hàng gợi ý */
.gl-tiles { display: grid; grid-template-columns: repeat(5, calc((100% - 60px) / 5.3)); justify-content: space-between; gap: 12px; }
.gl-tile {
  position: relative; display: block; aspect-ratio: 2 / 3;
  border-radius: var(--radius-md); overflow: hidden;
  background: var(--glass-2); border: 3px solid var(--stroke);
}
.gl-tile img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; object-position: center top; transition: transform .5s ease; }
.gl-tile:hover img { transform: scale(1.07); }
.gl-tile::after { content: ""; position: absolute; inset: 0; background: linear-gradient(0deg, rgba(0,0,0,.85) 0%, rgba(0,0,0,.05) 62%); }
.gl-tile-tag {
  position: absolute; z-index: 2; top: 12px; left: 12px;
  padding: 4px 10px; border-radius: 999px;
  background: var(--accent); color: var(--ink); font-size: 10px; font-weight: 800;
}
.gl-tile-info { position: absolute; z-index: 2; left: 12px; right: 48px; bottom: 12px; color: #ffffff; }
.gl-tile-info strong {
  font-size: 12px; font-weight: 800; line-height: 1.25;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}
.gl-tile-info em {
  margin-top: 4px; font-style: normal; font-size: 10px; line-height: 1.4; color: rgba(255,255,255,.75);
  display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden;
}
.gl-tile .gl-play { position: absolute; z-index: 2; right: 10px; bottom: 10px; width: 26px; height: 26px; font-size: 8px; }

/* Các mục bên dưới: bỏ khung lồng, chỉ để tiêu đề + lưới */
.gl-block { max-width: none; width: 100%; margin: 64px 0 0; padding: 0 4px; }

/* Truyện mới + Ưu đãi + Có thể bạn thích: bo khung xung quanh */
.gl-page #home-new, .gl-page #home-discounts, .gl-page #home-suggest {
  margin-top: 24px; padding: 20px;
  border-radius: var(--radius-xl);
  background: var(--glass); border: 1px solid var(--stroke);
}
@media (max-width: 720px) {
  .gl-page #home-new, .gl-page #home-discounts, .gl-page #home-suggest { margin-top: 16px; padding: 14px; border-radius: 24px; }
}

/* Thẻ truyện lưới */
.gl-grid { display: grid; grid-template-columns: repeat(5, calc((100% - 70px) / 5.3)); justify-content: space-between; gap: 40px 14px; }
.gl-card {
  border-radius: var(--radius-md); background: var(--glass); border: 3px solid var(--stroke);
  overflow: hidden;
  transition: transform .25s ease, background .25s ease, box-shadow .25s ease;
}
.gl-card:hover { transform: translateY(-4px); background: var(--glass-2); box-shadow: 0 14px 30px rgba(0,0,0,.45); }
.gl-card-thumb { position: relative; display: block; aspect-ratio: 1 / 1; overflow: hidden; background: var(--glass-2); }
.gl-card-thumb img { display: block; width: 100%; height: 100%; object-fit: cover; object-position: center top; transition: transform .5s ease; }
.gl-card:hover .gl-card-thumb img { transform: scale(1.05); }
.gl-tag {
  position: absolute; top: 10px; left: 10px; padding: 3px 9px; border-radius: 999px;
  background: var(--accent); color: var(--ink); font-size: 9.5px; font-weight: 800;
}
.gl-card-thumb .gl-play { position: absolute; right: 10px; bottom: 10px; width: 26px; height: 26px; font-size: 8px; }
.gl-card-body { padding: 8px 12px 10px; }
.gl-card-rate { display: flex; align-items: center; gap: 6px; }
.gl-card-rate small { font-size: 10px; color: var(--muted); }
.gl-stars { display: inline-flex; font-size: 11px; letter-spacing: 1px; }
.gl-stars i { font-style: normal; color: #55555c; }
.gl-stars i.on { color: #f2f2f2; }
.gl-card-title { margin: 4px 0 6px; font-size: 12px; font-weight: 700; line-height: 1.4; }
.gl-card-title a { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; min-height: 2.8em; }
.gl-card-title a:hover { color: var(--accent); text-decoration: underline; }
.gl-card-price { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.gl-card-price b { font-size: 13px; font-weight: 800; color: var(--accent); }
.gl-card-price s { margin-left: 6px; font-size: 11px; color: var(--muted); }
.gl-card-price small { font-size: 10px; font-weight: 700; color: var(--text); }
.gl-card-price small.out { color: var(--muted); }

/* Banner ưu đãi */
.gl-promo {
  position: relative; overflow: hidden;
  display: flex; align-items: center; justify-content: space-between; gap: 24px;
  padding: 40px 44px; margin-bottom: 36px;
  border-radius: var(--radius-lg);
  background: var(--glass-2);
  border: 1.5px solid var(--stroke);
}
.gl-promo.has-image {
  background-image: linear-gradient(90deg, rgba(0,0,0,.82), rgba(0,0,0,.3)), var(--promo-image);
  background-size: cover; background-position: center;
  color: #ffffff;
}
.gl-promo.has-image p { color: rgba(255,255,255,.78); }
.gl-promo.has-image .gl-promo-big { color: #ffffff; }
.gl-page .gl-promo.has-image .gl-btn--solid { background: #f2f2f2; color: #111111; border-color: #ffffff; }
.gl-promo h2 { display: block; font-size: 26px; font-weight: 800; line-height: 1.2; max-width: 460px; margin-bottom: 8px; }
.gl-promo h2::before { display: none; }
.gl-promo p { max-width: 420px; font-size: 13px; line-height: 1.65; color: var(--muted); margin-bottom: 20px; }
.gl-promo-big { font-size: 76px; font-weight: 800; line-height: 1; color: #ffffff; }

/* Dịch vụ */
.gl-benefits { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; }
.gl-benefit {
  display: flex; align-items: center; gap: 14px; padding: 16px 18px;
  border-radius: var(--radius-md); background: var(--glass); border: 1px solid var(--stroke);
}
.gl-benefit-ico {
  width: 42px; height: 42px; flex-shrink: 0; display: grid; place-items: center;
  border-radius: 50%; background: var(--glass-3); color: var(--text); font-size: 16px; font-weight: 800;
}
.gl-benefit strong { display: block; font-size: 12px; font-weight: 800; }
.gl-benefit span { font-size: 11px; color: var(--muted); }

.gl-empty { padding: 26px 0; text-align: center; color: var(--muted); font-size: 13px; }
.gl-flash {
  max-width: none; margin: 0 0 18px; padding: 12px 18px; border-radius: 16px;
  background: var(--glass-2); border: 1px solid var(--stroke); font-size: 13px;
}

.gl-page a:focus-visible, .gl-page button:focus-visible, .gl-page input:focus-visible, .gl-page select:focus-visible {
  outline: 2px solid var(--accent); outline-offset: 3px;
}

/* =====================================================
   MỤC CỬA HÀNG "TẤT CẢ TRUYỆN" (#catalog)
===================================================== */
.gl-page #catalog { scroll-margin-top: 20px; }
/* Chừa thêm 20px (đệm của khung .gl-shell) để khi nhảy tới #catalog nội dung không bị sát thanh menu */
html.gl-home-hidden .gl-page #catalog { scroll-margin-top: calc(var(--gl-head-h, 70px) + 48px); }
.gl-page .cp-layout {
  display: grid; grid-template-columns: 245px minmax(0, 1fr);
  gap: 22px; align-items: start;
}
.gl-page .cp-sidebar {
  overflow: hidden; border: 1px solid var(--stroke);
  border-radius: var(--radius-lg); background: var(--bg);
}
.gl-page .cp-side-section { padding: 12px 16px; border-bottom: 1px solid var(--stroke); }
.gl-page .cp-sidebar .cp-filter-link { padding: 3px 10px; }
.gl-page .cp-sidebar.is-capped { overflow: hidden; }
/* Thu gọn thêm nếu menu vẫn dài hơn hàng truyện đầu tiên (JS tự bật) */
.gl-page .cp-sidebar.is-tight .cp-side-section { padding: 10px 16px; }
.gl-page .cp-sidebar.is-tight .cp-side-title { margin-bottom: 6px; }
.gl-page .cp-sidebar.is-tight .cp-filter-link { padding: 2px 10px; }
.gl-page .cp-sidebar.is-tighter .cp-side-section { padding: 8px 16px; }
.gl-page .cp-sidebar.is-tighter .cp-side-title { margin-bottom: 4px; }
.gl-page .cp-sidebar.is-tighter .cp-filter-list { gap: 0; }
.gl-page .cp-sidebar.is-tighter .cp-filter-link { padding: 1px 10px; font-size: 11px; }
.gl-page .cp-side-section:last-child { border-bottom: 0; }
.gl-page .cp-side-title {
  display: flex; align-items: center; gap: 9px;
  margin: 0 0 9px; font-size: 13px; font-weight: 800;
}
.gl-page .cp-side-title::before { content: ""; width: 3px; height: 14px; border-radius: 3px; background: var(--accent); }
.gl-page .cp-filter-list { display: grid; gap: 2px; }
.gl-page .cp-filter-link {
  display: flex; justify-content: space-between; align-items: center; gap: 8px;
  padding: 9px 10px; border-radius: 12px;
  color: var(--muted); font-size: 11px; line-height: 1.5;
  transition: background .2s, color .2s;
}
.gl-page .cp-filter-link:hover, .gl-page .cp-filter-link.active { background: var(--glass-3); color: var(--text); }
.gl-page .cp-filter-count { color: var(--muted); font-size: 10px; }
.gl-page .cp-price-inputs { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.gl-page .cp-price-inputs input {
  width: 100%; min-width: 0; min-height: 38px; padding: 8px 10px;
  border: 1px solid var(--stroke); border-radius: 12px; outline: none;
  background: var(--glass-2); color: var(--text); font: inherit; font-size: 11px;
}
.gl-page .cp-price-inputs input::placeholder { color: #7c7c85; }
.gl-page .cp-price-inputs input:focus { border-color: var(--line); }
.gl-page .cp-filter-btn {
  display: flex; width: 100%; min-height: 38px; align-items: center; justify-content: center;
  margin-top: 10px; border: 0; border-radius: 999px;
  background: var(--accent); color: var(--ink);
  font-size: 11px; font-weight: 800; cursor: pointer;
  transition: background .2s, transform .2s;
}
.gl-page .cp-filter-btn:hover { background: #fff; transform: translateY(-1px); }

.gl-page .cp-main { min-width: 0; }
.gl-page .cp-toolbar {
  display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;
  gap: 13px; margin-bottom: 17px;
}
.gl-page .cp-result-title {
  display: flex; align-items: center; gap: 10px;
  margin: 0; font-size: 20px; font-weight: 800; letter-spacing: -.3px;
}
.gl-page .cp-result-title::before { content: ""; width: 4px; height: 18px; border-radius: 4px; background: var(--accent); }
.gl-page .cp-result-note { margin-top: 6px; color: var(--muted); font-size: 11px; line-height: 1.7; }
.gl-page .cp-search { display: flex; gap: 7px; width: min(100%, 355px); }
.gl-page .cp-search-center { display: flex; justify-content: center; flex: 1 1 320px; min-width: 0; margin: 0; }
.gl-page .cp-search-center .cp-search {
  width: min(100%, 520px); align-items: center; gap: 10px; padding: 4px;
  border: 1px solid var(--stroke); border-radius: 999px; background: var(--glass-2);
}
.gl-page .cp-search-center .cp-search svg { flex: none; margin-left: 12px; color: var(--muted); }
.gl-page .cp-search-center .cp-search input { border: 0; background: transparent; min-height: 38px; font-size: 13px; box-shadow: none; }
.gl-page .cp-search-center .cp-search input:focus { box-shadow: none; }
.gl-page .cp-search-center .cp-search:focus-within { border-color: var(--line); box-shadow: 0 0 0 3px rgba(255,255,255,.07); }
.gl-page .cp-search-center .cp-search button { min-height: 38px; padding: 9px 24px; font-size: 12px; }
.gl-page .cp-fpop { position: relative; }
.gl-page .cp-hide-home { margin-left: auto; }
html.gl-home-hidden #glHero { display: none; }
/* Khi ẩn banner: thanh menu cố định trên cùng, nội dung được đẩy xuống đúng bằng chiều cao menu */
html.gl-home-hidden .scrn-topbar {
  position: fixed !important; top: 0; left: 0; right: 0; z-index: 900;
}
html.gl-home-hidden .scrn-main-content { padding-top: calc(var(--gl-head-h, 70px) + 28px); }
.gl-page .cp-fpop-btn {
  display: inline-flex; align-items: center; gap: 9px; min-height: 40px; padding: 8px 18px;
  border: 1px solid var(--stroke); border-radius: 999px;
  background: var(--glass-2); color: var(--text); font: inherit; font-size: 11px; font-weight: 800;
  cursor: pointer; transition: background .2s, border-color .2s, box-shadow .2s;
}
.gl-page .cp-fpop-btn:hover { background: var(--glass-3); }
.gl-page .cp-fpop.open .cp-fpop-btn { border-color: var(--line); box-shadow: 0 0 0 3px rgba(255,255,255,.07); }
.gl-page .cp-fpop-badge {
  min-width: 18px; padding: 1px 6px; border-radius: 999px; text-align: center;
  background: var(--accent); color: var(--ink); font-size: 10px; font-weight: 800;
}
.gl-page .cp-fpop-btn .cp-dd-arrow {
  width: 7px; height: 7px; margin-top: -3px; border: solid var(--accent-2); border-width: 0 2px 2px 0;
  transform: rotate(45deg); transition: transform .2s, margin .2s;
}
.gl-page .cp-fpop.open .cp-dd-arrow { transform: rotate(-135deg); margin-top: 3px; }
.gl-page .cp-fpop-panel {
  position: absolute; top: calc(100% + 10px); right: 0; z-index: 70; width: 320px; max-width: calc(100vw - 32px);
  padding: 18px; border: 1px solid var(--stroke); border-radius: 20px;
  background: rgba(35,35,39,.98); backdrop-filter: blur(10px);
  box-shadow: 0 22px 50px rgba(0,0,0,.6);
  opacity: 0; visibility: hidden; transform: translateY(-6px);
  transition: opacity .18s, transform .18s, visibility .18s;
}
.gl-page .cp-fpop.open .cp-fpop-panel { opacity: 1; visibility: visible; transform: none; }
.gl-page .cp-fpop-title {
  display: flex; align-items: center; gap: 8px; margin: 0 0 10px;
  color: var(--text); font-size: 12px; font-weight: 800;
}
.gl-page .cp-fpop-title::before { content: ""; width: 3px; height: 13px; border-radius: 3px; background: var(--accent); }
.gl-page .cp-fpop-prices { display: flex; align-items: center; gap: 8px; margin-bottom: 18px; color: var(--muted); }
.gl-page .cp-fpop-prices input {
  width: 100%; min-width: 0; min-height: 40px; padding: 8px 14px;
  border: 1px solid var(--stroke); border-radius: 999px; outline: none;
  background: var(--bg); color: var(--text); font: inherit; font-size: 11px;
  -moz-appearance: textfield; appearance: textfield;
}
.gl-page .cp-fpop-prices input::-webkit-outer-spin-button,
.gl-page .cp-fpop-prices input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
.gl-page .cp-fpop-prices input::placeholder { color: #7c7c85; }
.gl-page .cp-fpop-prices input:focus { border-color: var(--line); box-shadow: 0 0 0 3px rgba(255,255,255,.07); }
.gl-page .cp-fpop-stars { display: grid; gap: 4px; margin-bottom: 18px; }
.gl-page .cp-star-row { display: block; cursor: pointer; }
.gl-page .cp-star-row input { position: absolute; opacity: 0; pointer-events: none; }
.gl-page .cp-star-label {
  display: flex; align-items: center; gap: 10px; padding: 9px 12px; border-radius: 12px;
  color: var(--muted); font-size: 11px; transition: background .15s, color .15s;
}
.gl-page .cp-star-row:hover .cp-star-label { background: var(--glass-3); color: var(--text); }
.gl-page .cp-star-row input:checked + .cp-star-label { background: var(--accent); color: var(--ink); }
.gl-page .cp-star-row input:focus-visible + .cp-star-label { outline: 2px solid var(--accent); outline-offset: 2px; }
.gl-page .cp-star-icons { color: #ffd166; font-size: 12px; letter-spacing: 1px; white-space: nowrap; }
.gl-page .cp-star-icons em { font-style: normal; color: #55555d; }
.gl-page .cp-star-row input:checked + .cp-star-label .cp-star-icons { color: #b7791f; }
.gl-page .cp-star-row input:checked + .cp-star-label .cp-star-icons em { color: #b9b9c0; }
.gl-page .cp-star-label b { flex: 1; font-weight: 700; }
.gl-page .cp-star-label small { font-size: 10px; opacity: .75; }
.gl-page .cp-fpop-actions { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.gl-page .cp-fpop-reset { color: var(--muted); font-size: 11px; font-weight: 700; text-decoration: underline; }
.gl-page .cp-fpop-reset:hover { color: var(--text); }
.gl-page .cp-fpop-actions button {
  padding: 10px 24px; border: 0; border-radius: 999px;
  background: var(--accent); color: var(--ink); font-size: 11px; font-weight: 800; cursor: pointer;
}
.gl-page .cp-fpop-actions button:hover { background: #fff; }
.gl-page .cp-search input {
  width: 100%; min-width: 0; min-height: 40px; flex: 1; padding: 9px 14px;
  border: 1px solid var(--stroke); border-radius: 999px; outline: none;
  background: var(--bg); color: var(--text); font: inherit; font-size: 11px;
}
.gl-page .cp-search input::placeholder { color: #7c7c85; }
.gl-page .cp-search input:focus { border-color: var(--line); box-shadow: 0 0 0 3px rgba(255,255,255,.07); }
.gl-page .cp-search button {
  padding: 9px 18px; border: 0; border-radius: 999px;
  background: var(--accent); color: var(--ink);
  font-size: 11px; font-weight: 800; cursor: pointer; transition: background .2s;
}
.gl-page .cp-search button:hover { background: #fff; }
.gl-page .cp-toolbar-bottom {
  display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;
  margin-bottom: 20px; padding: 12px 16px;
  border: 1px solid var(--stroke); border-radius: var(--radius-md); background: var(--bg);
}
.gl-page .cp-toolbar-bottom label { color: var(--muted); font-size: 11px; font-weight: 700; }
.gl-page .cp-sort {
  min-height: 36px; padding: 7px 12px;
  border: 1px solid var(--stroke); border-radius: 999px; outline: none;
  background: var(--glass-2); color: var(--text); font: inherit; font-size: 11px;
}
.gl-page .cp-sort option { background: #232327; color: #f2f2f2; }
/* Dropdown tùy chỉnh */
.gl-page .cp-dd { position: relative; display: inline-block; }
.gl-page .cp-dd > select { position: absolute; inset: 0; opacity: 0; pointer-events: none; }
.gl-page .cp-dd-btn {
  display: inline-flex; align-items: center; justify-content: space-between; gap: 12px;
  min-width: 150px; min-height: 40px; padding: 8px 14px;
  border: 1px solid var(--stroke); border-radius: 999px;
  background: var(--glass-2); color: var(--text); font: inherit; font-size: 11px; font-weight: 700;
  cursor: pointer; transition: border-color .2s, background .2s, box-shadow .2s;
}
.gl-page .cp-dd-btn:hover { background: var(--glass-3); }
.gl-page .cp-dd.open .cp-dd-btn,
.gl-page .cp-dd-btn:focus-visible { border-color: var(--line); box-shadow: 0 0 0 3px rgba(255,255,255,.07); outline: none; }
.gl-page .cp-dd-btn .cp-dd-arrow {
  width: 7px; height: 7px; margin-top: -3px; border: solid var(--accent-2); border-width: 0 2px 2px 0;
  transform: rotate(45deg); transition: transform .2s, margin .2s;
}
.gl-page .cp-dd.open .cp-dd-arrow { transform: rotate(-135deg); margin-top: 3px; }
.gl-page .cp-dd-menu {
  position: absolute; top: calc(100% + 8px); right: 0; z-index: 60;
  min-width: 100%; margin: 0; padding: 6px; list-style: none;
  border: 1px solid var(--stroke); border-radius: 16px;
  background: rgba(35,35,39,.97); backdrop-filter: blur(10px);
  box-shadow: 0 18px 40px rgba(0,0,0,.55);
  opacity: 0; visibility: hidden; transform: translateY(-6px);
  transition: opacity .18s, transform .18s, visibility .18s;
}
.gl-page .cp-dd.open .cp-dd-menu { opacity: 1; visibility: visible; transform: none; }
.gl-page .cp-dd-item {
  display: flex; align-items: center; justify-content: space-between; gap: 14px;
  padding: 9px 12px; border-radius: 11px; white-space: nowrap;
  color: var(--muted); font-size: 11px; font-weight: 600; cursor: pointer;
  transition: background .15s, color .15s;
}
.gl-page .cp-dd-item:hover, .gl-page .cp-dd-item.focus { background: var(--glass-3); color: var(--text); }
.gl-page .cp-dd-item.selected { color: var(--ink); background: var(--accent); font-weight: 800; }
.gl-page .cp-dd-item.selected::after { content: "✓"; font-size: 11px; }
.gl-page .cp-dd-star { color: #ffd166; letter-spacing: 1px; }
.gl-page .cp-dd-item.selected .cp-dd-star { color: #b7791f; }

.gl-page .cp-active-filters { display: flex; flex-wrap: wrap; align-content: flex-start; gap: 7px; margin-bottom: 17px; min-height: 30px; }
.gl-page .cp-chip {
  display: inline-flex; align-items: center; gap: 7px; padding: 6px 12px;
  border: 1px solid var(--line); border-radius: 999px;
  background: rgba(255,255,255,.08); color: var(--text);
  font-size: 10px; font-weight: 700;
}
.gl-page .cp-chip:hover { background: rgba(255,255,255,.18); }

.gl-page .cp-products { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; }
.gl-page .cp-products { align-content: start; }
.gl-page .cp-page-note { color: var(--muted); font-size: 12px; font-weight: 700; white-space: nowrap; }
.gl-page .cp-extra-head { grid-column: 1 / -1; margin: 6px 0 -2px; color: var(--muted); font-size: 12px; font-weight: 800; letter-spacing: .4px; }
.gl-page .cp-card {
  min-width: 0; overflow: hidden;
  border: 3px solid var(--stroke); border-radius: var(--radius-md); background: var(--bg);
  transition: transform .25s ease, background .25s ease, box-shadow .25s ease;
}
.gl-page .cp-card:hover { transform: translateY(-4px); background: var(--glass-2); box-shadow: 0 14px 30px rgba(0,0,0,.45); }
.gl-page .cp-cover {
  position: relative; display: block; overflow: hidden;
  aspect-ratio: 1 / 1; background: var(--glass-2);
}
.gl-page .cp-cover img {
  display: block; width: 100%; height: 100%;
  object-fit: cover; object-position: center top; transition: transform .5s ease;
}
.gl-page .cp-card:hover .cp-cover img { transform: scale(1.05); }
.gl-page .cp-badges {
  position: absolute; top: 10px; left: 10px;
  display: flex; flex-direction: column; align-items: flex-start; gap: 5px;
}
.gl-page .cp-badge {
  display: inline-flex; padding: 4px 10px; border-radius: 999px;
  background: var(--accent); color: var(--ink); font-size: 9.5px; font-weight: 800;
}
.gl-page .cp-badge.dark { background: #111111; color: #f2f2f2; border: 1px solid var(--line); }
.gl-page .cp-badge.gray { background: #55555c; color: #fff; }
.gl-page .cp-card-body { padding: 8px 12px 10px; }
.gl-page .cp-card-category {
  display: block; margin-bottom: 3px;
  color: var(--muted); font-size: 9px; font-weight: 700; letter-spacing: .4px; text-transform: uppercase;
}
.gl-page .cp-card-category:hover { color: var(--text); }
.gl-page .cp-card-title {
  display: -webkit-box; min-height: 36px; overflow: hidden;
  color: var(--text); font-size: 12px; font-weight: 700; line-height: 1.5;
  -webkit-box-orient: vertical; -webkit-line-clamp: 2;
}
.gl-page .cp-card-title:hover { text-decoration: underline; }
.gl-page .cp-card-author {
  overflow: hidden; margin-top: 3px;
  color: var(--muted); font-size: 10px; text-overflow: ellipsis; white-space: nowrap;
}
.gl-page .cp-card-rating { display: flex; align-items: center; gap: 4px; margin-top: 5px; color: var(--muted); font-size: 10px; }
.gl-page .cp-card-rating .star { color: #f2f2f2; font-size: 12px; }
.gl-page .cp-card-rating .count { color: #7c7c85; }
.gl-page .cp-card-price { display: flex; align-items: baseline; flex-wrap: wrap; gap: 6px; margin-top: 5px; }
.gl-page .cp-card-price strong { color: var(--accent); font-size: 13px; font-weight: 800; }
.gl-page .cp-card-price del { color: var(--muted); font-size: 10px; }
/* Đuôi thẻ gọn: giá bên trái, điểm sao bên phải, một hàng cuối */
.gl-page .cp-card-body, .gl-page .gl-card-body {
  display: grid; grid-template-columns: minmax(0, 1fr) auto; column-gap: 8px; align-items: center;
  padding: 8px 12px 8px;
}
.gl-page .cp-card-body > .cp-card-category, .gl-page .gl-card-body > .cp-card-category { grid-column: 1 / -1; grid-row: 1; margin-bottom: 2px; }
.gl-page .cp-card-body > .cp-card-title, .gl-page .gl-card-body > .cp-card-title { grid-column: 1 / -1; grid-row: 2; min-height: 0; line-height: 1.45; }
.gl-page .cp-card-body > .cp-card-price, .gl-page .gl-card-body > .cp-card-price { grid-column: 1; grid-row: 3; margin-top: 4px; }
.gl-page .cp-card-body > .cp-card-rating, .gl-page .gl-card-body > .cp-card-rating { grid-column: 2; grid-row: 3; margin-top: 4px; }
.gl-page .cp-card-body > .cp-card-bottom, .gl-page .gl-card-body > .cp-card-bottom { grid-column: 1 / -1; grid-row: 4; margin-top: 6px; padding-top: 6px; }
.gl-page .cp-view { width: 24px; height: 24px; font-size: 12px; }
.gl-page .gl-card-body > .cp-card-title { -webkit-line-clamp: 1; white-space: nowrap; text-overflow: ellipsis; display: block; }
.gl-page .gl-card-body { padding: 8px 12px 8px; }
.gl-page .cp-card-bottom {
  display: flex; justify-content: space-between; align-items: center; gap: 6px;
  margin-top: 7px; padding-top: 7px; border-top: 1px solid var(--stroke);
}
.gl-page .cp-stock { color: var(--text); font-size: 10px; font-weight: 700; }
.gl-page .cp-stock.out { color: var(--muted); }
.gl-page .cp-view {
  display: flex; width: 28px; height: 28px; flex-shrink: 0; align-items: center; justify-content: center;
  border: 1px solid var(--line); border-radius: 50%;
  background: rgba(255,255,255,.1); color: #fff; font-size: 13px;
  transition: background .2s, color .2s, transform .2s;
}
.gl-page .cp-view:hover { background: var(--accent); color: var(--ink); transform: scale(1.08); }
.gl-page .cp-empty {
  grid-column: 1 / -1; padding: 46px 18px;
  border: 1px solid var(--stroke); border-radius: var(--radius-lg);
  background: var(--bg); text-align: center;
}
.gl-page .cp-empty-icon { margin-bottom: 12px; color: var(--muted); font-size: 34px; }
.gl-page .cp-empty h3 { margin: 0 0 8px; font-size: 19px; font-weight: 800; }
.gl-page .cp-empty p { margin: 0 auto 17px; color: var(--muted); font-size: 12px; line-height: 1.8; }
.gl-page .cp-btn {
  display: inline-flex; min-height: 40px; align-items: center; justify-content: center;
  padding: 9px 20px; border-radius: 999px;
  background: var(--accent); color: var(--ink); font-size: 11px; font-weight: 800; transition: background .2s;
}
.gl-page .cp-btn:hover { background: #fff; color: var(--ink); }
.gl-page .cp-error {
  margin-bottom: 17px; padding: 12px 16px;
  border: 1px solid var(--stroke); border-left: 4px solid var(--accent); border-radius: 14px;
  background: var(--glass-2); color: var(--text); font-size: 11px; line-height: 1.7;
}
.gl-page .cp-pagination { display: flex; justify-content: center; align-items: center; flex-wrap: wrap; gap: 6px; margin-top: 28px; }
.gl-page .cp-page {
  display: inline-flex; min-width: 36px; height: 36px; align-items: center; justify-content: center;
  padding: 0 10px; border: 1px solid var(--stroke); border-radius: 999px;
  background: var(--bg); color: var(--muted); font-size: 11px; font-weight: 800;
  transition: background .2s, color .2s;
}
.gl-page .cp-page.disabled { opacity: .35; cursor: not-allowed; pointer-events: none; }
.gl-page .cp-page:hover, .gl-page .cp-page.current { border-color: var(--accent); background: var(--accent); color: var(--ink); }

/* ---------- Responsive ---------- */
@media (max-width: 1100px) {
  .gl-tiles, .gl-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
  .gl-page .cp-layout { grid-template-columns: 215px minmax(0, 1fr); gap: 16px; }
  .gl-page .cp-products { grid-template-columns: repeat(3, minmax(0, 1fr)); }
}
@media (max-width: 780px) {
  .gl-page .cp-layout { grid-template-columns: 1fr; }
  .gl-page .cp-sidebar { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .gl-page .cp-side-section { border-right: 1px solid var(--stroke); }
  .gl-page .cp-side-section:nth-child(2n) { border-right: 0; }
  .gl-page .cp-side-section:last-child { grid-column: 1 / -1; border-right: 0; }
}
@media (max-width: 640px) {
  .gl-tiles, .gl-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .gl-page .cp-sidebar { grid-template-columns: 1fr; }
  .gl-page .cp-side-section { border-right: 0; }
  .gl-page .cp-side-section:last-child { grid-column: auto; }
  .gl-page .cp-products { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 11px; }
  .gl-page .cp-card-body { padding: 9px; }
  .gl-page .cp-toolbar { align-items: stretch; }
  .gl-page .cp-search { width: 100%; }
}
@media (max-width: 1050px) {
  .gl-benefits { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
@media (max-width: 720px) {
  .gl-page { padding: 18px 12px 16px; }
  .gl-shell { padding: 14px; border-radius: 24px; }
  .gl-block { margin-top: 48px; }
  .gl-hero, .gl-hero-body { min-height: 430px; }
  .gl-hero-body { max-width: 100%; padding: 20px; }
  .gl-hero-poster { right: 50%; top: 24px; transform: translateX(50%); width: 120px; }
  .gl-hero::before { background: linear-gradient(0deg, rgba(28,28,31,.96) 25%, rgba(28,28,31,.2) 90%); }
  .gl-hero-title { font-size: 23px; }
  .gl-badge { display: none; }
  .gl-arrows { right: 14px; top: 14px; bottom: auto; }
  .gl-grid, .gl-tiles { gap: 10px; }
  .gl-benefits { grid-template-columns: 1fr; }
  .gl-promo { flex-direction: column; align-items: flex-start; padding: 28px 22px; }
  .gl-promo h2 { font-size: 21px; }
  .gl-promo-big { font-size: 52px; }
}
@media (prefers-reduced-motion: reduce) { .gl-page * { transition: none !important; } }
</style>

<?php
$maxDiscount = 0;
foreach ($discountComics as $discountComic) {
    $maxDiscount = max($maxDiscount, comic_home_prices($discountComic)['percent']);
}

$catAgeNames = [
    'all' => 'Mọi lứa tuổi',
    '13+' => '13 tuổi trở lên',
    '16+' => '16 tuổi trở lên',
    '18+' => '18 tuổi trở lên',
];
?>

<div class="gl-page">
    <div class="gl-bg"
         <?php if ($heroImage !== ''): ?>
             style="--bg-image:url('<?= comic_home_escape($heroImage) ?>')"
         <?php elseif ($firstSlide && strpos($firstSlide['image'], 'data:') !== 0): ?>
             style="--bg-image:url('<?= comic_home_escape($firstSlide['image']) ?>')"
         <?php endif; ?>
         aria-hidden="true"></div>

    <?php if ($homeError !== ''): ?>
        <div class="gl-flash" role="status"><?= comic_home_escape($homeError) ?></div>
    <?php endif; ?>

    <!-- ============ BANNER ĐẦU TRANG ============ -->
                <?php if ($firstSlide): ?>
                    <section class="gl-hero gl-hero--top" id="glHero" aria-label="Truyện nổi bật">
                        <div class="gl-hero-bg" id="glHeroBg"
                             style="background-image:url('<?= comic_home_escape($firstSlide['image']) ?>')"></div>

                        <span class="gl-badge">Đang thịnh hành</span>

                        <div class="gl-hero-poster">
                            <img id="glHeroPoster" src="<?= comic_home_escape($firstSlide['image']) ?>" alt="">
                        </div>

                        <div class="gl-hero-body">
                            <div class="gl-chips" id="glHeroChips">
                                <span class="gl-chip">Nổi bật</span>
                                <span class="gl-chip">★ <?= comic_home_escape($firstSlide['rating']) ?>/5</span>
                                <span class="gl-chip">Đã bán <?= comic_home_escape($firstSlide['sold']) ?></span>
                                <?php if ($firstSlide['percent'] > 0): ?>
                                    <span class="gl-chip gl-chip--sale">-<?= (int)$firstSlide['percent'] ?>%</span>
                                <?php endif; ?>
                            </div>

                            <h1 class="gl-hero-title" id="glHeroTitle"><?= comic_home_escape($firstSlide['title']) ?></h1>
                            <p class="gl-hero-desc" id="glHeroDesc">
                                <?= comic_home_escape($firstSlide['desc'] ?: 'Xem trang chi tiết để biết thêm nội dung bộ truyện này.') ?>
                            </p>
                            <div class="gl-hero-meta" id="glHeroMeta">
                                <b><?= comic_home_escape($firstSlide['price']) ?></b>
                                <?php if ($firstSlide['old'] !== ''): ?>
                                    <s><?= comic_home_escape($firstSlide['old']) ?></s>
                                <?php endif; ?>
                                <?= $firstSlide['stock'] ? 'Còn hàng' : 'Hết hàng' ?>
                            </div>

                            <div class="gl-hero-actions">
                                <a class="gl-btn gl-btn--solid" id="glHeroLink"
                                   href="<?= comic_home_escape($firstSlide['url']) ?>">▶ Xem chi tiết</a>
                                <a class="gl-btn" href="#catalog">Tất cả truyện</a>
                            </div>
                        </div>

                        <?php if (count($slides) > 1): ?>
                            <div class="gl-arrows">
                                <button class="gl-arrow" type="button" data-slide="-1" aria-label="Trước">‹</button>
                                <button class="gl-arrow" type="button" data-slide="1" aria-label="Sau">›</button>
                            </div>
                        <?php endif; ?>
                    </section>
                <?php else: ?>
                    <section class="gl-panel"><p class="gl-empty">Chưa có truyện để hiển thị.</p></section>
                <?php endif; ?>


    <script>
    try { if (localStorage.getItem('glHideHome') === '1') document.documentElement.classList.add('gl-home-hidden'); } catch (e) {}
    </script>

    <!-- ============ KHUNG CHÍNH: CỬA HÀNG TẤT CẢ TRUYỆN ============ -->
    <div class="gl-shell">

        <div class="gl-main">

            <div class="gl-stage">

                <section id="catalog" aria-label="Tất cả truyện">

                    <?php if ($catalogError !== ''): ?>
                        <div class="cp-error" role="alert">
                            <?= comic_home_escape($catalogError) ?>
                        </div>
                    <?php endif; ?>

                    <div class="cp-layout">

                        <!-- THANH BỘ LỌC -->
                        <aside class="cp-sidebar">

                            <section class="cp-side-section">
                                <h2 class="cp-side-title">Thể loại truyện</h2>

                                <div class="cp-filter-list">
                                    <?php
                                    $allCatParams = $catQuery;
                                    unset($allCatParams['category']);
                                    ?>
                                    <a
                                        class="cp-filter-link <?= $catCategory === '' ? 'active' : '' ?>"
                                        href="<?= comic_home_escape(comic_home_catalog_url($allCatParams)) ?>"
                                    >
                                        <span>Tất cả thể loại</span>
                                        <span class="cp-filter-count">
                                            <?= number_format(array_sum(array_column($catalogCategories, 'comic_count'))) ?>
                                        </span>
                                    </a>

                                    <?php foreach ($catalogCategories as $category): ?>
                                        <?php
                                        $categoryParams = $catQuery;
                                        $categoryParams['category'] = (string)$category['slug'];

                                        $isCategoryActive =
                                            $catCategory === (string)$category['slug'] ||
                                            $catCategory === (string)$category['id'];
                                        ?>
                                        <a
                                            class="cp-filter-link <?= $isCategoryActive ? 'active' : '' ?>"
                                            href="<?= comic_home_escape(comic_home_catalog_url($categoryParams)) ?>"
                                        >
                                            <span><?= comic_home_escape($category['name']) ?></span>
                                            <span class="cp-filter-count">
                                                <?= number_format((int)$category['comic_count']) ?>
                                            </span>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            </section>

                            <section class="cp-side-section">
                                <h2 class="cp-side-title">Độ tuổi</h2>

                                <div class="cp-filter-list">
                                    <?php
                                    $ageAllParams = $catQuery;
                                    unset($ageAllParams['age_rating']);
                                    ?>
                                    <a
                                        class="cp-filter-link <?= $catAge === '' ? 'active' : '' ?>"
                                        href="<?= comic_home_escape(comic_home_catalog_url($ageAllParams)) ?>"
                                    >
                                        <span>Tất cả độ tuổi</span>
                                    </a>

                                    <?php foreach ($catAgeNames as $ageValue => $ageName): ?>
                                        <?php
                                        $ageParams = $catQuery;
                                        $ageParams['age_rating'] = $ageValue;
                                        ?>
                                        <a
                                            class="cp-filter-link <?= $catAge === $ageValue ? 'active' : '' ?>"
                                            href="<?= comic_home_escape(comic_home_catalog_url($ageParams)) ?>"
                                        >
                                            <span><?= comic_home_escape($ageName) ?></span>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            </section>

                        </aside>

                        <!-- DANH SÁCH TRUYỆN -->
                        <div class="cp-main">

                            <div class="cp-toolbar">
                                <div>
                                    <h2 class="cp-result-title">
                                        <?= $catSearch !== '' ? 'Kết quả tìm kiếm' : 'Tất cả truyện' ?>
                                    </h2>

                                    <div class="cp-result-note">
                                        <?php if ($catSearch !== ''): ?>
                                            Từ khóa:
                                            <strong><?= comic_home_escape($catSearch) ?></strong>
                                            ·
                                        <?php endif; ?>

                                        <?= number_format($catalogTotal) ?> truyện phù hợp
                                    </div>
                                </div>

                                <!-- THANH TÌM KIẾM: cùng hàng với tiêu đề, nằm giữa -->
                                <div class="cp-search-center" id="catalog-search">
                                    <form class="cp-search" method="get" action="index.php#catalog" role="search">
                                        <?php foreach ($catQuery as $qKey => $qVal): ?>
                                            <?php if ($qKey === 'q') continue; ?>
                                            <input type="hidden" name="<?= comic_home_escape((string)$qKey) ?>" value="<?= comic_home_escape((string)$qVal) ?>">
                                        <?php endforeach; ?>
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
                                        <input type="search" name="q" value="<?= comic_home_escape($catSearch) ?>" placeholder="Tìm tên truyện, tác giả..." aria-label="Tìm kiếm truyện" autocomplete="off">
                                        <button type="submit">Tìm kiếm</button>
                                    </form>
                                </div>

                                <?php
                                $priceRatingActive = ($catMin !== null ? 1 : 0)
                                    + ($catMax !== null ? 1 : 0)
                                    + ($catRating > 0 ? 1 : 0)
                                    + ($catQuick === 'discount' ? 1 : 0);
                                ?>
                                <span class="cp-page-note">Trang <?= $catPage ?> / <?= $catalogPages ?></span>

                                <?php if ($firstSlide): ?>
                                <button type="button" class="cp-fpop-btn cp-hide-home" id="cp-hide-home" aria-pressed="false">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12s3.5-6 9-6 9 6 9 6-3.5 6-9 6-9-6-9-6z"/><circle cx="12" cy="12" r="2.6"/></svg>
                                    <span class="cp-hide-home-label">Ẩn trang chủ</span>
                                </button>
                                <?php endif; ?>

                                <div class="cp-fpop" id="cp-fpop">
                                    <button type="button" class="cp-fpop-btn" aria-expanded="false" aria-controls="cp-fpop-panel">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M7 12h10M10 18h4"/></svg>
                                        Lọc
                                        <?php if ($priceRatingActive > 0): ?>
                                            <span class="cp-fpop-badge"><?= $priceRatingActive ?></span>
                                        <?php endif; ?>
                                        <i class="cp-dd-arrow"></i>
                                    </button>

                                    <form class="cp-fpop-panel" id="cp-fpop-panel" method="get" action="index.php#catalog">
                                        <?php foreach ($catQuery as $key => $value): ?>
                                            <?php if (in_array($key, ['min_price', 'max_price', 'min_rating'], true)) continue; ?>
                                            <?php if ($key === 'filter' && $value === 'discount') continue; ?>
                                            <input
                                                type="hidden"
                                                name="<?= comic_home_escape($key) ?>"
                                                value="<?= comic_home_escape($value) ?>"
                                            >
                                        <?php endforeach; ?>

                                        <div class="cp-fpop-title">Khoảng giá (VNĐ)</div>
                                        <div class="cp-fpop-prices">
                                            <input
                                                type="number"
                                                name="min_price"
                                                min="0"
                                                step="1000"
                                                value="<?= $catMin !== null ? comic_home_escape($catMin) : '' ?>"
                                                placeholder="Từ"
                                                aria-label="Giá thấp nhất"
                                            >
                                            <span>–</span>
                                            <input
                                                type="number"
                                                name="max_price"
                                                min="0"
                                                step="1000"
                                                value="<?= $catMax !== null ? comic_home_escape($catMax) : '' ?>"
                                                placeholder="Đến"
                                                aria-label="Giá cao nhất"
                                            >
                                        </div>

                                        <div class="cp-fpop-title">Ưu đãi</div>
                                        <div class="cp-fpop-stars">
                                            <label class="cp-star-row">
                                                <input type="checkbox" name="filter" value="discount" <?= $catQuick === 'discount' ? 'checked' : '' ?>>
                                                <span class="cp-star-label"><b>Chỉ truyện đang giảm giá</b></span>
                                            </label>
                                        </div>

                                        <div class="cp-fpop-title">Đánh giá</div>
                                        <div class="cp-fpop-stars">
                                            <label class="cp-star-row">
                                                <input type="radio" name="min_rating" value="0" <?= $catRating === 0 ? 'checked' : '' ?>>
                                                <span class="cp-star-label">Tất cả số sao</span>
                                            </label>
                                            <?php for ($star = 5; $star >= 3; $star--): ?>
                                                <label class="cp-star-row">
                                                    <input type="radio" name="min_rating" value="<?= $star ?>" <?= $catRating === $star ? 'checked' : '' ?>>
                                                    <span class="cp-star-label">
                                                        <span class="cp-star-icons">
                                                            <?= str_repeat('★', $star) ?><em><?= str_repeat('★', 5 - $star) ?></em>
                                                        </span>
                                                        <b><?= $star === 5 ? '5 sao' : ($star === 4 ? 'Từ 4 đến 5 sao' : '4 sao trở xuống') ?></b>
                                                        <small><?= number_format($catStarCounts[$star]) ?></small>
                                                    </span>
                                                </label>
                                            <?php endfor; ?>
                                        </div>

                                        <div class="cp-fpop-actions">
                                            <?php $resetQuery = $catQuery; unset($resetQuery['min_price'], $resetQuery['max_price'], $resetQuery['min_rating']); if (($resetQuery['filter'] ?? '') === 'discount') unset($resetQuery['filter']); ?>
                                            <a class="cp-fpop-reset" href="<?= comic_home_escape(comic_home_catalog_url($resetQuery)) ?>">Xóa lọc</a>
                                            <button type="submit">Áp dụng</button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <?php
                            $activeFilterCount = 0;

                            if ($catSearch !== '') $activeFilterCount++;
                            if ($catCategory !== '') $activeFilterCount++;
                            if ($catAuthor !== '') $activeFilterCount++;
                            if ($catAge !== '') $activeFilterCount++;
                            if ($catMin !== null || $catMax !== null) $activeFilterCount++;
                            if ($catRating > 0) $activeFilterCount++;
                            if ($catQuick === 'discount') $activeFilterCount++;
                            ?>

                            <div class="cp-active-filters">
                                <?php if ($activeFilterCount > 0): ?>
                                    <?php if ($catSearch !== ''): ?>
                                        <?php $clear = $catQuery; unset($clear['q']); ?>
                                        <a class="cp-chip" href="<?= comic_home_escape(comic_home_catalog_url($clear)) ?>">
                                            Từ khóa: <?= comic_home_escape($catSearch) ?> ×
                                        </a>
                                    <?php endif; ?>

                                    <?php if ($catCategory !== ''): ?>
                                        <?php $clear = $catQuery; unset($clear['category']); ?>
                                        <a class="cp-chip" href="<?= comic_home_escape(comic_home_catalog_url($clear)) ?>">
                                            Bỏ lọc thể loại ×
                                        </a>
                                    <?php endif; ?>

                                    <?php if ($catAuthor !== ''): ?>
                                        <?php $clear = $catQuery; unset($clear['author']); ?>
                                        <a class="cp-chip" href="<?= comic_home_escape(comic_home_catalog_url($clear)) ?>">
                                            Bỏ lọc tác giả ×
                                        </a>
                                    <?php endif; ?>

                                    <?php if ($catAge !== ''): ?>
                                        <?php $clear = $catQuery; unset($clear['age_rating']); ?>
                                        <a class="cp-chip" href="<?= comic_home_escape(comic_home_catalog_url($clear)) ?>">
                                            Bỏ lọc độ tuổi ×
                                        </a>
                                    <?php endif; ?>

                                    <?php if ($catMin !== null || $catMax !== null): ?>
                                        <?php $clear = $catQuery; unset($clear['min_price'], $clear['max_price']); ?>
                                        <a class="cp-chip" href="<?= comic_home_escape(comic_home_catalog_url($clear)) ?>">
                                            Bỏ lọc giá ×
                                        </a>
                                    <?php endif; ?>

                                    <?php if ($catQuick === 'discount'): ?>
                                        <?php $clear = $catQuery; unset($clear['filter']); ?>
                                        <a class="cp-chip" href="<?= comic_home_escape(comic_home_catalog_url($clear)) ?>">
                                            Đang giảm giá ×
                                        </a>
                                    <?php endif; ?>

                                    <?php if ($catRating > 0): ?>
                                        <?php $clear = $catQuery; unset($clear['min_rating']); ?>
                                        <a class="cp-chip" href="<?= comic_home_escape(comic_home_catalog_url($clear)) ?>">
                                            <?= $catRating >= 5 ? '5 sao' : ($catRating === 4 ? 'Từ 4 đến 5 sao' : '4 sao trở xuống') ?> ×
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>

                            <div class="cp-products">

                                <?php if ($catBeyond): ?>

                                    <div class="cp-empty">
                                        <div class="cp-empty-icon">⌕</div>
                                        <h3>Không còn truyện ở trang này</h3>
                                        <p>Các trang sau cũng không có truyện. Bạn hãy quay lại trang trước để xem tiếp.</p>
                                        <a class="cp-btn" href="<?= comic_home_escape(comic_home_catalog_url(array_merge($catQuery, ['page' => $catalogPages]))) ?>">Về trang <?= (int)$catalogPages ?></a>
                                    </div>

                                <?php elseif (!$catalogComics): ?>

                                    <div class="cp-empty">
                                        <div class="cp-empty-icon">⌕</div>
                                        <h3>Không tìm thấy truyện phù hợp</h3>
                                        <p>Hãy thử thay đổi từ khóa hoặc bỏ bớt điều kiện lọc.</p>
                                        <a class="cp-btn" href="index.php#catalog">Xem tất cả truyện</a>
                                    </div>

                                <?php else: ?>

                                    <?php foreach ($catalogComics as $cc): ?>
                                        <?php
                                        $ccPrice = comic_home_prices($cc);
                                        $ccStock = (int)$cc['stock'];
                                        $ccUrl = comic_home_url($cc);
                                        ?>

                                        <article class="cp-card">

                                            <a class="cp-cover" href="<?= comic_home_escape($ccUrl) ?>">
                                                <img
                                                    src="<?= comic_home_escape(comic_home_cover($cc)) ?>"
                                                    alt="<?= comic_home_escape($cc['title']) ?>"
                                                    loading="lazy"
                                                >

                                                <div class="cp-badges">
                                                    <?php if ($ccPrice['hasSale']): ?>
                                                        <span class="cp-badge">-<?= $ccPrice['percent'] ?>%</span>
                                                    <?php endif; ?>

                                                    <?php if ((int)$cc['is_new'] === 1): ?>
                                                        <span class="cp-badge dark">MỚI</span>
                                                    <?php endif; ?>

                                                    <?php if ($ccStock <= 0): ?>
                                                        <span class="cp-badge gray">HẾT HÀNG</span>
                                                    <?php endif; ?>
                                                </div>
                                            </a>

                                            <div class="cp-card-body">

                                                <a
                                                    class="cp-card-category"
                                                    href="<?= comic_home_escape(comic_home_catalog_url(['category' => (string)$cc['category_slug']])) ?>"
                                                >
                                                    <?= comic_home_escape($cc['category_name']) ?>
                                                </a>

                                                <a class="cp-card-title" href="<?= comic_home_escape($ccUrl) ?>">
                                                    <?= comic_home_escape($cc['title']) ?>
                                                </a>

                                                <div class="cp-card-rating">
                                                    <span class="star">★</span>
                                                    <span><?= number_format((float)$cc['rating_avg'], 1) ?></span>
                                                    <span class="count">(<?= number_format((int)$cc['review_count']) ?>)</span>
                                                </div>

                                                <div class="cp-card-price">
                                                    <strong><?= comic_home_money($ccPrice['current']) ?></strong>

                                                    <?php if ($ccPrice['hasSale']): ?>
                                                        <del><?= comic_home_money($ccPrice['regular']) ?></del>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="cp-card-bottom">
                                                    <span class="cp-stock <?= $ccStock > 0 ? '' : 'out' ?>">
                                                        <?= $ccStock > 0 ? 'Còn hàng' : 'Hết hàng' ?>
                                                    </span>

                                                    <a
                                                        class="cp-view"
                                                        href="<?= comic_home_escape($ccUrl) ?>"
                                                        aria-label="Xem chi tiết <?= comic_home_escape($cc['title']) ?>"
                                                        title="Xem chi tiết"
                                                    >→</a>
                                                </div>
                                            </div>
                                        </article>

                                    <?php endforeach; ?>

                                <?php endif; ?>

                            </div>

                            <?php if (true): ?>
                                <nav class="cp-pagination" aria-label="Phân trang truyện">

                                    <?php if ($catPage > 1): ?>
                                        <a
                                            class="cp-page"
                                            href="<?= comic_home_escape(comic_home_catalog_url(array_merge($catQuery, ['page' => $catBeyond ? $catalogPages : $catPage - 1]))) ?>"
                                            aria-label="Trang trước"
                                        >‹</a>
                                    <?php else: ?>
                                        <span class="cp-page disabled" aria-disabled="true">‹</span>
                                    <?php endif; ?>

                                    <?php
                                    $startPage = max(1, $catPage - 2);
                                    $endPage = max(min($catalogPages, $catPage + 2), $catPage);

                                    for ($pageNumber = $startPage; $pageNumber <= $endPage; $pageNumber++):
                                    ?>
                                        <?php if ($pageNumber === $catPage): ?>
                                            <span class="cp-page current" aria-current="page"><?= $pageNumber ?></span>
                                        <?php else: ?>
                                            <a
                                                class="cp-page"
                                                href="<?= comic_home_escape(comic_home_catalog_url(array_merge($catQuery, ['page' => $pageNumber]))) ?>"
                                            ><?= $pageNumber ?></a>
                                        <?php endif; ?>
                                    <?php endfor; ?>

                                    <?php if (!$catBeyond && $catalogTotal > 0): ?>
                                        <a
                                            class="cp-page"
                                            href="<?= comic_home_escape(comic_home_catalog_url(array_merge($catQuery, ['page' => $catPage + 1]))) ?>"
                                            aria-label="Trang tiếp"
                                        >›</a>
                                    <?php else: ?>
                                        <span class="cp-page disabled" aria-disabled="true">›</span>
                                    <?php endif; ?>

                                </nav>
                            <?php endif; ?>

                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>

    <!-- ============ TRUYỆN MỚI ============ -->
    <section class="gl-block" id="home-new">
        <div class="gl-sec-head">
            <h2>Truyện mới</h2>
            <a class="gl-more" href="<?= comic_home_escape(comic_home_catalog_url(['filter' => 'new'])) ?>">Xem tất cả</a>
        </div>

        <?php if (!$newComics): ?>
            <p class="gl-empty">Chưa có truyện để hiển thị.</p>
        <?php else: ?>
            <div class="gl-grid">
                <?php foreach ($newComics as $comic): ?>
                    <?php comic_home_render_card($comic); ?>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- ============ ƯU ĐÃI ============ -->
    <section class="gl-block" id="home-discounts">
        <div class="gl-promo<?= $promoImage !== '' ? ' has-image' : '' ?>"
             <?php if ($promoImage !== ''): ?>
                 style="--promo-image:url('<?= comic_home_escape($promoImage) ?>')"
             <?php endif; ?>>
            <div>
                <h2>Mỗi trang truyện, một chuyến phiêu lưu mới</h2>
                <p>Chọn ngay bộ truyện yêu thích với mức giá ưu đãi, để tủ sách của bạn luôn đầy ắp câu chuyện hay.</p>
            </div>
            <?php if ($maxDiscount > 0): ?>
                <div class="gl-promo-big" aria-label="Giảm đến <?= $maxDiscount ?> phần trăm">-<?= $maxDiscount ?>%</div>
            <?php endif; ?>
        </div>

        <?php if ($discountComics): ?>
            <div class="gl-sec-head" style="margin-top:26px">
                <h2>Đang giảm giá</h2>
                <a class="gl-more" href="<?= comic_home_escape(comic_home_catalog_url(['filter' => 'discount'])) ?>">Xem tất cả</a>
            </div>
            <div class="gl-grid">
                <?php foreach ($discountComics as $comic): ?>
                    <?php comic_home_render_card($comic); ?>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- ============ LỢI ÍCH ============ -->
    <section class="gl-block" aria-label="Dịch vụ của cửa hàng">
        <div class="gl-benefits">
            <div class="gl-benefit">
                <span class="gl-benefit-ico" aria-hidden="true">⇢</span>
                <div><strong>Giao hàng tận nơi</strong><span>Đặt online, nhận tại nhà</span></div>
            </div>
            <div class="gl-benefit">
                <span class="gl-benefit-ico" aria-hidden="true">▣</span>
                <div><strong>Đóng gói cẩn thận</strong><span>Bảo vệ bìa và gáy truyện</span></div>
            </div>
            <div class="gl-benefit">
                <span class="gl-benefit-ico" aria-hidden="true">✓</span>
                <div><strong>Thanh toán an toàn</strong><span>Thông tin đơn hàng rõ ràng</span></div>
            </div>
            <div class="gl-benefit">
                <span class="gl-benefit-ico" aria-hidden="true">☺</span>
                <div><strong>Hỗ trợ khách hàng</strong><span>Gửi tin nhắn ở trang Liên hệ</span></div>
            </div>
        </div>
    </section>
</div>

<script>
(function () {
    var slides = <?= json_encode($slides, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    var hero = document.getElementById('glHero');

    if (!hero || slides.length < 2) return;

    var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var index = 0;
    var timer = null;

    function esc(s) {
        var d = document.createElement('div');
        d.textContent = s == null ? '' : String(s);
        return d.innerHTML;
    }

    function render(s) {
        document.getElementById('glHeroBg').style.backgroundImage = 'url("' + s.image.replace(/"/g, '%22') + '")';
        document.getElementById('glHeroPoster').src = s.image;
        document.getElementById('glHeroTitle').textContent = s.title;
        document.getElementById('glHeroDesc').textContent = s.desc || 'Xem trang chi tiết để biết thêm nội dung bộ truyện này.';
        document.getElementById('glHeroLink').href = s.url;

        document.getElementById('glHeroChips').innerHTML =
            '<span class="gl-chip">Nổi bật</span>' +
            '<span class="gl-chip">★ ' + esc(s.rating) + '/5</span>' +
            '<span class="gl-chip">Đã bán ' + esc(s.sold) + '</span>' +
            (s.percent > 0 ? '<span class="gl-chip gl-chip--sale">-' + esc(s.percent) + '%</span>' : '');

        document.getElementById('glHeroMeta').innerHTML =
            '<b>' + esc(s.price) + '</b>' +
            (s.old ? '<s>' + esc(s.old) + '</s>' : '') +
            (s.stock ? 'Còn hàng' : 'Hết hàng');
    }

    function go(step) {
        index = (index + step + slides.length) % slides.length;

        if (reduce) {
            render(slides[index]);
            return;
        }

        hero.classList.add('is-swap');
        setTimeout(function () {
            render(slides[index]);
            hero.classList.remove('is-swap');
        }, 220);
    }

    function start() {
        if (reduce) return;
        stop();
        timer = setInterval(function () { go(1); }, 7000);
    }

    function stop() {
        if (timer) { clearInterval(timer); timer = null; }
    }

    hero.querySelectorAll('[data-slide]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            go(Number(btn.dataset.slide));
            start();
        });
    });

    hero.addEventListener('mouseenter', stop);
    hero.addEventListener('mouseleave', start);
    start();
})();

/* Dropdown tùy chỉnh cho các ô chọn trong bộ lọc */
(function () {
  var selects = document.querySelectorAll('.gl-page select.cp-sort');
  var all = [];

  function closeAll(except) {
    all.forEach(function (d) { if (d !== except) d.classList.remove('open'); });
  }

  selects.forEach(function (sel) {
    var wrap = document.createElement('div');
    wrap.className = 'cp-dd';
    sel.parentNode.insertBefore(wrap, sel);
    wrap.appendChild(sel);
    sel.tabIndex = -1;

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'cp-dd-btn';
    btn.setAttribute('aria-haspopup', 'listbox');
    var label = document.createElement('span');
    var arrow = document.createElement('i');
    arrow.className = 'cp-dd-arrow';
    btn.appendChild(label);
    btn.appendChild(arrow);

    var menu = document.createElement('ul');
    menu.className = 'cp-dd-menu';
    menu.setAttribute('role', 'listbox');

    function stars(n) {
      return n > 0 ? '<span class="cp-dd-star">' + '★'.repeat(n) + '</span> ' : '';
    }

    function render() {
      menu.innerHTML = '';
      Array.prototype.forEach.call(sel.options, function (opt, i) {
        var li = document.createElement('li');
        li.className = 'cp-dd-item' + (opt.selected ? ' selected' : '');
        li.setAttribute('role', 'option');
        li.dataset.index = i;
        var n = sel.name === 'min_rating' ? parseInt(opt.value, 10) : 0;
        var span = document.createElement('span');
        span.innerHTML = stars(n);
        span.appendChild(document.createTextNode(n > 0 ? opt.text.replace(/^\d+ /, '') : opt.text));
        li.appendChild(span);
        menu.appendChild(li);
      });
      label.textContent = sel.options[sel.selectedIndex].text;
    }

    function choose(i) {
      sel.selectedIndex = i;
      render();
      wrap.classList.remove('open');
      sel.dispatchEvent(new Event('change', { bubbles: true }));
    }

    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      closeAll(wrap);
      wrap.classList.toggle('open');
    });
    menu.addEventListener('click', function (e) {
      var li = e.target.closest('.cp-dd-item');
      if (li) choose(parseInt(li.dataset.index, 10));
    });
    btn.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') wrap.classList.remove('open');
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        var next = sel.selectedIndex + (e.key === 'ArrowDown' ? 1 : -1);
        if (next >= 0 && next < sel.options.length) { sel.selectedIndex = next; render(); }
      }
      if (e.key === 'Enter' || e.key === ' ') {
        if (wrap.classList.contains('open')) {
          e.preventDefault();
          choose(sel.selectedIndex);
        }
      }
    });

    wrap.appendChild(btn);
    wrap.appendChild(menu);
    all.push(wrap);
    render();
  });

  document.addEventListener('click', function () { closeAll(null); });
})();

/* Nút Ẩn/Hiện trang chủ (banner đầu trang) */
(function () {
  var b = document.getElementById('cp-hide-home');
  if (!b) return;
  var root = document.documentElement;
  var label = b.querySelector('.cp-hide-home-label');
  /* Đo chiều cao thanh menu dính trên cùng để không che nội dung truyện */
  function setHeadH() {
    var bar = document.querySelector('.scrn-topbar');
    var h = bar ? bar.offsetHeight : 70;
    root.style.setProperty('--gl-head-h', h + 'px');
  }
  setHeadH();
  window.addEventListener('resize', setHeadH);
  function sync() {
    var hidden = root.classList.contains('gl-home-hidden');
    label.textContent = hidden ? 'Hiện trang chủ' : 'Ẩn trang chủ';
    b.setAttribute('aria-pressed', hidden ? 'true' : 'false');
  }
  sync();
  b.addEventListener('click', function () {
    var hidden = root.classList.toggle('gl-home-hidden');
    try { localStorage.setItem('glHideHome', hidden ? '1' : '0'); } catch (e) {}
    sync();
    if (hidden) {
      setHeadH();
      var c = document.getElementById('catalog');
      if (c) c.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  });
})();

/* Nút Lọc: xổ bảng giá + sao */
(function () {
  var pop = document.getElementById('cp-fpop');
  if (!pop) return;
  var btn = pop.querySelector('.cp-fpop-btn');
  btn.addEventListener('click', function (e) {
    e.stopPropagation();
    var open = pop.classList.toggle('open');
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  pop.addEventListener('click', function (e) { e.stopPropagation(); });
  document.addEventListener('click', function () {
    pop.classList.remove('open');
    btn.setAttribute('aria-expanded', 'false');
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { pop.classList.remove('open'); btn.setAttribute('aria-expanded', 'false'); }
  });
})();

/* Menu trái cao bằng hàng truyện đầu tiên + chuyển trang không tải lại trang */
(function () {
  if (!document.querySelector('.gl-page .cp-products')) return;

  function getGrid() { return document.querySelector('.gl-page .cp-products'); }

  /* Menu trái luôn có chiều cao tự nhiên theo nội dung (không còn ép theo hàng truyện đầu tiên,
     vì hàng đó đổi chiều cao khi hover / ít truyện / không có truyện làm menu lúc dài lúc ngắn) */
  function fitSide() {
    var side = document.querySelector('.gl-page .cp-sidebar');
    if (!side) return;
    side.style.height = '';
    side.classList.remove('is-capped', 'is-tight', 'is-tighter');
  }

  var rowHeight = 0; /* chiều cao 1 thẻ truyện, nhớ lại để dùng khi trang không có truyện */

  /* Luôn chừa chỗ cho đủ 2 hàng, hàng nào không có truyện thì để trống */
  function reserveTwoRows(grid, cards) {
    grid.style.minHeight = '';
    var gap = parseFloat(getComputedStyle(grid).rowGap) || 0;
    var h = 0;

    if (cards.length) {
      var top = cards[0].getBoundingClientRect().top;
      for (var i = 0; i < cards.length; i++) {
        if (Math.abs(cards[i].getBoundingClientRect().top - top) > 4) return; /* đã có từ 2 hàng */
        h = Math.max(h, cards[i].getBoundingClientRect().height);
      }
      rowHeight = h;
    } else {
      var cols = window.innerWidth <= 640 ? 2 : (window.innerWidth <= 1100 ? 3 : 4);
      h = rowHeight || ((grid.clientWidth - gap * (cols - 1)) / cols + 150);
    }

    if (h > 0) grid.style.minHeight = Math.round(h * 2 + gap) + 'px';
  }

  function fit() {
    var grid = getGrid();
    if (!grid) return;
    grid.style.minHeight = '';
    var cards = grid.querySelectorAll('.cp-card');
    reserveTwoRows(grid, cards);
    fitSide(cards);
  }

  function watchImages() {
    var grid = getGrid();
    if (!grid) return;
    grid.querySelectorAll('img').forEach(function (img) {
      if (!img.complete) img.addEventListener('load', fit);
    });
  }

  fit();
  watchImages();
  window.addEventListener('load', fit);
  window.addEventListener('resize', fit);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);

  /* ---------- Chuyển trang bằng AJAX ---------- */
  var swapSelectors = ['.cp-products', '.cp-pagination', '.cp-page-note', '.cp-result-title', '.cp-result-note', '.cp-sidebar'];
  var loading = false;

  function swapFrom(html) {
    var doc = new DOMParser().parseFromString(html, 'text/html');
    var ok = false;
    swapSelectors.forEach(function (sel) {
      var cur = document.querySelector('.gl-page ' + sel);
      var next = doc.querySelector('.gl-page ' + sel);
      if (cur && next) { cur.replaceWith(next); ok = true; }
    });

    /* Thẻ lọc đang áp dụng: có thể thêm / bớt khi đổi từ khóa */
    var curChips = document.querySelector('.gl-page .cp-active-filters');
    var nextChips = doc.querySelector('.gl-page .cp-active-filters');
    if (curChips && nextChips) curChips.innerHTML = nextChips.innerHTML;
    else if (curChips) curChips.remove();
    else if (nextChips && getGrid()) getGrid().parentNode.insertBefore(nextChips, getGrid());

    /* Huy hiệu số bộ lọc trên nút "Lọc" (hiện / ẩn / đổi số) */
    var curBtn = document.querySelector('.gl-page #cp-fpop .cp-fpop-btn[aria-controls]');
    var nextBtn = doc.querySelector('.gl-page #cp-fpop .cp-fpop-btn[aria-controls]');
    if (curBtn && nextBtn) {
      var curBadge = curBtn.querySelector('.cp-fpop-badge');
      var nextBadge = nextBtn.querySelector('.cp-fpop-badge');
      if (curBadge && nextBadge) curBadge.textContent = nextBadge.textContent;
      else if (curBadge) curBadge.remove();
      else if (nextBadge) curBtn.insertBefore(nextBadge, curBtn.querySelector('.cp-dd-arrow'));
    }

    /* Ô ẩn của bộ lọc giá/sao phải mang từ khóa mới */
    var curPanel = document.getElementById('cp-fpop-panel');
    var nextPanel = doc.getElementById('cp-fpop-panel');
    if (curPanel && nextPanel) {
      curPanel.innerHTML = nextPanel.innerHTML;
    }
    return ok;
  }

  function syncSearchInput() {
    var input = document.querySelector('.gl-page form.cp-search input[name="q"]');
    if (!input) return;
    var q = new URLSearchParams(window.location.search).get('q') || '';
    if (input.value !== q) input.value = q;
  }

  function stripHash(u) { return String(u).split('#')[0]; }

  function loadPage(url, push) {
    if (loading) return;
    loading = true;
    var grid = getGrid();
    if (grid) grid.style.opacity = '.45';

    /* Nhớ vị trí cuộn: thay nội dung xong thì trả lại đúng chỗ, trang không bị nhảy */
    var keepX = window.pageXOffset;
    var keepY = window.pageYOffset;

    fetch(url, { credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch' } })
      .then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.text();
      })
      .then(function (html) {
        var sameUrl = stripHash(url) === stripHash(window.location.pathname + window.location.search);
        if (!swapFrom(html)) throw new Error('Không đọc được trang');
        if (push && !sameUrl) history.pushState({ glCatalog: true }, '', url);
        fit();
        watchImages();
        window.scrollTo(keepX, keepY);
      })
      .catch(function () {
        window.location.href = url; /* lỗi mạng -> tải trang như bình thường */
      })
      .then(function () {
        loading = false;
        var g = getGrid();
        if (g) g.style.opacity = '';
      });
  }

  /* Nút "Xóa lọc": chạy trước mọi script khác (capture) để không script nào cuộn trang tới #catalog */
  document.addEventListener('click', function (e) {
    var a = e.target.closest ? e.target.closest('.gl-page .cp-fpop-reset') : null;
    if (!a || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    e.preventDefault();
    e.stopPropagation();

    var keepX = window.pageXOffset, keepY = window.pageYOffset;

    /* Xóa luôn những gì đã nhập trong bảng nhưng chưa bấm "Áp dụng" */
    var panel = document.getElementById('cp-fpop-panel');
    if (panel) {
      panel.querySelectorAll('input[type="number"]').forEach(function (i) { i.value = ''; });
      panel.querySelectorAll('input[type="checkbox"]').forEach(function (i) { i.checked = false; });
      var all = panel.querySelector('input[name="min_rating"][value="0"]');
      if (all) all.checked = true;
    }

    var pop = document.getElementById('cp-fpop');
    if (pop) {
      pop.classList.remove('open');
      var pb = pop.querySelector('.cp-fpop-btn[aria-controls]');
      if (pb) { pb.setAttribute('aria-expanded', 'false'); }
    }

    /* Chỉ tải lại danh sách khi địa chỉ thật sự đổi (đang có lọc giá / sao / giảm giá) */
    if (a.search !== window.location.search) {
      loadPage(a.pathname + a.search + '#catalog', true);
    }

    /* Giữ nguyên vị trí cuộn */
    window.scrollTo(keepX, keepY);
    requestAnimationFrame(function () { window.scrollTo(keepX, keepY); });
  }, true);

  document.addEventListener('click', function (e) {
    var a = e.target.closest ? e.target.closest('.gl-page .cp-sidebar a, .gl-page .cp-main a') : null;
    if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    if (a.target && a.target !== '_self') return;
    var href = a.getAttribute('href');
    if (!href || href.charAt(0) === '#') return;
    function normPath(x) { return x.replace(/index\.php$/, ''); }
    if (normPath(a.pathname) !== normPath(window.location.pathname)) return; /* link sang trang khác (chi tiết truyện...) */
    e.preventDefault();
    var pop = document.getElementById('cp-fpop');
    if (pop) {
      pop.classList.remove('open');
      var pb = pop.querySelector('.cp-fpop-btn[aria-controls]');
      if (pb) pb.setAttribute('aria-expanded', 'false');
    }
    loadPage(a.pathname + a.search + '#catalog', true);
  });

  /* Tìm kiếm không tải lại trang */
  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form || !form.matches || !form.matches('.gl-page form.cp-search, .gl-page #cp-fpop-panel')) return;
    e.preventDefault();
    var params = new URLSearchParams();
    new FormData(form).forEach(function (v, k) {
      v = String(v).trim();
      if (v === '' || k === 'page') return;
      if (k === 'min_rating' && v === '0') return;
      if (k === 'filter') params.set(k, v); else params.append(k, v);
    });
    var pop = document.getElementById('cp-fpop');
    if (pop) {
      pop.classList.remove('open');
      var pb = pop.querySelector('.cp-fpop-btn');
      if (pb) pb.setAttribute('aria-expanded', 'false');
    }
    var qs = params.toString();
    var url = window.location.pathname + (qs ? '?' + qs : '') + '#catalog';
    var input = form.querySelector('input[name="q"]');
    if (input) input.blur();
    loadPage(url, true);
  });

  window.addEventListener('popstate', function () {
    loadPage(window.location.href, false);
    syncSearchInput();
  });

  var g0 = getGrid();
  if (g0) g0.style.transition = 'opacity .15s';
})();
</script>

<?php
if ($hasFooter) {
    require_once $footerFile;
} else {
    echo '</body></html>';
}
?>
