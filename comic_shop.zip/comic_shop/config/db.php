<?php

declare(strict_types=1);

/**
 * Comic Shop - Kết nối database (PDO + MySQL)
 *
 * Cách dùng ở các file khác:
 *     require_once __DIR__ . '/config/db.php';   // có sẵn biến $pdo
 *     $stmt = $pdo->prepare('SELECT * FROM comics WHERE id = :id');
 *     $stmt->execute([':id' => 1]);
 *     $comic = $stmt->fetch();
 */

$dbHost    = '127.0.0.1';
$dbPort    = 3306;          // XAMPP mặc định 3306; MAMP có thể là 8889
$dbName    = 'comic_shop';
$dbUser    = 'root';
$dbPass    = '';            // XAMPP mặc định rỗng; MAMP thường là 'root'
$dbCharset = 'utf8mb4';

$dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset={$dbCharset}";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,   // lỗi SQL ném exception
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,         // fetch() trả về mảng kết hợp
    PDO::ATTR_EMULATE_PREPARES   => false,                    // dùng prepared statement thật
    PDO::ATTR_PERSISTENT         => false,
];

try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, $options);
} catch (PDOException $e) {
    // Ghi lỗi chi tiết vào log, không in ra màn hình (tránh lộ thông tin).
    error_log('Comic Shop database connection error: ' . $e->getMessage());

    http_response_code(500);

    exit('Không thể kết nối đến cơ sở dữ liệu. Vui lòng kiểm tra cấu hình trong config/db.php.');
}
