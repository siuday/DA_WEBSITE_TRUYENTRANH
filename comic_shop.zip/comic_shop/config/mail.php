<?php

/**
 * Cấu hình gửi email (Gmail SMTP) cho chức năng "Quên mật khẩu".
 *
 * Lấy mật khẩu ứng dụng: bật xác minh 2 bước tại
 * https://myaccount.google.com/security rồi tạo mã tại
 * https://myaccount.google.com/apppasswords (mã 16 ký tự).
 *
 * Không dùng mật khẩu Gmail thường và không đưa file này lên GitHub
 * khi đã điền mật khẩu thật.
 */

return [
    'host'       => 'smtp.gmail.com',
    'port'       => 587,
    'secure'     => 'tls',               // 'tls' (cổng 587) hoặc 'ssl' (cổng 465)

    'username'   => '',                  // Gmail dùng để gửi
    'password'   => '',                  // Mật khẩu ứng dụng 16 ký tự

    'from_email' => '',                  // thường trùng username
    'from_name'  => 'Comic Shop',

    'otp_minutes' => 10,                 // thời hạn mã OTP
    'debug'       => true,               // hiện lý do lỗi khi gửi thất bại (tắt khi nộp)
];
