<?php
/*
 * COMIC SHOP
 * File: contact.php
 * Trang liên hệ khách hàng.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. KẾT NỐI DATABASE
========================================================= */

$dbConfigFile = __DIR__ . '/config/db.php';
$dbConfigReturn = null;

if (is_file($dbConfigFile)) {
    $dbConfigReturn = require_once $dbConfigFile;
}

$contactDb = null;

$contactCandidates = [
    $dbConfigReturn,
    $GLOBALS['comic_shop_db'] ?? null,
    $GLOBALS['pdo'] ?? null,
    $GLOBALS['conn'] ?? null,
    $GLOBALS['mysqli'] ?? null,
    $GLOBALS['db'] ?? null,
    $pdo ?? null,
    $conn ?? null,
    $mysqli ?? null,
    $db ?? null,
];

foreach ($contactCandidates as $candidate) {
    if (
        $candidate instanceof PDO ||
        (class_exists('mysqli') && $candidate instanceof mysqli)
    ) {
        $contactDb = $candidate;
        break;
    }
}

$contactDbReady = $contactDb instanceof PDO ||
    (class_exists('mysqli') && $contactDb instanceof mysqli);

/* =========================================================
   2. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_contact_escape')) {
    function comic_contact_escape($value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_contact_insert')) {
    function comic_contact_insert(
        $database,
        string $fullName,
        string $email,
        ?string $subject,
        string $message
    ): void {
        $sql = 'INSERT INTO contact_messages
                    (full_name, email, subject, message)
                VALUES (?, ?, ?, ?)';

        if ($database instanceof PDO) {
            $statement = $database->prepare($sql);
            $statement->execute([
                $fullName,
                $email,
                $subject,
                $message,
            ]);

            $statement->closeCursor();
            return;
        }

        if (
            class_exists('mysqli') &&
            $database instanceof mysqli
        ) {
            $statement = $database->prepare($sql);

            if (!$statement) {
                throw new RuntimeException(
                    'Không thể chuẩn bị truy vấn gửi liên hệ.'
                );
            }

            $statement->bind_param(
                'ssss',
                $fullName,
                $email,
                $subject,
                $message
            );

            if (!$statement->execute()) {
                $error = $statement->error;
                $statement->close();

                throw new RuntimeException(
                    $error ?: 'Không thể lưu tin nhắn.'
                );
            }

            $statement->close();
            return;
        }

        throw new RuntimeException(
            'Không tìm thấy kết nối database hợp lệ.'
        );
    }
}

/* =========================================================
   3. CSRF VÀ THÔNG BÁO
========================================================= */

if (
    empty($_SESSION['comic_contact_csrf']) ||
    !is_string($_SESSION['comic_contact_csrf'])
) {
    $_SESSION['comic_contact_csrf'] = bin2hex(random_bytes(32));
}

$contactCsrf = $_SESSION['comic_contact_csrf'];

$contactFlash = $_SESSION['comic_contact_flash'] ?? null;
unset($_SESSION['comic_contact_flash']);

$contactErrors = [];

$formData = [
    'full_name' => '',
    'email' => '',
    'subject' => '',
    'message' => '',
];

/* Điền sẵn thông tin nếu phiên đăng nhập có lưu hồ sơ. */
$sessionUser = $_SESSION['user'] ?? [];

if (is_array($sessionUser)) {
    $formData['full_name'] = (string)(
        $sessionUser['full_name'] ??
        $sessionUser['name'] ??
        ''
    );

    $formData['email'] = (string)(
        $sessionUser['email'] ?? ''
    );
}

/* =========================================================
   4. XỬ LÝ GỬI TIN NHẮN
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $formData = [
        'full_name' => trim((string)(
            $_POST['full_name'] ?? ''
        )),
        'email' => trim((string)(
            $_POST['email'] ?? ''
        )),
        'subject' => trim((string)(
            $_POST['subject'] ?? ''
        )),
        'message' => trim((string)(
            $_POST['message'] ?? ''
        )),
    ];

    $postedToken = isset($_POST['csrf_token']) &&
        is_string($_POST['csrf_token'])
        ? $_POST['csrf_token']
        : '';

    if (
        !hash_equals($contactCsrf, $postedToken)
    ) {
        $contactErrors[] =
            'Phiên làm việc đã hết hạn. Hãy tải lại trang và gửi lại biểu mẫu.';
    }

    $fullName = $formData['full_name'];
    $email = $formData['email'];
    $subject = $formData['subject'];
    $message = $formData['message'];

    $nameLength = function_exists('mb_strlen')
        ? mb_strlen($fullName, 'UTF-8')
        : strlen($fullName);

    $subjectLength = function_exists('mb_strlen')
        ? mb_strlen($subject, 'UTF-8')
        : strlen($subject);

    $messageLength = function_exists('mb_strlen')
        ? mb_strlen($message, 'UTF-8')
        : strlen($message);

    if ($fullName === '' || $nameLength > 120) {
        $contactErrors[] =
            'Họ và tên là bắt buộc, tối đa 120 ký tự.';
    }

    if (
        $email === '' ||
        strlen($email) > 150 ||
        !filter_var($email, FILTER_VALIDATE_EMAIL)
    ) {
        $contactErrors[] =
            'Vui lòng nhập địa chỉ email hợp lệ.';
    }

    if ($subjectLength > 200) {
        $contactErrors[] =
            'Tiêu đề không được vượt quá 200 ký tự.';
    }

    if ($message === '' || $messageLength > 10000) {
        $contactErrors[] =
            'Nội dung bắt buộc nhập và tối đa 10.000 ký tự.';
    }

    if (!$contactDbReady) {
        $contactErrors[] =
            'Chưa kết nối được database. Hãy kiểm tra config/db.php.';
    }

    if (!$contactErrors) {
        try {
            comic_contact_insert(
                $contactDb,
                $fullName,
                $email,
                $subject !== '' ? $subject : null,
                $message
            );

            $_SESSION['comic_contact_flash'] = [
                'type' => 'success',
                'message' =>
                    'Cảm ơn bạn đã liên hệ! Tin nhắn đã được gửi đến cửa hàng.',
            ];

            $_SESSION['comic_contact_csrf'] =
                bin2hex(random_bytes(32));

            header('Location: contact.php?sent=1', true, 303);
            exit;

        } catch (Throwable $exception) {
            error_log(
                '[Comic Shop Contact] ' . $exception->getMessage()
            );

            $contactErrors[] =
                'Không gửi được tin nhắn. Vui lòng thử lại sau.';
        }
    }
}

/* =========================================================
   5. THÔNG TIN TRANG
========================================================= */

$pageTitle = 'Liên hệ | Comic Shop';

$pageDescription =
    'Liên hệ Comic Shop để được hỗ trợ về truyện tranh, đơn hàng và dịch vụ.';

$activeMenu = 'contact';

/* Trang liên hệ không hiện icon tìm kiếm trên thanh header */
$hideHeaderSearch = true;

$headerFile = __DIR__ . '/includes/header.php';
$footerFile = __DIR__ . '/includes/footer.php';

if (is_file($headerFile)) {
    require_once $headerFile;
} else {
    ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= comic_contact_escape($pageTitle) ?></title>
        <meta
            name="description"
            content="<?= comic_contact_escape($pageDescription) ?>"
        >
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
    <?php
}
?>

<style>
/* Giao diện trang liên hệ: cùng bảng màu đen nhạt, thẻ kính, viền xám và nút bo tròn như trang chủ */
body:has(.contact-page),
.scrn-page-wrapper:has(.contact-page){
    background-color:#1c1c1f;
}
.contact-page{
    --bg:#1c1c1f;
    --glass:#232327;
    --glass-2:#2c2c31;
    --glass-3:#36363c;
    --stroke:#3d3d44;
    --line:rgba(255,255,255,.38);
    --text:#f2f2f2;
    --muted:#a9a9b2;
    --radius-xl:30px;
    --radius-lg:24px;
    --radius-md:18px;
    width:100%;
    padding:24px 24px 40px;
    background:var(--bg);
    color:var(--text);
}
.contact-page *{box-sizing:border-box}
.contact-page a{color:inherit;text-decoration:none}
.contact-page .ct-wrap{
    width:100%;
    max-width:1400px;
    margin:0 auto;
}
.contact-page .ct-hero{
    position:relative;
    overflow:hidden;
    max-width:1400px;
    margin:0 auto;
    padding:44px 40px;
    border:1px solid var(--stroke);
    border-radius:var(--radius-xl);
    background:
        radial-gradient(ellipse at 90% 0%,rgba(255,255,255,.07),transparent 45%),
        var(--glass);
    color:var(--text);
}
.contact-page .ct-hero .ct-wrap{padding:0}
.contact-page .ct-hero + .ct-wrap{padding-top:24px}
.contact-page .ct-eyebrow{
    color:var(--muted);
    font-size:10px;
    font-weight:800;
    letter-spacing:2.4px;
    text-transform:uppercase;
}
.contact-page .ct-hero h1{
    display:flex;
    align-items:center;
    gap:12px;
    margin:12px 0;
    font-size:clamp(26px,4vw,40px);
    font-weight:800;
    letter-spacing:-.8px;
}
.contact-page .ct-hero h1::before{
    content:"";
    flex:none;
    width:5px;
    height:.9em;
    border-radius:4px;
    background:var(--text);
}
.contact-page .ct-hero p{
    max-width:620px;
    margin:0;
    color:var(--muted);
    font-size:13px;
    line-height:1.9;
}
.contact-page .ct-alert{
    margin-bottom:17px;
    padding:13px 18px;
    border:1px solid var(--stroke);
    border-left:4px solid var(--text);
    border-radius:var(--radius-md);
    background:var(--glass);
    color:var(--text);
    font-size:12px;
    line-height:1.8;
}
.contact-page .ct-alert.success{
    border-left-color:#7ddc9a;
    background:var(--glass);
    color:var(--text);
}
.contact-page .ct-layout{
    display:grid;
    grid-template-columns:minmax(0,1fr) 320px;
    gap:22px;
    align-items:start;
    padding-top:0;
}
.contact-page .ct-panel{
    overflow:hidden;
    border:1px solid var(--stroke);
    border-radius:var(--radius-lg);
    background:var(--glass);
    box-shadow:none;
}
.contact-page .ct-panel-head{
    padding:22px 26px;
    border-bottom:1px solid var(--stroke);
}
.contact-page .ct-panel-head h2{
    display:flex;
    align-items:center;
    gap:10px;
    margin:0;
    font-size:18px;
    font-weight:800;
    letter-spacing:-.2px;
}
.contact-page .ct-panel-head h2::before{
    content:"";
    width:4px;
    height:16px;
    border-radius:4px;
    background:var(--text);
}
.contact-page .ct-panel-head p{
    margin:8px 0 0;
    color:var(--muted);
    font-size:11px;
    line-height:1.8;
}
.contact-page .ct-panel-body{padding:26px}
.contact-page .ct-grid{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:18px;
}
.contact-page .ct-field{min-width:0}
.contact-page .ct-field.full{grid-column:1/-1}
.contact-page .ct-field label{
    display:block;
    margin-bottom:8px;
    color:var(--text);
    font-size:12px;
    font-weight:700;
}
.contact-page .ct-field input,
.contact-page .ct-field textarea{
    box-sizing:border-box;
    width:100%;
    min-height:46px;
    padding:11px 18px;
    border:1px solid var(--stroke);
    border-radius:999px;
    outline:none;
    background:var(--bg);
    color:var(--text);
    font:inherit;
    font-size:12px;
    transition:border-color .15s,box-shadow .15s;
}
.contact-page .ct-field textarea{
    min-height:165px;
    padding:14px 18px;
    border-radius:var(--radius-md);
    resize:vertical;
    line-height:1.8;
}
.contact-page .ct-field input:focus,
.contact-page .ct-field textarea:focus{
    border-color:var(--line);
    box-shadow:0 0 0 3px rgba(255,255,255,.07);
}
.contact-page .ct-field input::placeholder,
.contact-page .ct-field textarea::placeholder{
    color:#7c7c85;
}
.contact-page .ct-field input:-webkit-autofill{
    -webkit-box-shadow:0 0 0 40px var(--bg) inset;
    -webkit-text-fill-color:var(--text);
}
.contact-page .ct-help{
    margin-top:6px;
    padding-left:6px;
    color:var(--muted);
    font-size:10px;
    line-height:1.7;
}
.contact-page .ct-actions{
    display:flex;
    align-items:center;
    flex-wrap:wrap;
    gap:10px;
    margin-top:22px;
}
.contact-page .ct-btn{
    display:inline-flex;
    height:42px;
    align-items:center;
    justify-content:center;
    gap:8px;
    padding:0 24px;
    border:1.5px solid #f2f2f2;
    border-radius:999px;
    background:#f2f2f2;
    color:#111111;
    font:inherit;
    font-size:12px;
    font-weight:700;
    cursor:pointer;
    transition:background .2s,color .2s,transform .2s;
}
.contact-page .ct-btn:hover{
    border-color:#ffffff;
    background:#ffffff;
    color:#111111;
    transform:translateY(-1px);
}
.contact-page .ct-btn:disabled{
    opacity:.6;
    cursor:default;
    transform:none;
}
.contact-page .ct-btn.secondary{
    border-color:var(--line);
    background:rgba(255,255,255,.08);
    color:var(--text);
}
.contact-page .ct-btn.secondary:hover{
    background:rgba(255,255,255,.18);
    color:var(--text);
}
.contact-page .ct-sidebar-card{
    margin-bottom:16px;
    padding:22px;
    border:1px solid var(--stroke);
    border-radius:var(--radius-lg);
    background:var(--glass);
}
.contact-page .ct-sidebar-card h2{
    display:flex;
    align-items:center;
    gap:10px;
    margin:0 0 16px;
    padding-bottom:14px;
    border-bottom:1px solid var(--stroke);
    font-size:15px;
    font-weight:800;
}
.contact-page .ct-sidebar-card h2::before{
    content:"";
    width:3px;
    height:14px;
    border-radius:3px;
    background:var(--text);
}
.contact-page .ct-info-item{
    display:flex;
    align-items:flex-start;
    gap:12px;
    margin-bottom:18px;
}
.contact-page .ct-info-item:last-child{margin-bottom:0}
.contact-page .ct-info-icon{
    display:flex;
    width:38px;
    height:38px;
    flex-shrink:0;
    align-items:center;
    justify-content:center;
    border-radius:12px;
    background:var(--glass-2);
    color:var(--text);
    font-size:15px;
    font-weight:800;
}
.contact-page .ct-info-title{
    display:block;
    margin:1px 0 5px;
    color:var(--text);
    font-size:11px;
    font-weight:800;
}
.contact-page .ct-info-text{
    display:block;
    color:var(--muted);
    font-size:11px;
    line-height:1.8;
    overflow-wrap:anywhere;
}
.contact-page .ct-info-text a:hover{color:var(--text)}
.contact-page .ct-promo{
    padding:24px;
    border:1px solid var(--stroke);
    border-radius:var(--radius-lg);
    background:
        radial-gradient(ellipse at 100% 0%,rgba(255,255,255,.10),transparent 45%),
        var(--glass-2);
    color:var(--text);
}
.contact-page .ct-promo-label{
    color:var(--muted);
    font-size:9px;
    font-weight:800;
    letter-spacing:2px;
    text-transform:uppercase;
}
.contact-page .ct-promo h3{
    margin:11px 0;
    font-size:20px;
    font-weight:800;
    line-height:1.3;
}
.contact-page .ct-promo p{
    margin:0 0 18px;
    color:var(--muted);
    font-size:11px;
    line-height:1.8;
}
.contact-page .ct-promo a{
    display:inline-flex;
    height:38px;
    align-items:center;
    justify-content:center;
    padding:0 18px;
    border-radius:999px;
    background:#f2f2f2;
    color:#111111;
    font-size:11px;
    font-weight:700;
    transition:background .2s,transform .2s;
}
.contact-page .ct-promo a:hover{
    background:#ffffff;
    transform:translateY(-1px);
}
.contact-page .ct-note{
    margin-top:16px;
    color:var(--muted);
    font-size:10px;
    line-height:1.8;
}
@media(max-width:800px){
    .contact-page{padding:16px 16px 32px}
    .contact-page .ct-hero{padding:32px 24px}
    .contact-page .ct-layout{grid-template-columns:1fr}
    .contact-page .ct-sidebar{
        display:grid;
        grid-template-columns:repeat(2,minmax(0,1fr));
        gap:14px;
    }
    .contact-page .ct-sidebar-card{margin:0}
    .contact-page .ct-promo{grid-column:1/-1}
}
@media(max-width:540px){
    .contact-page{padding:12px 12px 28px}
    .contact-page .ct-hero{padding:26px 18px}
    .contact-page .ct-panel-body{padding:18px}
    .contact-page .ct-grid{grid-template-columns:1fr}
    .contact-page .ct-field.full{grid-column:auto}
    .contact-page .ct-sidebar{grid-template-columns:1fr}
    .contact-page .ct-promo{grid-column:auto}
}
</style>

<main class="contact-page">

    <section class="ct-hero">
        <div class="ct-wrap">
            <div class="ct-eyebrow">Comic Shop · Hỗ trợ khách hàng</div>
            <h1>Chúng tôi luôn sẵn sàng lắng nghe</h1>
            <p>
                Bạn có thắc mắc về truyện, đơn hàng hoặc dịch vụ của cửa hàng?
                Hãy gửi tin nhắn cho Comic Shop, chúng tôi sẽ tiếp nhận yêu cầu
                của bạn qua hệ thống liên hệ.
            </p>
        </div>
    </section>

    <div class="ct-wrap">

        <?php if (
            is_array($contactFlash) &&
            !empty($contactFlash['message'])
        ): ?>
            <div
                class="ct-alert <?= ($contactFlash['type'] ?? '') === 'success' ? 'success' : '' ?>"
                role="status"
            >
                <?= comic_contact_escape($contactFlash['message']) ?>
            </div>
        <?php endif; ?>

        <?php if ($contactErrors): ?>
            <div class="ct-alert" role="alert">
                <strong>Vui lòng kiểm tra lại:</strong>
                <ul style="margin:7px 0 0;padding-left:20px">
                    <?php foreach ($contactErrors as $error): ?>
                        <li><?= comic_contact_escape($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="ct-layout">

            <section class="ct-panel">
                <div class="ct-panel-head">
                    <h2>Gửi tin nhắn cho chúng tôi</h2>
                    <p>
                        Điền thông tin và nội dung cần hỗ trợ.
                        Những trường có dấu * là bắt buộc.
                    </p>
                </div>

                <div class="ct-panel-body">
                    <form method="post" action="contact.php" id="contact-form">

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= comic_contact_escape($contactCsrf) ?>"
                        >

                        <div class="ct-grid">

                            <div class="ct-field">
                                <label for="contact-name">Họ và tên *</label>
                                <input
                                    type="text"
                                    id="contact-name"
                                    name="full_name"
                                    maxlength="120"
                                    required
                                    autocomplete="name"
                                    value="<?= comic_contact_escape($formData['full_name']) ?>"
                                    placeholder="Nhập họ tên của bạn"
                                >
                            </div>

                            <div class="ct-field">
                                <label for="contact-email">Địa chỉ email *</label>
                                <input
                                    type="email"
                                    id="contact-email"
                                    name="email"
                                    maxlength="150"
                                    required
                                    autocomplete="email"
                                    value="<?= comic_contact_escape($formData['email']) ?>"
                                    placeholder="email@example.com"
                                >
                            </div>

                            <div class="ct-field full">
                                <label for="contact-subject">Tiêu đề</label>
                                <input
                                    type="text"
                                    id="contact-subject"
                                    name="subject"
                                    maxlength="200"
                                    value="<?= comic_contact_escape($formData['subject']) ?>"
                                    placeholder="Ví dụ: Hỏi về tình trạng đơn hàng"
                                >
                                <div class="ct-help">
                                    Có thể để trống nếu bạn chưa có tiêu đề cụ thể.
                                </div>
                            </div>

                            <div class="ct-field full">
                                <label for="contact-message">Nội dung tin nhắn *</label>
                                <textarea
                                    id="contact-message"
                                    name="message"
                                    maxlength="10000"
                                    required
                                    placeholder="Nhập câu hỏi hoặc nội dung cần hỗ trợ..."
                                ><?= comic_contact_escape($formData['message']) ?></textarea>
                                <div class="ct-help">
                                    Tối đa 10.000 ký tự. Không nhập mật khẩu hoặc
                                    thông tin thanh toán nhạy cảm vào tin nhắn.
                                </div>
                            </div>

                        </div>

                        <div class="ct-actions">
                            <button class="ct-btn" type="submit" id="contact-submit">
                                Gửi tin nhắn →
                            </button>

                            <button
                                class="ct-btn secondary"
                                type="reset"
                            >
                                Xóa nội dung
                            </button>
                        </div>

                        <p class="ct-note">
                            Tin nhắn được lưu trong hệ thống để nhân viên
                            quản trị có thể xem tại mục Tin nhắn.
                        </p>
                    </form>
                </div>
            </section>

            <aside class="ct-sidebar">

                <section class="ct-sidebar-card">
                    <h2>Thông tin hỗ trợ</h2>

                    <div class="ct-info-item">
                        <div class="ct-info-icon">✉</div>
                        <div>
                            <span class="ct-info-title">Liên hệ qua email</span>
                            <span class="ct-info-text">
                                Hãy điền email của bạn trong biểu mẫu để
                                cửa hàng có thể phản hồi đúng địa chỉ.
                            </span>
                        </div>
                    </div>

                    <div class="ct-info-item">
                        <div class="ct-info-icon">▤</div>
                        <div>
                            <span class="ct-info-title">Hỗ trợ đơn hàng</span>
                            <span class="ct-info-text">
                                Ghi mã đơn hàng vào nội dung nếu bạn cần
                                kiểm tra tình trạng giao hàng hoặc thanh toán.
                            </span>
                        </div>
                    </div>

                    <div class="ct-info-item">
                        <div class="ct-info-icon">✓</div>
                        <div>
                            <span class="ct-info-title">Tiếp nhận yêu cầu</span>
                            <span class="ct-info-text">
                                Tin nhắn được lưu vào hệ thống quản trị
                                để nhân viên kiểm tra và xử lý.
                            </span>
                        </div>
                    </div>
                </section>

                <section class="ct-promo">
                    <div class="ct-promo-label">Comic Shop</div>
                    <h3>Khám phá câu chuyện tiếp theo của bạn.</h3>
                    <p>
                        Tìm thêm những bộ manga yêu thích trong bộ sưu tập
                        truyện tranh của cửa hàng.
                    </p>
                    <a href="comics.php">Khám phá truyện →</a>
                </section>

            </aside>

        </div>
    </div>
</main>

<script>
(function () {
    'use strict';

    var form = document.getElementById('contact-form');
    var submitButton = document.getElementById('contact-submit');

    if (form && submitButton) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                form.reportValidity();
                return;
            }

            if (submitButton.dataset.sending === '1') {
                event.preventDefault();
                return;
            }

            submitButton.dataset.sending = '1';
            submitButton.disabled = true;
            submitButton.textContent = 'Đang gửi...';
        });
    }
})();
</script>

<?php
if (is_file($footerFile)) {
    require_once $footerFile;
} else {
    echo '</body></html>';
}
?>
