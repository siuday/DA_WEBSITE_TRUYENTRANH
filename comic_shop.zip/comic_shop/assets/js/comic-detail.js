/*
 * COMIC SHOP
 * File: assets/js/comic-detail.js
 * Tương tác cho trang chi tiết truyện.
 */

(function () {
  "use strict";

  /* =====================================================
       1. THƯ VIỆN ẢNH TRUYỆN
    ===================================================== */

  function initComicGallery() {
    var mainFrame = document.querySelector(".cd-main-image");
    var mainImage = document.getElementById("cd-main-cover");
    var placeholder = document.getElementById("cd-cover-placeholder");

    var thumbnails = document.querySelectorAll(".cd-thumb[data-image]");

    if (!mainFrame || !thumbnails.length) {
      return;
    }

    function showImage(url, button) {
      if (!url) {
        return;
      }

      if (!mainImage) {
        mainImage = document.createElement("img");
        mainImage.id = "cd-main-cover";
        mainImage.alt = document.querySelector(".cd-title")
          ? document.querySelector(".cd-title").textContent.trim()
          : "Ảnh truyện";

        mainImage.style.display = "block";
        mainFrame.insertBefore(mainImage, mainFrame.firstChild);
      }

      if (placeholder) {
        placeholder.style.display = "none";
      }

      mainImage.style.display = "block";
      mainImage.src = url;

      thumbnails.forEach(function (thumbnail) {
        thumbnail.classList.remove("active");
        thumbnail.setAttribute("aria-pressed", "false");
      });

      if (button) {
        button.classList.add("active");
        button.setAttribute("aria-pressed", "true");
      }
    }

    thumbnails.forEach(function (button) {
      if (button.dataset.galleryInitialized === "1") {
        return;
      }

      button.dataset.galleryInitialized = "1";

      button.setAttribute(
        "aria-pressed",
        button.classList.contains("active") ? "true" : "false",
      );

      button.addEventListener("click", function () {
        showImage(button.getAttribute("data-image"), button);
      });
    });

    if (mainImage) {
      mainImage.addEventListener("error", function () {
        mainImage.style.display = "none";

        if (placeholder) {
          placeholder.style.display = "flex";
        }
      });
    }
  }

  /* =====================================================
       2. NÚT TĂNG / GIẢM SỐ LƯỢNG
    ===================================================== */

  function initQuantity() {
    var input = document.getElementById("cd-quantity");
    var minusButton = document.getElementById("cd-quantity-minus");
    var plusButton = document.getElementById("cd-quantity-plus");

    if (!input) {
      return;
    }

    var form = input.closest("form");

    function getBounds() {
      var min = parseInt(input.min || "1", 10);
      var max = parseInt(input.max || "999", 10);

      if (!Number.isFinite(min) || min < 1) {
        min = 1;
      }

      if (!Number.isFinite(max) || max < min) {
        max = min;
      }

      return {
        min: min,
        max: max,
      };
    }

    function normalizeQuantity() {
      var bounds = getBounds();
      var value = parseInt(input.value || "1", 10);

      if (!Number.isFinite(value)) {
        value = bounds.min;
      }

      value = Math.max(bounds.min, Math.min(bounds.max, value));

      input.value = String(value);

      if (minusButton) {
        minusButton.disabled = input.disabled || value <= bounds.min;
      }

      if (plusButton) {
        plusButton.disabled = input.disabled || value >= bounds.max;
      }

      return value;
    }

    function changeQuantity(amount) {
      if (input.disabled) {
        return;
      }

      var currentValue = normalizeQuantity();
      input.value = String(currentValue + amount);
      normalizeQuantity();
    }

    if (minusButton) {
      minusButton.addEventListener("click", function (event) {
        event.preventDefault();
        changeQuantity(-1);
      });
    }

    if (plusButton) {
      plusButton.addEventListener("click", function (event) {
        event.preventDefault();
        changeQuantity(1);
      });
    }

    input.addEventListener("input", function () {
      var bounds = getBounds();
      var value = parseInt(input.value || "0", 10);

      if (
        Number.isFinite(value) &&
        value >= bounds.min &&
        value <= bounds.max
      ) {
        if (minusButton) {
          minusButton.disabled = input.disabled || value <= bounds.min;
        }

        if (plusButton) {
          plusButton.disabled = input.disabled || value >= bounds.max;
        }
      }
    });

    input.addEventListener("change", normalizeQuantity);
    input.addEventListener("blur", normalizeQuantity);

    if (form) {
      form.addEventListener("submit", function (event) {
        if (input.disabled) {
          event.preventDefault();
          return;
        }

        normalizeQuantity();

        if (!form.checkValidity()) {
          event.preventDefault();
          form.reportValidity();
          return;
        }

        var submitButton = form.querySelector('button[type="submit"]');

        if (submitButton && submitButton.dataset.submitting !== "1") {
          submitButton.dataset.submitting = "1";
          submitButton.disabled = true;
          submitButton.textContent = "Đang thêm vào giỏ...";
        }
      });
    }

    normalizeQuantity();
  }

  /* =====================================================
       3. CUỘN TỚI ĐÁNH GIÁ
    ===================================================== */

  function initReviewAnchor() {
    if (window.location.hash !== "#reviews") {
      return;
    }

    var reviewSection = document.getElementById("reviews");

    if (!reviewSection) {
      return;
    }

    /*
     * Không cần thêm thư viện bên ngoài.
     * Cuộn tới phần đánh giá khi trang đã sẵn sàng.
     */
    window.requestAnimationFrame(function () {
      reviewSection.scrollIntoView({
        behavior: "auto",
        block: "start",
      });
    });
  }

  /* =====================================================
       4. KHỞI ĐỘNG
    ===================================================== */

  function initComicDetail() {
    initComicGallery();
    initQuantity();
    initReviewAnchor();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initComicDetail);
  } else {
    initComicDetail();
  }
})();
