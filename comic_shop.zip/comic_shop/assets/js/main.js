/*
 * COMIC SHOP
 * File: assets/js/main.js
 * Các chức năng JavaScript dùng chung cho website.
 */

(function () {
  "use strict";

  /* =====================================================
       1. HÀM TIỆN ÍCH
    ===================================================== */

  function queryAll(selector, parent) {
    return Array.prototype.slice.call(
      (parent || document).querySelectorAll(selector),
    );
  }

  function getTarget(element) {
    if (!element) {
      return null;
    }

    var selector =
      element.getAttribute("data-target") ||
      element.getAttribute("aria-controls");

    if (!selector) {
      var href = element.getAttribute("href") || "";

      if (href.charAt(0) === "#" && href.length > 1) {
        selector = href;
      }
    }

    if (!selector) {
      return null;
    }

    try {
      return document.querySelector(selector);
    } catch (error) {
      return null;
    }
  }

  function setExpanded(element, expanded) {
    if (!element) {
      return;
    }

    element.setAttribute("aria-expanded", expanded ? "true" : "false");
  }

  function closeElement(element) {
    if (!element) {
      return;
    }

    element.classList.remove("is-open");
    element.classList.remove("is-active");
    element.classList.remove("open");
    element.classList.remove("show");

    setExpanded(element, false);
  }

  function toggleElement(element, force) {
    if (!element) {
      return false;
    }

    var currentlyOpen =
      element.classList.contains("is-open") ||
      element.classList.contains("is-active") ||
      element.classList.contains("open") ||
      element.classList.contains("show");

    var shouldOpen = typeof force === "boolean" ? force : !currentlyOpen;

    element.classList.toggle("is-open", shouldOpen);
    setExpanded(element, shouldOpen);

    return shouldOpen;
  }

  /* =====================================================
       2. MENU ĐIỀU HƯỚNG TRÊN ĐIỆN THOẠI
    ===================================================== */

  function initMobileNavigation() {
    var toggleSelectors = [
      "[data-menu-toggle]",
      ".menu-toggle",
      ".nav-toggle",
      ".hamburger-toggle",
      ".mobile-menu-toggle",
    ].join(",");

    var navSelectors = [
      "[data-site-nav]",
      ".site-nav",
      ".main-nav",
      ".header-nav",
      ".nav-menu",
      "#main-nav",
      "#site-nav",
    ].join(",");

    var toggles = queryAll(toggleSelectors);

    toggles.forEach(function (button) {
      var target = getTarget(button);

      if (!target) {
        target = document.querySelector(navSelectors);
      }

      if (!target) {
        return;
      }

      button.setAttribute("aria-controls", target.id || "");

      if (!target.id) {
        var generatedId = "comic-shop-main-nav";

        if (document.getElementById(generatedId)) {
          generatedId += "-" + Math.random().toString(36).slice(2, 7);
        }

        target.id = generatedId;
        button.setAttribute("aria-controls", generatedId);
      }

      if (!target.hasAttribute("aria-hidden")) {
        target.setAttribute("aria-hidden", "false");
      }

      button.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();

        var opened = toggleElement(target);

        setExpanded(button, opened);
        target.setAttribute("aria-hidden", opened ? "false" : "true");
      });

      target.addEventListener("click", function (event) {
        var link = event.target.closest("a");

        if (link && link.getAttribute("href")) {
          closeElement(target);
          setExpanded(button, false);
          target.setAttribute("aria-hidden", "true");
        }
      });

      document.addEventListener("click", function (event) {
        if (!target.contains(event.target) && !button.contains(event.target)) {
          closeElement(target);
          setExpanded(button, false);
          target.setAttribute("aria-hidden", "true");
        }
      });

      document.addEventListener("keydown", function (event) {
        if (event.key === "Escape") {
          closeElement(target);
          setExpanded(button, false);
          target.setAttribute("aria-hidden", "true");
        }
      });
    });
  }

  /* =====================================================
       3. MENU THẢ XUỐNG
    ===================================================== */

  function initDropdowns() {
    var selector = ["[data-dropdown-toggle]", ".account-dropdown-toggle"].join(
      ",",
    );

    queryAll(selector).forEach(function (button) {
      if (button.dataset.dropdownInitialized === "true") {
        return;
      }

      var parent =
        button.closest("[data-dropdown]") ||
        button.closest(".dropdown") ||
        button.parentElement;

      if (!parent) {
        return;
      }

      var menu = getTarget(button);

      if (!menu) {
        menu = parent.querySelector("[data-dropdown-menu], .dropdown-menu");
      }

      if (!menu) {
        return;
      }

      button.dataset.dropdownInitialized = "true";

      button.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();

        var shouldOpen = toggleElement(parent);

        setExpanded(button, shouldOpen);

        if (menu !== parent) {
          menu.classList.toggle("is-open", shouldOpen);
          menu.classList.toggle("show", shouldOpen);
        }
      });

      document.addEventListener("click", function (event) {
        if (!parent.contains(event.target)) {
          closeElement(parent);
          closeElement(menu);
          setExpanded(button, false);
        }
      });

      document.addEventListener("keydown", function (event) {
        if (event.key === "Escape") {
          closeElement(parent);
          closeElement(menu);
          setExpanded(button, false);
        }
      });
    });
  }


  /* =====================================================
       3B. HỘP TÌM KIẾM VÀ THÔNG BÁO NHANH
       Khớp với id/class trong includes/header.php
    ===================================================== */

  function initSearchOverlay() {
    var openBtn = document.getElementById("scrnSearchBtn");
    var overlay = document.getElementById("scrnSearchOverlay");
    var closeBtn = document.getElementById("scrnSearchClose");
    var input = document.getElementById("scrnSearchInput");

    if (!openBtn || !overlay) {
      return;
    }

    function setSearch(open) {
      overlay.classList.toggle("open", open);
      overlay.setAttribute("aria-hidden", open ? "false" : "true");

      if (open && input) {
        window.setTimeout(function () {
          input.focus();
        }, 80);
      }
    }

    openBtn.addEventListener("click", function (event) {
      event.preventDefault();
      setSearch(true);
    });

    if (closeBtn) {
      closeBtn.addEventListener("click", function () {
        setSearch(false);
      });
    }

    overlay.addEventListener("click", function (event) {
      if (event.target === overlay) {
        setSearch(false);
      }
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        setSearch(false);
      }
    });
  }

  /* window.scrnShowToast(message, type) - dùng ở footer (đăng ký bản tin) */
  function initToast() {
    window.scrnShowToast = function (message, type) {
      var container = document.getElementById("scrnToastContainer");

      if (!container) {
        return;
      }

      var toast = document.createElement("div");

      toast.className = "scrn-toast scrn-toast--" + (type || "success");
      toast.textContent = String(message || "");
      container.appendChild(toast);

      window.setTimeout(function () {
        toast.style.opacity = "0";
      }, 3200);

      window.setTimeout(function () {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 3700);
    };
  }

  /* =====================================================
       4. MỞ VÀ ĐÓNG KHUNG TÌM KIẾM
    ===================================================== */

  function initSearchToggles() {
    var toggles = queryAll("[data-search-toggle]");

    toggles.forEach(function (button) {
      var target = getTarget(button);

      if (!target) {
        target = document.querySelector(
          "[data-search-panel], .header-search-panel",
        );
      }

      if (!target) {
        return;
      }

      button.addEventListener("click", function (event) {
        event.preventDefault();

        var opened = toggleElement(target);
        setExpanded(button, opened);

        if (opened) {
          var input = target.querySelector(
            'input[type="search"], input[name="q"], input[type="text"]',
          );

          if (input) {
            window.setTimeout(function () {
              input.focus();
            }, 50);
          }
        }
      });
    });

    queryAll("[data-search-close]").forEach(function (button) {
      button.addEventListener("click", function () {
        var target = getTarget(button) || button.closest("[data-search-panel]");

        if (target) {
          closeElement(target);
        }
      });
    });
  }

  /* =====================================================
       5. HIỆN / ẨN MẬT KHẨU
    ===================================================== */

  function initPasswordToggles() {
    queryAll("[data-toggle-password]").forEach(function (button) {
      var target = getTarget(button);

      if (!target) {
        var container = button.closest(
          ".password-wrapper, .login-input-wrap, .input-group, .form-group",
        );

        if (container) {
          target = container.querySelector(
            'input[type="password"], input[type="text"]',
          );
        }
      }

      if (!target) {
        return;
      }

      button.setAttribute("aria-pressed", "false");

      button.addEventListener("click", function () {
        var isHidden = target.type === "password";

        target.type = isHidden ? "text" : "password";

        button.setAttribute("aria-pressed", isHidden ? "true" : "false");

        button.setAttribute(
          "aria-label",
          isHidden ? "Ẩn mật khẩu" : "Hiện mật khẩu",
        );

        if (button.hasAttribute("data-password-label")) {
          button.textContent = isHidden ? "Ẩn" : "Hiện";
        }
      });
    });
  }

  /* =====================================================
       6. NÚT QUAY LÊN ĐẦU TRANG
    ===================================================== */

  function initBackToTop() {
    var buttons = queryAll("[data-scroll-top]");

    if (!buttons.length) {
      return;
    }

    function updateButtons() {
      var visible = window.scrollY > 300;

      buttons.forEach(function (button) {
        button.hidden = !visible;
        button.classList.toggle("is-visible", visible);
      });
    }

    buttons.forEach(function (button) {
      button.addEventListener("click", function () {
        window.scrollTo({
          top: 0,
          behavior: "smooth",
        });
      });
    });

    window.addEventListener("scroll", updateButtons, {
      passive: true,
    });

    updateButtons();
  }

  /* =====================================================
       7. CUỘN ĐẾN MỤC TRÊN TRANG
    ===================================================== */

  function initAnchorLinks() {
    queryAll("a[data-smooth-scroll]").forEach(function (link) {
      link.addEventListener("click", function (event) {
        var href = link.getAttribute("href") || "";

        if (href.length < 2 || href.charAt(0) !== "#") {
          return;
        }

        var target;

        try {
          target = document.querySelector(href);
        } catch (error) {
          target = null;
        }

        if (!target) {
          return;
        }

        event.preventDefault();

        target.scrollIntoView({
          behavior: window.matchMedia("(prefers-reduced-motion: reduce)")
            .matches
            ? "auto"
            : "smooth",
          block: "start",
        });

        if (target.id) {
          history.replaceState(null, "", "#" + encodeURIComponent(target.id));
        }
      });
    });
  }

  /* =====================================================
       8. HIỂN THỊ NĂM HIỆN TẠI Ở CHÂN TRANG
    ===================================================== */

  function initCurrentYear() {
    var year = String(new Date().getFullYear());

    queryAll("[data-current-year]").forEach(function (element) {
      element.textContent = year;
    });
  }

  /* =====================================================
       9. ĐÓNG CÁC MENU BẰNG PHÍM ESCAPE
    ===================================================== */

  function initGlobalEscape() {
    document.addEventListener("keydown", function (event) {
      if (event.key !== "Escape") {
        return;
      }

      queryAll(
        "[data-search-panel].is-open, .header-search-panel.is-open",
      ).forEach(function (element) {
        closeElement(element);
      });
    });
  }

  /* =====================================================
       10. KHỞI CHẠY
    ===================================================== */

  function init() {
    initMobileNavigation();
    initDropdowns();
    initSearchOverlay();
    initToast();
    initSearchToggles();
    initPasswordToggles();
    initBackToTop();
    initAnchorLinks();
    initCurrentYear();
    initGlobalEscape();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
