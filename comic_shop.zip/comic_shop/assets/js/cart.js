/*
 * COMIC SHOP
 * File: assets/js/cart.js
 * Tương tác giỏ hàng.
 */

(function () {
  "use strict";

  /* =====================================================
       1. HÀM TIỆN ÍCH
    ===================================================== */

  function getNumber(value, fallback) {
    var number = parseInt(value, 10);

    return Number.isFinite(number) ? number : fallback;
  }

  function clampQuantity(input) {
    var min = Math.max(1, getNumber(input.getAttribute("min"), 1));

    var max = Math.max(min, getNumber(input.getAttribute("max"), 999));

    var value = getNumber(input.value, min);

    value = Math.max(min, Math.min(max, value));

    input.value = String(value);

    return {
      min: min,
      max: max,
      value: value,
    };
  }

  function submitForm(form) {
    if (!form || form.dataset.submitting === "1") {
      return;
    }

    if (typeof form.requestSubmit === "function") {
      form.requestSubmit();
    } else {
      form.submit();
    }
  }

  /* =====================================================
       2. CẬP NHẬT NÚT TĂNG / GIẢM
    ===================================================== */

  function initQuantityControls() {
    var inputs = document.querySelectorAll("[data-cart-quantity]");

    inputs.forEach(function (input) {
      if (input.dataset.cartJsInitialized === "1") {
        return;
      }

      input.dataset.cartJsInitialized = "1";

      var row = input.closest("[data-cart-item]");

      if (!row) {
        return;
      }

      var form = input.closest("form");

      var minusButton = row.querySelector('[data-qty-action="decrease"]');

      var plusButton = row.querySelector('[data-qty-action="increase"]');

      function updateButtonStates() {
        var quantity = clampQuantity(input);

        if (minusButton) {
          minusButton.disabled =
            input.disabled || quantity.value <= quantity.min;
        }

        if (plusButton) {
          plusButton.disabled =
            input.disabled || quantity.value >= quantity.max;
        }
      }

      function changeQuantity(change) {
        if (input.disabled) {
          return;
        }

        var quantity = clampQuantity(input);

        var nextValue = Math.max(
          quantity.min,
          Math.min(quantity.max, quantity.value + change),
        );

        if (nextValue === quantity.value) {
          updateButtonStates();
          return;
        }

        input.value = String(nextValue);

        updateButtonStates();

        /*
         * Gửi form để PHP cập nhật bảng cart trong database.
         * Không cập nhật giả trên giao diện nếu chưa lưu thành công.
         */
        if (form) {
          submitForm(form);
        }
      }

      if (minusButton) {
        minusButton.addEventListener("click", function (event) {
          event.preventDefault();
          changeQuantity(-1);
        });
      }

      if (plusButton) {
        plusButton.addEventListener("click", function (event) {
          event.preventDefault();
          changeQuantity(1);
        });
      }

      /*
       * Khi người dùng tự nhập số lượng rồi rời khỏi ô nhập,
       * chuẩn hóa giá trị và gửi yêu cầu cập nhật.
       */
      input.addEventListener("change", function () {
        if (input.disabled) {
          return;
        }

        updateButtonStates();

        if (form) {
          submitForm(form);
        }
      });

      input.addEventListener("keydown", function (event) {
        if (event.key === "Enter") {
          event.preventDefault();

          updateButtonStates();

          if (form) {
            submitForm(form);
          }
        }
      });

      input.addEventListener("blur", updateButtonStates);

      updateButtonStates();
    });
  }

  /* =====================================================
       3. XÁC NHẬN XÓA SẢN PHẨM / XÓA GIỎ HÀNG
    ===================================================== */

  function initConfirmForms() {
    var forms = document.querySelectorAll("form[data-confirm]");

    forms.forEach(function (form) {
      if (form.dataset.cartConfirmInitialized === "1") {
        return;
      }

      form.dataset.cartConfirmInitialized = "1";

      form.addEventListener("submit", function (event) {
        if (form.dataset.confirmed === "1") {
          return;
        }

        var message = form.getAttribute("data-confirm");

        if (!message) {
          return;
        }

        if (!window.confirm(message)) {
          event.preventDefault();
          return;
        }

        /*
         * Đánh dấu để tránh hỏi xác nhận lần thứ hai
         * nếu form được gửi lại trong cùng trang.
         */
        form.dataset.confirmed = "1";
      });
    });
  }

  /* =====================================================
       4. KHÓA NÚT KHI GỬI FORM CẬP NHẬT
    ===================================================== */

  function initCartUpdateForms() {
    var forms = document.querySelectorAll('form[data-auto-submit="quantity"]');

    forms.forEach(function (form) {
      if (form.dataset.cartUpdateInitialized === "1") {
        return;
      }

      form.dataset.cartUpdateInitialized = "1";

      form.addEventListener("submit", function () {
        if (form.dataset.submitting === "1") {
          return;
        }

        form.dataset.submitting = "1";

        var input = form.querySelector("[data-cart-quantity]");

        if (input) {
          input.setAttribute("aria-busy", "true");
        }

        var buttons = form.querySelectorAll("button");

        buttons.forEach(function (button) {
          button.disabled = true;
        });
      });
    });
  }

  /* =====================================================
       5. KHỞI CHẠY
    ===================================================== */

  function initCart() {
    initQuantityControls();
    initConfirmForms();
    initCartUpdateForms();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initCart);
  } else {
    initCart();
  }
})();
