<?php
/**
 * Comic Shop - Trang quên / đặt lại mật khẩu bằng OTP email.
 *
 * Đường dẫn:
 * C:\xampp\htdocs\comic_shop\forgot-password.php
 *
 * Phụ thuộc:
 * config/db.php
 * includes/forgot-flow.php
 * includes/mailer.php
 */

declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/* =========================================================
   1. KẾT NỐI CƠ SỞ DỮ LIỆU
========================================================= */

$configFile = __DIR__ . '/config/db.php';
$configReturn = null;

if (is_file($configFile)) {
    $configReturn = require_once $configFile;
}

$forgotDb = null;

if (
    $configReturn instanceof PDO ||
    (class_exists('mysqli') && $configReturn instanceof mysqli)
) {
    $forgotDb = $configReturn;
} else {
    foreach (
        ['pdo', 'conn', 'mysqli', 'db', 'connection', 'database']
        as $candidate
    ) {
        if (
            isset($$candidate) &&
            (
                $$candidate instanceof PDO ||
                (
                    class_exists('mysqli') &&
                    $$candidate instanceof mysqli
                )
            )
        ) {
            $forgotDb = $$candidate;
            break;
        }
    }
}

/* =========================================================
   2. NẠP CHỨC NĂNG QUÊN MẬT KHẨU
========================================================= */

$flowFile = __DIR__ . '/includes/forgot-flow.php';

if (is_file($flowFile)) {
    require_once $flowFile;
}

/* =========================================================
   3. HÀM HỖ TRỢ
========================================================= */

if (!function_exists('comic_shop_forgot_password_escape')) {
    function comic_shop_forgot_password_escape($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('comic_shop_forgot_password_redirect')) {
    function comic_shop_forgot_password_redirect(): void
    {
        header(
            'Location: forgot-password.php',
            true,
            303
        );
        exit;
    }
}

if (
    !isset($_SESSION['comic_shop_forgot_step']) ||
    !in_array(
        $_SESSION['comic_shop_forgot_step'],
        ['email', 'code', 'done'],
        true
    )
) {
    $_SESSION['comic_shop_forgot_step'] = 'email';
}

/* =========================================================
   4. XỬ LÝ BIỂU MẪU POST
========================================================= */

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {

    $postedToken =
        isset($_POST['csrf_token']) &&
        is_string($_POST['csrf_token'])
            ? $_POST['csrf_token']
            : null;

    $csrfValid =
        function_exists('comic_shop_forgot_flow_csrf_valid') &&
        comic_shop_forgot_flow_csrf_valid($postedToken);

    if (!$csrfValid) {
        $_SESSION['comic_shop_forgot_flash'] = [
            'type' => 'error',
            'message' => 'Phiên biểu mẫu đã hết hạn. Vui lòng thử lại.'
        ];

        comic_shop_forgot_password_redirect();
    }

    unset($_SESSION['comic_shop_forgot_csrf']);

    $action =
        isset($_POST['action']) && is_string($_POST['action'])
            ? $_POST['action']
            : '';

    /* -----------------------------------------------------
       YÊU CẦU GỬI OTP HOẶC GỬI LẠI OTP
    ----------------------------------------------------- */

    if (
        $action === 'request_code' ||
        $action === 'resend_code'
    ) {
        $email =
            isset($_POST['email']) && is_string($_POST['email'])
                ? strtolower(trim($_POST['email']))
                : '';

        if (
            $email === '' ||
            filter_var($email, FILTER_VALIDATE_EMAIL) === false
        ) {
            $_SESSION['comic_shop_forgot_step'] = 'email';
            $_SESSION['comic_shop_forgot_email'] = $email;

            $_SESSION['comic_shop_forgot_flash'] = [
                'type' => 'error',
                'message' => 'Vui lòng nhập địa chỉ email hợp lệ.'
            ];

            comic_shop_forgot_password_redirect();
        }

        if (!function_exists('comic_shop_forgot_flow_request_code')) {
            $_SESSION['comic_shop_forgot_step'] = 'email';

            $_SESSION['comic_shop_forgot_flash'] = [
                'type' => 'error',
                'message' =>
                    'Chức năng quên mật khẩu chưa được cài đặt đầy đủ. ' .
                    'Hãy kiểm tra includes/forgot-flow.php.'
            ];

            comic_shop_forgot_password_redirect();
        }

        if (
            !function_exists('comic_shop_forgot_flow_db_is_supported') ||
            !comic_shop_forgot_flow_db_is_supported($forgotDb)
        ) {
            $_SESSION['comic_shop_forgot_step'] = 'email';
            $_SESSION['comic_shop_forgot_email'] = $email;

            $_SESSION['comic_shop_forgot_flash'] = [
                'type' => 'error',
                'message' =>
                    'Chưa kết nối được cơ sở dữ liệu. ' .
                    'Hãy kiểm tra config/db.php.'
            ];

            comic_shop_forgot_password_redirect();
        }

        $result = comic_shop_forgot_flow_request_code(
            $forgotDb,
            $email
        );

        $_SESSION['comic_shop_forgot_email'] = $email;
        $_SESSION['comic_shop_forgot_step'] = 'code';

        $_SESSION['comic_shop_forgot_flash'] = [
            'type' => !empty($result['success'])
                ? 'success'
                : 'error',

            'message' => (string) (
                $result['message'] ??
                'Nếu email tồn tại và tài khoản đang hoạt động, ' .
                'hướng dẫn sẽ được gửi nếu có thể.'
            )
        ];

        comic_shop_forgot_password_redirect();
    }

    /* -----------------------------------------------------
       XÁC THỰC OTP VÀ CẬP NHẬT MẬT KHẨU
    ----------------------------------------------------- */

    if ($action === 'reset_password') {

        $email =
            isset($_SESSION['comic_shop_forgot_email']) &&
            is_string($_SESSION['comic_shop_forgot_email'])
                ? $_SESSION['comic_shop_forgot_email']
                : '';

        $code =
            isset($_POST['otp_code']) &&
            is_string($_POST['otp_code'])
                ? trim($_POST['otp_code'])
                : '';

        $newPassword =
            isset($_POST['new_password']) &&
            is_string($_POST['new_password'])
                ? $_POST['new_password']
                : '';

        $confirmPassword =
            isset($_POST['confirm_password']) &&
            is_string($_POST['confirm_password'])
                ? $_POST['confirm_password']
                : '';

        if (!function_exists('comic_shop_forgot_flow_reset_password')) {
            $_SESSION['comic_shop_forgot_step'] = 'code';

            $_SESSION['comic_shop_forgot_flash'] = [
                'type' => 'error',
                'message' =>
                    'Chức năng đặt lại mật khẩu chưa được cài đặt đầy đủ.'
            ];

            comic_shop_forgot_password_redirect();
        }

        if (
            !function_exists('comic_shop_forgot_flow_db_is_supported') ||
            !comic_shop_forgot_flow_db_is_supported($forgotDb)
        ) {
            $_SESSION['comic_shop_forgot_step'] = 'code';

            $_SESSION['comic_shop_forgot_flash'] = [
                'type' => 'error',
                'message' =>
                    'Chưa kết nối được cơ sở dữ liệu. ' .
                    'Hãy kiểm tra config/db.php.'
            ];

            comic_shop_forgot_password_redirect();
        }

        if (preg_match('/^[0-9]{6}$/', $code) !== 1) {
            $_SESSION['comic_shop_forgot_step'] = 'code';

            $_SESSION['comic_shop_forgot_flash'] = [
                'type' => 'error',
                'message' => 'Mã xác thực phải gồm đúng 6 chữ số.'
            ];

            comic_shop_forgot_password_redirect();
        }

        if (
            strlen($newPassword) < 8 ||
            strlen($newPassword) > 72
        ) {
            $_SESSION['comic_shop_forgot_step'] = 'code';

            $_SESSION['comic_shop_forgot_flash'] = [
                'type' => 'error',
                'message' =>
                    'Mật khẩu phải có ít nhất 8 ký tự ' .
                    'và tối đa 72 byte.'
            ];

            comic_shop_forgot_password_redirect();
        }

        if (!hash_equals($newPassword, $confirmPassword)) {
            $_SESSION['comic_shop_forgot_step'] = 'code';

            $_SESSION['comic_shop_forgot_flash'] = [
                'type' => 'error',
                'message' => 'Mật khẩu xác nhận không khớp.'
            ];

            comic_shop_forgot_password_redirect();
        }

        $result = comic_shop_forgot_flow_reset_password(
            $forgotDb,
            $email,
            $code,
            $newPassword,
            $confirmPassword
        );

        if (!empty($result['success'])) {

            unset($_SESSION['comic_shop_forgot_email']);

            $_SESSION['comic_shop_forgot_step'] = 'done';

            $_SESSION['comic_shop_forgot_flash'] = [
                'type' => 'success',
                'message' =>
                    $result['message'] ??
                    'Đặt lại mật khẩu thành công.'
            ];

        } else {

            $_SESSION['comic_shop_forgot_step'] = 'code';

            $_SESSION['comic_shop_forgot_flash'] = [
                'type' => 'error',
                'message' =>
                    $result['message'] ??
                    'Không thể đặt lại mật khẩu. Vui lòng thử lại.'
            ];
        }

        comic_shop_forgot_password_redirect();
    }

    /* -----------------------------------------------------
       QUAY LẠI NHẬP EMAIL
    ----------------------------------------------------- */

    if (
        $action === 'change_email' ||
        $action === 'back_to_email'
    ) {
        unset($_SESSION['comic_shop_forgot_email']);

        $_SESSION['comic_shop_forgot_step'] = 'email';

        $_SESSION['comic_shop_forgot_flash'] = [
            'type' => 'info',
            'message' =>
                'Bạn có thể nhập email để nhận mã xác thực mới.'
        ];

        comic_shop_forgot_password_redirect();
    }

    $_SESSION['comic_shop_forgot_flash'] = [
        'type' => 'error',
        'message' => 'Thao tác không hợp lệ. Vui lòng thử lại.'
    ];

    comic_shop_forgot_password_redirect();
}

/* =========================================================
   5. DỮ LIỆU HIỂN THỊ
========================================================= */

$step = (string) (
    $_SESSION['comic_shop_forgot_step'] ?? 'email'
);

$emailValue =
    isset($_SESSION['comic_shop_forgot_email']) &&
    is_string($_SESSION['comic_shop_forgot_email'])
        ? $_SESSION['comic_shop_forgot_email']
        : '';

$flash = $_SESSION['comic_shop_forgot_flash'] ?? null;

unset($_SESSION['comic_shop_forgot_flash']);

$csrfToken =
    function_exists('comic_shop_forgot_flow_csrf_token')
        ? comic_shop_forgot_flow_csrf_token()
        : bin2hex(random_bytes(32));

$headerFile = __DIR__ . '/includes/header.php';
$footerFile = __DIR__ . '/includes/footer.php';

if (is_file($headerFile)) {
    require_once $headerFile;
} else {
    ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Quên mật khẩu | Comic Shop</title>
    </head>
    <body>
    <?php
}
?>

<style>
.forgot-page {
    --fp-red: #111111;
    --fp-ink: #111111;
    --fp-muted: #666666;
    --fp-line: #e5e5e5;

    color: var(--fp-ink);
    font-family: inherit;
    padding: 42px 18px 72px;
    background: #f6f6f4;
    min-height: 65vh;
}

.forgot-page * {
    box-sizing: border-box;
}

.forgot-page a {
    color: inherit;
}

.forgot-page .fp-wrap {
    width: min(1080px, 100%);
    margin: 0 auto;
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(320px, 460px);
    gap: clamp(28px, 5vw, 76px);
    align-items: center;
}

.forgot-page .fp-story {
    position: relative;
    min-height: 400px;
    padding: clamp(28px, 4vw, 54px);
    display: flex;
    justify-content: flex-end;
    flex-direction: column;
    overflow: hidden;
    color: white;

    background:
        radial-gradient(
            circle at 78% 12%,
            rgba(255,255,255,.28),
            transparent 26%
        ),
        radial-gradient(
            circle at 12% 88%,
            rgba(0,0,0,.55),
            transparent 34%
        ),
        linear-gradient(145deg, #161616, #2f2f2f 58%, #474747);

    box-shadow: 0 18px 42px rgba(0,0,0,.1);
}

.forgot-page .fp-story:before {
    content: "COMIC / STORIES / COLLECT";
    position: absolute;
    top: 28px;
    left: 28px;
    color: rgba(255,255,255,.11);
    font-weight: 900;
    letter-spacing: .16em;
    font-size: clamp(17px, 2.5vw, 30px);
}

.forgot-page .fp-kicker {
    position: relative;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: .2em;
    text-transform: uppercase;
    color: #dedede;
}

.forgot-page .fp-story h1 {
    position: relative;
    margin: 14px 0 12px;
    font-size: clamp(32px, 4.2vw, 52px);
    line-height: 1.04;
    letter-spacing: -.04em;
}

.forgot-page .fp-story p {
    position: relative;
    max-width: 420px;
    margin: 0;
    color: rgba(255,255,255,.76);
    font-size: 14px;
    line-height: 1.8;
}

.forgot-page .fp-stamp {
    position: absolute;
    right: 26px;
    top: 100px;
    width: 120px;
    height: 120px;
    border: 1px solid rgba(255,255,255,.18);
    border-radius: 50%;
    display: grid;
    place-items: center;
    color: rgba(255,255,255,.22);
    font-size: 45px;
    transform: rotate(-12deg);
}

.forgot-page .fp-card {
    background: #fff;
    padding: clamp(25px, 4vw, 40px);
    border: 1px solid #ededed;
    box-shadow: 0 15px 45px rgba(0,0,0,.055);
}

.forgot-page .fp-brand {
    font-size: 12px;
    font-weight: 900;
    letter-spacing: .22em;
    color: var(--fp-red);
    text-transform: uppercase;
}

.forgot-page .fp-card h2 {
    margin: 13px 0 8px;
    font-size: 27px;
    line-height: 1.15;
    letter-spacing: -.035em;
}

.forgot-page .fp-lead {
    margin: 0 0 23px;
    color: var(--fp-muted);
    font-size: 13px;
    line-height: 1.75;
}

.forgot-page .fp-alert {
    padding: 12px 14px;
    margin: 0 0 18px;
    border-left: 3px solid #999;
    background: #f5f5f5;
    font-size: 13px;
    line-height: 1.6;
}

.forgot-page .fp-alert.success {
    border-color: #111111;
    background: #f5f5f5;
    color: #111111;
}

.forgot-page .fp-alert.error {
    border-color: var(--fp-red);
    background: #f4f4f4;
    color: #111111;
}

.forgot-page .fp-alert.info {
    border-color: #111111;
    background: #f5f5f5;
    color: #111111;
}

.forgot-page .fp-field {
    display: block;
    margin: 0 0 15px;
}

.forgot-page .fp-field span {
    display: block;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: .08em;
    text-transform: uppercase;
    margin: 0 0 7px;
}

.forgot-page input {
    display: block;
    width: 100%;
    min-height: 47px;
    padding: 12px 13px;
    border: 1px solid #dcdcdc;
    border-radius: 0;
    background: #fff;
    color: #111111;
    font: inherit;
    font-size: 14px;
    outline: none;
    transition: border-color .2s, box-shadow .2s;
}

.forgot-page input:focus {
    border-color: var(--fp-red);
    box-shadow: 0 0 0 3px rgba(0,0,0,.1);
}

.forgot-page input::placeholder {
    color: #a4a4a4;
}

.forgot-page .fp-otp {
    letter-spacing: .32em;
    text-align: center;
    font-size: 22px;
    font-weight: 800;
}

.forgot-page .fp-btn {
    display: flex;
    width: 100%;
    min-height: 48px;
    align-items: center;
    justify-content: center;
    border: 0;
    background: var(--fp-red);
    color: white;
    padding: 13px 16px;
    font: inherit;
    font-size: 12px;
    font-weight: 900;
    letter-spacing: .12em;
    text-transform: uppercase;
    text-decoration: none;
    cursor: pointer;
    transition: background .2s, transform .2s;
}

.forgot-page .fp-btn:hover {
    background: #111111;
    transform: translateY(-1px);
}

.forgot-page .fp-secondary {
    display: block;
    width: 100%;
    margin-top: 12px;
    padding: 11px 12px;
    text-align: center;
    border: 1px solid var(--fp-line);
    background: #fff;
    font-size: 12px;
    font-weight: 700;
    text-decoration: none;
    cursor: pointer;
}

.forgot-page .fp-links {
    display: flex;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
    margin-top: 20px;
    color: #666666;
    font-size: 12px;
}

.forgot-page .fp-links a {
    text-decoration: none;
    border-bottom: 1px solid #ddd;
    padding-bottom: 2px;
}

.forgot-page .fp-links a:hover {
    color: var(--fp-red);
}

.forgot-page .fp-steps {
    display: flex;
    gap: 7px;
    margin: 0 0 22px;
}

.forgot-page .fp-step {
    height: 3px;
    flex: 1;
    background: #e5e5e5;
}

.forgot-page .fp-step.active {
    background: var(--fp-red);
}

.forgot-page .fp-note {
    font-size: 11px;
    line-height: 1.65;
    color: #858585;
    margin: 12px 0 0;
}

.forgot-page .fp-success-mark {
    width: 58px;
    height: 58px;
    margin: 4px 0 20px;
    border-radius: 50%;
    display: grid;
    place-items: center;
    background: #f5f5f5;
    color: #111111;
    font-size: 30px;
}

@media (max-width: 820px) {
    .forgot-page {
        padding: 24px 14px 45px;
    }

    .forgot-page .fp-wrap {
        grid-template-columns: 1fr;
        max-width: 520px;
    }

    .forgot-page .fp-story {
        min-height: 230px;
        padding: 28px;
    }

    .forgot-page .fp-stamp {
        width: 74px;
        height: 74px;
        right: 22px;
        top: 67px;
        font-size: 28px;
    }

    .forgot-page .fp-card {
        padding: 25px;
    }
}

@media (prefers-reduced-motion: reduce) {
    .forgot-page * {
        transition: none !important;
    }
}
</style>

<main class="forgot-page">
    <div class="fp-wrap">

        <section class="fp-story" aria-label="Comic Shop">
            <div class="fp-stamp" aria-hidden="true">✦</div>

            <div class="fp-kicker">
                Comic Shop · Account Care
            </div>

            <h1>
                Trở lại với<br>
                thế giới truyện.
            </h1>

            <p>
                Chúng tôi sẽ giúp bạn đặt lại mật khẩu an toàn
                để tiếp tục khám phá những bộ truyện yêu thích.
            </p>
        </section>

        <section class="fp-card" aria-labelledby="forgot-title">

            <div class="fp-brand">Comic Shop</div>

            <?php if (is_array($flash) && isset($flash['message'])): ?>
                <div
                    class="fp-alert <?= comic_shop_forgot_password_escape($flash['type'] ?? 'info') ?>"
                    role="status"
                >
                    <?= comic_shop_forgot_password_escape($flash['message']) ?>
                </div>
            <?php endif; ?>

            <?php if ($step === 'done'): ?>

                <div class="fp-success-mark" aria-hidden="true">
                    ✓
                </div>

                <h2 id="forgot-title">
                    Mật khẩu đã được cập nhật
                </h2>

                <p class="fp-lead">
                    Bạn có thể đăng nhập lại bằng mật khẩu mới
                    và tiếp tục mua sắm tại Comic Shop.
                </p>

                <a class="fp-btn" href="login.php">
                    Đăng nhập ngay
                </a>

                <div class="fp-links">
                    <a href="index.php">← Về trang chủ</a>
                </div>

            <?php elseif ($step === 'code'): ?>

                <h2 id="forgot-title">Đặt lại mật khẩu</h2>

                <p class="fp-lead">
                    Nhập mã OTP gồm 6 chữ số đã gửi đến
                    <strong>
                        <?= comic_shop_forgot_password_escape($emailValue) ?>
                    </strong>
                    và chọn mật khẩu mới. Mã hết hạn sau 10 phút.
                </p>

                <div class="fp-steps" aria-label="Bước 2 trên 2">
                    <span class="fp-step"></span>
                    <span class="fp-step active"></span>
                </div>

                <form
                    method="post"
                    action="forgot-password.php"
                    autocomplete="on"
                >
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= comic_shop_forgot_password_escape($csrfToken) ?>"
                    >

                    <input
                        type="hidden"
                        name="action"
                        value="reset_password"
                    >

                    <label class="fp-field">
                        <span>Mã xác thực OTP</span>
                        <input
                            class="fp-otp"
                            type="text"
                            name="otp_code"
                            inputmode="numeric"
                            pattern="[0-9]{6}"
                            minlength="6"
                            maxlength="6"
                            placeholder="000000"
                            required
                            autocomplete="one-time-code"
                            aria-label="Mã OTP 6 chữ số"
                        >
                    </label>

                    <label class="fp-field">
                        <span>Mật khẩu mới</span>
                        <input
                            type="password"
                            name="new_password"
                            minlength="8"
                            maxlength="72"
                            required
                            autocomplete="new-password"
                            placeholder="Ít nhất 8 ký tự"
                        >
                    </label>

                    <label class="fp-field">
                        <span>Nhập lại mật khẩu mới</span>
                        <input
                            type="password"
                            name="confirm_password"
                            minlength="8"
                            maxlength="72"
                            required
                            autocomplete="new-password"
                            placeholder="Nhập lại mật khẩu"
                        >
                    </label>

                    <button class="fp-btn" type="submit">
                        Xác nhận &amp; cập nhật mật khẩu
                    </button>
                </form>

                <p class="fp-note">
                    Không nhận được email? Kiểm tra thư mục Spam.
                    Mỗi lần yêu cầu gửi lại mã cần cách nhau
                    ít nhất 60 giây.
                </p>

                <form method="post" action="forgot-password.php">
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= comic_shop_forgot_password_escape($csrfToken) ?>"
                    >

                    <input
                        type="hidden"
                        name="action"
                        value="resend_code"
                    >

                    <input
                        type="hidden"
                        name="email"
                        value="<?= comic_shop_forgot_password_escape($emailValue) ?>"
                    >

                    <button class="fp-secondary" type="submit">
                        Gửi lại mã OTP
                    </button>
                </form>

                <form method="post" action="forgot-password.php">
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= comic_shop_forgot_password_escape($csrfToken) ?>"
                    >

                    <input
                        type="hidden"
                        name="action"
                        value="change_email"
                    >

                    <button class="fp-secondary" type="submit">
                        ← Dùng email khác
                    </button>
                </form>

            <?php else: ?>

                <h2 id="forgot-title">Quên mật khẩu?</h2>

                <p class="fp-lead">
                    Nhập email đăng ký tài khoản. Nếu email hợp lệ
                    và tài khoản đang hoạt động, bạn sẽ nhận được
                    mã OTP để đặt lại mật khẩu.
                </p>

                <div class="fp-steps" aria-label="Bước 1 trên 2">
                    <span class="fp-step active"></span>
                    <span class="fp-step"></span>
                </div>

                <form
                    method="post"
                    action="forgot-password.php"
                    autocomplete="on"
                >
                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= comic_shop_forgot_password_escape($csrfToken) ?>"
                    >

                    <input
                        type="hidden"
                        name="action"
                        value="request_code"
                    >

                    <label class="fp-field">
                        <span>Email đăng ký</span>
                        <input
                            type="email"
                            name="email"
                            value="<?= comic_shop_forgot_password_escape($emailValue) ?>"
                            maxlength="150"
                            required
                            autocomplete="email"
                            placeholder="ban@email.com"
                        >
                    </label>

                    <button class="fp-btn" type="submit">
                        Gửi mã xác thực
                    </button>
                </form>

                <p class="fp-note">
                    Vì lý do bảo mật, trang không nên tiết lộ
                    email có tồn tại trong hệ thống hay không.
                </p>

                <div class="fp-links">
                    <a href="login.php">← Quay lại đăng nhập</a>
                    <a href="index.php">Trang chủ</a>
                </div>

            <?php endif; ?>

        </section>
    </div>
</main>

<?php
if (is_file($footerFile)) {
    require_once $footerFile;
} else {
    echo '</body></html>';
}
?>
